(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``;function n(){return!!document.querySelector(`[name="graderinfo[text]"]`)}function r(){return document.querySelectorAll(`input[id$="-mark"]`).length!==0&&!!(document.querySelector(`.qtype_essay_response`)||document.querySelector(`textarea[id$="-comment_id"]`)||document.querySelector(`textarea[name$="-comment"]`)||document.querySelector(`.ablock`))}let i=n()?`bearbeiten`:r()?`bewertung`:null;if(!i)return;let a=/^\s*[\[(]?\s*moodle[-\s]?ai[-\s]?(coach|grader)\s*[\])]?\s*[:.–-]?\s*/i,o=/rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%/i,s=/punkteschritte\s*[:\-]?\s*([\d.,]+)/i;function c(e,t){return`<p>[Rechtschreibung: `+C(e)+`%]</p><p>[Punkteschritte: `+C(t)+`]</p>`}function l(e){let t=D(e).split(`
`).map(e=>e.trim()),n=[];for(let e of t)if(e&&(f.test(e)||(n.push(e),n.length>=6)))break;return n.join(`
`)}function u(e){let t=l(e).match(o);return t?parseFloat(t[1].replace(`,`,`.`)):null}function d(e){let t=l(e).match(s);return t?w(t[1]):null}let f=/^\s*[①-⑳⓪]?\s*Aufgabe\s+(\d+)\b/i,p={I:{kopf:`#eaf4ea`,feld:`#f5faf5`},II:{kopf:`#fdf2e0`,feld:`#fffaf0`},III:{kopf:`#fbe9e9`,feld:`#fdf3f3`},neutral:{kopf:`#eceff3`,feld:`#f8f9fb`}},m=[[1,0],[2,1/3],[3.5,2/3],[1/0,1]],h=[0,1/3,1/2,2/3,5/6,1],g={fach:``,jahrgang:``,kursniveau:`G`,punkteschritte:`0.5`,rechtschreibung:`10`,feedbacklaenge:`Ausführlich`,afbFarben:!1,vorlagePunkte:!0,vorlageAfb:!0,kiHinweis:!0,entferneQuellen:!0,promptHorizont:null,promptKorrektur:null,horizontLokal:``},_=JSON.parse(JSON.stringify(g)),v=!1,y=(e,t)=>(t||document).querySelector(e),b=(e,t)=>[...(t||document).querySelectorAll(e)];function x(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r}function S(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function C(e){return String(e).replace(`.`,`,`)}function w(e){return parseFloat(String(e??``).replace(`,`,`.`))}function ee(e,t,n){let r=n||parseFloat(_.punkteschritte)||.5,i=Math.round(e/r)*r;return i=Math.max(0,Math.min(i,t)),Math.round(i*100)/100}function te(e){return(String(e||``).trim().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length}function T(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function ne(e){let t=String(e||``),n=T(t);t=a.test(n)?t.replace(n,n.replace(a,``)).replace(/^\s*\n/,``):t.replace(/^\s*[\[(]?\s*moodle[-\s]?ai[-\s]?(coach|grader)\s*[\])]?\s*[:.–-]?\s*$/im,``).replace(/^\s*\n+/,``);for(let e=0;e<2;e++){let e=T(t);if(e&&(o.test(e)||s.test(e)))t=t.replace(e,``).replace(/^\s*\n/,``);else break}return t}function re(e){return _.entferneQuellen?String(e||``).replace(/\[\w+:\d+\]/g,``).replace(/ {2,}/g,` `).trim():String(e||``)}function E(){let e=parseInt(_.jahrgang,10);return!isNaN(e)&&e>=11?`Sie haben`:`Du hast`}function D(e){let t=String(e||``).replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi,`</$1>
`);return(new DOMParser().parseFromString(t,`text/html`).body.textContent||``).replace(/[ \t]+/g,` `).replace(/\n{3,}/g,`

`).trim()}function ie(e){return new DOMParser().parseFromString(String(e||``),`text/html`).body}function ae(e,t){e.replaceChildren(...ie(t).childNodes)}let oe=/^(DIV|P|H[1-6]|UL|OL|LI|TABLE|TBODY|TR|TD|TH|BLOCKQUOTE|SECTION|ARTICLE|PRE)$/;function se(e){return String(e.textContent||``).replace(/\s+/g,` `).trim()}async function O(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function ce(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&e.type!==`button`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}async function le(e,t,n){let r=[...e.querySelectorAll(`input[type=submit],button[type=submit]`)].filter(e=>e.name&&e.name!==`cancel`),i=r.find(e=>e.name===`submitbutton`)||r[0];i&&t.set(i.name,i.value);let a=new URL(e.getAttribute(`action`)||n,n).href,o=await fetch(a,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:t.toString()});if(!o.ok)throw Error(`HTTP `+o.status+` beim Speichern`);return o}async function ue(e,t,n){try{let r=new URL(e.url||n),i=r.searchParams.get(`lastchanged`),a=new URL(n).searchParams.get(`cmid`)||r.searchParams.get(`cmid`);if(i)return location.origin+`/question/bank/editquestion/question.php?id=`+i+(a?`&cmid=`+a:``);let o=[...new DOMParser().parseFromString(await e.clone().text(),`text/html`).querySelectorAll(`[data-itemtype="questionname"]`)].find(e=>(e.getAttribute(`data-value`)||``)===t);if(o&&o.getAttribute(`data-itemid`))return location.origin+`/question/bank/editquestion/question.php?id=`+o.getAttribute(`data-itemid`)+(a?`&cmid=`+a:``)}catch{}return null}function de(e,t){let n=e=>D(e).replace(/\s+/g,` `).trim(),r=n(e),i=n(t);if(!r||!i)return!1;if(r===i)return!0;if(Math.abs(r.length-i.length)>Math.max(40,i.length*.2))return!1;let a=i.slice(Math.floor(i.length/2),Math.floor(i.length/2)+40);return r.includes(i.slice(0,40))&&(a.length<20||r.includes(a))}async function fe(e,t){let n=location.href,r=await O(n),i=[...r.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!i)throw Error(r.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let a=ce(i),o=[];for(let n of Object.keys(e)){if(!a.has(n))throw Error(`Feld „`+n+`" nicht im Formular`);let r=a.get(n)||``;o.push({feld:n,belegt:D(r).length>0}),t||a.set(n,e[n])}if(t)return{bericht:o};let s=(i.querySelector(`[name="name"]`)||{}).value||``,c=await ue(await le(i,a,n),s,n),l=[...(await O(c||n)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),u=[];for(let t of Object.keys(e)){let n=l&&l.querySelector(`[name="`+CSS.escape(t)+`"]`);u.push({feld:t,ok:!!n&&de(n.value,e[t])})}return{bericht:o,ergebnis:u,neueUrl:c,warnung:c?null:`Die neue Fragenversion war nicht auffindbar — die Gegenprobe lief gegen den alten Stand und kann falsch sein.`}}function pe(){if(i===`bearbeiten`){let e=y(`[name="questiontext[text]"]`);return e?D(e.value):``}let e=y(`.que .qtext`)||y(`.qtext`);return e?e.innerText.trim():``}function k(){if(i===`bearbeiten`){let e=y(`[name="defaultmark"]`);return e&&w(e.value)||0}let e=y(`input[name$="-maxmark"]`);if(e)return w(e.value)||0;let t=y(`.que .grade`),n=t&&t.innerText.match(/([\d.,]+)\s*$/);return n?w(n[1]):0}function A(){if(i===`bearbeiten`){let e=y(`[name="graderinfo[text]"]`);return e?e.value:``}let e=y(`.que .graderinfo`)||y(`.graderinfo`);return e?e.innerHTML:``}function me(){let e=D(A());if(!e)return{horizont:!1,wer:null};let t=T(e).match(a);return{horizont:!0,wer:t?t[1].toLowerCase():null}}function he(e){let t=ie(ne(String(e||``))),n=[],r=null;if([...t.children].forEach(e=>{let t=se(e),i=t.match(f);if(i&&/^(H[1-6]|P|DIV)$/.test(e.tagName)&&t.length<200){r={nr:parseInt(i[1],10),kopf:t,html:``,text:``},n.push(r);return}r&&(r.html+=e.outerHTML,r.text+=D(e.outerHTML)+`
`)}),!n.length){let t=ne(D(e));return t?[{nr:1,kopf:`Aufgabe 1`,html:String(e||``),text:t,punkte:null,afb:null,ganzeArbeit:!0}]:[]}return n.forEach(e=>{e.text=e.text.trim();let t=e.kopf.match(/\(\s*([\d.,]+)\s*(?:P\.?|Punkte?)\s*\)/i);e.punkte=t?w(t[1]):null;let n=e.kopf.match(/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i);e.afb=n?n[1].replace(/\s/g,``):null}),n}function ge(e){let t=e;for(let e=0;e<12&&t;e++)if(t=t.parentElement,t&&t.classList&&(t.classList.contains(`que`)||t.classList.contains(`content`)))return t;return null}function j(){return b(`input[id$="-mark"]`).map((e,t)=>{let n=ge(e),r=n&&n.querySelector(`.qtype_essay_response`),i=n&&n.querySelector(`textarea[name$="-comment"]`),a=n&&n.querySelector(`input[name$="-maxmark"]`),o=r&&r.innerHTML||``,s=r?r.innerText.trim():``;return{nr:t+1,markfeld:e.name||``,kommentarfeld:i?i.name:``,ist:w(e.value)||0,max:a?w(a.value)||0:k(),rohHtml:o,text:s,anker:n&&n.id?`#`+n.id:``}}).filter(e=>e.markfeld)}function _e(e,t){let n=ie(e),r=[],i=null,a=e=>{let t=[...e.children].filter(e=>oe.test(e.tagName));if(!t.length){let t=se(e);if(!t)return;let n=t.match(f);n&&t.length<160?(i={nr:parseInt(n[1],10),text:``},r.push(i)):i&&(i.text+=t+`
`);return}t.forEach(a)};return a(n),r.length>=1?(r.forEach(e=>{e.text=e.text.trim()}),{gegliedert:!0,aufgaben:r,leer:r.every(e=>!e.text)}):{gegliedert:!1,aufgaben:[{nr:1,text:String(t||``).trim()}]}}function ve(e,t){if(t<40){let t=Math.min(Math.round(e),h.length-1);return h[t]}let n=t>0?e*100/t:0;for(let[e,t]of m)if(n<=e)return t;return 1}function ye(e){return(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0)}function be(e,t,n,r,i){let a=e.max||k()||0,o=(n||[]).filter(e=>e.punkte!=null).reduce((e,t)=>e+t.punkte,0),s=n&&n.length?n.map(e=>e.nr):(t.aufgaben||[]).map(e=>Number(e.nr)),c=Math.max(1,s.length),l=[],u=s.map(e=>{let r=(t.aufgaben||[]).find(t=>Number(t.nr)===e)||(l.push(e),{nr:e,prozent:0}),i=(n||[]).find(t=>t.nr===e),s;s=i&&i.punkte!=null&&o>0?a>0?i.punkte*a/o:i.punkte:a/c;let u=Math.max(0,Math.min(100,Number(r.prozent)||0));return{nr:e,max:s,prozent:u,roh:s*u/100}}),d=u.reduce((e,t)=>e+t.roh,0),f=a*(r??(parseFloat(_.rechtschreibung)||0))/100,p=ye(t.fehler),m=te(e.text),h=ve(p,m),g=Math.min(f*h,d);u.forEach(e=>{let t=d>0?e.roh/d:0;e.abzug=g*t,e.netto=Math.max(0,e.roh-e.abzug)});let v=i||parseFloat(_.punkteschritte)||.5,y=ee(u.reduce((e,t)=>e+t.netto,0),a,v);u.forEach(e=>{e.punkte=Math.max(0,Math.floor(e.netto/v+1e-9)*v),e.rest=e.netto-e.punkte});let b=Math.round((y-u.reduce((e,t)=>e+t.punkte,0))/v),x=u.slice().sort((e,t)=>t.rest-e.rest);for(let e=0;b>0&&e<x.length*4;e++){let t=x[e%x.length];t.punkte+v<=t.max+1e-9&&(t.punkte+=v,b--)}for(let e=0;b<0&&e<x.length*4;e++){let t=x[x.length-1-e%x.length];t.punkte-v>=-1e-9&&(t.punkte-=v,b++)}return u.forEach(e=>{e.punkte=Math.round(e.punkte*100)/100}),{teil:u,wortzahl:m,fehlerGewichtet:p,fehlerDichte:m>0?Math.round(p*1e3/m)/10:0,hoechstabzug:Math.round(f*100)/100,abzug:Math.round(g*100)/100,gesamt:y,max:a,fehlendeAufgaben:l}}function xe(e){if(!_.afbFarben)return p.neutral;let t=String(e||``).toUpperCase().split(/[-–]/).pop().trim();return p[t]||p.neutral}function Se(e){let t=S([`Aufgabe `+e.nr][0]);return _.vorlageAfb&&e.afb&&(t+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+S(e.afb)+`</span>`),e.schlagwort&&(t+=` · `+S(e.schlagwort)),_.vorlagePunkte&&e.punkte!=null&&(t+=` <span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+S(C(e.punkte))+(e.punkte===1?` Punkt`:` Punkte`)+`)</span>`),t}function Ce(e){return(e||[]).map(e=>{let t=xe(e.afb);return`<div style="border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:10px 0;"><div style="background:`+t.kopf+`;padding:9px 14px;font-size:16px;font-weight:bold;color:#33404d;border-bottom:1.5px solid #9e9e9e;">`+Se(e)+`</div><div style="background:`+t.feld+`;padding:10px 14px;font-size:15px;line-height:1.45;"><p style="margin:0;">&nbsp;</p><p style="margin:0;">&nbsp;</p></div></div>`}).join(`
`)}function we(e){return((e||[]).some(e=>a.test(T(D(e.horizont))))?``:`<p>[moodle-ai-grader]</p>`+c(_.rechtschreibung,_.punkteschritte))+(e||[]).map(e=>{let t=String(e.horizont||``).trim();return/<[a-z][\s\S]*>/i.test(t)||(t=`<p>`+S(t).replace(/\n{2,}/g,`</p><p>`).replace(/\n/g,`<br>`)+`</p>`),`<h4>`+Se(e)+`</h4>`+t}).join(`
`)}let Te={G:`G — gymnasial`,M:`M — mittel`,E:`E — einfach`};function Ee(){return[`Fach: `+(_.fach||`[nicht angegeben]`),`Jahrgang: `+(_.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(Te[_.kursniveau]||_.kursniveau),`Feedbacklänge: `+_.feedbacklaenge,`Anrede im Feedback: `+E()+` …`].join(`
`)}function M(){return`Du bist erfahrene Lehrkraft und erstellst den Erwartungshorizont für eine Klausur.

RAHMENDATEN
[MAG_RAHMENDATEN]

AUFGABENSTELLUNG (aus Moodle übernommen, Gesamtpunktzahl: [MAG_GESAMTPUNKTE])
[MAG_AUFGABEN]

WAS DU TUST
1. Zerlege die Aufgabenstellung in ihre Teilaufgaben. Übernimm die Nummerierung der
   Aufgabenstellung. Steht dort eine Punktzahl je Aufgabe, übernimm sie unverändert;
   fehlt sie, verteile die Gesamtpunktzahl begründet und weise darauf hin.
2. Bestimme je Aufgabe den Operator und die Anforderungsstufe AFB (I, II, III oder eine
   Spanne wie II-III).
3. Schreibe je Aufgabe einen Erwartungshorizont in dieser Reihenfolge:
   Kernaussage · Muss enthalten · Auch richtig · Inhalt in Stufen · Reicht nicht ·
   Häufiger Fehler.
   - Nur die Stufen 100 / 75 / 50 / 25 / 0 Prozent. Kein 90.
   - KEINE Sprachregeln, KEINEN Rechtschreibabzug, KEINE Punktzahlen in den Horizont —
     das steht global in der Erweiterung und würde sich sonst widersprechen.

   - „AUCH RICHTIG" ist der wichtigste Abschnitt und der am häufigsten misslungene.
     Gemeint sind NICHT ausformulierte Musterantworten, sondern die rauen, verkürzten
     Formulierungen, mit denen Lernende dieser Jahrgangsstufe dasselbe sagen — auch
     umgangssprachlich, auch ohne Fachbegriff.
     Schlecht: „Von links nach rechts werden die Atome kleiner, weil die Kernladung
     zunimmt und die Elektronen stärker angezogen werden." So schreibt eine Lehrkraft.
     Wer so antwortet, liegt ohnehin bei 100 % — der Eintrag hilft beim Bewerten nicht.
     Gut: „nach rechts wird es kleiner" · „der Kern zieht doller" · „es kommt eine
     Schale dazu, deshalb wird es dicker" · „mehr Protonen, gleiche Schale".
     Nenne mindestens vier solcher Fassungen je Aufgabe und schreibe dazu, welche
     abweichenden Wörter dasselbe meinen (etwa Ring, Bahn oder Ebene statt Schale).

   - JEDE STUFE HÄNGT AN ZÄHLBAREN BEDINGUNGEN, nie an Wörtern wie „überwiegend",
     „im Wesentlichen", „etwas unvollständig" oder „deutliche Lücken". Solche
     Formulierungen führen dazu, dass zwei Modelle dieselbe Antwort verschieden
     einstufen. Zähle stattdessen, was da sein muss: Trends, Aspekte, Teilaussagen.
     Beispiel: 100 — beide Trends beschrieben UND beide erklärt · 75 — beide
     beschrieben, einer erklärt · 50 — beide beschrieben, keiner erklärt ODER einer
     beschrieben und erklärt.
     Prüfe zum Schluss, dass jede denkbare Antwort genau EINER Stufe zuzuordnen ist:
     keine Lücke, keine Überschneidung.

   - „REICHT NICHT" enthält nur Antworten, die sachlich RICHTIG, aber zu wenig sind.
     Sachlich falsche Aussagen gehören nicht dorthin, sondern zu Stufe 0 und unter
     „Häufiger Fehler" — sonst liest ein Bewertungsmodell sie als fast richtig.
4. Gib je Aufgabe ein Schlagwort von zwei bis vier Wörtern an, das die Aufgabe benennt.

ARBEITSWEISE
Zeige mir zuerst je Aufgabe eine lesbare Übersicht (Nummer, Operator, AFB, Punkte,
Schlagwort, Erwartungshorizont) und frage nach, ob sie passt. Ändere, bis ich zustimme.
Stelle immer nur EINE Frage auf einmal.

ERST WENN ICH BESTÄTIGE, gib genau EINEN Codeblock aus — nichts davor, nichts danach:

\`\`\`json
{ "aufgaben": [
  { "nr": 1,
    "schlagwort": "kurzes Stichwort",
    "afb": "II-III",
    "punkte": 4,
    "operator": "Beschreibe / Erkläre",
    "horizont": "<p><strong>Kernaussage:</strong> …</p><p><strong>Muss enthalten:</strong> …</p>" }
] }
\`\`\`

Das Feld "horizont" ist HTML (erlaubt: p, br, ul, li, strong, em). Keine Überschrift für
die Aufgabe selbst — die setzt die Erweiterung. Keine Punktzahlen im Fließtext.`}function De(){return((_.promptHorizont||``).trim()||M()).replace(`[MAG_RAHMENDATEN]`,Ee()).replace(`[MAG_GESAMTPUNKTE]`,C(k()||`?`)).replace(`[MAG_AUFGABEN]`,pe()||`[keine Aufgabenstellung gefunden]`)}let Oe={Kurz:`ein bis zwei Sätze je Aufgabe`,Mittel:`drei bis vier Sätze je Aufgabe`,Ausführlich:`ein Absatz je Aufgabe mit konkretem Bezug auf die Antwort`,Umfangreich:`ein ausführlicher Absatz je Aufgabe, dazu ein eigener Abschnitt zur Operatorerfüllung`};function N(){return`Du bewertest Klausurantworten nach einem vorgegebenen Erwartungshorizont.

RAHMENDATEN
[MAG_RAHMENDATEN]

ERWARTUNGSHORIZONT (gilt für alle Abgaben)
[MAG_HORIZONT]

WICHTIG — WAS DU NICHT TUST
Du vergibst KEINE Punkte und rechnest NICHT. Die Erweiterung rechnet Punkte, Rundung,
Rechtschreibabzug und Gesamtsumme selbst. Du lieferst ausschließlich Prozentwerte,
gezählte Fehler und Begründungstexte OHNE Zahlenangaben. Schreibe in keiner Begründung
„x von y Punkten" — die Zahlen setzt die Erweiterung ein.

JE AUFGABE
Vergib einen Erfüllungsgrad in Prozent, nur diese Stufen: 100, 75, 50, 25, 0.
Verankere jede Einstufung an einer Formulierung des Erwartungshorizonts.
Prüfe dabei den Operator: Wer „erläutere" liest und nur beschreibt, erfüllt die Aufgabe
nicht vollständig, auch wenn der Inhalt stimmt.

JE ABGABE
Zähle die sprachlichen Fehler und gib sie EINZELN an — Wort, Korrektur, Kategorie.
Kategorien: satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache. Ein Satz ohne Prädikat, ein abgebrochener Satz oder ein
Satzbau, den man zweimal lesen muss, zählt als "schwer": true. Denselben Fehler im selben
Wort nur einmal zählen. Zähle vollständig — die Erweiterung leitet daraus den Abzug ab.

FEEDBACKTEXTE
Länge: [MAG_FBLAENGE]. Anrede: [MAG_ANREDE] … Sachlich, konkret, zugewandt.
Bei Sprachfehlern den fehlerhaften Satz wörtlich zitieren und richtig danebenschreiben,
nicht „achte auf die Satzstellung". Höchstens zwei bis drei Vorschläge.
Jede Aufgabe bekommt eine Begründung — auch eine vollständig richtige.

ABGABEN
[MAG_ABGABEN]

AUSGABE — genau EIN Codeblock, nichts davor, nichts danach:

\`\`\`json
{ "bewertungen": [
  { "nr": 1,
    "staerken": "was gut gelungen ist",
    "aufgaben": [ { "nr": 1, "prozent": 75, "begruendung": "…", "operator": "erfüllt" } ],
    "fehler": [ { "wort": "Atomradiuse", "korrektur": "Atomradien",
                  "kategorie": "rechtschreibung", "schwer": false } ],
    "sprachfeedback": "…",
    "zusammenfassung": "…" }
] }
\`\`\`

"nr" ist die Nummer der Abgabe aus dem Datenblock, nicht die des Schülers.
Liefere für JEDE Abgabe des Blocks einen Eintrag, auch für leere Abgaben
(dort alle Prozentwerte 0 und ein Hinweis in der Zusammenfassung).`}function ke(e,t,n,r){let i=he(t),a=i.length?i.map(e=>e.kopf+`
`+e.text).join(`

`):D(t),o=e.map(e=>{let t=_e(e.rohHtml,e.text),n=`ABGABE `+e.nr+(t.gegliedert?``:`  (ohne Gliederung)`),r=t.gegliedert?t.aufgaben.map(e=>`  Aufgabe `+e.nr+`:
  `+(e.text||`(leer)`)).join(`
`):`  `+(e.text||`(leer)`);return n+`
`+r}).join(`

`),s=((_.promptKorrektur||``).trim()||N()).replace(`[MAG_RAHMENDATEN]`,Ee()).replace(`[MAG_HORIZONT]`,a||`[kein Horizont hinterlegt]`).replace(`[MAG_FBLAENGE]`,Oe[_.feedbacklaenge]||Oe.Ausführlich).replace(`[MAG_ANREDE]`,E()).replace(`[MAG_ABGABEN]`,o);return r>1&&(s=`TEIL `+n+` VON `+r+` — bewerte NUR die unten stehenden Abgaben und gib nur für sie JSON aus. Warte auf den nächsten Teil.

`+s),s}function Ae(e,t,n){let r=[];if(e.staerken&&r.push(e.staerken.trim()),(e.aufgaben||[]).forEach(e=>{let i=t.teil.find(t=>t.nr===e.nr),a=(n||[]).find(t=>t.nr===e.nr),o=`Aufgabe `+e.nr+(a&&a.kopf.includes(`·`)?` – `+a.kopf.split(`·`).slice(1).join(`·`).replace(/\(.*?\)/,``).trim():``)+`: `+(i?C(i.punkte):`?`)+` von `+(i?C(Math.round(i.max*100)/100):`?`)+` P.`;i&&i.abzug>.004&&(o+=` (davon −`+C(Math.round(i.abzug*100)/100)+` P. Rechtschreibung)`),r.push(o+`
`+(e.begruendung||``).trim())}),_.feedbacklaenge===`Umfangreich`){let t=(e.aufgaben||[]).filter(e=>e.operator);t.length&&r.push(`Operatorerfüllung:
`+t.map(e=>`Aufgabe `+e.nr+`: `+e.operator).join(`
`))}let i=e.fehler||[],a=`Rechtschreibung und Sprache: `;return t.abzug>.004?a+=`Abzug `+C(t.abzug)+` von höchstens `+C(t.hoechstabzug)+` P. (`+C(t.fehlerDichte)+` Fehler je 100 Wörter).`:i.length?a+=`kein Punktabzug, aber ein paar Stellen zum Nachschauen.`:a+=`keine Auffälligkeiten.`,i.length&&(a+=`
`+i.slice(0,12).map(e=>`• `+(e.wort||``)+` → `+(e.korrektur||``)).join(`
`),i.length>12&&(a+=`
• … und `+(i.length-12)+` weitere`)),e.sprachfeedback&&(a+=`
`+e.sprachfeedback.trim()),r.push(a),e.zusammenfassung&&r.push(e.zusammenfassung.trim()),r.push(`Gesamt: `+C(t.gesamt)+` von `+C(t.max)+` Punkten.`),r.filter(Boolean).map(re).join(`

`)}function je(e){let t=e.split(/\n{2,}/).map(e=>`<p>`+S(e).replace(/\n/g,`<br>`)+`</p>`).join(``);return _.kiHinweis&&(t+=`<p><em><small>Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.</small></em></p>`),t}function Me(e){let t=[],n=0,r=-1,i=!1,a=!1;for(let o=0;o<e.length;o++){let s=e[o];if(i){a?a=!1:s===`\\`?a=!0:s===`"`&&(i=!1);continue}if(s===`"`){n>0&&(i=!0);continue}s===`{`?(n===0&&(r=o),n++):s===`}`&&n>0&&(n--,n===0&&r>=0&&(t.push(e.slice(r,o+1)),r=-1))}return t}function Ne(e,t){let n=[],r=[],i=/```(?:json)?\s*([\s\S]*?)```/g,a;for(;(a=i.exec(e))!==null;)r.push(a[1]);if(r.push(e.replace(/```(?:json)?\s*[\s\S]*?```/g,``)),r.forEach(e=>{let r=e.trim();if(r){try{let e=JSON.parse(r),i=Array.isArray(e)?e:e[t]||(e.nr==null?null:[e]);i&&n.push(...i);return}catch{}Me(r).forEach(e=>{try{let r=JSON.parse(e),i=Array.isArray(r)?r:r[t]||(r.nr==null?null:[r]);i&&n.push(...i)}catch{}})}}),!n.length)throw Error(`Kein verwertbares JSON gefunden.`);return n}function Pe(e,t){let n=new Set,r=[];return e.forEach(e=>{let t=Number(e.nr);n.has(t)&&r.push(t),n.add(t)}),{fehlend:t.filter(e=>!n.has(e)),doppelt:r}}async function Fe(e){let t=await O(location.href),n=t.querySelector(`form#manualgradingform`)||[...t.forms].find(e=>e.querySelector(`input[name$="-mark"]`));if(!n&&!e)return await new Promise(e=>setTimeout(e,900)),Fe(!0);if(!n)throw Error(`Bewertungsformular nicht gefunden`);return{dok:t,form:n}}async function Ie(e,t,n){let{form:r}=await Fe(!1),i=ce(r),a=[],o=0;if(e.forEach(e=>{let r=i.has(e.markfeld),s=!e.kommentarfeld||i.has(e.kommentarfeld);if(!r||!s){o++,n(`✗ Abgabe `+e.nr+`: `+(r?`Kommentarfeld`:`Punktefeld`)+` nicht auf der Seite`);return}t||(i.set(e.markfeld,C(e.punkte)),e.kommentarfeld&&i.set(e.kommentarfeld,e.feedbackHtml)),a.push(e)}),t)return n(a.length+` von `+e.length+` Abgaben vollständig vorhanden.`),{ok:a.length,fehler:o,trocken:!0};if(!a.length)return{ok:0,fehler:e.length};await le(r,i,location.href);let{form:s}=await Fe(!1),c=0,l=o;return a.forEach(e=>{let t=s.querySelector(`input[name="`+CSS.escape(e.markfeld)+`"]`),r=t?w(t.value):null;r!==null&&Math.abs(r-e.punkte)<.005?(c++,n(`✓ Abgabe `+e.nr+` — `+C(e.punkte)+` P. eingetragen`)):(l++,n(`✗ Abgabe `+e.nr+` — steht auf `+(r==null?`keinem Wert`:C(r))+` statt `+C(e.punkte)))}),{ok:c,fehler:l}}let Le=i===`bearbeiten`?[[`horizont`,`1 · Horizont`],[`vorlage`,`2 · Vorlage`],[`einst`,`⚙`]]:[[`korrektur`,`1 · Korrektur`],[`horizont`,`2 · Horizont`],[`einst`,`⚙`]],P=x(`div`,`mag-panel`);P.innerHTML=`
    <div class="mag-kopf">
      <img class="mag-kopfbild" alt="">
      <div class="mag-titelblock">
        <span class="mag-titel">Moodle AI Grader <span class="mag-version"></span></span>
        <span class="mag-untertitel">Klausuren bewerten mit Feedback</span>
      </div>
      <button class="mag-ikon" data-tu="zu" title="Schließen">✕</button>
    </div>
    <div class="mag-banner" hidden></div>
    <div class="mag-reiter">

    </div>

    <div class="mag-inhalt" data-panel="horizont">
      <div class="mag-status" data-rolle="hstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt</div>
        <div data-rolle="hrahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <label>1 · Prompt für die KI</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-primary" data-tu="hprompt">📋 Prompt kopieren</button>
        <button class="mag-btn mag-btn-rand" data-tu="hedit" title="Prompt anpassen">✏️</button>
      </div>
      <label>2 · Antwort der KI einfügen</label>
      <textarea data-rolle="hjson" rows="5" placeholder='{ "aufgaben": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="hpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-liste" data-rolle="hliste"></div>
      <div class="mag-protokoll" data-rolle="hlog" hidden></div>
      <div class="mag-reihe" data-rolle="hknoepfe" hidden></div>
      <details class="mag-details">
        <summary>Kein Bearbeitungsrecht? Horizont hier behalten</summary>
        <p class="mag-hinweis">Wer Fragen nicht bearbeiten darf, klebt den fertigen Horizont
        hierher. Er bleibt dann in der Erweiterung statt in der Frage.</p>
        <textarea data-rolle="hlokal" rows="4" placeholder="Erwartungshorizont …"></textarea>
        <button class="mag-btn mag-btn-rand" data-tu="hlokalsichern">Hier speichern</button>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="vorlage" hidden>
      <div class="mag-status" data-rolle="vstatus"></div>
      <p class="mag-hinweis">Die Antwortvorlage wird den Lernenden beim Öffnen der Frage in
      das Eingabefeld geladen. Sie entsteht aus demselben Durchgang wie der Horizont.</p>
      <label>Aussehen</label>
      <label class="mag-haken"><input type="checkbox" data-opt="afbFarben"> Farben nach AFB statt neutral</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlagePunkte"> Punkte in der Kopfzeile</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlageAfb"> AFB in der Kopfzeile</label>
      <label>So sieht das Eingabefeld für die Lernenden aus</label>
      <div class="mag-vorschau" data-rolle="vvorschau"></div>
      <details class="mag-details">
        <summary>Und das steht dann im Erwartungshorizont der Frage</summary>
        <div class="mag-vorschau" data-rolle="vhorizont"></div>
      </details>
      <div class="mag-protokoll" data-rolle="vlog" hidden></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="beides">Beides eintragen</button>
      </div>
      <p class="mag-hinweis">Erwartungshorizont und Antwortvorlage gehen in <strong>einem</strong>
      Speichervorgang in die Frage. Getrennt einzutragen wäre riskant: Nach dem ersten
      Speichern zeigt diese Seite eine veraltete Fassung, und der zweite Schreibvorgang
      würde den ersten wieder überschreiben.</p>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-klein mag-btn-grau" data-tu="kopierh">📋 nur Horizont</button>
        <button class="mag-btn mag-btn-klein mag-btn-grau" data-tu="kopierv">📋 nur Antwortvorlage</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="korrektur" hidden>
      <div class="mag-status" data-rolle="kstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt und in die Rechnung</div>
        <div data-rolle="krahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <label>Abgaben je Durchgang</label>
      <select data-rolle="kgroesse"></select>
      <div class="mag-hinweis" data-rolle="kgroessehinweis"></div>
      <label>1 · Prompt für die KI</label>
      <div class="mag-reihe" data-rolle="kknoepfe"></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kedit">✏️ Prompt anpassen</button>
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="krohdaten">📋 Rohdaten</button>
      </div>
      <label>2 · Antworten der KI einfügen</label>
      <textarea data-rolle="kjson" rows="5" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="kpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-hinweis" data-rolle="rsabgleich" hidden></div>
      <div class="mag-liste" data-rolle="kliste"></div>
      <div class="mag-protokoll" data-rolle="klog" hidden></div>
      <div class="mag-reihe" data-rolle="keintragen" hidden>
        <button class="mag-btn mag-btn-ok" data-tu="kschreiben">Alle eintragen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="einst" hidden>
      <div class="mag-status" data-rolle="estatus"></div>
      <p class="mag-hinweis">Diese Angaben stehen später als Rahmendaten im Prompt und
      steuern, wie die Erweiterung rechnet. Bitte einmal durchsehen, bevor du den Prompt
      kopierst — nachträglich lässt sich ein Horizont nur neu erzeugen.</p>
      <label>Fach</label><input type="text" data-opt="fach" placeholder="z. B. Chemie">
      <label>Jahrgang</label><input type="text" data-opt="jahrgang" placeholder="z. B. 10">
      <div class="mag-hinweis" data-rolle="anredehinweis"></div>
      <label>Kursniveau</label>
      <select data-opt="kursniveau">
        <option value="G">G — gymnasial</option>
        <option value="M">M — mittel</option>
        <option value="E">E — einfach</option>
      </select>
      <label>Punkteschritte</label>
      <select data-opt="punkteschritte">
        <option value="0.25">0,25</option><option value="0.5">0,5 (Standard)</option>
        <option value="1">1,0 — nur ganze Punkte</option>
      </select>
      <label>Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl</label>
      <select data-opt="rechtschreibung">
        <option value="0">0 % — kein Abzug</option><option value="5">5 %</option>
        <option value="10">10 % (Standard Mittelstufe)</option><option value="15">15 %</option>
        <option value="20">20 %</option><option value="25">25 % (Oberstufe, Klausuren)</option>
        <option value="30">30 %</option>
      </select>
      <div class="mag-hinweis" data-rolle="rshinweis"></div>
      <label>Feedbacklänge</label>
      <select data-opt="feedbacklaenge">
        <option value="Kurz">Kurz</option><option value="Mittel">Mittel</option>
        <option value="Ausführlich">Ausführlich (Standard)</option>
        <option value="Umfangreich">Umfangreich — mit Operatorerfüllung</option>
      </select>
      <label class="mag-haken"><input type="checkbox" data-opt="kiHinweis"> KI-Transparenzhinweis unter das Feedback</label>
      <label class="mag-haken"><input type="checkbox" data-opt="entferneQuellen"> Quellenangaben entfernen</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="esichern">Speichern und weiter</button>
        <button class="mag-btn mag-btn-grau" data-tu="eabbruch">Verwerfen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="prompt" hidden>
      <label data-rolle="ptitel">Prompt bearbeiten</label>
      <textarea data-rolle="ptext" rows="16"></textarea>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="psichern">Speichern</button>
        <button class="mag-btn mag-btn-rand" data-tu="pzurueck">↺ Original</button>
        <button class="mag-btn mag-btn-grau" data-tu="pabbruch">Abbrechen</button>
      </div>
    </div>`,P.querySelector(`.mag-version`).textContent=e;let Re=P.querySelector(`.mag-reiter`);Le.forEach((e,t)=>{let n=document.createElement(`button`);n.className=`mag-tab`+(t===0?` aktiv`:``),n.dataset.tab=e[0],n.textContent=e[1],Re.appendChild(n)});function ze(e,t,n){let r=document.createElement(`button`);return r.className=t,r.dataset.tu=n,r.textContent=e,r}let Be=P.querySelector(`[data-rolle="hknoepfe"]`);i===`bearbeiten`?Be.appendChild(ze(`Weiter zur Antwortvorlage →`,`mag-btn mag-btn-ok`,`weiter`)):Be.appendChild(ze(`In die Frage eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));let F=x(`button`,`mag-knopf`);F.title=`Moodle AI Grader`;let I=document.createElement(`img`);I.className=`mag-knopf-bild`,I.alt=`Moodle AI Grader`;try{I.src=t.runtime.getURL(`icon/128.png`)}catch{F.textContent=`AI`}I.src&&F.appendChild(I);let L=e=>P.querySelector(`[data-rolle="`+e+`"]`),Ve=e=>P.querySelector(`[data-panel="`+e+`"]`),R=null,z=null,B=Le[0][0];function He(){if(i===`bearbeiten`)return location.href;let e=new URLSearchParams(location.search),t=e.get(`qid`),n=e.get(`id`)||e.get(`cmid`);return t?location.origin+`/question/bank/editquestion/question.php?id=`+t+(n?`&cmid=`+n:``):null}function V(e,t,n){let r=L(e);r&&(r.textContent=t||``,r.className=`mag-status`+(t?n?` fehler`:` ok`:``))}function Ue(e){let t=L(e);return t.hidden=!1,t.innerHTML=``,e=>{t.appendChild(x(`div`,`mag-logzeile`,e)),t.scrollTop=t.scrollHeight}}function We(){return new Promise(e=>{if(!(t!==void 0&&t.storage))return e();t.storage.local.get([`magSettings`],t=>{t.magSettings&&(_=Object.assign({},g,t.magSettings)),e()})})}function H(){t!==void 0&&t.storage&&t.storage.local.set({magSettings:_})}function U(){P.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;e.type===`checkbox`?e.checked=!!_[t]:e.value=_[t]==null?``:_[t]}),G()}function Ge(){P.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;_[t]=e.type===`checkbox`?e.checked:e.value}),_.promptHorizont=null,_.promptKorrektur=null,H(),G()}function Ke(){let e=parseFloat(_.rechtschreibung)===0?`Rechtschreibung: kein Abzug`:`Rechtschreibung: `+_.rechtschreibung+` %`;return[_.fach||`⚠ Fach fehlt`,`Jahrgang `+(_.jahrgang||`⚠ fehlt`),`Niveau `+(Te[_.kursniveau]||_.kursniveau).split(` `)[0],`Feedback `+_.feedbacklaenge,e,`Schritte `+C(_.punkteschritte)].join(` · `)}function W(){return!String(_.fach||``).trim()||!String(_.jahrgang||``).trim()}function qe(){let e=Ke(),t=W();[`hrahmen`,`krahmen`].forEach(n=>{let r=L(n);r&&(r.textContent=e,r.parentElement.classList.toggle(`unvollstaendig`,t))})}function G(){qe();let e=L(`anredehinweis`);e&&(e.textContent=`Im Feedback wird „`+E()+` …" verwendet.`);let t=L(`rshinweis`);t&&(t.textContent=parseFloat(_.rechtschreibung)===0?`Kein Punktabzug — das Sprachfeedback wird trotzdem geschrieben.`:`Voller Abzug ab `+C(m[2][0])+` Fehlern je 100 Wörtern; unter 40 Wörtern zählt die absolute Fehlerzahl.`);let n=L(`vvorschau`);n&&ae(n,R?Ce(R):`<p class="mag-hinweis">Erst im Reiter „Horizont" die Antwort der KI einlesen.</p>`);let r=L(`vhorizont`);r&&ae(r,R?we(R):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`)}function K(e){P.querySelectorAll(`.mag-inhalt`).forEach(t=>{t.hidden=t.dataset.panel!==e}),P.querySelectorAll(`.mag-tab`).forEach(t=>t.classList.toggle(`aktiv`,t.dataset.tab===e));let t=Le.some(t=>t[0]===e);P.querySelector(`.mag-reiter`).hidden=!t,t&&e!==`einst`&&(B=e),e===`vorlage`&&G(),e===`korrektur`&&Qe()}let q=null;function J(e,t,n,r){navigator.clipboard.writeText(e).then(()=>{let i=n+`  (`+e.length.toLocaleString(`de-DE`)+` Zeichen)`;if(V(t,i),!r||!L(r))return;clearInterval(q);let a=3;V(t,i+` — weiter in `+a+` s`),q=setInterval(()=>{if(a--,a>0)return V(t,i+` — weiter in `+a+` s`);clearInterval(q),q=null,V(t,i+` — jetzt die Antwort der KI einfügen.`);let e=L(r);e.focus(),e.scrollIntoView({block:`nearest`})},1e3)}).catch(()=>V(t,`Kopieren fehlgeschlagen — Text bitte von Hand markieren.`,!0))}function Je(){let e=L(`hjson`).value.trim();if(!e)return V(`hstatus`,`Bitte erst die Antwort der KI einfügen.`,!0);try{let t=Ne(e,`aufgaben`).map(e=>({nr:Number(e.nr),schlagwort:e.schlagwort||``,afb:e.afb||``,punkte:e.punkte==null?null:w(e.punkte),operator:e.operator||``,horizont:e.horizont||e.text||``})).filter(e=>!isNaN(e.nr)).sort((e,t)=>e.nr-t.nr);if(!t.length)throw Error(`Keine Aufgaben im JSON.`);let{doppelt:n}=Pe(t,t.map(e=>e.nr));if(n.length)throw Error(`Aufgabe `+n.join(`, `)+` kommt doppelt vor.`);let r=t.reduce((e,t)=>e+(t.punkte||0),0),a=k();R=t;let o=L(`hliste`);o.innerHTML=``,t.forEach(e=>{let t=x(`div`,`mag-karte`);t.appendChild(x(`div`,`mag-kartenkopf`,`Aufgabe `+e.nr+(e.afb?` · AFB `+e.afb:``)+(e.schlagwort?` · `+e.schlagwort:``)+(e.punkte==null?``:`  (`+C(e.punkte)+` P.)`)));let n=x(`textarea`,`mag-kartentext`);n.value=D(e.horizont),n.rows=5,n.addEventListener(`input`,()=>{e.horizont=n.value}),t.appendChild(n),o.appendChild(t)});let s=t.length+` Aufgaben gelesen.`;a&&Math.abs(r-a)>.005&&(s+=`  ⚠ Punktsumme `+C(r)+` weicht von der Fragenpunktzahl `+C(a)+` ab — die Erweiterung rechnet sie beim Bewerten um.`),i===`bearbeiten`&&(s+=`  Weiter zu „3 · Vorlage" — dort siehst du beides und trägst es ein.`),V(`hstatus`,s),L(`hknoepfe`).hidden=!1,G()}catch(e){V(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function Ye(e){let t=i===`bearbeiten`,n=t?`vstatus`:`hstatus`;if(!R)return V(n,`Es liegt noch kein geprüfter Horizont vor — bitte erst im Reiter „Horizont" die Antwort der KI einlesen und prüfen.`,!0);if(!He())return V(n,`Die Adresse der Frage lässt sich hier nicht bestimmen — bitte die Frage zum Bearbeiten öffnen.`,!0);let r=Ue(t?`vlog`:`hlog`),a={"graderinfo[text]":we(R)};i===`bearbeiten`&&Ve(`vorlage`)&&(a[`responsetemplate[text]`]=Ce(R)),await Xe(a,e,r,n)}async function Xe(e,t,n,r){let a=Object.keys(e);try{if(V(r,t?`Trockenlauf läuft …`:`Wird eingetragen …`),i!==`bearbeiten`){let i=He(),o=[...(await O(i)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!o)throw Error(`Bearbeiten-Formular der Frage nicht erreichbar.`);let s=ce(o);if(a.forEach(r=>{if(!s.has(r))throw Error(`Feld „`+r+`" nicht im Formular`);n((t?`✓ `:``)+`Feld `+r+` vorhanden`+(D(s.get(r)).length?` (enthält schon Text!)`:``)),t||s.set(r,e[r])}),t)return V(r,`Alles vorhanden. Jetzt eintragen.`);let c=(o.querySelector(`[name="name"]`)||{}).value||``,l=await ue(await le(o,s,i),c,i),u=[...(await O(l||i)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),d=0;return a.forEach(t=>{let r=u&&u.querySelector(`[name="`+CSS.escape(t)+`"]`),i=!!r&&de(r.value,e[t]);n((i?`✓ `:`✗ `)+t+(i?` eingetragen`:` NICHT angekommen`)),i||d++}),l||n(`⚠ Neue Fragenversion nicht auffindbar — Gegenprobe unsicher.`),V(r,d?d+` Feld(er) nicht angekommen — Protokoll lesen.`:`In die Frage eingetragen und gegengeprüft.`,d>0)}let o=await fe(e,t);if(o.bericht.forEach(e=>n((t?`✓ `:``)+`Feld `+e.feld+` vorhanden`+(e.belegt?` (enthält schon Text!)`:``))),t)return V(r,`Alles vorhanden. Jetzt eintragen.`);o.warnung&&n(`⚠ `+o.warnung);let s=0;if((o.ergebnis||[]).forEach(e=>{n((e.ok?`✓ `:`✗ `)+e.feld+(e.ok?` eingetragen`:` NICHT angekommen`)),e.ok||s++}),s)return V(r,s+` Feld(er) nicht angekommen — Protokoll lesen.`,!0);n(`✓ gespeichert und gegengeprüft`),et(o.neueUrl),V(r,o.neueUrl?`Eingetragen und gegengeprüft. Diese Seite zeigt jetzt einen veralteten Stand.`:`Eingetragen und gegengeprüft. Bitte die Frage neu öffnen — Moodle hat beim Speichern eine neue Version angelegt.`,!1)}catch(e){n(`✗ `+e.message),V(r,`Fehler: `+e.message,!0)}}function Ze(e){let t=e.length?e.reduce((e,t)=>e+te(t.text),0)/e.length:0,n=Math.max(200,t*6);return Math.max(1,Math.min(30,Math.floor(22e3/n)))}function Qe(){let e=j(),t=L(`kgroesse`);t.options.length||([1,2,3,5,8,10,15,20,30].forEach(e=>t.appendChild(new Option(e+` Abgaben`,e))),t.value=String(Ze(e)),t.addEventListener(`change`,Qe));let n=e.length?Math.round(e.reduce((e,t)=>e+te(t.text),0)/e.length):0;L(`kgroessehinweis`).textContent=e.length+` Abgaben, im Schnitt `+n+` Wörter. Vorschlag: `+Ze(e)+` je Durchgang.`;let r=A()||_.horizontLokal,i=parseInt(t.value,10)||5,a=Math.ceil(e.length/i)||1,o=L(`kknoepfe`);o.innerHTML=``;for(let t=0;t<a;t++){let n=t*i,s=Math.min(n+i,e.length),c=x(`button`,`mag-btn mag-btn-primary`,a===1?`📋 Prompt kopieren`:`📋 Teil `+(t+1)+` (Abgabe `+(n+1)+`–`+s+`)`);c.addEventListener(`click`,()=>{if(!r)return V(`kstatus`,`Kein Erwartungshorizont — bitte erst den Reiter „Horizont" verwenden.`,!0);J(ke(e.slice(n,s),r,t+1,a),`kstatus`,a===1?`Prompt kopiert.`:`Teil `+(t+1)+` kopiert.`,`kjson`)}),o.appendChild(c)}}let Y=!1;function X(){let e=L(`kjson`).value.trim();if(!e)return V(`kstatus`,`Bitte erst die Antworten der KI einfügen.`,!0);try{let t=j(),n=A()||_.horizontLokal,r=he(n),i=Ne(e,`bewertungen`).filter(e=>e&&e.nr!=null),{fehlend:a,doppelt:o}=Pe(i,t.map(e=>e.nr));if(o.length)throw Error(`Abgabe `+o.join(`, `)+` kommt doppelt vor.`);if(a.length&&!Y){let e=L(`kliste`);e.innerHTML=``,L(`keintragen`).hidden=!0,z=null;let n=L(`rsabgleich`);n&&(n.hidden=!0);let r=t.length-a.length;V(`kstatus`,`Teil erkannt: `+r+` von `+t.length+` Abgaben. Nächsten Teil einfach dazu einfügen — geprüft wird, sobald alle da sind. (Es fehlen: `+a.join(`, `)+`)`);let i=x(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`Trotzdem nur diese `+r+` prüfen`);i.addEventListener(`click`,()=>{Y=!0,X()}),e.appendChild(i);return}let s=parseFloat(_.rechtschreibung)||0,c=u(n),l=d(n),f=c!=null&&!v?c:s,p=l??(parseFloat(_.punkteschritte)||.5),m=L(`kliste`);m.innerHTML=``;let h=L(`rsabgleich`);if(h){if(h.innerHTML=``,c!=null&&c!==s){h.hidden=!1,h.appendChild(x(`div`,null,`⚠ Im Horizont steht `+C(c)+` % Rechtschreibung, eingestellt sind `+C(s)+` %. Es gilt gerade: `+(v?C(s)+` % (Einstellung)`:C(c)+` % (Horizont)`)+`.`));let e=x(`button`,`mag-btn mag-btn-grau`,v?`Stattdessen den Horizont-Wert verwenden`:`Stattdessen `+C(s)+` % (Einstellung) verwenden`);e.addEventListener(`click`,()=>{v=!v,X()}),h.appendChild(e)}else h.hidden=!0}z=[];let g=0;i.forEach(e=>{let n=t.find(t=>t.nr===Number(e.nr));if(!n)return;let i=be(n,e,r,f,p),a=Ae(e,i,r);if(Math.abs(i.gesamt-n.ist)<.005&&!n.kommentarfeld){g++;return}z.push({nr:n.nr,markfeld:n.markfeld,kommentarfeld:n.kommentarfeld,punkte:i.gesamt,feedbackHtml:je(a),text:a});let o=x(`div`,`mag-karte`);o.appendChild(x(`div`,`mag-kartenkopf`,`Abgabe `+n.nr+`:  `+C(n.ist)+` → `+C(i.gesamt)+` von `+C(i.max)+` P.`+(i.abzug>.004?`   (−`+C(i.abzug)+` P. Sprache)`:``))),o.appendChild(x(`div`,`mag-kartenzeile`,i.teil.map(e=>`A`+e.nr+`: `+e.prozent+`%`).join(`   `)+`   ·   `+i.wortzahl+` Wörter, `+C(i.fehlerDichte)+` Fehler/100`+(i.fehlendeAufgaben.length?`   ·   ⚠ Aufgabe `+i.fehlendeAufgaben.join(`, `)+` von der KI nicht bewertet (0 %)`:``)));let s=x(`textarea`,`mag-kartentext`);s.value=a,s.rows=6;let c=z[z.length-1];s.addEventListener(`input`,()=>{c.text=s.value,c.feedbackHtml=je(s.value)}),o.appendChild(s),m.appendChild(o)});let y=z.length+` Abgaben vorbereitet.`;g&&(y+=`  `+g+` ohne Änderung übersprungen.`),a.length&&(y+=`  ⚠ Es fehlen die Abgaben `+a.join(`, `)+` — bitte den fehlenden Teil nachreichen.`),V(`kstatus`,y,a.length>0),L(`keintragen`).hidden=z.length===0}catch(e){V(`kstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function $e(e){if(!z||!z.length)return;let t=Ue(`klog`);try{V(`kstatus`,e?`Trockenlauf läuft …`:`Wird eingetragen …`);let n=await Ie(z,e,t);if(e)return V(`kstatus`,n.fehler?n.fehler+` Abgabe(n) nicht auf der Seite — Protokoll lesen.`:`Alles vorhanden. Jetzt eintragen.`,n.fehler>0);if(t(`— `+n.ok+` eingetragen · `+n.fehler+` fehlgeschlagen —`),n.fehler)V(`kstatus`,n.fehler+` fehlgeschlagen — Protokoll lesen.`,!0);else{let e=3,t=n.ok+` Bewertungen eingetragen und gegengeprüft.`;V(`kstatus`,t+` Fenster schließt in `+e+` s …`);let r=setInterval(()=>{if(e--,e>0)return V(`kstatus`,t+` Fenster schließt in `+e+` s …`);clearInterval(r),Q.zu(),location.reload()},1e3)}}catch(e){t(`✗ `+e.message),V(`kstatus`,`Fehler: `+e.message,!0)}}let Z=`horizont`,Q={einst:()=>{U(),K(`einst`)},zueinst:()=>{U(),K(`einst`)},zu:()=>{P.classList.remove(`offen`),F.classList.remove(`versteckt`)},hprompt:()=>J(De(),`hstatus`,`Prompt kopiert.`,`hjson`),hedit:()=>tt(`horizont`),hpruefen:Je,hschreiben:()=>Ye(!1),hlokalsichern:()=>{_.horizontLokal=L(`hlokal`).value.trim(),H(),V(`hstatus`,_.horizontLokal?`Horizont in der Erweiterung gespeichert (nicht in der Frage).`:`Gespeicherter Horizont gelöscht.`),Qe()},weiter:()=>K(`vorlage`),beides:()=>Ye(!1),kopierh:()=>R?J(we(R),`vstatus`,`Horizont-HTML kopiert.`):V(`vstatus`,`Erst im Reiter „Horizont" die KI-Antwort einlesen.`,!0),kopierv:()=>R?J(Ce(R),`vstatus`,`Antwortvorlage kopiert.`):V(`vstatus`,`Erst im Reiter „Horizont" die KI-Antwort einlesen.`,!0),kedit:()=>tt(`korrektur`),kpruefen:X,kschreiben:()=>$e(!1),krohdaten:()=>J(JSON.stringify({stand:new Date().toLocaleString(`de-DE`),fach:_.fach,jahrgang:_.jahrgang,gesamtpunkte:k(),aufgabenstellung:pe(),horizont:D(A()||_.horizontLokal),abgaben:j().map(e=>{let t=_e(e.rohHtml,e.text);return{nr:e.nr,ist:e.ist,max:e.max,gegliedert:t.gegliedert,aufgaben:t.aufgaben}})},null,2),`kstatus`,`Rohdaten kopiert.`),esichern:()=>{if(Ge(),W())return V(`estatus`,`Fach und Jahrgang fehlen noch — beides steht im Prompt und bestimmt Anspruchsniveau und Anrede.`,!0);V(`estatus`,``),K(i===`bearbeiten`?`horizont`:B===`einst`?`korrektur`:B)},eabbruch:()=>{U(),V(`estatus`,``)},psichern:()=>{let e=L(`ptext`).value.trim(),t=e===(Z===`horizont`?M():N()).trim()?null:e;Z===`horizont`?_.promptHorizont=t:_.promptKorrektur=t,H(),K(B)},pzurueck:()=>{L(`ptext`).value=Z===`horizont`?M():N()},pabbruch:()=>K(B)},$=null;function et(e){let t=P.querySelector(`.mag-banner`);if(t.hidden=!1,t.className=`mag-banner warnung`,t.innerHTML=``,t.appendChild(x(`div`,null,`Moodle hat beim Speichern eine neue Fassung der Frage angelegt. Dieses Formular zeigt den alten Stand — hier nichts mehr speichern!`)),!e)return;let n=x(`button`,`mag-btn mag-btn-ok`,`Zur neuen Fassung der Frage`),r=x(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`hier bleiben`);n.addEventListener(`click`,()=>{location.href=e}),t.appendChild(n),t.appendChild(r);let i=8,a=x(`div`,`mag-hinweis`,`Wechsel in `+i+` Sekunden …`);t.appendChild(a),r.addEventListener(`click`,()=>{clearInterval($),$=null,a.textContent=`Wechsel angehalten. Diese Seite bitte nicht mehr speichern.`,r.remove()}),$=setInterval(()=>{if(i--,i<=0){clearInterval($),location.href=e;return}a.textContent=`Wechsel in `+i+` Sekunden …`},1e3)}function tt(e){Z=e,L(`ptitel`).textContent=e===`horizont`?`Prompt für den Erwartungshorizont`:`Prompt für die Korrektur`;let t=e===`horizont`?_.promptHorizont:_.promptKorrektur;L(`ptext`).value=t&&t.trim()||(e===`horizont`?M():N()),K(`prompt`)}P.addEventListener(`click`,e=>{let t=e.target.closest(`.mag-tab`);if(t)return q&&=(clearInterval(q),null),t.dataset.tab===`einst`?Q.einst():K(t.dataset.tab);let n=e.target.closest(`[data-tu]`);n&&Q[n.dataset.tu]&&(e.preventDefault(),Q[n.dataset.tu]())}),P.addEventListener(`paste`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;if(t===`hjson`&&setTimeout(Je,0),t===`kjson`){let t=e.clipboardData&&e.clipboardData.getData(`text`);if(t){e.preventDefault();let n=e.target,r=n.value.replace(/\s+$/,``);n.value=r?r+`

`+t:t,n.scrollTop=n.scrollHeight}Y=!1,setTimeout(X,0)}});let nt=null;P.addEventListener(`input`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;t!==`hjson`&&t!==`kjson`||e.inputType===`insertFromPaste`||(t===`kjson`&&(Y=!1),clearTimeout(nt),nt=setTimeout(()=>{e.target.value.trim()&&(t===`hjson`?Je:X)()},800))}),P.addEventListener(`change`,e=>{let t=e.target.closest(`[data-opt]`);t&&[`afbFarben`,`vorlagePunkte`,`vorlageAfb`].includes(t.dataset.opt)&&(_[t.dataset.opt]=t.checked,H(),G())}),F.addEventListener(`click`,()=>{P.classList.add(`offen`),F.classList.add(`versteckt`)}),We().then(()=>{try{let e=P.querySelector(`.mag-kopfbild`);e&&(e.src=t.runtime.getURL(`icon/128.png`))}catch{let e=P.querySelector(`.mag-kopfbild`);e&&e.remove()}document.body.appendChild(F),document.body.appendChild(P),U(),L(`hlokal`).value=_.horizontLokal||``;let e=me(),n=P.querySelector(`.mag-banner`);e.wer===`coach`?(n.hidden=!1,n.textContent=`Diese Frage ist für den Moodle AI Coach gebaut. Der Grader kann sie trotzdem bewerten.`):!e.horizont&&i===`bewertung`&&!_.horizontLokal&&(n.hidden=!1,n.textContent=`Diese Frage hat noch keinen Erwartungshorizont. Er lässt sich hier nachtragen.`);let r;if(W()?(r=`einst`,V(`estatus`,`Bitte einmal ausfüllen: Fach und Jahrgang fehlen. Beides geht als Rahmendatum in den Prompt.`,!0)):r=i===`bewertung`&&!e.horizont&&!_.horizontLokal||i===`bearbeiten`?`horizont`:`korrektur`,K(r),qe(),i===`bewertung`){let e=j().length;V(`kstatus`,e?e+` Abgaben auf dieser Seite.`:`Keine Abgaben gefunden.`)}else V(`hstatus`,e.horizont?`Diese Frage hat bereits einen Erwartungshorizont — ein neuer ersetzt ihn.`:`Noch kein Erwartungshorizont in dieser Frage.`)})}var r=e({matches:[`*://*/*mod/quiz/report.php*`,`*://*/*question/bank/editquestion/question.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){n()}}),i={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},a=class e extends Event{static EVENT_NAME=o(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function o(e){return`${t?.runtime?.id}:content:${e}`}var s=typeof globalThis.navigation?.addEventListener==`function`;function c(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),s?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new a(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new a(e,t)),t=e)},1e3))}}}var l=class e{static SCRIPT_STARTED_MESSAGE_TYPE=o(`wxt:content-script-started`);id;abortController;locationWatcher=c(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?o(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),i.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=r;return await e(new l(`content`,t))}catch(e){throw u.error(`The content script "content" crashed on startup!`,e),e}})()})();