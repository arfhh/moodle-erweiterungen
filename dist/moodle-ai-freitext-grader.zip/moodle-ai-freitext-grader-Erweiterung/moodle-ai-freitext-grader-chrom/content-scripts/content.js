(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`[moodle-ai-freitext: kurztest]`,r=`[moodle-ai-freitext: klausur]`,i=String.raw`moodle[-\s]?ai[-\s]?(?:(coach|grader)|freitext(?:[-\s]?grader)?\s*[:\-–]?\s*(kurztest|klausur))`,a=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*`,`i`),o=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*$`,`im`);function s(e){return e?e[1]?e[1].toLowerCase():/kurztest/i.test(e[2]||``)?`coach`:`grader`:null}function c(e){let t=s((String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``).match(a));return t===`coach`?`kurztest`:t===`grader`?`klausur`:null}var l={Kurz:`FEEDBACKLÄNGE: KURZ (ein bis zwei Sätze an die Schülerin / den Schüler)
Die Bewertungsstufen bleiben genauso scharf wie sonst – die Feedbacklänge ändert nichts
an der Punktvergabe. Kürzer werden nur die Teile, aus denen die Rückmeldung entsteht:
• „Reicht nicht" und „Häufiger Fehler" je höchstens ein Eintrag in einem Satz.
• Füge nach „Häufiger Fehler" diesen Abschnitt an:

Wichtigster Hinweis:
<der eine Satz, den jemand mit unvollständiger Antwort am dringendsten braucht>`,Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis fünf Sätze an die Schülerin / den Schüler)
„Reicht nicht" und „Häufiger Fehler" liefern den Stoff für die Rückmeldung. Schreibe zu
jedem Eintrag einen Halbsatz, warum es nicht reicht bzw. was stattdessen richtig ist.`},u={Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis vier Sätze je Teilaufgabe)
Die Abschnitte oben genügen. „Reicht nicht" und „Häufiger Fehler" je ein bis zwei Einträge.`,Ausführlich:`FEEDBACKLÄNGE: AUSFÜHRLICH (ein Absatz je Teilaufgabe mit Bezug auf die Antwort)
Ergänze je Aufgabe nach „Häufiger Fehler" diesen Abschnitt:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt – so formuliert, dass die Bewertung ihn als
Begründung aufgreifen kann.</p>`,Umfangreich:`FEEDBACKLÄNGE: UMFANGREICH (ausführlicher Absatz je Teilaufgabe, dazu ein eigener
Abschnitt „Operatorerfüllung" im Feedback)
Ergänze je Aufgabe nach „Häufiger Fehler" diese beiden Abschnitte:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt.</p>
<p><strong>Operatorerfüllung:</strong> was der Operator in DIESER Aufgabe konkret verlangt
(z. B. „Erläutere": Ursache nennen, Wirkung nennen, beides mit „weil/dadurch" verknüpfen)
und woran man eine Verfehlung erkennt (z. B. nur beschrieben, nicht verknüpft).</p>`};function d(e,t){let n=e===`kurztest`?l:u,r=e===`kurztest`?`Mittel`:`Ausführlich`;return n[t]||n[r]}function f(){return`FEEDBACKLÄNGE JE AUFGABE
Bei jeder Aufgabe steht „feedback". Es gilt der passende Block:

[Kurz]
${l.Kurz}

[Mittel]
${l.Mittel}`}var p=/\bM\s?\d{1,2}\b|\bMaterial|\bAbb(?:ildung|\.)|\bTabelle|\bDiagramm|\bGrafik|\bTextauszug|\bQuelle\b/i;function m(e,t){return t&&t.length>0||(e||[]).some(e=>p.test(String(e||``)))}function ee(e,t){if(!m(e,t))return``;let n=t||[];return`MATERIAL
Die Aufgabe verweist auf Material (M1, Abbildung, Tabelle …).
• Liegt das Material hier im Chat nicht vollständig vor, FRAGE ZUERST danach und schreibe
  den Horizont erst, wenn es da ist. Rate keine Werte.
• Werte das Material JETZT aus. Beim späteren Bewerten liegt es NICHT mehr vor. Schreibe alle
  Werte und Aussagen, die eine Antwort braucht, mit Quelle direkt in die Erwartungen
  (z. B. „M2, Tabelle: Siedetemperatur 78 °C"), nicht nur „siehe M2".
• Wörtliche Übernahmen aus dem Material ohne eigene Erklärung sind ein „Reicht nicht"-Fall,
  wo die Aufgabe eine Erklärung verlangt.`+(n.length?`

In der Aufgabe stehen Bilder/Dateien, die hier nur als Name ankommen:
- `+n.join(`
- `)+`
Die Lehrkraft lädt sie zusätzlich in den Chat hoch.`:``)}function h(e){return`• Nur die Stufen 100 / 75 / 50 / 25 / 0 Prozent. Lass Stufen weg, die die Aufgabe nicht
  hergibt (bei einer Aufzählung von drei Dingen etwa 100 / 75 / 50 / 0).
• JEDE STUFE HÄNGT AN ZÄHLBAREN BEDINGUNGEN („beide Teilaspekte", „Name ohne Funktion"),
  nie an Wörtern wie „überwiegend", „im Wesentlichen" oder „deutliche Lücken". Solche
  Wörter führen dazu, dass dieselbe Antwort verschieden eingestuft wird. Prüfe zum
  Schluss: Jede denkbare Antwort gehört zu genau EINER Stufe – keine Lücke, keine
  Überschneidung.
• „AUCH RICHTIG" ist der wichtigste Abschnitt. Gemeint sind nicht ausformulierte
  Musterantworten, sondern die rauen, verkürzten Fassungen, mit denen ${e?`Lernende der Jahrgangsstufe `+e:`Lernende dieser Jahrgangsstufe`}
  dasselbe sagen – auch umgangssprachlich, auch ohne Fachbegriff. Mindestens vier,
  dazu Wörter, die dasselbe meinen (etwa Ring, Bahn oder Ebene statt Schale).
• Der OPERATOR zählt: Schreibe in die 100-%-Bedingung, was er hier verlangt. Bei „Nenne"
  reicht die Nennung, bei „Beschreibe" der Sachverhalt, bei „Erkläre/Erläutere" muss ein
  Zusammenhang (weil, dadurch) dastehen, bei „Vergleiche" beide Seiten, bei
  „Beurteile/Bewerte" ein begründetes Urteil.
• STICHPUNKTE gelten als vollständige Antwort, solange sie den Inhalt tragen. Verlangt der
  Operator einen Zusammenhang, den Stichpunkte nicht zeigen, lege in den Stufen fest,
  wo sie landen.
• ZUSATZWISSEN: Fachlich richtige Zusätze, die nicht verlangt sind, heben keine Stufe.
  Lege keine Stufe an, die für Zusatzwissen mehr gibt.
• „REICHT NICHT" enthält nur Antworten, die sachlich RICHTIG, aber zu wenig sind.
  Sachlich Falsches gehört zu 0 % und unter „Häufiger Fehler" – sonst liest die
  Bewertung es als fast richtig.
• NICHT in den Horizont: Sprachregeln, Rechtschreibabzug, Feedback-Stil, Rolle,
  Punktzahlen, allgemeine Bewertungsregeln. Das steht im Bewertungsprompt der
  Erweiterung. Im Horizont steht nur, was für DIESE Aufgabe gilt.`}var g=`WOZU DER HORIZONT DIENT
Mit diesem Horizont bewertet später eine KI die Antworten einer ganzen Lerngruppe.
Gleiche Antworten sollen immer dieselbe Stufe bekommen – egal welches Modell bewertet
und wie oft. Das gelingt nur, wenn der Horizont keinen Ermessensspielraum lässt.`;function te(e={}){let t=!!e.einzeln,n=e.stufe===`gemischt`?f():d(`kurztest`,e.stufe);return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KURZTEST)
═══════════════════════════════════════════════════════

Für ${t?`die Aufgabe unten brauchst du einen Erwartungshorizont`:`die Aufgaben unten brauchst du je einen Erwartungshorizont`}
in genau dem Format unten. Er wird in Moodle im Feld „Informationen für Bewerter/innen"
der Aufgabe gespeichert und bei jeder Bewertung benutzt.

${g}

BISHERIGER HORIZONT
Steht ${t?`bei der Aufgabe`:`bei einer Aufgabe`} „horizont_bisher", ist das ein älterer Horizont. Er ist
Ausgangspunkt, keine Vorlage zum Abschreiben: Übernimm, was fachlich gut ist, und
schreibe ihn im Format unten neu. Sag der Lehrkraft ZUERST in zwei, drei Sätzen, dass
ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst.${t?``:` Stehen unten Änderungswünsche der Lehrkraft, haben sie
Vorrang – auch wenn der bisherige Horizont das Gegenteil sagt.`}
Steht kein „horizont_bisher" dabei, schreibst du neu.

KERNAUSSAGE = MUSTERANTWORT
Die Kernaussage sehen die Schülerinnen und Schüler: Bei unvollständigen Antworten setzt
die Erweiterung sie als „So hättest du es schreiben können" unter die Rückmeldung.
Schreibe sie als vollständige Musterantwort in einfacher Sprache – ein bis zwei kurze
Sätze, so wie eine gute Schülerin oder ein guter Schüler sie schreiben würde.

FORMAT${t?``:` je Aufgabe`}

Erwartungshorizont

Kernaussage:
<Musterantwort, ein bis zwei kurze Sätze>

Muss enthalten:
- <Teilaspekt 1>
- <Teilaspekt 2>

Auch richtig:
<gleichwertige Formulierungen, Synonyme, umgangssprachliche Varianten>

Inhalt:
100 % – <Bedingung>
 75 % – <Bedingung>
 50 % – <Bedingung>
 25 % – <Bedingung>
  0 % – <Bedingung>

Reicht nicht:
<sachlich richtige, aber zu knappe Antwort und warum sie nicht reicht>

Häufiger Fehler:
<typischer Denkfehler und was stattdessen richtig ist>

Teile:                          (nur wenn die Aufgabe Teile a, b … hat)
a) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)
b) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)

REGELN
${h(e.jahrgang)}
• TEILE: Hat die Aufgabe Teile (a, b …), gehört der Abschnitt „Teile:" dazu. Die Punkte
  aller Teile ergeben zusammen genau „max". Die Stufen unter „Inhalt" gelten für die
  ganze Aufgabe und nennen, welche Teile erfüllt sein müssen.
• Die Schülerantworten sind ein bis drei Sätze lang. Halte den Horizont entsprechend
  knapp – er ist kein Lehrbuchtext.

${n}

AUSGABE
Gib zuerst ${t?`den Horizont`:`alle Horizonte`} als lesbaren Text aus, damit die Lehrkraft prüfen kann.
Frage dann: „Passt das so? Wenn ja, antworte mit ok." Ändere, bis die Lehrkraft
zustimmt. Erst nach „ok" gibst du genau EINEN Codeblock aus:

\`\`\`json
{
  "horizonte": [
    { "qid": "115576570", "frage": "Edelgasregel",
      "text": "Erwartungshorizont\\n\\nKernaussage:\\n…" }
  ]
}
\`\`\`

„qid" übernimmst du unverändert aus den Daten unten.

═══════════════════════════════════════════════════════
${t?`DIESE AUFGABE`:`AUFGABEN`}
═══════════════════════════════════════════════════════

[MOODLE_AI_COACH_AUFGABEN]`}function ne(e={}){let t=e.fach?e.fach+`lehrkraft`:`Fachlehrkraft`,n=[e.jahrgang?`Jahrgang `+e.jahrgang:``,e.niveau?`Niveau `+e.niveau:``].filter(Boolean).join(`, `);return`ROLLE
Du bist ${t} und bewertest Schülerantworten${n?` (`+n+`)`:``} streng nach einem
festen Erwartungshorizont.${e.anrede?`

ANREDE
`+(e.anrede===`sie`?`Sprich die Schülerinnen und Schüler in jeder Rückmeldung mit „Sie" an („Sie haben …"). Beispiele in diesem Prompt, die „du" verwenden, überträgst du in die Sie-Form.`:`Sprich die Schülerinnen und Schüler in jeder Rückmeldung mit „du" an („Du hast …").`):``}

ZENTRALE BEWERTUNGSREGEL
Bewerte alle folgenden Antworten strikt nach demselben Maßstab. Fachlich gleiche
Antworten bekommen dieselbe Stufe – egal, an welcher Stelle sie stehen und wie die
Antworten davor ausgefallen sind.

ORGANISATIONSREGEL
Die Antworten stammen von verschiedenen Schülerinnen und Schülern. Bewerte jede für sich,
ohne sie untereinander zu vergleichen, aber mit identischem Maßstab.

GRUNDREGELN
• Bewerte nur, was tatsächlich dasteht. Interpretiere keine fehlenden Aussagen hinein.
• Maßstab ist ausschließlich der Erwartungshorizont. Eigenes Fachwissen nutzt du nur, um
  zu erkennen, ob eine abweichende Formulierung dasselbe meint.
• Eine Stufe gibt es nur für klar erkennbare, fachlich richtige Aussagen. Liegt eine
  Antwort zwischen zwei Stufen, gilt die niedrigere – nenne den Grund in der Begründung.
• Andere fachlich korrekte Formulierungen mit demselben Inhalt bekommen dieselbe Stufe.
  „Auch richtig" im Horizont ist verbindlich, auch umgangssprachlich.
• Fachlich richtige Zusätze, die nicht verlangt waren, bringen nichts – sie kosten aber
  auch nichts.
• Fachlich richtige Stichpunkte werden bewertet wie ganze Sätze, außer der Horizont
  sagt für diese Aufgabe etwas anderes.
• Der Operator zählt: Die volle Stufe gibt es nur, wenn die Antwort die geforderte
  Tiefe hat. Anforderungsbereiche: AFB I = Reproduktion, AFB II = Reorganisation /
  Transfer, AFB III = Reflexion / Bewertung.
• Teilpunkte entstehen nur über die Stufen des Horizonts. Punkte rechnet die
  Erweiterung.`}function _(e,t){let n=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!n)throw Error(`Feld „`+e+`" nicht im Formular`);n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0}));let r=n.id||``,i=r&&document.getElementById(r+`_ifr`);if(i&&i.contentDocument&&i.contentDocument.body)return i.contentDocument.body.innerHTML=t,i.contentDocument.body.dispatchEvent(new Event(`input`,{bubbles:!0})),`TinyMCE`;let a=r&&document.getElementById(r+`editable`);return a?(a.innerHTML=t,a.dispatchEvent(new Event(`input`,{bubbles:!0})),`Atto`):`Textfeld`}function re(e){let t=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!t)return``;let n=t.id||``,r=n&&document.getElementById(n+`_ifr`);if(r&&r.contentDocument&&r.contentDocument.body)return r.contentDocument.body.innerHTML;let i=n&&document.getElementById(n+`editable`);return i?i.innerHTML:t.value||``}var ie={I:{op:`#2e7d32`,block:`#eaf4ea`,feld:`#f5faf5`},II:{op:`#b45309`,block:`#fdf2e0`,feld:`#fffaf0`},III:{op:`#c62828`,block:`#fbe9e9`,feld:`#fdf3f3`},neutral:{op:`#33404d`,block:`#eceff3`,feld:`#f8f9fb`}},v=/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i,y=/\s*\(\s*AFB\s*I{1,3}(?:\s*[-–]\s*I{1,3})?\s*\)\s*/gi,ae=/^\s*(?:Aufgabe\s*)?(\d{1,2})?\s*([a-h])?\s*[.):]\s*|^\s*[①-⑳]\s*/i,b=/^\s*(?:Aufgabe\s*)?(\d{1,2})\s*([a-h])?\s*[.):]\s*/i,x=/^\s*([a-h])\s*\)\s*/i,oe=/^\s*([①-⑳])/,S=/^\s*(?:M\s?\d+\b|Material\b)/i,se=/^(Nenne|Benenne|Gib|Beschreibe|Erkläre|Erläutere|Begründe|Vergleiche|Beurteile|Bewerte|Diskutiere|Erörtere|Stelle|Skizziere|Zeichne|Berechne|Ermittle|Bestimme|Formuliere|Deute|Interpretiere|Analysiere|Untersuche|Entwickle|Plane|Prüfe|Überprüfe|Ordne|Fasse|Werte|Leite|Definiere|Charakterisiere|Gliedere|Zeige|Notiere|Markiere|Kennzeichne|Ergänze|Wende|Übertrage|Gestalte|Entwirf|Nimm)\b/,ce=`①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳`;function le(e){let t=String(e||``).match(v);return t?t[1].replace(/\s+/g,``):``}function C(e){let t=String(e||``).toUpperCase().split(/[-–]/).pop().trim();return ie[t]?t:null}function w(e){return ie[C(e)]||ie.neutral}function ue(e){return/#B9C7DA/i.test(String(e||``))}function T(e){return String(e??``).replace(/\s+/g,``).toLowerCase()}function E(e){return String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function D(e){return String(e).replace(`.`,`,`)}function O(e){return`<span style="display:inline-block;min-width:22px;height:22px;line-height:20px;padding:0 5px;box-sizing:border-box;border:1.5px solid #33404d;border-radius:11px;background:#fff;color:#222;font-weight:700;font-size:13px;text-align:center;">`+E(e)+`</span>`}function k(e){return e==null||e===``?``:`<span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+E(D(e))+(Number(e)===1?` Punkt`:` Punkte`)+`)</span>`}function A({label:e,titel:t,afb:n,punkte:r,farbig:i,zeigeAfb:a,zeigePunkte:o}){let s=i?w(n):ie.neutral,c=(e?O(e)+` · `:``)+E(t||`Deine Antwort`);return a&&n&&(c+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+E(n)+`</span>`),o&&r!=null&&(c+=` `+k(r)),`<div style="border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:10px 0;"><div style="background:`+s.block+`;padding:9px 14px;font-size:16px;font-weight:bold;color:#33404d;border-bottom:1.5px solid #9e9e9e;">`+c+`</div><div style="background:`+s.feld+`;padding:10px 14px;font-size:15px;line-height:1.45;"><p style="margin:0;">&nbsp;</p><p style="margin:0;">&nbsp;</p></div></div>`}function j(e,t){let n=w(t);return`<div style="display:flex;border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:6px 0 10px;"><div style="width:40px;flex-shrink:0;background:#B9C7DA;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:4px;padding:10px 4px;"><span style="font-size:10px;font-weight:bold;line-height:1.2;text-align:center;color:#6b6b6b;">`+(t?`AFB<br>`+E(t):``)+`</span></div><div style="flex:1;"><div style="padding:10px 14px 8px;background:`+n.block+`;font-size:15px;line-height:1.6;border-radius:0 12px 12px 0;">`+e+`</div></div></div>`}function de(e,t,n,r){let i=e.ownerDocument,a=i.createTreeWalker(e,4),o;for(;(o=a.nextNode())&&!o.data.trim(););let s=!1;if(o){let e=o.data.replace(y,` `).replace(/^\s+/,``).replace(ae,``),t=(e.match(/^\s*/)||[``])[0];e=e.slice(t.length);let r=e.match(se),a=i.createDocumentFragment();if(r){let t=i.createElement(`span`);t.setAttribute(`style`,`font-weight:700;color:`+n+`;`),t.textContent=r[1],a.appendChild(t),a.appendChild(i.createTextNode(e.slice(r[1].length))),s=!0}else a.appendChild(i.createTextNode(e));o.parentNode.replaceChild(a,o)}let c=e.innerHTML.replace(y,` `).trim(),l=t?O(t)+` `:``,u=r==null?``:` `+k(r);return c=/^<p[\s>]/i.test(c)?c.replace(/^(<p[^>]*>)/i,`$1`+l):l+c,/<\/p>\s*$/i.test(c)?c=c.replace(/<\/p>\s*$/i,u+`</p>`):c+=u,{html:c,opGefunden:s}}function fe(e){let t=new DOMParser().parseFromString(`<div id="w">`+String(e||``)+`</div>`,`text/html`),n=[...t.getElementById(`w`).childNodes].filter(e=>e.nodeType===1||e.nodeType===3&&e.data.trim()),r=e=>(e.textContent||``).replace(/ /g,` `),i=[],a=null,o=``,s=0;if(n.forEach(e=>{let t=r(e),n=null,c;if((c=t.match(b))?(o=c[1],n=c[1]+(c[2]?c[2].toLowerCase():``)):(c=t.match(x))?n=o+c[1].toLowerCase():(c=t.match(oe))&&(s=ce.indexOf(c[1])+1,o=String(s),n=o),n){a={typ:`aufgabe`,label:n,knoten:[e]},i.push(a);return}if(S.test(t)||!a||a.typ===`frei`){(!a||a.typ!==`frei`||S.test(t))&&(a={typ:`frei`,knoten:[]},i.push(a)),a.knoten.push(e);return}a.knoten.push(e)}),!i.some(e=>e.typ===`aufgabe`)){let e=n.find(e=>e.tagName===`OL`&&e.children.length>=2);if(e){let r=[];return n.forEach(t=>{t===e?[...e.children].forEach((e,t)=>r.push({typ:`aufgabe`,label:String(t+1),knoten:[...e.childNodes]})):r.push({typ:`frei`,knoten:[t]})}),{doc:t,segmente:r}}}return i.forEach((e,n)=>{if(e.typ!==`aufgabe`||!/^\d+$/.test(e.label))return;let a=i.slice(n+1).find(e=>e.typ===`aufgabe`);if(a&&a.label.startsWith(e.label)&&a.label!==e.label){e.typ=`frei`;let n=e.knoten[0],i=t.createTreeWalker(n,4),a;for(;(a=i.nextNode())&&!a.data.trim(););a&&(a.data=a.data.replace(b,``)),!r(n).trim()&&!n.querySelector?.(`img,table`)&&e.knoten.shift()}}),{doc:t,segmente:i}}function pe(e,t={}){let{doc:n,segmente:r}=fe(e),i=[],a=t.aufgaben||[],o=new Map(a.map(e=>[T(e.nr),e])),s=r.filter(e=>e.typ===`aufgabe`),c=e=>{let t=n.createElement(`div`);return e.forEach(e=>t.appendChild(e.cloneNode(!0))),t};if(!s.length){let e=c(r.flatMap(e=>e.knoten)),n=a.length===1&&a[0].afb||t.gesamtAfb||le(e.textContent),o=de(e,``,w(n).op,null);return o.opGefunden||i.push(`Kein Operator am Anfang erkannt – der Text steht unverändert in der Karte.`),n||i.push(`Kein AFB gefunden – die Karte bleibt neutral grau.`),a.length>1&&i.push(`Im Horizont stehen `+a.length+` Teilaufgaben, im Fragetext ist keine Nummerierung zu erkennen (z. B. „1.", „2a)", „b)").`),{html:j(o.html,n),gefunden:0,erwartet:a.length,hinweise:i}}a.length&&s.length!==a.length&&i.push(`Gefunden: `+s.length+` Teilaufgaben, im Horizont stehen `+a.length+`. Bitte die Vorschau genau prüfen.`);let l=0,u=0,d=0,f=r.map(e=>{let n=c(e.knoten);if(e.typ===`frei`)return n.innerHTML.replace(y,` `).replace(/<p[^>]*>(?:\s|&nbsp;|<br\s*\/?>)*<\/p>/gi,``).trim();let r=o.get(T(e.label))||a[l]||{};l++;let i=r.afb||le(n.textContent)||t.gesamtAfb||``,s=t.punkte===!1||r.punkte==null?null:r.punkte;t.punkte!==!1&&s==null&&d++;let f=de(n,e.label,w(i).op,s);return f.opGefunden||u++,j(f.html,i)}).join(`
`);return u&&i.push(u+` Teilaufgabe(n) ohne erkannten Operator am Anfang – dort ist nichts eingefärbt.`),d&&i.push(d+` Teilaufgabe(n) ohne Punkte im Horizont – dort steht keine Punktzahl.`),{html:f,gefunden:s.length,erwartet:a.length,hinweise:i,labels:s.map(e=>e.label)}}async function me(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function he(e){if(!e)return null;let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function ge(e,t){let n=[...(await me(t(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!n)return null;let r=await me(new URL(n.getAttribute(`href`),t(e)).href),i=null;for(let e of r.querySelectorAll(`table tbody tr`))for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){i=e[1];break}}if(!i||String(i)===String(e))return null;let a=(await me(t(i))).querySelector(`[name="graderinfo[text]"]`),o=a?String(a.value||``).trim():``;return o?{qid:i,html:o}:null}var M={fach:/^\s*\[?\s*fach\s*:\s*([^\]\n]+?)\s*\]?\s*$/im,jahrgang:/^\s*\[?\s*jahrgang\s*:\s*(\d{1,2})\s*\]?\s*$/im,niveau:/^\s*\[?\s*(?:kurs)?niveau\s*:\s*(gymnasial|mittel|einfach|[GME])\b[^\]\n]*\]?\s*$/im,feedback:/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im},_e=/^\s*\[?\s*(?:rechtschreibung\s*[:\-]?\s*\d{1,3}(?:[.,]\d+)?\s*%|punkteschritte\s*[:\-]?\s*[\d.,]+)\s*\]?\s*$/i;function ve(e){let t=String(e||``).trim();return t?_e.test(t)||Object.values(M).some(e=>new RegExp(e.source,`i`).test(t)):!1}function ye(e){let t=String(e||``).split(`
`).map(e=>e.trim()).filter(Boolean).slice(0,10).join(`
`),n={},r=t.match(M.fach);r&&(n.fach=r[1].trim());let i=t.match(M.jahrgang);i&&(n.jahrgang=i[1]);let a=t.match(M.niveau);a&&(n.niveau=a[1].charAt(0).toUpperCase());let o=t.match(M.feedback);return o&&(n.feedback=o[1].charAt(0).toUpperCase()+o[1].slice(1).toLowerCase()),n}var be={G:`gymnasial`,M:`mittel`,E:`einfach`};function xe({fach:e,jahrgang:t,niveau:n,feedback:r}={}){return(e?`<p>[Fach: `+we(e)+`]</p>`:``)+(t?`<p>[Jahrgang: `+we(t)+`]</p>`:``)+(n?`<p>[Niveau: `+we(be[n]||n)+`]</p>`:``)+(r?`<p>[Feedback: `+we(r)+`]</p>`:``)}function Se(e){let t=parseInt(e,10);return!isNaN(t)&&t>=11?`sek2`:`sek1`}function Ce(e,t){return t===`du`?`du`:t===`sie`||Se(e)===`sek2`?`sie`:`du`}function we(e){return String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}var Te=[[1,0],[2,1/3],[3.5,2/3],[1/0,1]],N=[0,1/3,1/2,2/3,5/6,1];function Ee(e){return(String(e||``).trim().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length}function De(e){return(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0)}function Oe(e,t){if(t<40)return N[Math.min(Math.max(0,Math.round(e)),N.length-1)];let n=t>0?e*100/t:0;for(let[e,t]of Te)if(n<=e)return t;return 1}function ke(e,t){let n=Number(e)||0;return n?`Höchstens `+String(n).replace(`.`,`,`)+` % `+(t||`der Punkte`)+`. Kurze Antworten (unter 40 Wörtern): 1 Fehler kostet ein Drittel davon, ab 5 Fehlern alles. Längere Antworten nach Fehlerquotient: bis 1 Fehler je 100 Wörter nichts, ab 3,5 alles. Schwere Fehler zählen doppelt.`:`Sprache kostet keine Punkte. Eine Rückmeldung zur Sprache gibt es trotzdem.`}function Ae(e,t){return`Zur Einordnung, was mit deiner Zählung geschieht: Der Höchstabzug ist gerade auf
${String(Number(e)||0).replace(`.`,`,`)} % ${t||`der Punkte`} eingestellt. Bei Antworten unter 40 Wörtern kostet
1 Fehler ein Drittel davon, 2 die Hälfte, 3 zwei Drittel, 4 fünf Sechstel, ab 5 den vollen
Abzug. Bei längeren Antworten zählt der Fehlerquotient (Fehler je 100 Wörter): bis 1 kein
Abzug, bis 2 ein Drittel, bis 3,5 zwei Drittel, darüber der volle Abzug.`}var je=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,Me=[`kiHinweis`,`kiHinweisText`,`entferneQuellen`,`kompaktPrompt`],Ne={kiHinweis:!0,kiHinweisText:je,entferneQuellen:!0,kompaktPrompt:!1};function Pe(e){return String(e??``).replace(/\[\w+:\d+\]/g,``).replace(/【[^】]*】/g,``).replace(/\[\d{1,2}\](?!\()/g,``).replace(/ {2,}/g,` `).replace(/ +([.,;:!?])/g,`$1`).trim()}function P(e){if(typeof e==`string`)return Pe(e);if(Array.isArray(e))return e.map(P);if(e&&typeof e==`object`){let t={};return Object.keys(e).forEach(n=>{t[n]=P(e[n])}),t}return e}var Fe=`BEWERTUNGSLOGIK (KOMPAKT)
Falls du Zugriff auf die Skills „2-didaktik-bewertung" und „3-moodle-erweiterungen"
von A. Spielhoff hast: Wende deren Klausur-Bewertungslogik an — Erfüllungsgrad je Aufgabe
nur in den Stufen 100, 75, 50, 25, 0, jede Stufe an einer Formulierung des Horizonts
verankert, Operator geprüft; Sprachfehler einzeln zählen (Wort, Korrektur, Kategorie:
satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache; schwer = doppelt); jede Aufgabe bekommt eine Begründung,
auch eine vollständig richtige. Du vergibst KEINE Punkte und schreibst keine Zahlen in
die Begründungen — das rechnet die Erweiterung.

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt" ausschalten) statt zu raten.`,F=e=>`freitextRundgang_`+e;function Ie(e,n){try{return t.storage.local.set({[F(e)]:{liste:n,stand:Date.now()}})}catch{return Promise.resolve()}}function Le(e){return new Promise(n=>{try{t.storage.local.get([F(e)],t=>n(t&&t[F(e)]||null))}catch{n(null)}})}function Re(e,t){return location.origin+location.pathname+`?id=`+e+`&mode=grading&slot=`+t.slot+`&qid=`+t.qid+`&grade=needsgrading&qperpage=100`}function ze(e){return location.origin+location.pathname+`?id=`+e+`&mode=grading`}function Be(e,t,n){if(!e||!e.liste||!e.liste.length)return null;let r=e.liste.findIndex(e=>String(e.slot)===String(t)&&String(e.qid)===String(n));return r<0?null:{index:r,gesamt:e.liste.length,naechste:e.liste[r+1]||null}}function Ve(e){"use strict";e||={};let r=t.runtime.getManifest?t.runtime.getManifest().version:``,i=be,o={};try{t.storage.local.get([`magSettings`]).then(e=>{let t=e&&e.magSettings||{},n=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t};o={fach:t.fach||``,jahrgang:t.jahrgang||``,niveau:t.kursniveau||``,rsSek1:n(t.rsSek1!==void 0&&t.rsSek1!==``?t.rsSek1:t.rechtschreibung),rsSek2:n(t.rsSek2!==void 0&&t.rsSek2!==``?t.rsSek2:25),anredeWahl:t.anredeWahl||`auto`},typeof ut==`function`&&ut()}).catch(()=>{})}catch{}let c=new URLSearchParams(location.search);if(c.get(`mode`)!==`grading`)return;let l=e.einzel||null,u=e.ziel||null;if(c.get(`slot`)&&!l||c.get(`includeauto`)===`1`)return;let d=c.get(`id`);if(!d)return;let f=location.origin+location.pathname,p=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),m=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},h=e=>Number(e).toFixed(2).replace(`.`,`,`),g=e=>String(Number(e)).replace(`.`,`,`),_=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function re(e,t,n){if(!e||typeof e!=`object`)return``;let r=t=>String(e[t]||``).trim(),i=r(`lob`),a=[[`Inhalt`,r(`inhalt`)],[`Rechtschreibung`,r(`rechtschreibung`)],[`Grammatik`,r(`grammatik`)],[`Tipp`,r(`tipp`)]].filter(([,e])=>e);if(!a.length&&!i)return``;if(!a.length)return`<p><strong><u>Feedback:</u></strong> `+_(i)+`</p>`;let o=a.map(([e])=>e),s=o.includes(`Grammatik`)?`Grammatik`:o.includes(`Rechtschreibung`)?`Rechtschreibung`:null,c=e=>`<span style="color:#767676;font-style:italic;"> (`+e+`)</span>`,l=!!(n&&n.gewicht>=5),u=e=>e>=5?`5 oder mehr Fehlerpunkte`:e===1?`1 Fehlerpunkt`:e+` Fehlerpunkte`,d=`<p><strong><u>Feedback</u></strong></p>`;return i&&(d+=`<p>`+_(i)+`</p>`),a.forEach(([e,r])=>{let i=``;n&&(e===`Inhalt`&&n.inhalt!=null?i=c(n.inhaltMax==null?h(n.inhalt)+` Punkte`:h(n.inhalt)+` von `+h(n.inhaltMax)+` Punkten`):e===s&&n.abzug&&(i=c(`−`+h(n.abzug)+` Punkte`+(n.gewicht==null?``:` — `+u(n.gewicht)+(l?`, höchste Stufe`:``))))),d+=`<p><u>`+e+`:</u> `+_(r)+i+`</p>`,e===`Inhalt`&&t&&(d+=`<p><u>So hättest du es schreiben können:</u> `+_(t)+`</p>`),e===s&&l&&(d+=`<p>In deiner Antwort häufen sich mehrere grundlegende Fehler — das ist die höchste Fehlerstufe. Es lohnt sich, gezielt daran zu arbeiten.</p>`)}),d}function ie(e){let t=String(e||``).replace(/\r/g,``).match(/Kernaussage\s*:?\s*([\s\S]*?)(?=\n\s*(?:Muss enthalten|Auch richtig|Inhalt|Reicht nicht|Häufiger Fehler|Wichtigster Hinweis|Teile)\s*:|$)/i),n=t?t[1].replace(/\s+/g,` `).trim():``;return n.length>300?``:n}let v=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function y(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let ae=e=>new Promise(t=>setTimeout(t,e)),b=(e,t,n)=>`${f}?id=${d}&mode=grading&slot=${e}&qid=${t}&grade=${n||`needsgrading`}&qperpage=100`,x=e=>`${p}/question/bank/editquestion/question.php?id=${e}&cmid=${d}`,oe=e=>e&&e.slot&&e.qid?b(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``):null;async function S(e){try{await navigator.clipboard.writeText(e)}catch{let t=v(`textarea`,`co-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}let se=n,ce=a;function le(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function C(e){let t=String(e||``).split(`
`).map(e=>e.trim()).filter(Boolean);return s(t.slice(0,5).map(e=>e.match(ce)).find(Boolean)||null)||(t.some(e=>/^(?:[①-⑳]\s*)?Aufgabe\s+\d{1,2}\s*[a-h]?\b/i.test(e))?`grader`:t.some(e=>/^Kernaussage\s*:/i.test(e))?`coach`:null)}function w(e){let t=String(e||``).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&ce.test(t[n])&&(t[n]=t[n].replace(ce,``).trim(),t[n]||t.splice(n,1)),t.join(`
`).trim()}let ue=/^\s*\[?\s*rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%?\s*\]?\s*$/i;function T(e){let t=le(w(e)).match(ue);return t?parseFloat(t[1].replace(`,`,`.`)):null}function E(e){let t=w(e).split(`
`),n=t.findIndex(e=>e.trim());n>-1&&ue.test(t[n].trim())&&t.splice(n,1);for(let e=0;e<8;e++){let e=t.findIndex(e=>e.trim());if(e>-1&&ve(t[e]))t.splice(e,1);else break}return t.join(`
`).trim()}let D={maxSprachabzug:10,kiHinweisText:je,promptOverride:``,horizontPromptOverride:``,nurMitMarker:!1,kompaktPrompt:!1,kiHinweis:!0,entferneQuellen:!0},O={...D};function k(e){let t=Se(e)===`sek2`?`rsSek2`:`rsSek1`;return o&&o[t]!=null?o[t]:t===`rsSek2`?25:O.maxSprachabzug??D.maxSprachabzug}function A(){let e=H!==void 0&&H&&H.fragen?Object.values(H.fragen):[],t=t=>{let n={};return e.forEach(e=>{e[t]&&(n[e[t]]=(n[e[t]]||0)+1)}),Object.keys(n).sort((e,t)=>n[t]-n[e])[0]||``},n=t(`jahrgang`)||o.jahrgang||``,r=t(`niveau`)||o.niveau||``;return{fach:t(`fach`)||o.fach||``,jahrgang:n,niveau:i[r]||r,anrede:Ce(n,o.anredeWahl)}}function j(){return k(A().jahrgang)}function de(e){let t=j();return e&&e.jahrgang?k(e.jahrgang):t}function fe(){return new Promise(e=>{try{t.storage.local.get([`coachOptionen`,`magSettings`],t=>{let n=t&&t.magSettings||{},r={};Me.forEach(e=>{n[e]!==void 0&&(r[e]=n[e])}),O={...D,...t&&t.coachOptionen?t.coachOptionen:{},...r},e(O)})}catch{e(O)}})}function pe(e){return O={...O,...e},new Promise(e=>{try{t.storage.local.get([`magSettings`],n=>{let r={...n&&n.magSettings||{}};Me.forEach(e=>{r[e]=O[e]}),t.storage.local.set({coachOptionen:O,magSettings:r},e)})}catch{e()}})}function me(e,t,n){let r=n??j();return Oe(e,t)*r}function he(e,t,n,r,i){let a=De(n),o=me(a,Ee(i),r),s=e*t/100-e*o/100;return{gewicht:a,abzug:o,inhaltPunkte:Math.round(e*t/100*100)/100,abzugPunkte:Math.round(e*o/100*100)/100,punkte:Math.max(0,Math.round(s*100)/100)}}function ge(){if(l)return[{slot:String(l.slot),qid:String(l.qid),name:l.name||`Diese Aufgabe`,summe:null}];let e=document.querySelector(`table`);return e?[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)||``).find(e=>/slot=/.test(e))||``,n=(t.match(/slot=(\d+)/)||[])[1],r=(t.match(/qid=(\d+)/)||[])[1];if(!n||!r)return null;let i=(e.cells[5]?e.cells[5].textContent.trim():``).match(/^(\d+)/);return{slot:n,qid:r,name:e.cells[2]?e.cells[2].textContent.trim():``,summe:i?+i[1]:null}}).filter(Boolean):[]}let M=e=>e?e.innerHTML.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&amp;/g,`&`).replace(/&lt;/g,`<`).replace(/&gt;/g,`>`).replace(/&quot;/g,`"`).replace(/\s+/g,` `).trim():``,_e=e=>e.querySelector(`textarea.qtype_essay_response, div.qtype_essay_response`),xe=/^\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/i,we=/(^|\s)([a-h])\s*·\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/gi,Te=/^\s*(?:[^\n]{0,120}?\s)?AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?\s*·[^()\n]{0,80}\(\s*[\d.,]+\s+Punkte?\s*\)\s*/i,N=e=>(e.tagName===`TEXTAREA`?e.value||``:M(e)).replace(Te,``).replace(we,(e,t,n)=>(t?`
`:``)+n.toLowerCase()+`) `).replace(xe,``).trim().replace(/^(?:[a-h]\)\s*)+$/i,``);async function Pe(e,t){let n=null,r=new Set,i=[];for(let a=0;a<t;a++){a>0&&await ae(500);let t=await y(b(e.slot,e.qid,`all`));if(n=t,[...t.querySelectorAll(`.que`)].forEach(e=>{let t=(e.id||``).match(/^question-(\d+)-(\d+)$/),n=t?t[1]:e.id;n&&!r.has(n)&&(r.add(n),i.push(e))}),e.summe!=null&&i.length>=e.summe)break}return{bloecke:i,letzterDoc:n}}async function Fe(e,t){if(!e.length||!e.some(e=>_e(e)))return null;let n=e[0],r=n.querySelector(`.graderinfo`),i=r?r.innerText.trim():``,a=Ue(n),o=null;if(a&&a.gesamt>a.ist)try{let e=await L(t.qid);e&&e.horizont&&(i=e.horizont,o=a.gesamt)}catch{}let s={name:t.name,qid:t.qid,slot:t.slot,aufgabe:M(n.querySelector(`.qtext`)),zustaendig:C(i),vonFreitext:/moodle[-\s]?ai[-\s]?freitext/i.test(i),...(()=>{let e=ye(i);return{fach:e.fach||``,jahrgang:e.jahrgang||``,niveau:e.niveau||``}})(),horizontProzent:T(i),feedback:(i.match(/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel)\s*\]?\s*$/im)||[])[1]||`Mittel`,horizont:E(i),max:m((n.querySelector(`input[name$="-maxmark"]`)||{}).value)??1,...o?{horizont_aus_fassung:o}:{}},c=[];return e.forEach(e=>{let n=(e.id||``).match(/^question-(\d+)-(\d+)$/);if(!n)return;let r=_e(e),i=e.querySelector(`input[name$="-mark"]`),a=e.querySelector(`textarea[name$="-comment"]`);if(!r||!i)return;let o=String(i.value||``).trim()!==``;c.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:n[1],antwort:N(r),max:m((e.querySelector(`input[name$="-maxmark"]`)||{}).value)??s.max,markfeld:i.name,kommentarfeld:a?a.name:null,hat_kommentar:!!(a&&a.value.trim()),schon_bewertet:o,bisher:o?m(i.value):null})}),{frage:s,versuche:c}}async function F(e,t){let n=ge();if(!n.length)throw Error(`Auf dieser Seite steht keine Fragenübersicht.`);let r={},i={},a=[],o=[],s=0,c=0,u=0,f=0,p=0,m=0,ee=0,h=[...n];return await Promise.all(Array.from({length:1},async()=>{for(;h.length;){let d=h.shift();try{let{bloecke:e}=await Pe(d,l?3:8),n=await Fe(e,d);if(!n)f++;else{let e=n.frage.name||d.slot+`|`+d.qid,o=n.frage.zustaendig,s=o===`grader`,f=O.nurMitMarker&&o!==`coach`&&!l;s||f?i[e]||(i[e]={...n.frage,grund:s?`grader`:`kein-marker`},s?p++:ee++):(r[e]||(r[e]=n.frage,n.frage.horizont?o||m++:u++),n.versuche.forEach(e=>{if(e.schon_bewertet&&!t){c++;return}a.push(e)}))}}catch(e){o.push({frage:d.name,meldung:e.message})}s++,e(s,n.length,a.length)}})),a.forEach((e,t)=>{e.nr=t+1}),{meta:{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:(()=>{let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return e?e.textContent.trim():``})(),cmid:d,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.length,fragen_mit_horizont:Object.values(r).filter(e=>e.horizont).length,fragen_ohne_horizont:u,fragen_fuer_grader:p,fragen_ohne_marker:m,streng_uebersprungen:ee,nur_mit_marker:!!O.nurMitMarker,keine_freitextfrage:f,antworten:a.length,uebersprungen:c,max_sprachabzug_prozent:j()},fragen:r,fremde:i,antworten:a,fehler:o}}function Le(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function ze(e){let t=new Map;return(e||[]).forEach(e=>{let n=e.slot+`|`+e.qid;t.has(n)||t.set(n,{slot:e.slot,qid:e.qid,eintraege:[]}),t.get(n).eintraege.push(e)}),[...t.values()]}async function Be(e,t,n){let r=ze(e),i=0,a=0,o=0;for(let e of r){try{let n=(await y(b(e.slot,e.qid,`all`))).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);let r=Le(n);e.eintraege.forEach(e=>{let n=[];r.has(e.markfeld)||n.push(`Punktefeld`),e.text&&e.kommentarfeld&&!r.has(e.kommentarfeld)&&n.push(`Kommentarfeld`),n.length?(a++,t(`✗ ${n.join(` und `)} fehlt — ${e.frage}`,oe(e))):i++})}catch(n){a+=e.eintraege.length,t(`✗ Seite ${e.eintraege[0].frage}: ${n.message}`)}o++,n(o,r.length)}return{ok:i,fehler:a,gruppen:r.length,trocken:!0}}async function Ve(e,t,n){let r=null,i=new URLSearchParams,a=new Set;for(let o=0;o<n;o++){o>0&&await ae(500);let n=(await y(e)).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);r=n;let s=Le(n);if([...new Set(s.keys())].forEach(e=>{a.has(e)||(i.set(e,s.get(e)),a.add(e))}),t.every(e=>i.has(e)))break}return{form:r,felder:i}}async function I(e,t,n,r){let i=ze(e),a=0,o=0,s=0,c=[];for(let e of i){try{let r=b(e.slot,e.qid,`all`),{form:i,felder:s}=await Ve(r,e.eintraege.map(e=>e.markfeld),8),l=s,u=[];if(e.eintraege.forEach(e=>{if(!l.has(e.markfeld)){o++,c.push(e),n(`✗ Punktefeld nicht auf der Seite — ${e.frage}`,oe(e));return}if(l.set(e.markfeld,h(e.punkte)),e.text&&e.kommentarfeld&&l.has(e.kommentarfeld)){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(O.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim();e&&(n+=`<p><em><small>`+_(e)+`</small></em></p>`)}l.set(e.kommentarfeld,n)}u.push(e)}),u.length){let e=[...i.elements].find(e=>e.type===`submit`&&e.name);e&&l.set(e.name,e.value);let t=new URL(i.getAttribute(`action`)||r,r).href,s=await fetch(t,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:l.toString()});if(!s.ok)throw Error(`HTTP `+s.status+` beim Speichern`);let d=u.slice(),f=new Map;for(let e=0;e<8&&d.length;e++){e>0&&await ae(500);let t=await y(r);d=d.filter(e=>{let n=t.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`),r=n?m(n.value):null;return r!==null&&Math.abs(r-e.punkte)<.005?(f.set(e,r),!1):(f.set(e,r),!0)})}u.forEach(e=>{if(!d.includes(e))a++,n(`✓ ${e.frage} — ${h(e.punkte)} von ${h(e.max)}`,oe(e));else{o++,c.push(e);let t=f.get(e);n(`✗ ${e.frage} — steht auf ${t==null?`keinem Wert`:h(t)} statt ${h(e.punkte)}`,oe(e))}})}}catch(t){o+=e.eintraege.length,c.push(...e.eintraege),n(`✗ ${e.eintraege[0].frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,fehlgeschlagen:c}}async function He(e,t,n,r){let i=e,a=0,o=0,s=0;for(let e=1;e<=3&&i.length;e++){s=e,e>1&&(n(`↻ Versuch ${e}/3: ${i.length} Eintrag/Einträge erneut …`),await ae(1500));let c=await I(i,t,n,r);a+=c.ok,o+=c.gruppen,i=c.fehlgeschlagen}return{ok:a,fehler:i.length,gruppen:o,versuche:s}}function Ue(e){let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function L(e){let t=[...(await y(x(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!t)return null;let n=[...(await y(new URL(t.getAttribute(`href`),x(e)).href)).querySelectorAll(`table tbody tr`)];if(!n.length)return null;let r=null;for(let e of n)for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){r=e[1];break}}if(!r||String(r)===String(e))return null;let i=(await y(x(r))).querySelector(`[name="graderinfo[text]"]`);if(!i)return null;let a=new DOMParser().parseFromString(String(i.value||``),`text/html`),o=(a.body?a.body.textContent:``).trim();return o?{qid:r,horizont:o}:null}function We(e,t,n){let r=ce.test(le(t))?t:se+`
`+t;return Ke(e,()=>`<p>`+_(r).replace(/\n/g,`<br>`)+`</p>`,r,n)}function Ge(e){let t=`<p>`+se+`</p>`;return Ke(e,e=>t+(e||``),se,!1)}async function Ke(e,t,n,r){let i=x(e),a=await y(i),o=[...a.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`))||[...a.forms].find(e=>e.querySelector(`[name*="graderinfo"]`));if(!o)throw Error(a.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let s=Le(o),c=`graderinfo[text]`;if(!s.has(c))throw Error(`Feld „graderinfo[text]" nicht im Formular`);if(r)return{ok:!0,feld:c,vorher:s.get(c)||``};s.set(c,t(s.get(c)||``));let l=[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name===`submitbutton`)||[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name&&e.name!==`cancel`);if(!l)throw Error(`Kein Speichern-Knopf im Formular`);s.set(l.name,l.value);let u=new URL(o.getAttribute(`action`)||i,i).href,d=await fetch(u,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!d.ok)throw Error(`HTTP `+d.status+` beim Speichern`);let f=null;try{f=new URL(d.url).searchParams.get(`lastchanged`)}catch{}let p=(await y(f?x(f):i)).querySelector(`[name="${CSS.escape(c)}"]`),m=p?String(p.value||``).replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,ee=String(n).replace(/\s+/g,` `).trim().slice(0,30);if(!m||!m.includes(ee.slice(0,20)))throw Error(f?`Text nicht angekommen (geprüft an der neuen Fragenversion)`:`Nicht gegengeprüft: Moodle hat keine neue Fragen-Nummer zurückgemeldet. Sieh in der Frage selbst nach — gespeichert sein kann es trotzdem.`);return{ok:!0,feld:c,neueId:f}}let qe=`[MOODLE_AI_COACH_DATEN]`;function Je(){let e=A().jahrgang;return e?`Jahrgang `+e:`Sekundarstufe I`}function Ye(){let e=A().jahrgang;return Se(e)===`sek2`?`Es lesen Schülerinnen und Schüler der Oberstufe (Jahrgang ${e}). Sie sollen daraus
lernen — also klar, fachlich genau und ohne Umschweife, wie eine Lehrkraft, die einer
Oberstufenschülerin etwas erklärt.`:`Es lesen Schülerinnen und Schüler ${e?`des Jahrgangs `+e:`der Mittelstufe`}, viele davon
schreibschwach. Sie sollen daraus lernen — also schreibst du wie eine Deutschlehrkraft, die
einem Kind dieses Alters etwas erklärt.`}function Xe(){return O.kompaktPrompt?$e():Ze()}function Ze(){let e=j();return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:
1. „Willkommen beim Moodle AI Freitext Grader."
2. „Ich bewerte kurze Freitextantworten nach dem Erwartungshorizont, der in der
   Aufgabe hinterlegt ist, und schreibe jedem Schüler eine Rückmeldung zur Sprache.
   Entscheiden tust du."
3. „Der „Moodle AI Freitext Grader" wurde von T. Henken und A. Spielhoff entwickelt und ist unter der Lizenz
   CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen,
   solange du ihn nennst."

═══════════════════════════════════════════════════════
BEWERTUNGSMASSSTAB
═══════════════════════════════════════════════════════

${ne(A())}

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Die Schülerinnen und Schüler haben eine Frage in ein bis drei Sätzen beantwortet.
Zu jeder Aufgabe steht unter „horizont" der Erwartungshorizont der Lehrkraft: die
Kernaussage, was enthalten sein muss, was auch als richtig gilt und – am wichtigsten –
eine Abstufung, welcher Prozentsatz wofür vergeben wird.

Deine Aufgabe hat zwei Teile, die STRIKT getrennt bleiben:
  1. INHALT  – wie gut trifft die Antwort den Erwartungshorizont?
  2. SPRACHE – welche Sprachfehler stehen im Text?

═══════════════════════════════════════════════════════
TEIL 1 – INHALT
═══════════════════════════════════════════════════════

Vergib einen Prozentwert nach der Abstufung, die im Horizont unter „Inhalt:" steht.
Halte dich an diese Stufen. Erfinde keine Zwischenwerte und keine eigene Skala –
die Lehrkraft hat für diese Aufgabe bereits entschieden.

Steht im Horizont ausnahmsweise keine Abstufung, benutze 100 / 75 / 50 / 25 / 0.

Es gelten die Grundregeln oben. Dazu: Eine Antwort in Stichworten ist inhaltlich nicht
schlechter – der Satzbau wird in Teil 2 bewertet, nicht hier.

═══════════════════════════════════════════════════════
TEIL 2 – SPRACHE
═══════════════════════════════════════════════════════

Du zählst die Fehler. Den Abzug rechnet die Erweiterung daraus selbst aus –
schreibe nirgends einen Abzug oder eine Punktzahl hin.

Zähle als Fehler, was eine strenge Deutschlehrkraft anstreichen würde:

SCHWER (zählt doppelt):
  • Satz ohne Prädikat oder abgebrochener Satz
  • Satzbau so falsch, dass man den Satz zweimal lesen muss

NORMAL (zählt einfach):
  • falscher Fall oder falscher Numerus („die Atome verbindet sich")
  • falsche Zeitform
  • Nomen kleingeschrieben oder Verb großgeschrieben
  • Fachbegriff falsch geschrieben
  • sonstiger Rechtschreibfehler
  • fehlender Punkt am Satzende oder fehlendes Komma vor dem Nebensatz
  • Umgangssprache statt Fachsprache („das Zeug", „macht kaputt")

Zählregeln:
• Derselbe Fehler im selben Wort zählt nur einmal, auch wenn das Wort mehrfach
  vorkommt.
• Zähle nur, was du benennen kannst. Ein Bauchgefühl ist kein Fehler.
• Eine leere Antwort hat keine Sprachfehler – dort ist der Inhalt 0 %.

${Ae(e,`der Aufgabenpunkte`)}

═══════════════════════════════════════════════════════
TEIL 3 – RÜCKMELDUNG
═══════════════════════════════════════════════════════

Das Feedback ist das eigentliche Produkt. ${Ye()}

SPRACHE — so schreibst du:
• Kurze Hauptsätze. Ein Gedanke pro Satz. KEINE verschachtelten Sätze.
• Sag die Regel, nicht nur die Korrektur.
  Schwach: „Der Name wird großgeschrieben."
  Gut:     „Vor „Löschsand" kannst du „der" setzen. Solche Wörter sind Nomen. Nomen
            schreibt man groß: Löschsand."
• Stell falsch und richtig direkt gegenüber: löchsand → Löschsand.
  Lange Satzzitate sind für schwache Leser schwerer als ein Wortpaar.
• Kein Fachjargon ohne Erklärung. „Nomen", „Satzende", „Komma" sind bekannt;
  „Prädikat", „Kasus", „Numerus" erklärst du in eigenen Worten.
• Höchstens zwei Korrekturen je Zeile. Der Rest bleibt ungesagt — lieber weniger,
  das dafür verstanden.
• Freundlich und sachlich. Keine Floskeln, keine Emojis, kein Ausrufezeichen-Gewitter.

GLIEDERUNG — du schreibst KEINEN Fließtext, sondern füllst Felder:
Aus ihnen baut die Erweiterung selbst das fertige Feedback mit Überschrift, Umbrüchen
und Unterstreichungen. Schreib deshalb nirgends HTML, keine Sternchen, keine Zeilen-
umbrüche in die Felder.

  lob             – nur bei 95 % und mehr der Punkte: ein Satz Anerkennung,
                    konkret auf die Aufgabe bezogen („Du hast die Aufgabe zum
                    Löschsand richtig gut beantwortet.")
  inhalt          – was inhaltlich fehlte oder falsch war, und wie es richtig heißt.
                    Bei voller Punktzahl: was genau gut war.
  rechtschreibung – nur Rechtschreibung: Groß- und Kleinschreibung, falsch
                    geschriebene Wörter. Mit der Regel dahinter.
  grammatik       – nur Satzbau und Zeichensetzung: fehlende Punkte und Kommas,
                    Sätze ohne Trennung, falsche Fälle und Zeitformen.
  tipp            – freiwillig: EIN Merksatz für das nächste Mal. Nur, wenn er wirklich
                    hilft. Nicht bei jeder Antwort.

Felder, zu denen es nichts zu sagen gibt, lässt du weg. Eine Antwort ohne
Rechtschreibfehler bekommt keine Zeile „Rechtschreibung".

DIE DREI FÄLLE:

1. Volle Punktzahl, keine Sprachfehler → NUR das Feld „lob", sonst nichts.
   Beispiel: lob = „Das hast du super beantwortet — Name und Funktion sind richtig."

2. 95 % oder mehr, aber eine Kleinigkeit → zuerst „lob", dann die eine Zeile, die es
   betrifft. Erst loben, dann verbessern.
   Beispiel: lob = „Du hast die Aufgabe zum Löschsand richtig gut beantwortet."
             grammatik = „Am Satzende fehlt der Punkt."

3. Unter 95 % → kein Lob-Feld. Zuerst „inhalt", dann Rechtschreibung und Grammatik,
   wo nötig.

Die Musterlösung schreibst du NICHT. Liegt die Antwort unter 100 %, hängt die
Erweiterung von sich aus die Zeile „So hättest du es schreiben können: …" an und setzt
dort die Kernaussage aus dem Erwartungshorizont ein — wörtlich das, was die Lehrkraft
hinterlegt hat. Im Feld „inhalt" steht deshalb nur, WAS fehlte oder falsch war, nicht
die fertige Lösung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert. Je Frage eine Kopfzeile mit der
Aufgabe und der Kernaussage aus dem Horizont, darunter die Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|
| 1 | „Hefe wandelt Zucker in Alkohol um" | 50 | 1 normal | Prozess nicht benannt |

• „Nr" ist die Zahl aus dem Feld „nr" – nicht deine eigene Zählung.
• „Sprachfehler": Anzahl und Art, zum Beispiel „2 normal, 1 schwer".
• „Begründung": ein Halbsatz, der sich auf die Abstufung im Horizont bezieht.
• Keine Punkte- und keine Abzugsspalte. Das rechnet die Erweiterung.

Halte danach an und schreibe:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 75.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir das JSON aus."

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok" (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH):

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "Du hast geschrieben, dass Hefe Zucker umwandelt. Das stimmt. Es fehlt, was dabei entsteht: Alkohol und Kohlenstoffdioxid.",
        "rechtschreibung": "Vor „Zucker" kannst du „der" setzen. Solche Wörter sind Nomen, und Nomen schreibt man groß: Zucker.",
        "grammatik": "Am Satzende fehlt der Punkt."
      } },
    { "frage": "Löschsand (AFB I)", "qubaid": "2433020", "slot": "6",
      "inhalt": 100, "fehler": [],
      "rueckmeldung": { "lob": "Das hast du super beantwortet — Name und Funktion sind richtig." } }
  ]
}
\`\`\`

• Ein Eintrag je Versuch. „qubaid" und „slot" unverändert aus den Daten.
• „inhalt" ist der Prozentwert aus der Abstufung des Horizonts.
• „fehler" ist die Liste der gezählten Sprachfehler, leer bei fehlerfreiem Text.
• „rueckmeldung" enthält die Felder aus Teil 3. Nur die füllen, zu denen es etwas zu
  sagen gibt; leere Felder ganz weglassen. Jedes Feld ist ein oder zwei ganze Sätze,
  ohne Zeilenumbruch und ohne Formatierungszeichen — Überschrift, Absätze und
  Unterstreichungen setzt die Erweiterung selbst.
• JEDER Eintrag bekommt eine Rückmeldung, auch die fehlerfreien: dort steht das
  Lob-Feld allein.
• Keine Punktzahlen, kein Abzug, keine Feldnamen.
• WICHTIG – Anführungszeichen im JSON: Willst du in einem Rückmeldungstext ein Wort
  hervorheben oder ein Zitat setzen, benutze dafür EINFACHE Anführungszeichen ('so')
  oder schreibe es ohne Anführungszeichen. Gerade doppelte Anführungszeichen ("so")
  NIEMALS in einem JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die
  JSON-Begrenzung und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Schreibe darunter: „Kopiere diesen Block in die Erweiterung, Reiter „2 · Eintragen" —
die Prüfung startet beim Einfügen von selbst."

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Hat die Lehrkraft in Schritt 1 Prozentwerte geändert, ist das mehr als eine
Einzelfallentscheidung: Der Horizont bildet ihren Maßstab an dieser Stelle nicht ab
und würde beim nächsten Durchgang denselben Fehler wieder erzeugen.

Deshalb NACH dem JSON – aber nur, wenn tatsächlich korrigiert wurde:

1. Nenne je betroffener Frage in einem Satz, welche Regel sich aus der Korrektur
   ergibt. Nicht „Nr. 7 wurde auf 100 gesetzt", sondern die dahinterliegende
   Entscheidung: „Beim Löschsand reicht ‚löscht Brände' für 100 % – der Metallbrand
   muss nicht genannt werden."
2. Sag dazu, was sich im Horizont ändern müsste: meist wandert ein Teilaspekt von
   „Muss enthalten" nach „Auch richtig", und die betroffene Prozentstufe entfällt
   oder wird neu beschrieben.
3. Biete an, die Horizonte dieser Fragen neu zu schreiben, mit dem Weg dorthin:
   „Reiter 3 · Horizont, Häkchen ‚Auch Fragen einbeziehen, die schon einen Horizont
   haben' setzen, Prompt kopieren – ich baue die Korrekturen dann direkt ein."
4. Merke dir die Korrekturen für diesen Fall, damit sie in den neuen Horizont
   einfließen, wenn der Horizont-Prompt gleich nachkommt.

Wurde nichts geändert, lässt du diesen Schritt ersatzlos weg – kein „hier gab es
nichts zu korrigieren".

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

- „fragen"    – je Frage: Aufgabentext, Maximalpunkte und der Erwartungshorizont
                aus dem Moodle-Feld „Bewerterinformation".
- „antworten" – je Versuch die Schülerantwort mit „nr", „qubaid" und „slot".

${qe}`}function Qe(e){return te({einzeln:!1,stufe:e||`Mittel`})}function $e(){let e=j();return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST (KOMPAKT)
═══════════════════════════════════════════════════════

${ne(A())}

Falls du Zugriff auf die Skills „2-didaktik-bewertung“ und „3-moodle-erweiterungen“
von A. Spielhoff hast: Wende deren Bewertungslogik an — Inhalt strikt getrennt von
Sprache, die Abstufung im Horizont ist verbindlich (keine eigene Skala erfinden),
Sprachfehler zählen (schwer = doppelt) statt selbst Punkte abzuziehen, die
Feedback-Gliederung in Felder (lob/inhalt/rechtschreibung/grammatik/tipp) mit
kurzen, schülergerechten Sätzen (${Je()}), und die drei Rückmeldungsfälle
(volle Punktzahl → nur Lob; ≥95 % → Lob zuerst; darunter → kein Lob).

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt“ ausschalten) statt zu raten — ohne die genauen Regeln (besonders
die Trennung Inhalt/Sprache und die Feld-Gliederung) sind falsche Bewertungen und
unpassendes Feedback wahrscheinlich.

${Ae(e,`der Aufgabenpunkte`)}
Punkte NICHT selbst ausrechnen, nur Inhalt-Prozent und Fehlerliste angeben — das
rechnet die Erweiterung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert, mit Kopfzeile (Aufgabe +
Kernaussage aus dem Horizont), dann eine Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Datensatz. Keine Punkte- und keine Abzugsspalte. Halte
danach an und frage: „Passt das so? Nenne mir die Nummern, die ich ändern soll, zum
Beispiel: 3 auf 75. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok“ (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH) ausgeben:

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "…",
        "rechtschreibung": "…",
        "grammatik": "…"
      } }
  ]
}
\`\`\`

Ein Eintrag je Versuch, „qubaid“/„slot“ unverändert übernehmen. „inhalt“ ist der
Prozentwert aus der Horizont-Abstufung. „fehler“ leer bei fehlerfreiem Text.
„rueckmeldung“ nur die Felder füllen, zu denen es etwas zu sagen gibt (leere Felder
weglassen), jedes ein bis zwei ganze Sätze ohne Formatierung. Musterlösung NICHT
selbst schreiben — das hängt die Erweiterung an. WICHTIG: Hebst du in einem
Rückmeldungstext ein Wort hervor, benutze dafür einfache Anführungszeichen ('so'),
nie gerade doppelte ("so") — die brechen das JSON, weil sie die JSON-Begrenzung
sind. Satz danach: „Kopiere diesen Block
in die Erweiterung, Reiter „2 · Eintragen“ — die Prüfung startet beim Einfügen von selbst.“

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Wurden in Schritt 1 Prozentwerte geändert, nenne je betroffener Frage in einem Satz
die dahinterliegende Regel (nicht „Nr. 7 auf 100", sondern z. B. „Beim Löschsand
reicht ‚löscht Brände' für 100 % – der Metallbrand muss nicht genannt werden"), sag
was sich im Horizont ändern müsste, und biete an, die Horizonte über Reiter 3 neu zu
schreiben. Ohne Korrektur diesen Schritt ersatzlos weglassen.

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: Aufgabentext, Maximalpunkte, Erwartungshorizont aus
„Bewerterinformation“. „antworten“ – je Versuch die Schülerantwort mit „nr“,
„qubaid“, „slot“.

${qe}`}function et(e){let t=(O.promptOverride||``).trim()||(O.kompaktPrompt?$e():Ze()),n=(Object.values(e&&e.fragen||{}).some(e=>e&&e.feedback===`Kurz`)?`FEEDBACKLÄNGE JE AUFGABE: Steht bei einer Aufgabe "feedback": "Kurz", gib für diese Aufgabe höchstens zwei Felder aus (inhalt und höchstens ein weiteres), je EIN kurzer Satz. Bei "Mittel" gilt das Format wie beschrieben.

`:``)+"```json\n"+JSON.stringify(e,(e,t)=>e===`bisher`?void 0:t,1)+"\n```";return t.includes(qe)?t.replace(qe,n):t+`

`+n}function R(e){let t=(O.horizontPromptOverride||``).trim(),n=new Set(e.map(e=>e.feedback===`Kurz`?`Kurz`:`Mittel`)),r=t||Qe(n.size>1?`gemischt`:[...n][0]),i="```json\n"+JSON.stringify(e.map(e=>{let t={qid:e.qid,frage:e.name,aufgabe:e.aufgabe,max:e.max};return n.size>1&&(t.feedback=e.feedback===`Kurz`?`Kurz`:`Mittel`),e.horizont&&(t.horizont_bisher=w(e.horizont)),t}),null,1)+"\n```",a=String((typeof Ct==`function`?Ct():``)||``).trim(),o=a?`═══════════════════════════════════════════════════════
ÄNDERUNGSWÜNSCHE DER LEHRKRAFT
═══════════════════════════════════════════════════════

Diese Vorgaben haben Vorrang vor allem, was in „horizont_bisher" steht.
Wo sie einem bisherigen Horizont widersprechen, gilt der Wunsch.

`+a+`

`:``,s=`[MOODLE_AI_COACH_AUFGABEN]`,c=ee(e.map(e=>e.aufgabe),[]),l=o+(c?c+`

`:``)+i;return r.includes(s)?r.replace(s,l):r+`

`+l}let z=v(`button`,`co-fab`);z.title=`Moodle AI Freitext Grader`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`Freitext Grader`,e.className=`co-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),z.textContent=`Co`}),z.appendChild(e)}catch{z.textContent=`Co`}u||document.body.appendChild(z);let B=v(`div`,u?`co-panel co-eingebettet`:`co-panel co-hidden`);B.innerHTML=`
    <div class="co-head">
      <div class="co-titelblock">
        <span class="co-title">Freitext Grader · Kurztest <span class="co-version"></span></span>
        <span class="co-untertitel">(Zufalls-)Freitexte als Kurztest bewerten</span>
      </div>
      <button class="co-close" title="Schließen">✕</button>
    </div>
    <div class="co-tabs">
      <button class="co-tab co-aktiv" data-tab="lesen">1 · Bewerten</button>
      <button class="co-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="co-tab" data-tab="horizont">3 · Horizonte <span class="co-badge co-hidden"></span></button>
      <button class="co-tab" data-tab="opt">⚙</button>
    </div>

    <div class="co-body" data-panel="lesen">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Hier bewertest du alle Kurztest-Antworten dieses Tests auf einmal. Die Erweiterung sammelt die Antworten aller Versuche und baut daraus mit den Erwartungshorizonten einen Prompt. Diesen in die KI einfügen; deren Antwort kommt in Reiter 2.</p>
      </details>
      <p class="co-meta"></p>
      <div class="co-kasten">
        <div class="co-kastenkopf">Für diese Bewertung</div>
        <label class="co-label">Anrede im Feedback
          <select class="co-anrede">
            <option value="auto">Automatisch nach Jahrgang</option>
            <option value="du">Du</option><option value="sie">Sie</option>
          </select>
        </label>
        <label class="co-label"><span class="co-abzuglabel">Rechtschreibung: Höchstabzug in % der Aufgabenpunkte</span>
          <select class="co-abzug">
            <option value="0">0 % – kein Abzug</option><option value="5">5 %</option>
            <option value="10">10 %</option><option value="15">15 %</option>
            <option value="20">20 %</option><option value="25">25 %</option><option value="30">30 %</option>
          </select>
        </label>
        <p class="co-abzuginfo"></p>
        <details class="co-details co-mehr">
          <summary>Was bedeuten Anrede und Rechtschreibung?</summary>
          <p class="co-hinweis"><strong>Anrede:</strong> „Automatisch" schreibt bis Jahrgang 10 „Du hast …",
          ab Jahrgang 11 „Sie haben …". Der Jahrgang steht im Erwartungshorizont der Aufgaben.</p>
          <p class="co-hinweis"><strong>Rechtschreibung:</strong> So viel Prozent der Aufgabenpunkte kann die
          Sprache höchstens kosten. Es gibt einen Wert für die Sekundarstufe I (bis Jahrgang 10) und einen für
          die Oberstufe – dieselben wie bei Klausuren. Auch bei 0 % bekommen die Lernenden eine Rückmeldung
          zur Sprache.</p>
        </details>
        <p class="co-kastenfuss"></p>
      </div>
      <label class="co-check"><input type="checkbox" class="co-bereits">
        Auch schon bewertete Versuche noch einmal vorlegen</label>
      <button class="co-go">Kurztest-Aufgaben durchsuchen</button>
      <p class="co-hinweis">Klausur-Aufgaben in diesem Test werden erkannt, hier übersprungen und
      im Ergebnis verlinkt – sie werden auf ihrer eigenen Bewertungsseite bewertet.</p>
      <div class="co-progress co-hidden"><div class="co-bar"></div><span class="co-ptext"></span></div>
      <div class="co-result co-hidden">
        <p class="co-summary"></p>
        <p class="co-hinweis co-hzhinweis co-hidden"></p>
        <p class="co-warn co-hidden"></p>
        <div class="co-prozentbox co-hidden"></div>
        <div class="co-zust co-hidden"></div>
        <div class="co-uebersichtshinweis co-hidden">
          <p class="co-hinweis">Mehrere Kurztests lassen sich auch auf einmal bewerten: auf der Übersicht des
          Tests, alle Kurztest-Fragen zusammen in einem Prompt.</p>
          <a class="co-zweit co-uebersichtlink">Zur Übersicht →</a>
        </div>
        <button class="co-copy">📋 Prompt + Daten kopieren</button>
        <button class="co-copy2 co-zweit">📋 nur JSON</button>
        <p class="co-groesse"></p>
        <div class="co-list"></div>
      </div>
      <p class="co-error co-hidden"></p>
      <details class="co-details">
        <summary>Bewertungs-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit bewertet die KI die Schülerantworten.</strong>
        Hier steht der vollständige Prompt, den „📋 Prompt + Daten kopieren" verschickt —
        du kannst ihn lesen und ändern. „Standard einfügen" holt die mitgelieferte Fassung
        zurück. Der Platzhalter <code>[MOODLE_AI_COACH_DATEN]</code> wird beim Kopieren
        durch die Fragen und Antworten aus Moodle ersetzt.</p>
        <textarea class="co-prompt" rows="8"></textarea>
        <button class="co-promptstd co-zweit">Standard einfügen</button>
        <button class="co-promptsave co-zweit">Prompt speichern</button>
      </details>
    </div>

    <div class="co-body co-hidden" data-panel="eintrag">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Hier fügst du die Bewertung der KI ein. Die Erweiterung rechnet die Punkte aus Inhaltsstufe und Fehlerzahl selbst, zeigt alles zur Kontrolle und trägt Punkte und Rückmeldung je Versuch in Moodle ein.</p>
      </details>
      <p class="co-hinweis">Hier das Bewertungs-JSON der KI einfügen. Die Punkte rechnet
      die Erweiterung aus Inhalt und Fehlerzahl selbst.</p>
      <textarea class="co-json" rows="6" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <label class="co-check"><input type="checkbox" class="co-ki" checked>
        KI-Hinweis ans Feedback anhängen <span class="co-hinweis">(Standard und Wortlaut unter ⚙)</span></label>
      <p class="co-kivorschau"></p>
      <button class="co-pruef co-hidden">🔍 Prüfen</button>
      <p class="co-pinfo co-hidden"></p>
      <div class="co-schreibknoepfe co-hidden">
        <button class="co-alle">Alle eintragen</button>
      </div>
      <div class="co-progress2 co-hidden"><div class="co-bar2"></div><span class="co-ptext2"></span></div>
      <p class="co-abschluss co-hidden"></p>
      <div class="co-log co-hidden"></div>
      <div class="co-vorschau"></div>
    </div>

    <div class="co-body co-hidden" data-panel="horizont">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Übersicht über alle Freitextaufgaben dieses Tests: Ist es ein Kurztest oder eine
        Klausur? Hat sie einen aktuellen Erwartungshorizont? Erstellt oder überarbeitet wird ein Horizont
        immer für <strong>eine</strong> Aufgabe – im Frageneditor oder auf ihrer Bewertungsseite (Reiter
        „Horizont"). Nur dort lassen sich Modus, Feedbacklänge, Fach, Jahrgang und Niveau einstellen.</p>
      </details>
      <p class="co-hinweis co-hzregel"><strong>Horizonte entstehen Aufgabe für Aufgabe.</strong> Öffne die
      Aufgabe über einen der Links unten – im Frageneditor oder auf ihrer Bewertungsseite – und erstelle
      oder überarbeite ihren Horizont dort im Reiter „Horizont“.</p>
      <div class="co-aufgabenliste"><p class="co-hinweis">Erst in Reiter 1 „Kurztest-Aufgaben durchsuchen" –
      dann stehen hier alle Aufgaben mit ihren Links.</p></div>
      <div class="co-hidden co-althorizont">
      <p class="co-hinweis">Der Erwartungshorizont gehört in die Frage, nicht in die
      Erweiterung — einmal erstellt, gilt er dauerhaft und wandert beim Export mit.
      Hier wird er angelegt, wo er fehlt — oder für vorhandene neu geschrieben.</p>
      <div class="co-ohneliste"></div>
      <label class="co-check"><input type="checkbox" class="co-halle">
        Auch Fragen einbeziehen, die schon einen Horizont haben — <strong>der wird dabei
        überschrieben</strong></label>
      <label class="co-feldkopf">Was soll anders werden? (geht mit in den Prompt)</label>
      <textarea class="co-hwunsch" rows="3"
        placeholder="z. B.: Beim Löschsand müssen Metallbrände NICHT genannt werden — Name plus „löscht Brände“ reicht für 100 %."></textarea>
      <p class="co-hinweis">Ohne diese Zeilen sieht das Sprachmodell nur den bisherigen
      Horizont — und der sagt ja gerade das, was du ändern willst. Es schreibt ihn dann
      fort. Was hier steht, hat im Prompt Vorrang vor dem bisherigen Horizont.</p>
      <p class="co-hinweis">Beim Neuschreiben bekommt die KI den bisherigen Horizont mit,
      damit sie weiß, wovon sie abweicht. Ersetzt wird er erst, wenn du die Antwort in
      Schritt 2 einfügst und einträgst.</p>
      <p class="co-schritt">Schritt 1 — Prompt holen</p>
      <button class="co-hcopy">📋 Prompt für Erwartungshorizont kopieren</button>
      <details class="co-details">
        <summary>Horizont-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit schreibt die KI den Erwartungshorizont</strong>
        für Fragen, die noch keinen haben — also das, was später in der Frage steht und
        wonach der Bewertungs-Prompt dann bewertet. Hier steht der vollständige Prompt,
        den der Knopf oben kopiert. Der Platzhalter
        <code>[MOODLE_AI_COACH_AUFGABEN]</code> wird beim Kopieren durch die Aufgaben
        ohne Horizont ersetzt.</p>
        <textarea class="co-hprompt" rows="8"></textarea>
        <button class="co-hpromptstd co-zweit">Standard einfügen</button>
        <button class="co-hpromptsave co-zweit">Prompt speichern</button>
      </details>
      <p class="co-schritt">Schritt 2 — Antwort der KI einfügen</p>
      <textarea class="co-hjson" rows="5" placeholder='{ "horizonte": [ … ] }'></textarea>
      <button class="co-hpruef co-hidden">🔍 Prüfen</button>
      <p class="co-hinfo co-hidden"></p>
      <div class="co-hliste"></div>
      <div class="co-progress3 co-hidden"><div class="co-bar3"></div><span class="co-ptext3"></span></div>
      <p class="co-habschluss co-hidden"></p>
      <div class="co-hlog co-hidden"></div>
      <div class="co-hknoepfe co-hidden">
        <button class="co-hschreib">In die Aufgaben eintragen</button>
      </div>
      </div>
    </div>

    <div class="co-body co-hidden" data-panel="opt">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Hier steht nur, was für alle Aufgaben gleich ist. Fach, Jahrgang, Niveau und
        Feedbacklänge gehören zur Aufgabe und stehen in ihrem Erwartungshorizont; Anrede und Rechtschreibung
        stehen im Reiter „1 · Bewerten" unter „Für diese Bewertung".</p>
      </details>
      <p class="co-hinweis">Diese Einstellungen gelten überall in der Erweiterung – auf der Kurztest-Übersicht
      ebenso wie auf der Bewertungsseite einer Aufgabe.</p>
      <label class="co-check"><input type="checkbox" class="co-kian"> KI-Hinweis unter das Feedback</label>
      <label class="co-label">Text des KI-Hinweises
        <textarea class="co-kitext" rows="3"></textarea>
      </label>
      <button class="co-kistd co-zweit">Standardtext einsetzen</button>
      <details class="co-details co-mehr">
        <summary>Was bedeutet „KI-Hinweis“?</summary>
        <p class="co-hinweis">Unter jedes eingetragene Feedback setzt die Erweiterung diesen Satz, kursiv
        und klein. Er kommt von der Erweiterung, nicht von der KI. Den Wortlaut kannst du ändern.</p>
      </details>
      <label class="co-check"><input type="checkbox" class="co-quellen"> Quellenangaben entfernen</label>
      <details class="co-details co-mehr">
        <summary>Was bedeutet „Quellenangaben entfernen“?</summary>
        <p class="co-hinweis">Manche KI-Chats hängen Quellenmarken wie [1] oder 【4†source】 an. Mit Häkchen
        entfernt die Erweiterung sie aus dem Feedback, bevor es eingetragen wird.</p>
      </details>
      <label class="co-check"><input type="checkbox" class="co-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <details class="co-details co-mehr">
        <summary>Was bedeutet „Kompakter Prompt“?</summary>
        <p class="co-hinweis">Der Bewertungsprompt verweist für die Bewertungslogik auf die Skills
        „2-didaktik-bewertung" und „3-moodle-erweiterungen", statt sie auszuschreiben – spart mehrere Tausend
        Zeichen. <strong>Nur einschalten, wenn die verwendete KI diese Skills wirklich kennt.</strong> Den
        Prompt selbst kannst du im Reiter 1 unter „Bewertungs-Prompt anpassen" lesen und ändern.</p>
      </details>
      <p class="co-hinweis"><strong>Nur auf der Kurztest-Übersicht:</strong></p>
      <label class="co-check"><input type="checkbox" class="co-nurmarker">
        Nur Fragen bewerten, die als Kurztest markiert sind</label>
      <details class="co-details co-mehr">
        <summary>Was bedeutet „Nur markierte Fragen bewerten“?</summary>
        <p class="co-hinweis">Ein Erwartungshorizont trägt in der ersten Zeile, wie die Aufgabe bewertet
        wird: <code>[moodle-ai-freitext: kurztest]</code> oder <code>[moodle-ai-freitext: klausur]</code>
        (ältere Horizonte: <code>[moodle-ai-coach]</code> bzw. <code>[moodle-ai-grader]</code>).
        Klausur-Aufgaben werden hier <strong>immer</strong> übersprungen. Das Häkchen betrifft nur Aufgaben
        <em>ohne</em> Marker: aus (Standard) werden sie hier bewertet, wenn ihr Horizont wie ein Kurztest
        aussieht, und im Ergebnis gemeldet; an bleiben sie liegen.</p>
      </details>
      <button class="co-optsave">Speichern</button>
      <button class="co-optreset co-zweit">Alles zurücksetzen</button>
      <p class="co-optinfo co-hidden"></p>
    </div>`,(u||document.body).appendChild(B),B.querySelector(`.co-version`).textContent=r;let V=e=>B.querySelector(e),H=null,tt=null,U=null,nt=`coachErnte_`+d+(l?`_slot`+l.slot:``);function rt(){try{t.storage.local.set({[nt]:H})}catch{}}try{t.storage.local.get([nt],e=>{let t=e&&e[nt];if(t&&!H){H=t;let e=V(`.co-meta`);e&&(e.textContent+=` · ${(t.antworten||[]).length} Antworten aus einem früheren Durchlauf geladen`)}})}catch{}if(z.addEventListener(`click`,()=>B.classList.toggle(`co-hidden`)),u){B.querySelector(`.co-head`).classList.add(`co-hidden`),B.querySelector(`.co-tabs`).classList.add(`co-hidden`),B.querySelectorAll(`[data-panel="horizont"], [data-panel="opt"]`).forEach(e=>e.classList.add(`co-hidden`)),B.querySelector(`[data-panel="eintrag"]`).classList.remove(`co-hidden`);let t=B.querySelector(`[data-panel="lesen"] .co-wozu`);t&&t.classList.add(`co-hidden`);let n=B.querySelector(`[data-panel="eintrag"] .co-wozu`);n&&n.classList.add(`co-hidden`);let r=B.querySelector(`.co-go`);r&&(r.textContent=`Antworten dieser Aufgabe laden`);let i=[...B.querySelectorAll(`[data-panel="lesen"] .co-hinweis`)].find(e=>/Klausur-Aufgaben in diesem Test/.test(e.textContent));i&&i.classList.add(`co-hidden`);let a=B.querySelector(`.co-uebersichtshinweis`);if(a&&e.uebersicht){a.classList.remove(`co-hidden`);let t=a.querySelector(`.co-uebersichtlink`);t.href=e.uebersicht}let o=v(`p`,`co-schritttitel`,`Ergebnis der KI einfügen und eintragen`);B.querySelector(`[data-panel="eintrag"]`).prepend(o)}V(`.co-close`).addEventListener(`click`,()=>B.classList.add(`co-hidden`));function it(e){if(u){let t=B.querySelector(`[data-panel="`+e+`"]`);t&&(e===`lesen`||e===`eintrag`)&&t.scrollIntoView({behavior:`smooth`,block:`start`});return}B.querySelectorAll(`.co-tab`).forEach(t=>t.classList.toggle(`co-aktiv`,t.dataset.tab===e)),B.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`co-hidden`,t.dataset.panel!==e))}let at=null;function ot(){at&&=(clearTimeout(at),clearInterval(at),null)}B.querySelectorAll(`.co-tab`).forEach(e=>{e.addEventListener(`click`,()=>{ot(),it(e.dataset.tab)})});function st(){let e=m(V(`.co-abzug`).value);return e===null||e<0?D.maxSprachabzug:Math.min(100,e)}function ct(){let e=st();V(`.co-abzuginfo`).textContent=ke(e,`der Aufgabenpunkte`)}function lt(){let e=V(`.co-kivorschau`),t=(O.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim();if(!V(`.co-ki`).checked||!t){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}V(`.co-ki`).addEventListener(`change`,lt),V(`.co-abzug`).addEventListener(`input`,ct),V(`.co-abzug`).addEventListener(`change`,async()=>{ct(),await pe({maxSprachabzug:st()});let e=Se(A().jahrgang)===`sek2`?`rsSek2`:`rsSek1`;o[e]=st(),await dt(e,String(st())),ut()});function ut(){let e=V(`.co-abzug`),t=A();e&&(e.value=String(j()),ct());let n=V(`.co-abzuglabel`);n&&(n.textContent=`Rechtschreibung: Höchstabzug in % der Aufgabenpunkte – `+(Se(t.jahrgang)===`sek2`?`Oberstufe (ab Jahrgang 11)`:`Sekundarstufe I (bis Jahrgang 10)`));let r=V(`.co-anrede`);r&&(r.value=o.anredeWahl||`auto`);let i=V(`.co-kastenfuss`);i&&(i.textContent=`Im Feedback steht „`+(t.anrede===`sie`?`Sie haben`:`Du hast`)+` …"`+(t.jahrgang?` · Jahrgang `+t.jahrgang:` · Jahrgang unbekannt (Horizont ohne Angabe)`)+`.`)}async function dt(e,n){try{let r=await t.storage.local.get([`magSettings`]),i=r&&r.magSettings||{};i[e]=n,await t.storage.local.set({magSettings:i})}catch{}}V(`.co-anrede`).addEventListener(`change`,async()=>{o.anredeWahl=V(`.co-anrede`).value,await dt(`anredeWahl`,o.anredeWahl),ut()}),V(`.co-nurmarker`).addEventListener(`change`,async e=>{await pe({nurMitMarker:e.target.checked})}),fe().then(()=>{ut(),V(`.co-kitext`).value=O.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,V(`.co-prompt`).value=O.promptOverride||Xe(),V(`.co-hprompt`).value=O.horizontPromptOverride||Qe(),V(`.co-nurmarker`).checked=!!O.nurMitMarker,V(`.co-kompakt`).checked=!!O.kompaktPrompt,V(`.co-kian`).checked=O.kiHinweis!==!1,V(`.co-ki`).checked=O.kiHinweis!==!1,V(`.co-quellen`).checked=O.entferneQuellen!==!1,ct(),lt()}),V(`.co-kistd`).addEventListener(`click`,()=>{V(`.co-kitext`).value=je});function ft(e){let t=V(`.co-optinfo`);t.textContent=e,t.classList.remove(`co-hidden`),setTimeout(()=>t.classList.add(`co-hidden`),3e3)}V(`.co-optsave`).addEventListener(`click`,async()=>{await pe({maxSprachabzug:st(),nurMitMarker:V(`.co-nurmarker`).checked,kompaktPrompt:V(`.co-kompakt`).checked,kiHinweis:V(`.co-kian`).checked,entferneQuellen:V(`.co-quellen`).checked,kiHinweisText:V(`.co-kitext`).value.trim()||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`}),V(`.co-ki`).checked=O.kiHinweis!==!1,O.promptOverride||(V(`.co-prompt`).value=Xe()),V(`.co-kitext`).value=O.kiHinweisText,ct(),lt(),ft(`Gespeichert ✓`),pt(V(`.co-optsave`),`✓ Gespeichert`,`Speichern`),setTimeout(()=>it(`lesen`),900)});function pt(e,t,n){e.textContent=t,setTimeout(()=>e.textContent=n,2e3)}V(`.co-promptstd`).addEventListener(`click`,()=>{V(`.co-prompt`).value=Xe(),pt(V(`.co-promptstd`),`✓ eingefügt`,`Standard einfügen`)}),V(`.co-promptsave`).addEventListener(`click`,async()=>{let e=V(`.co-prompt`).value.trim(),t=e===Xe().trim()||e===Ze().trim()?``:e;await pe({promptOverride:t}),pt(V(`.co-promptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),V(`.co-hpromptstd`).addEventListener(`click`,()=>{V(`.co-hprompt`).value=Qe(),pt(V(`.co-hpromptstd`),`✓ eingefügt`,`Standard einfügen`)}),V(`.co-hpromptsave`).addEventListener(`click`,async()=>{let e=V(`.co-hprompt`).value.trim(),t=e===Qe().trim()?``:e;await pe({horizontPromptOverride:t}),pt(V(`.co-hpromptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),V(`.co-optreset`).addEventListener(`click`,async()=>{await pe({...D,...Ne}),V(`.co-kian`).checked=!0,V(`.co-ki`).checked=!0,V(`.co-quellen`).checked=!0,V(`.co-abzug`).value=g(D.maxSprachabzug),V(`.co-nurmarker`).checked=D.nurMitMarker,V(`.co-kompakt`).checked=D.kompaktPrompt,V(`.co-kitext`).value=je,V(`.co-prompt`).value=Xe(),V(`.co-hprompt`).value=Qe(),ct(),lt(),ft(`Auf Standard zurückgesetzt — auch die Prompts in Reiter 1 und 3.`)}),V(`.co-meta`).textContent=(document.title||``).replace(/\s*\|.*$/,``).trim()||`Manuelle Bewertung`,V(`.co-go`).addEventListener(`click`,async()=>{let e=V(`.co-go`);e.disabled=!0,e.textContent=`läuft …`,V(`.co-error`).classList.add(`co-hidden`),V(`.co-result`).classList.add(`co-hidden`),V(`.co-progress`).classList.remove(`co-hidden`);try{H=await F((e,t,n)=>{V(`.co-bar`).style.width=Math.round(e/t*100)+`%`,V(`.co-ptext`).textContent=`${e} / ${t} Fragen · ${n} Antworten`},V(`.co-bereits`).checked);let e=H.meta,t=Object.values(H.fragen).filter(e=>e.horizont),n=Object.values(H.fragen).filter(e=>!e.horizont),r=Object.values(H.fremde||{}),i=Object.values(H.fragen).filter(e=>e.horizont_aus_fassung).length;V(`.co-summary`).textContent=`${e.antworten} Antworten auf ${Object.keys(H.fragen).length} Freitextfragen · ${t.length} mit Horizont, ${n.length} ohne · ${e.uebersprungen} übersprungen`+(r.length?` · ${r.length} Klausur-Aufgabe(n), siehe unten`:``)+(i?` · ${i} Horizont(e) aus der neuesten Fragenfassung geholt`:``);let a=V(`.co-warn`);n.length?(a.classList.remove(`co-hidden`),a.textContent=`⚠ ${n.length} Frage(n) haben keinen Erwartungshorizont. Sie sind im Prompt nicht enthalten — leg ihn in Reiter 3 an.`):a.classList.add(`co-hidden`);function o(){let e=V(`.co-prozentbox`);e.innerHTML=``,e.classList.add(`co-hidden`)}o();let s=V(`.co-zust`);s.innerHTML=``;let c=Object.values(H.fragen).filter(e=>e.horizont&&!e.zustaendig);if(r.length||c.length){s.classList.remove(`co-hidden`);let e=r.filter(e=>e.grund===`grader`),t=r.filter(e=>e.grund!==`grader`);if(e.length){s.appendChild(v(`div`,`co-zustkopf`,`↷ ${e.length} Klausur-Frage(n) — werden auf ihrer Einzelseite bewertet, hier übersprungen.`));let t=e.map(e=>({slot:e.slot,qid:e.qid,name:e.name}));l||Ie(d,t),e.forEach(e=>{let t=v(`a`,`co-logzeile`,`→ `+e.name);t.href=Re(d,e),s.appendChild(t)});let n=Object.keys(H.fragen||{}).length,r=v(`button`,`co-jetzt`,n?`Nach den Kurztests: weiter zur Klausur-Frage 1 von ${t.length}`:`Weiter zur Klausur-Frage 1 von ${t.length}`);if(r.addEventListener(`click`,()=>{location.href=Re(d,t[0])}),s.appendChild(r),!n){let e=3,n=v(`div`,`co-logzeile`,`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`);s.appendChild(n);let r=setInterval(()=>{if(e--,e>0){n.textContent=`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`;return}clearInterval(r),location.href=Re(d,t[0])},1e3);n.addEventListener(`click`,()=>{clearInterval(r),n.textContent=`Automatischer Sprung abgebrochen.`})}}if(t.length&&(s.appendChild(v(`div`,`co-zustkopf`,`↷ ${t.length} Frage(n) ohne Marker — übersprungen, weil „nur mit Marker" eingeschaltet ist (⚙).`)),t.forEach(e=>s.appendChild(v(`div`,`co-logzeile`,e.name)))),c.length){s.appendChild(v(`div`,`co-zustkopf`,`⚠ ${c.length} Frage(n) haben einen Horizont, aber keinen Marker — sie wurden mitbewertet. Markiere sie als Kurztest (Knopf unten), dann ist die Zuständigkeit dauerhaft geklärt.`)),c.forEach(e=>s.appendChild(v(`div`,`co-logzeile`,e.name)));let e=c.length===1?`Diese Frage als Kurztest markieren`:`Diese ${c.length} Fragen als Kurztest markieren`,t=v(`button`,`co-marker co-zweit`,e),n=!1,r=null;t.addEventListener(`click`,async()=>{if(!n){n=!0,t.textContent=`Wirklich? Ändert die Fragen — noch einmal klicken`,r=setTimeout(()=>{n&&(n=!1,t.textContent=e)},8e3);return}r&&=(clearTimeout(r),null),t.disabled=!0;let i=v(`div`,`co-marklog`);s.appendChild(i);let a=0,o=[];for(let e=0;e<c.length;e++){let n=c[e];t.textContent=`Trage nach … ${e+1} von ${c.length}: ${n.name}`;let r=v(`div`,`co-logzeile`,`… ${n.name}`);i.appendChild(r),i.scrollTop=i.scrollHeight;try{await Ge(n.qid),a++,r.textContent=`✓ ${n.name}`}catch(e){o.push(`${n.name}: ${e.message}`),r.textContent=`✗ ${n.name}: ${e.message}`,r.classList.add(`co-logfehler`)}}t.textContent=`${a} nachgetragen`+(o.length?`, ${o.length} fehlgeschlagen`:``),a&&s.appendChild(v(`div`,`co-logzeile`,`Bitte „Kurztest-Aufgaben durchsuchen" noch einmal laufen lassen — dann liest die Erweiterung den neuen Stand.`))}),s.appendChild(t);let i=v(`button`,`co-hneu co-zweit`,`Horizonte einzeln überarbeiten →`);i.title=`Springt zu Reiter 3 · Horizonte: Liste aller Aufgaben mit Links`,i.addEventListener(`click`,()=>it(`horizont`)),s.appendChild(i)}}else s.classList.add(`co-hidden`);B.querySelector(`.co-badge`);let u=V(`.co-list`);u.innerHTML=``,Object.values(H.fragen).forEach(e=>{let t=v(`div`,`co-qname`);t.appendChild(v(`span`,e.horizont?`co-ok`:`co-fehlt`,e.horizont?`✓`:`✗`)),t.appendChild(v(`span`,`co-qtext`,` ${e.name} · ${h(e.max)} P.`)),u.appendChild(t),H.antworten.filter(t=>t.qid===e.qid).forEach(e=>{let t=v(`a`,`co-row`);t.href=oe(e),t.target=`_blank`,t.rel=`noopener`,t.appendChild(v(`span`,`co-nr`,`#`+e.nr)),t.appendChild(v(`span`,`co-ans`,e.antwort.slice(0,90))),u.appendChild(t)})});let f=V(`.co-ohneliste`);f.innerHTML=``,n.length?(f.appendChild(v(`div`,`co-fehlendkopf`,`Ohne Erwartungshorizont:`)),n.forEach(e=>f.appendChild(v(`div`,`co-logzeile`,`${e.name} — ${e.aufgabe.slice(0,90)}`)))):(f.appendChild(v(`div`,`co-fehlendkopf`,`Alle Fragen haben einen Horizont. Willst du einen neuen für die Aufgaben schreiben?`)),f.appendChild(v(`div`,`co-logzeile`,`Setz dazu unten das Häkchen — der vorhandene Horizont wird beim Eintragen überschrieben.`))),!n.length&&t.length&&(V(`.co-halle`).checked=!0),wt(),gt(),ut(),rt();let p=et(H).length;V(`.co-groesse`).textContent=`Prompt ≈ ${Math.round(p/1e3)} 000 Zeichen`,V(`.co-result`).classList.remove(`co-hidden`),H.fehler.length&&(V(`.co-error`).textContent=H.fehler.length+` Frage(n) konnten nicht geladen werden.`,V(`.co-error`).classList.remove(`co-hidden`))}catch(e){V(`.co-error`).textContent=`Fehler: `+e.message,V(`.co-error`).classList.remove(`co-hidden`)}finally{V(`.co-progress`).classList.add(`co-hidden`),e.disabled=!1,e.textContent=l?`Antworten dieser Aufgabe neu laden`:`Kurztest-Aufgaben durchsuchen`}});function mt(e){let t={meta:{...e.meta},fragen:{},antworten:[]};Object.entries(e.fragen).forEach(([e,n])=>{n.horizont&&(t.fragen[e]=n)});let n=new Set(Object.values(t.fragen).map(e=>e.qid));return t.antworten=e.antworten.filter(e=>n.has(e.qid)),t.meta.antworten=t.antworten.length,t}function ht(e,t,n,r){let i=V(e);ot();let a=3;i.textContent=`✓ Kopiert — weiter in ${a} s`,at=setInterval(()=>{if(a--,a>0){i.textContent=`✓ Kopiert — weiter in ${a} s`;return}ot(),i.textContent=t,n&&it(n);let e=r&&V(r);e&&(e.focus(),e.scrollIntoView({block:`nearest`}))},1e3)}V(`.co-copy`).addEventListener(`click`,async()=>{H&&(await S(et(mt(H))),ht(`.co-copy`,`📋 Prompt + Daten kopieren`,`eintrag`,`.co-json`))}),V(`.co-copy2`).addEventListener(`click`,async()=>{H&&(await S(JSON.stringify(mt(H),null,1)),ht(`.co-copy2`,`📋 nur JSON`,`eintrag`,`.co-json`))});function gt(){let e=V(`.co-aufgabenliste`);if(!e||!H)return;e.innerHTML=``;let t=e=>location.origin+`/question/bank/editquestion/question.php?id=`+e+(d?`&cmid=`+d:``),n=(e,n)=>{let r=v(`div`,`co-aufgabe`),i=e.horizont?e.vonFreitext?`Horizont aktuell`:`alter Horizont – bitte überarbeiten`:`kein Horizont`,a=[e.jahrgang?`Jg. `+e.jahrgang:``,e.feedback&&e.vonFreitext?`Feedback `+e.feedback:``].filter(Boolean).join(` · `);r.appendChild(v(`div`,`co-aufgabekopf`,e.name||`Aufgabe `+e.slot)),r.appendChild(v(`div`,`co-aufgabestatus`+(e.horizont&&e.vonFreitext?` co-ok`:` co-fehlt`),n+` · `+i+(a?` · `+a:``)));let o=v(`div`,`co-aufgabelinks`);if(e.qid){let n=v(`a`,`co-link`,`Im Frageneditor öffnen`);n.href=t(e.qid),n.target=`_blank`,n.rel=`noopener`,o.appendChild(n)}if(e.qid&&e.slot&&d){let t=v(`a`,`co-link`,`Auf der Bewertungsseite öffnen`);t.href=Re(d,{slot:e.slot,qid:e.qid}),t.target=`_blank`,t.rel=`noopener`,o.appendChild(t)}return r.appendChild(o),r},r=Object.values(H.fragen||{}),i=Object.values(H.fremde||{});e.appendChild(v(`p`,`co-hinweis`,`Frageneditor: für Aufgaben, die noch nicht geschrieben wurden oder gestaltet werden sollen. Bewertungsseite: für schon geschriebene Tests – dort im Reiter „Horizont".`)),r.forEach(t=>e.appendChild(n(t,`Kurztest`))),i.forEach(t=>e.appendChild(n(t,t.grund===`grader`?`Klausur`:`ohne Marker`))),!r.length&&!i.length&&e.appendChild(v(`p`,`co-hinweis`,`Keine Freitextaufgaben gefunden.`));let a=[...r,...i].filter(e=>!(e.horizont&&e.vonFreitext)).length,o=B.querySelector(`.co-badge`);o&&(o.textContent=a?String(a):``,o.classList.toggle(`co-hidden`,!a||!!l));let s=V(`.co-hzhinweis`);if(s&&(s.innerHTML=``,s.classList.toggle(`co-hidden`,!a||!!l),a&&!l)){s.appendChild(document.createTextNode(a+(a===1?` Aufgabe hat`:` Aufgaben haben`)+` keinen aktuellen Horizont. `));let e=v(`a`,null,`Zu Reiter 3 · Horizonte →`);e.addEventListener(`click`,()=>it(`horizont`)),s.appendChild(e)}}let _t=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Reiter 1 „Kurztest-Aufgaben durchsuchen" laufen lassen.`;function vt(e){let t=e.value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen.`);return JSON.parse(t)}V(`.co-pruef`).addEventListener(`click`,()=>{let e=V(`.co-pinfo`);e.classList.remove(`co-hidden`),V(`.co-schreibknoepfe`).classList.add(`co-hidden`),V(`.co-abschluss`).classList.add(`co-hidden`),V(`.co-log`).classList.add(`co-hidden`),V(`.co-vorschau`).innerHTML=``,tt=null;try{if(!H)throw Error(_t);let t=vt(V(`.co-json`)),n=t.bewertungen||[];if(!n.length)throw Error(`Keine „bewertungen" im JSON gefunden.`);let r=new Map(H.antworten.map(e=>[e.qubaid+`|`+e.slot,e])),i=[];n.forEach((e,t)=>{let n=t+1;if(e.qubaid==null||e.slot==null)throw Error(`Eintrag ${n}: „qubaid" oder „slot" fehlt.`);let a=r.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Eintrag ${n}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesene Antwort. Stammt das JSON zu diesem Durchlauf?`);let o=Number(e.inhalt);if(isNaN(o)||o<0||o>100)throw Error(`Eintrag ${n}: „inhalt" ist kein Prozentwert (${e.inhalt}).`);let s=H.fragen&&H.fragen[a.frage]||{},c=he(a.max,o,e.fehler,de(s),a.antwort),l=o<100?ie(s.horizont):``,u=re(O.entferneQuellen?P(e.rueckmeldung):e.rueckmeldung,l,{inhalt:c.inhaltPunkte,inhaltMax:a.max,abzug:c.abzugPunkte,gewicht:c.gewicht})||String(e.text||``).trim();i.push({...a,inhalt:o,fehler:e.fehler||[],text:u,punkte:c.punkte,gewicht:c.gewicht,abzug:c.abzug,rechnung:`Inhalt ${g(o)} % = ${h(c.inhaltPunkte)} · ${c.gewicht} Fehlerpunkt(e) → −${g(Math.round(c.abzug*10)/10)} % · = ${h(c.punkte)} von ${h(a.max)}`})}),tt=i;let a=i.filter(e=>!e.text).length,o=new Set(i.map(e=>e.slot+`|`+e.qid)).size;e.className=`co-pinfo co-ok`,e.textContent=`✓ ${i.length} Bewertungen auf ${o} Fragenseiten — bereit. Punkte und Abzug wurden aus Inhalt und Fehlerzahl berechnet (Rechtschreib-Höchstabzug ${g(j())} %).`+(a?` ⚠ ${a} Eintrag/Einträge ohne Rückmeldungstext.`:``);let s=i.filter(e=>e.bisher!=null),c=s.filter(e=>Math.abs(e.bisher-e.punkte)<.005).length,l=s.filter(e=>e.punkte-e.bisher>=.005).length,u=s.length-c-l;s.length&&(e.textContent+=` Vergleich mit der bisherigen Bewertung: ${c} gleich, ${l} höher, ${u} niedriger.`);let d=typeof t.besprochen==`boolean`?t.besprochen:null;d===!0&&(e.textContent+=` Mit der KI gemeinsam besprochen.`),d===!1&&(e.textContent+=` Automatisch bewertet – ein Blick in die Liste lohnt sich.`);let f=v(`div`,`co-rechnung`);i.forEach(e=>{let t=v(`a`,`co-logzeile co-vorschauzeile`),n=oe(e);if(n&&(t.href=n,t.target=`_blank`,t.rel=`noopener`),t.appendChild(v(`span`,`co-vfrage`,e.frage)),t.appendChild(v(`span`,`co-vans`,`„`+e.antwort.slice(0,60)+`"`)),t.appendChild(v(`span`,`co-vpkt`,e.rechnung)),e.bisher!=null){let n=Math.abs(e.bisher-e.punkte)>=.005,r=v(`span`,`co-vbisher`+(n?` co-vanders`:``),`bisher `+h(e.bisher)+` → neu `+h(e.punkte));t.appendChild(r)}f.appendChild(t)}),V(`.co-vorschau`).appendChild(f),V(`.co-schreibknoepfe`).classList.remove(`co-hidden`),V(`.co-schreibknoepfe`).scrollIntoView({block:`nearest`})}catch(t){e.className=`co-pinfo co-error`,e.textContent=`Fehler: `+t.message}});function yt(e){return(t,n)=>{let r=v(n?`a`:`div`,`co-logzeile`,t);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`),(t.startsWith(`✗`)||t.startsWith(`⚠`))&&r.classList.add(`co-logfehler`),e.appendChild(r),e.scrollTop=e.scrollHeight}}async function bt(e){if(!tt)return;let t=V(`.co-log`),n=V(`.co-abschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),V(`.co-progress2`).classList.remove(`co-hidden`),V(`.co-alle`).disabled=!0,V(`.co-progress2`).scrollIntoView({block:`nearest`});let r=yt(t),i=(e,t)=>{V(`.co-bar2`).style.width=Math.round(e/t*100)+`%`,V(`.co-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await Be(tt,r,i):await He(tt,V(`.co-ki`).checked,r,i);if(t.prepend(v(`div`,`co-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`+(a.versuche>1?` · ${a.versuche} Versuche gebraucht`:``))),n.classList.remove(`co-hidden`),a.fehler>0)n.className=`co-abschluss co-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen. Trag noch nichts ein — stammt das JSON zu diesem Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach.`,e||(V(`.co-alle`).textContent=`Erneut versuchen`);else if(n.className=`co-abschluss co-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,e||(V(`.co-alle`).textContent=`Alle eintragen`),!e&&l)n.textContent=`✓ Fertig — ${a.ok} Einträge, keine Fehler. Die Seite lädt neu und zeigt die neuen Punkte …`,setTimeout(()=>location.reload(),2500);else if(!e){let e=3,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),B.classList.add(`co-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);B.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message)}finally{V(`.co-progress2`).classList.add(`co-hidden`),V(`.co-alle`).disabled=!1}}V(`.co-alle`).addEventListener(`click`,()=>bt(!1)),V(`.co-json`).addEventListener(`paste`,()=>setTimeout(()=>V(`.co-pruef`).click(),0)),V(`.co-hjson`).addEventListener(`paste`,()=>setTimeout(()=>V(`.co-hpruef`).click(),0)),[[`.co-json`,`.co-pruef`],[`.co-hjson`,`.co-hpruef`]].forEach(([e,t])=>{let n=null;V(e).addEventListener(`input`,r=>{r.inputType!==`insertFromPaste`&&(clearTimeout(n),n=setTimeout(()=>{V(e).value.trim()&&V(t).click()},800))})});function xt(){if(!H)return[];let e=Object.values(H.fragen);return V(`.co-halle`).checked?e:e.filter(e=>!e.horizont)}let St=`coachWunsch_`+d;function Ct(){let e=B.querySelector(`.co-hwunsch`);return e?e.value.trim():``}try{t.storage.local.get([St],e=>{let t=e&&e[St];t&&!Ct()&&(B.querySelector(`.co-hwunsch`).value=t)})}catch{}B.querySelector(`.co-hwunsch`).addEventListener(`input`,()=>{try{t.storage.local.set({[St]:Ct()})}catch{}});function wt(){let e=xt().length,t=V(`.co-halle`).checked;V(`.co-hcopy`).textContent=t?`📋 Prompt zum Neuschreiben kopieren (${e} Frage${e===1?``:`n`})`:`📋 Prompt für Erwartungshorizont kopieren`}V(`.co-halle`).addEventListener(`change`,wt),V(`.co-hcopy`).addEventListener(`click`,async()=>{if(!H){V(`.co-hinfo`).className=`co-hinfo co-error`,V(`.co-hinfo`).classList.remove(`co-hidden`),V(`.co-hinfo`).textContent=_t;return}let e=xt();if(!e.length){V(`.co-hinfo`).className=`co-hinfo`,V(`.co-hinfo`).classList.remove(`co-hidden`),V(`.co-hinfo`).textContent=`Es fehlt kein Horizont. Setz das Häkchen darüber, wenn du die vorhandenen neu schreiben lassen willst.`;return}await S(R(e));let t=V(`.co-hcopy`).textContent;ht(`.co-hcopy`,t,`horizont`,`.co-hjson`)}),V(`.co-hpruef`).addEventListener(`click`,()=>{let e=V(`.co-hinfo`);e.classList.remove(`co-hidden`),V(`.co-hknoepfe`).classList.add(`co-hidden`),V(`.co-habschluss`).classList.add(`co-hidden`),V(`.co-hlog`).classList.add(`co-hidden`),V(`.co-hliste`).innerHTML=``,U=null;try{let t=vt(V(`.co-hjson`)).horizonte||[];if(!t.length)throw Error(`Keine „horizonte" im JSON gefunden.`);let n=H?new Map(Object.values(H.fragen).map(e=>[String(e.qid),e])):new Map;U=t.map((e,t)=>{if(!e.qid)throw Error(`Horizont ${t+1}: „qid" fehlt.`);let r=n.get(String(e.qid)),i=String(e.text||``).trim();if(!i)throw Error(`Horizont ${t+1}: „text" ist leer.`);return{qid:String(e.qid),frage:e.frage||(r?r.name:`Frage `+e.qid),text:i,bekannt:!!r,hatteHorizont:!!(r&&r.horizont)}});let r=U.filter(e=>e.hatteHorizont).length,i=U.filter(e=>!e.bekannt).length;e.className=`co-hinfo co-ok`,e.textContent=`✓ ${U.length} Horizont(e) gelesen.`+(i?` ⚠ ${i} gehören zu keiner ausgelesenen Frage.`:``)+(r?` ⚠ ${r} würden einen vorhandenen Horizont überschreiben.`:``);let a=V(`.co-hliste`);U.forEach((e,t)=>{let n=v(`div`,`co-hcard`);n.appendChild(v(`div`,`co-fehlendkopf`,`${e.frage}  ·  qid ${e.qid}`));let r=v(`textarea`,`co-htext`);r.value=e.text,r.rows=10,r.addEventListener(`input`,()=>{U[t].text=r.value}),n.appendChild(r),a.appendChild(n)}),V(`.co-hknoepfe`).classList.remove(`co-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`co-hinfo co-error`,e.textContent=`Fehler: `+t.message}});async function Tt(e){if(!U||!U.length)return;let t=V(`.co-hlog`),n=V(`.co-habschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),V(`.co-progress3`).classList.remove(`co-hidden`),V(`.co-hschreib`).disabled=!0,V(`.co-progress3`).scrollIntoView({block:`nearest`});let r=yt(t),i=0,a=0,o=0;try{for(let t of U){try{let n=await We(t.qid,t.text,e);i++,r(e?`✓ ${t.frage} — Feld „${n.feld}" vorhanden`+(n.vorher&&n.vorher.replace(/<[^>]*>/g,``).trim()?` (enthält schon Text!)`:``):`✓ ${t.frage} — Horizont eingetragen`)}catch(e){a++,r(`✗ ${t.frage}: ${e.message}`)}o++,V(`.co-bar3`).style.width=Math.round(o/U.length*100)+`%`,V(`.co-ptext3`).textContent=`${o} / ${U.length} Fragen`}t.prepend(v(`div`,`co-logkopf`,e?`${i} Fragen erreichbar · ${a} nicht`:`${i} Horizonte eingetragen · ${a} fehlgeschlagen`)),n.classList.remove(`co-hidden`),n.className=`co-habschluss `+(a?`co-abfehler`:`co-abok`),n.textContent=a?`⚠ ${a} Frage(n) konnten nicht geschrieben werden. Sieh ins Protokoll.`:e?`✓ Alle ${i} Fragen sind erreichbar und haben das Feld. Du kannst eintragen.`:`✓ ${i} Horizonte stehen jetzt in den Fragen. Führe Reiter 1 noch einmal aus, dann sind sie im Bewertungs-Prompt dabei.`,n.scrollIntoView({block:`nearest`}),!a&&!e&&(n.textContent+=` Weiter zu Reiter 1 in 3 s …`,ot(),at=setTimeout(()=>{at=null,it(`lesen`)},3e3))}finally{V(`.co-progress3`).classList.add(`co-hidden`),V(`.co-hschreib`).disabled=!1}}V(`.co-hschreib`).addEventListener(`click`,()=>{let e=U?U.length:0;if(!e)return;let t=V(`.co-habschluss`);t.classList.remove(`co-hidden`),t.className=`co-habschluss co-abfrage`,t.innerHTML=``,t.appendChild(v(`div`,null,`Der Erwartungshorizont wird in ${e} Frage(n) der Fragensammlung geschrieben. Das ändert die Fragen selbst, nicht nur eine Bewertung.`));let n=v(`button`,`co-jetzt`,`Ja, in ${e} Frage(n) eintragen`);t.appendChild(n),n.addEventListener(`click`,()=>{t.classList.add(`co-hidden`),Tt(!1)})})}function I(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``;function i(){return!!document.querySelector(`[name="graderinfo[text]"]`)}function l(){return document.querySelectorAll(`input[id$="-mark"]`).length!==0&&!!(document.querySelector(`.qtype_essay_response`)||document.querySelector(`textarea[id$="-comment_id"]`)||document.querySelector(`textarea[name$="-comment"]`)||document.querySelector(`.ablock`))}let u=i()?`bearbeiten`:l()?`bewertung`:null;if(!u)return;let f=a,p=r,m=/rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%/i,ie=/punkteschritte\s*[:\-]?\s*([\d.,]+)/i;function v(e){let t=I();return xe({fach:t.fach,jahrgang:t.jahrgang,niveau:t.niveau,feedback:e})}function y(e){let t=L(e).split(`
`).map(e=>e.trim()),n=[];for(let e of t)if(e&&(S.test(e)||(n.push(e),n.length>=6)))break;return n.join(`
`)}let ae=/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im;function b(e){let t=y(e).match(ae);return t?t[1].charAt(0).toUpperCase()+t[1].slice(1).toLowerCase():null}function x(){if(Y!==void 0&&Y)return Y;let e=``;try{e=B()||C.horizontLokal||``}catch{}return b(e)||`Ausführlich`}function oe(){let e=``;try{e=B()||C.horizontLokal||``}catch{}return!!b(e)}let S=/^\s*[①-⑳⓪]?\s*(?:Aufgabe\s+(\d{1,2}\s*[a-h]?)(?![a-z])|(\d{1,2}[a-h]?)\s*·)/i,se=e=>T(e[1]||e[2]),ce={fach:``,jahrgang:``,kursniveau:`G`,punkteschritte:`0.5`,rechtschreibung:`10`,rsSek1:``,rsSek2:`25`,anredeWahl:`auto`,feedbacklaenge:`Ausführlich`,afbFarben:!0,vorlagePunkte:!0,vorlageAfb:!0,kartePunkte:!0,layoutAufgabe:!0,layoutAntwort:!0,kiHinweis:!0,kiHinweisText:je,entferneQuellen:!0,kompaktPrompt:!1,promptHorizont:null,promptKorrektur:null,horizontLokal:``,sprachabzugKurztest:`30`},C=JSON.parse(JSON.stringify(ce)),w=(e,t)=>(t||document).querySelector(e),E=(e,t)=>[...(t||document).querySelectorAll(e)];function D(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r}function O(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function k(e){return String(e).replace(`.`,`,`)}function j(e){return parseFloat(String(e??``).replace(`,`,`.`))}function de(e,t,n){let r=n||parseFloat(C.punkteschritte)||.5,i=Math.round(e/r)*r;return i=Math.max(0,Math.min(i,t)),Math.round(i*100)/100}function me(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function M(e){let t=String(e||``),n=me(t);t=f.test(n)?t.replace(n,n.replace(f,``)).replace(/^\s*\n/,``):t.replace(o,``).replace(/^\s*\n+/,``);for(let e=0;e<8;e++){let e=me(t);if(e&&(ve(e)||m.test(e)||ie.test(e)||ae.test(e)))t=t.replace(e,``).replace(/^\s*\n/,``);else break}return t}function _e(e){return C.entferneQuellen?Pe(e):String(e||``)}function we(){return Ce(P().jahrgang,C.anredeWahl)}function Te(){return we()===`sie`?`Sie haben`:`Du hast`}let N=null,Me=null;function Ne(){return Me||={fach:C.fach||``,jahrgang:C.jahrgang||``,niveau:C.kursniveau||`G`},Me}function P(){if(u!==`bewertung`)return I();let e=Ie(),t=Ne();return{fach:e.fach||t.fach,jahrgang:e.jahrgang||t.jahrgang,niveau:e.niveau||t.niveau,ausHorizont:!!(e.fach||e.jahrgang||e.niveau)}}function F(){if(u!==`bewertung`)return x();let e=``;try{e=B()||C.horizontLokal||``}catch{}return b(e)||(J===`kurztest`?`Mittel`:`Ausführlich`)}function Ie(){let e=``;try{e=B()||C.horizontLokal||``}catch{}return ye(L(e))}function I(){if(N)return N;let e=Ie();return{fach:e.fach||C.fach||``,jahrgang:e.jahrgang||C.jahrgang||``,niveau:e.niveau||C.kursniveau||`G`,ausHorizont:!!(e.fach||e.jahrgang||e.niveau)}}function He(e){return Se(e)===`sek2`?C.rsSek2===``||C.rsSek2==null?`25`:String(C.rsSek2):C.rsSek1===``||C.rsSek1==null?String(C.rechtschreibung||`10`):String(C.rsSek1)}function Ue(e){return Se(e)===`sek2`?`rsSek2`:`rsSek1`}function L(e){let t=String(e||``).replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi,`</$1>
`);return(new DOMParser().parseFromString(t,`text/html`).body.textContent||``).replace(/[ \t]+/g,` `).replace(/\n{3,}/g,`

`).trim()}function We(e){return new DOMParser().parseFromString(String(e||``),`text/html`).body}function Ge(e,t){e.replaceChildren(...We(t).childNodes)}let Ke=/^(DIV|P|H[1-6]|UL|OL|LI|TABLE|TBODY|TR|TD|TH|BLOCKQUOTE|SECTION|ARTICLE|PRE)$/;function qe(e){return String(e.textContent||``).replace(/\s+/g,` `).trim()}async function Je(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function Ye(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&e.type!==`button`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}async function Xe(e,t,n){let r=[...e.querySelectorAll(`input[type=submit],button[type=submit]`)].filter(e=>e.name&&e.name!==`cancel`),i=r.find(e=>e.name===`submitbutton`)||r[0];i&&t.set(i.name,i.value);let a=new URL(e.getAttribute(`action`)||n,n).href,o=await fetch(a,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:t.toString()});if(!o.ok)throw Error(`HTTP `+o.status+` beim Speichern`);return o}async function Ze(e,t,n){try{let r=new URL(e.url||n),i=r.searchParams.get(`lastchanged`),a=new URL(n).searchParams.get(`cmid`)||r.searchParams.get(`cmid`);if(i)return location.origin+`/question/bank/editquestion/question.php?id=`+i+(a?`&cmid=`+a:``);let o=[...new DOMParser().parseFromString(await e.clone().text(),`text/html`).querySelectorAll(`[data-itemtype="questionname"]`)].find(e=>(e.getAttribute(`data-value`)||``)===t);if(o&&o.getAttribute(`data-itemid`))return location.origin+`/question/bank/editquestion/question.php?id=`+o.getAttribute(`data-itemid`)+(a?`&cmid=`+a:``)}catch{}return null}function Qe(e,t){let n=e=>L(e).replace(/\s+/g,` `).trim(),r=n(e),i=n(t);if(!r||!i)return!1;if(r===i)return!0;if(Math.abs(r.length-i.length)>Math.max(40,i.length*.2))return!1;let a=i.slice(Math.floor(i.length/2),Math.floor(i.length/2)+40);return r.includes(i.slice(0,40))&&(a.length<20||r.includes(a))}async function $e(e,t){let n=location.href,r=await Je(n),i=[...r.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!i)throw Error(r.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let a=Ye(i),o=[];for(let n of Object.keys(e)){if(!a.has(n))throw Error(`Feld „`+n+`" nicht im Formular`);let r=a.get(n)||``;o.push({feld:n,belegt:L(r).length>0}),t||a.set(n,e[n])}if(t)return{bericht:o};let s=(i.querySelector(`[name="name"]`)||{}).value||``,c=await Ze(await Xe(i,a,n),s,n),l=[...(await Je(c||n)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),u=[];for(let t of Object.keys(e)){let n=l&&l.querySelector(`[name="`+CSS.escape(t)+`"]`);u.push({feld:t,ok:!!n&&Qe(n.value,e[t])})}return{bericht:o,ergebnis:u,neueUrl:c,warnung:c?null:`Die neue Fragenversion war nicht auffindbar — die Gegenprobe lief gegen den alten Stand und kann falsch sein.`}}function et(){if(u===`bearbeiten`){let e=w(`[name="questiontext[text]"]`);return e?L(e.value):``}let e=w(`.que .qtext`)||w(`.qtext`);return e?e.innerText.trim():``}function R(){if(u===`bearbeiten`){let e=w(`[name="defaultmark"]`);return e&&j(e.value)||0}let e=w(`input[name$="-maxmark"]`);if(e)return j(e.value)||0;let t=w(`.que .grade`),n=t&&t.innerText.match(/([\d.,]+)\s*$/);return n?j(n[1]):0}let z=null;function B(){if(u===`bearbeiten`)return re(`graderinfo[text]`);if(z)return z;let e=w(`.que .graderinfo`)||w(`.graderinfo`);return e?e.innerHTML.replace(/^\s*<h\d[^>]*>[^<]*Bewerter[^<]*<\/h\d>/i,``):``}function V(){let e=L(B());if(!e)return{horizont:!1,wer:null};let t=s(e.split(`
`).map(e=>e.trim()).filter(Boolean).slice(0,5).map(e=>e.match(f)).find(Boolean)||null);return!t&&/Kernaussage\s*:/i.test(e)&&!e.split(`
`).some(e=>S.test(e))&&(t=`coach`),{horizont:!0,wer:t}}function H(e){let t=We(M(String(e||``))),n=[],r=null;if([...t.children].forEach(e=>{let t=qe(e),i=t.match(S);if(i&&/^(H[1-6]|P|DIV)$/.test(e.tagName)&&t.length<200){r={nr:se(i),kopf:t,html:``,text:``},n.push(r);return}r&&(r.html+=e.outerHTML,r.text+=L(e.outerHTML)+`
`)}),!n.length){let t=M(L(e));return t?[{nr:`1`,kopf:`Aufgabe 1`,html:String(e||``),text:t,punkte:null,afb:null,ganzeArbeit:!0}]:[]}return n.forEach(e=>{e.text=e.text.trim();let t=e.kopf.match(/\(\s*([\d.,]+)\s*(?:P\.?|Punkte?)\s*\)/i);e.punkte=t?j(t[1]):null;let n=e.kopf.match(/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i);e.afb=n?n[1].replace(/\s/g,``):null}),n}function tt(e){let t=e;for(let e=0;e<12&&t;e++)if(t=t.parentElement,t&&t.classList&&(t.classList.contains(`que`)||t.classList.contains(`content`)))return t;return null}function U(){return E(`input[id$="-mark"]`).map((e,t)=>{let n=tt(e),r=n&&n.querySelector(`.qtype_essay_response`),i=n&&n.querySelector(`textarea[name$="-comment"]`),a=n&&n.querySelector(`input[name$="-maxmark"]`),o=r&&r.innerHTML||``,s=r?r.innerText.trim():``;return{nr:t+1,markfeld:e.name||``,kommentarfeld:i?i.name:``,ist:j(e.value)||0,max:a?j(a.value)||0:R(),rohHtml:o,text:s,anker:n&&n.id?`#`+n.id:``}}).filter(e=>e.markfeld)}function nt(e,t){let n=We(e),r=[],i=null,a=e=>{let t=[...e.children].filter(e=>Ke.test(e.tagName));if(!t.length){let t=qe(e);if(!t)return;let n=t.match(S);n&&t.length<160?(i={nr:se(n),text:``},r.push(i)):i&&(i.text+=t+`
`);return}t.forEach(a)};return a(n),r.length>=1?(r.forEach(e=>{e.text=e.text.trim()}),{gegliedert:!0,aufgaben:r,leer:r.every(e=>!e.text)}):{gegliedert:!1,aufgaben:[{nr:`1`,text:String(t||``).trim()}]}}function rt(e,t,n,r,i){let a=e.max||R()||0,o=(n||[]).filter(e=>e.punkte!=null).reduce((e,t)=>e+t.punkte,0),s=n&&n.length?n.map(e=>e.nr):(t.aufgaben||[]).map(e=>T(e.nr)),c=Math.max(1,s.length),l=[],u=s.map(e=>{let r=(t.aufgaben||[]).find(t=>T(t.nr)===e)||(l.push(e),{nr:e,prozent:0}),i=(n||[]).find(t=>t.nr===e),s;s=i&&i.punkte!=null&&o>0?a>0?i.punkte*a/o:i.punkte:a/c;let u=Math.max(0,Math.min(100,Number(r.prozent)||0));return{nr:e,max:s,prozent:u,roh:s*u/100}}),d=u.reduce((e,t)=>e+t.roh,0),f=a*(r??(parseFloat(C.rechtschreibung)||0))/100,p=De(t.fehler),m=Ee(e.text),ee=Oe(p,m),h=Math.min(f*ee,d);u.forEach(e=>{let t=d>0?e.roh/d:0;e.abzug=h*t,e.netto=Math.max(0,e.roh-e.abzug)});let g=i||parseFloat(C.punkteschritte)||.5,te=de(u.reduce((e,t)=>e+t.netto,0),a,g);u.forEach(e=>{e.punkte=Math.max(0,Math.floor(e.netto/g+1e-9)*g),e.rest=e.netto-e.punkte});let ne=Math.round((te-u.reduce((e,t)=>e+t.punkte,0))/g),_=u.slice().sort((e,t)=>t.rest-e.rest);for(let e=0;ne>0&&e<_.length*4;e++){let t=_[e%_.length];t.punkte+g<=t.max+1e-9&&(t.punkte+=g,ne--)}for(let e=0;ne<0&&e<_.length*4;e++){let t=_[_.length-1-e%_.length];t.punkte-g>=-1e-9&&(t.punkte-=g,ne++)}return u.forEach(e=>{e.punkte=Math.round(e.punkte*100)/100}),{teil:u,wortzahl:m,fehlerGewichtet:p,fehlerDichte:m>0?Math.round(p*1e3/m)/10:0,hoechstabzug:Math.round(f*100)/100,abzug:Math.round(h*100)/100,gesamt:te,max:a,fehlendeAufgaben:l}}function it(e){let t=O(`Aufgabe `+e.nr);return e.afb&&(t+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+O(e.afb)+`</span>`),e.schlagwort&&(t+=` · `+O(e.schlagwort)),e.punkte!=null&&(t+=` <span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+O(k(e.punkte))+(Number(e.punkte)===1?` Punkt`:` Punkte`)+`)</span>`),t}function at(){return{farbig:C.afbFarben!==!1,zeigeAfb:!!C.vorlageAfb,zeigePunkte:!!C.vorlagePunkte}}function ot(e){return(e||[]).map(e=>A(Object.assign({label:String(e.nr),titel:e.schlagwort||`Deine Antwort`,afb:e.afb,punkte:e.punkte},at()))).join(`
`)}function st(e){let t=String(e||``).replace(/\r/g,``).match(/Teile\s*:\s*\n([\s\S]*?)(?:\n\s*\n|$)/i),n={};return t&&t[1].split(`
`).forEach(e=>{let t=e.match(/^\s*[-•]?\s*([a-h])\s*[).:]?\s.*?([\d]+(?:[.,]\d+)?)\s*Punkt/i);t&&(n[t[1].toLowerCase()]=j(t[2]))}),n}function ct(){return X||L(B()||``)}function lt(){let e=re(`questiontext[text]`)||``,t=fe(ue(e)?``:e).segmente.filter(e=>e.typ===`aufgabe`),n=st(ct()),r=le(L(e));return t.filter(e=>/^[a-h]$/.test(e.label)).map(e=>({nr:e.label,afb:le(e.knoten.map(e=>e.textContent||``).join(` `))||r,punkte:n[e.label]==null?null:n[e.label]}))}function ut(){let e=lt(),t=at();if(e.length>=2)return e.map(e=>A(Object.assign({label:e.nr,titel:`Deine Antwort`,afb:e.afb,punkte:e.punkte},t))).join(`
`);let n=re(`questiontext[text]`)||``;return A(Object.assign({label:``,titel:`Deine Antwort`,afb:le(L(n)),punkte:R()||null},t))}function dt(){if(K)return K;let e=H(B());return!e.length||e[0].ganzeArbeit?null:e.map(e=>{let t=(e.kopf.match(/·\s*([^()]+?)\s*(?:\(|$)/)||[])[1]||``;return{nr:e.nr,afb:e.afb,punkte:e.punkte,schlagwort:t}})}function ft(){return!!(K||X||L(B()||``).trim())}function pt(){if(u!==`bearbeiten`)return!0;let e=w(`[name="responseformat"]`);return!e||/editor/i.test(e.value||``)}function mt(){if(u===`bearbeiten`&&J===`kurztest`)return ut();let e=dt();return e?ot(e):null}function ht(){let e=re(`questiontext[text]`);if(!L(e||``).trim())return{fehler:`Die Aufgabenstellung ist noch leer.`};if(ue(e))return{fehler:`Die Aufgabenstellung ist schon im Kartendesign gestaltet. Zum Neugestalten erst den ursprünglichen Text wiederherstellen (Moodle-Versionsverlauf der Frage).`};let t=J===`kurztest`,n=t?lt():dt()||[],r=pe(e,{aufgaben:n,punkte:t?!0:C.kartePunkte!==!1,gesamtAfb:t?le(L(e)):``});return t&&n.length>=2&&n.some(e=>e.punkte==null)&&r.hinweise.push(`Im Horizont fehlen die Punkte je Teil (Abschnitt „Teile:"). Horizont neu erstellen, dann stehen sie dort.`),r}function gt(){if(!G(`hstatus`))return;let e=B()||``,t=L(e).trim(),n=G(`hschritt1`),r=W.querySelector(`[data-tu="hprompt"]`),i=W.querySelector(`[data-tu="hschreiben"]`),a=G(`hbisher`);if(!t)return n&&(n.textContent=`1 · Prompt zum Erstellen des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`3 · In die Aufgabe eintragen`),a&&(a.hidden=!0),Z(`hstatus`,`Noch kein Erwartungshorizont in dieser Aufgabe.`+(pn()?` Bitte unter „Diese Aufgabe" Fach und Jahrgang angeben.`:``));let o=/moodle[-\s]?ai[-\s]?(coach|grader)/i.test(t),s=c(t),l=b(e),u=[s===`kurztest`?`Kurztest`:s===`klausur`?`Klausur`:``,l?`Feedback `+l:``].filter(Boolean).join(`, `);if(Z(`hstatus`,o?`Dieser Horizont stammt noch aus Coach oder Grader. Bitte neu erstellen – der alte geht als Vorlage in den Prompt ein.`:`Diese Aufgabe hat schon einen Erwartungshorizont`+(u?` (`+u+`)`:``)+`. Der Prompt nimmt ihn als Vorlage mit; die KI sagt dir, was sie übernimmt und was sie ändert.`),n&&(n.textContent=`1 · Prompt zum Überarbeiten des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`3 · Vorhandenen Horizont in der Aufgabe ersetzen`),a){a.hidden=!1;let e=a.querySelector(`pre`);e&&(e.textContent=M(t))}}function _t(){let e=G(`hstatus`)?G(`hstatus`).textContent:``;gt(),e&&G(`hstatus`)&&(G(`hstatus`).textContent=e),$()}function vt(){let e=W.querySelector(`.mag-tab[data-tab="vorlage"]`);if(e&&(e.hidden=!(u===`bearbeiten`&&ft())),!G(`lseca`))return;G(`lseca`).hidden=C.layoutAufgabe===!1,G(`lsecv`).hidden=C.layoutAntwort===!1;let t=J===`kurztest`;G(`lpunktezeile`).hidden=t,G(`lpunktehinweis`).hidden=t;let n=W.querySelector(`[data-tu="lein"]`);if(n&&(n.disabled=C.layoutAufgabe===!1&&C.layoutAntwort===!1),C.layoutAufgabe!==!1){let e=ht();e.fehler?(Ge(G(`lavorschau`),`<p class="mag-hinweis">`+O(e.fehler)+`</p>`),G(`lahinweise`).textContent=``):(Ge(G(`lavorschau`),e.html),G(`lahinweise`).textContent=e.hinweise.join(` `))}}function yt(e){return((e||[]).some(e=>f.test(me(L(e.horizont))))?``:`<p>`+p+`</p>`+v(Y))+(e||[]).map(e=>{let t=String(e.horizont||``).trim();return/<[a-z][\s\S]*>/i.test(t)||(t=`<p>`+O(t).replace(/\n{2,}/g,`</p><p>`).replace(/\n/g,`<br>`)+`</p>`),`<h4>`+it(e)+`</h4>`+t}).join(`
`)}let bt=be;function xt(){let e=P();return[`Fach: `+(e.fach||`[nicht angegeben]`),`Jahrgang: `+(e.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(bt[e.niveau]||e.niveau),`Feedbacklänge: `+F(),`Anrede im Feedback: `+Te()+` …`].join(`
`)}function St(){let e=I();return[`Fach: `+(e.fach||`[nicht angegeben]`),`Jahrgang: `+(e.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(bt[e.niveau]||e.niveau)].join(`
`)}function Ct(){return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KLAUSUR)
═══════════════════════════════════════════════════════

Du bist erfahrene Lehrkraft und erstellst den Erwartungshorizont für eine Klausur. Er
wird in Moodle im Feld „Informationen für Bewerter/innen" gespeichert; Schülerinnen und
Schüler sehen ihn nicht.

${g}

RAHMENDATEN
[MAG_RAHMENDATEN]

AUFGABENSTELLUNG (aus Moodle übernommen, Gesamtpunktzahl: [MAG_GESAMTPUNKTE])
[MAG_AUFGABEN]

WAS DU TUST
1. Zerlege die Aufgabenstellung in ihre Teilaufgaben. Übernimm die Nummerierung der
   Aufgabenstellung. Steht dort eine Punktzahl je Aufgabe, übernimm sie unverändert;
   fehlt sie, verteile die Gesamtpunktzahl begründet und weise darauf hin.
   Hat eine Aufgabe Teile (a, b …), ist JEDER TEIL eine eigene Aufgabe mit eigener
   Punktzahl, eigenem Operator und eigenem AFB: "nr": "2a", "2b". Eine übergeordnete
   Aufgabe 2 ohne eigene Punkte gibt es dann nicht. Die Punkte aller Einträge ergeben
   zusammen die Gesamtpunktzahl.
2. Bestimme je Aufgabe den Operator und den Anforderungsbereich AFB (I, II, III oder
   eine Spanne wie II-III).
3. Schreibe je Aufgabe einen Erwartungshorizont in dieser Reihenfolge:
   Kernaussage · Muss enthalten · Auch richtig · Inhalt in Stufen · Reicht nicht ·
   Häufiger Fehler.
4. Gib je Aufgabe ein Schlagwort von zwei bis vier Wörtern an, das die Aufgabe benennt.

REGELN
${h(`[MAG_JAHRGANG]`)}

BEISPIEL „AUCH RICHTIG"
Schlecht: „Von links nach rechts werden die Atome kleiner, weil die Kernladung zunimmt
und die Elektronen stärker angezogen werden." So schreibt eine Lehrkraft – wer so
antwortet, liegt ohnehin bei 100 %.
Gut: „nach rechts wird es kleiner" · „der Kern zieht doller" · „es kommt eine Schale
dazu, deshalb wird es dicker" · „mehr Protonen, gleiche Schale".

BEISPIEL ZÄHLBARE STUFEN
100 — beide Trends beschrieben UND beide erklärt · 75 — beide beschrieben, einer
erklärt · 50 — beide beschrieben, keiner erklärt ODER einer beschrieben und erklärt.

[MAG_STUFE]

ARBEITSWEISE
Zeige mir zuerst je Aufgabe eine lesbare Übersicht (Nummer, Operator, AFB, Punkte,
Schlagwort, Erwartungshorizont) und frage: „Passt das so? Wenn ja, antworte mit ok."
Ändere, bis ich zustimme. Stelle immer nur EINE Frage auf einmal.

ERST WENN ICH BESTÄTIGE, gib genau EINEN Codeblock aus – nichts davor, nichts danach:

\`\`\`json
{ "aufgaben": [
  { "nr": "1",
    "schlagwort": "kurzes Stichwort",
    "afb": "I",
    "punkte": 2,
    "operator": "Nenne",
    "horizont": "<p><strong>Kernaussage:</strong> …</p><p><strong>Muss enthalten:</strong> …</p>" },
  { "nr": "2a", "schlagwort": "…", "afb": "II", "punkte": 3, "operator": "Erläutere", "horizont": "…" }
] }
\`\`\`

Das Feld "horizont" ist HTML (erlaubt: p, br, ul, li, strong, em). Jeder Abschnitt ist
ein eigenes <p> mit fettem Abschnittsnamen. Keine Überschrift für die Aufgabe selbst –
die setzt die Erweiterung. Keine Punktzahlen im Fließtext.`}function wt(){let e=w(`[name="questiontext[text]"]`),t=e?e.value:(w(`.que .qtext`)||{}).innerHTML||``;if(!t)return[];let n=new DOMParser().parseFromString(t,`text/html`),r=[];return n.querySelectorAll(`img`).forEach(e=>r.push(`Bild: `+(e.getAttribute(`alt`)||decodeURIComponent((e.getAttribute(`src`)||``).split(`/`).pop().split(`?`)[0])||`ohne Namen`))),n.querySelectorAll(`a[href*="pluginfile"]`).forEach(e=>r.push(`Datei: `+(e.textContent.trim()||decodeURIComponent(e.getAttribute(`href`).split(`/`).pop().split(`?`)[0])))),r}function Tt(){return ee([et()],wt())}function Et(){if(J===`kurztest`){let e={qid:`diese-frage`,frage:(w(`[name="name"]`)||{}).value||`Diese Frage`,aufgabe:et(),max:R()},t=L(B());t&&(e.horizont_bisher=M(t));let n=Tt(),r=`Rahmendaten:
`+St()+`

`+(n?n+`

`:``)+"```json\n"+JSON.stringify([e],null,1)+"\n```";return te({einzeln:!0,jahrgang:I().jahrgang,stufe:x()}).replace(`[MOODLE_AI_COACH_AUFGABEN]`,r)}let e=(C.promptHorizont||``).trim()||Ct(),t=d(`klausur`,x());e=e.includes(`[MAG_STUFE]`)?e.replace(`[MAG_STUFE]`,t):e+`

`+t;let n=Tt();return e.replace(`Lernende der Jahrgangsstufe [MAG_JAHRGANG]`,I().jahrgang?`Lernende der Jahrgangsstufe `+I().jahrgang:`Lernende dieser Jahrgangsstufe`).replace(`[MAG_RAHMENDATEN]`,St()).replace(`[MAG_GESAMTPUNKTE]`,k(R()||`?`)).replace(`[MAG_AUFGABEN]`,(et()||`[keine Aufgabenstellung gefunden]`)+(n?`

`+n:``)+(L(B())?`

BISHERIGER HORIZONT (Ausgangspunkt, keine Vorlage zum Abschreiben – übernimm, was gut ist, und erstelle ihn im aktuellen Format neu. Sag mir ZUERST in zwei, drei Sätzen, dass ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst):
`+M(L(B())):``))}let Dt={Kurz:`ein bis zwei Sätze je Aufgabe`,Mittel:`drei bis vier Sätze je Aufgabe`,Ausführlich:`ein Absatz je Aufgabe mit konkretem Bezug auf die Antwort`,Umfangreich:`ein ausführlicher Absatz je Aufgabe, dazu ein eigener Abschnitt zur Operatorerfüllung`};function Ot(){return`Du bewertest Klausurantworten nach einem vorgegebenen Erwartungshorizont.

[MAG_KOPF]

RAHMENDATEN
[MAG_RAHMENDATEN]

ERWARTUNGSHORIZONT (gilt für alle Abgaben)
[MAG_HORIZONT]

[MAG_MODUS]

WICHTIG — WAS DU NICHT TUST
Du vergibst KEINE Punkte und rechnest NICHT. Die Erweiterung rechnet Punkte, Rundung,
Rechtschreibabzug und Gesamtsumme selbst. Du lieferst ausschließlich Prozentwerte,
gezählte Fehler und Begründungstexte OHNE Zahlenangaben. Schreibe in keiner Begründung
„x von y Punkten" — die Zahlen setzt die Erweiterung ein.

JE AUFGABE
Vergib einen Erfüllungsgrad in Prozent, nur diese Stufen: 100, 75, 50, 25, 0.
Verankere jede Einstufung an einer Formulierung des Erwartungshorizonts.
Prüfe dabei den Operator: Wer „erläutere" liest und nur beschreibt, erfüllt die Aufgabe
nicht vollständig, auch wenn der Inhalt stimmt.

JE ABGABE
Zähle die sprachlichen Fehler und gib sie EINZELN an — Wort, Korrektur, Kategorie.
Kategorien: satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache. Ein Satz ohne Prädikat, ein abgebrochener Satz oder ein
Satzbau, den man zweimal lesen muss, zählt als "schwer": true. Denselben Fehler im selben
Wort nur einmal zählen. Zähle vollständig — die Erweiterung leitet daraus den Abzug ab.
${Ae(He(P().jahrgang),`der Gesamtpunktzahl`)}

FEEDBACKTEXTE
Länge: [MAG_FBLAENGE]. Anrede: [MAG_ANREDE] … Sachlich, konkret, zugewandt.
Bei Sprachfehlern den fehlerhaften Satz wörtlich zitieren und richtig danebenschreiben,
nicht „achte auf die Satzstellung". Höchstens zwei bis drei Vorschläge.
Jede Aufgabe bekommt eine Begründung — auch eine vollständig richtige.

ABGABEN
[MAG_ABGABEN]

AUSGABE — am Ende genau EIN Codeblock (im Modus AUTOMATISCH nichts davor, nichts danach):

\`\`\`json
{ "bewertungen": [
  { "nr": 1,
    "besprochen": true,
    "staerken": "was gut gelungen ist",
    "aufgaben": [ { "nr": 1, "prozent": 75, "begruendung": "…", "operator": "erfüllt" } ],
    "fehler": [ { "wort": "Atomradiuse", "korrektur": "Atomradien",
                  "kategorie": "rechtschreibung", "schwer": false } ],
    "sprachfeedback": "…",
    "zusammenfassung": "…" }
] }
\`\`\`

"nr" ist die Nummer der Abgabe aus dem Datenblock, nicht die des Schülers.
In "aufgaben" ist "nr" die Aufgabennummer wie im Datenblock (z. B. "1", "2a").
"besprochen": true nur für Arbeiten, die du im Modus GEMEINSAM mit der Lehrkraft durchgegangen
bist und die sie mit OK bestätigt hat; sonst false.
Liefere für JEDE Abgabe des Blocks einen Eintrag, auch für leere Abgaben
(dort alle Prozentwerte 0 und ein Hinweis in der Zusammenfassung).`}function kt(){let e=Ot();if(!C.kompaktPrompt)return e;let t=e.indexOf(`WICHTIG — WAS DU NICHT TUST`),n=e.indexOf(`FEEDBACKTEXTE`);return t<0||n<t?e:e.slice(0,t)+Fe+`
`+Ae(He(P().jahrgang),`der Gesamtpunktzahl`)+`

`+e.slice(n)}function At(e,t){return(e||1)>1?`MODUS
Der Modus wurde in Teil 1 gewählt und gilt weiter. Frage NICHT erneut. Im Modus GEMEINSAM gehst
du diese Arbeiten wieder einzeln mit mir durch, im Modus AUTOMATISCH gibst du sofort das JSON aus.`:`MODUSFRAGE — STELLE SIE ZUERST UND WARTE
Bevor du irgendetwas bewertest, stelle GENAU DIESE EINE Frage und gib danach nichts weiter aus,
bis ich geantwortet habe:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir jede Arbeit einzeln, du bestätigst oder änderst, dann kommt die
     nächste. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alle Arbeiten und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl, kein stiller Standard. Triff keine Annahme.

MODUS GEMEINSAM — je Arbeit dieses Schema, dann warten:
  ABGABE [nr]
  Je Aufgabe: Antwort (gekürzt) · Stufe in % · Begründung (ein Satz, Bezug auf den Horizont)
  Sprachfehler: Wort → Korrektur (Kategorie)
  Rückmeldung an die Schülerin / den Schüler (so, wie sie eingetragen würde)
  Grobe Punkteschätzung (nur zur Orientierung – genau rechnet die Erweiterung)
  „1 OK – weiter · 2 Stufe ändern · 3 Rückmeldung ändern · 4 neu bewerten"
Erst nach OK kommt die nächste Arbeit. Nach der letzten Arbeit${t>1?` dieses Teils`:``} das JSON.`}function jt(e,t,n,r){let i=H(t),a=i.length?i.map(e=>e.kopf+`
`+e.text).join(`

`):L(t),o=e.map(e=>{let t=nt(e.rohHtml,e.text),n=`ABGABE `+e.nr+(t.gegliedert?``:`  (ohne Gliederung)`),r=t.gegliedert?t.aufgaben.map(e=>`  Aufgabe `+e.nr+`:
  `+(e.text||`(leer)`)).join(`
`):`  `+(e.text||`(leer)`);return n+`
`+r}).join(`

`),s=(C.promptKorrektur||``).trim(),c=P(),l=ne({fach:c.fach,jahrgang:c.jahrgang,niveau:bt[c.niveau]||c.niveau,anrede:we()}),u=s||kt();return u=(u.includes(`[MAG_KOPF]`)?u.replace(`[MAG_KOPF]`,l):l+`

`+u).replace(`[MAG_RAHMENDATEN]`,xt()).replace(`[MAG_HORIZONT]`,a||`[kein Horizont hinterlegt]`).replace(`[MAG_FBLAENGE]`,Dt[F()]||Dt.Ausführlich).replace(`[MAG_ANREDE]`,Te()).replace(`[MAG_ABGABEN]`,o).replace(`[MAG_MODUS]`,At(n,r)),r>1&&(u=`TEIL `+n+` VON `+r+` — bewerte NUR die unten stehenden Abgaben und gib nur für sie JSON aus. Warte auf den nächsten Teil.

`+u),u}function Mt(e,t,n){let r=[];if(e.staerken&&r.push(e.staerken.trim()),(e.aufgaben||[]).forEach(e=>{let i=t.teil.find(t=>t.nr===T(e.nr)),a=(n||[]).find(t=>t.nr===T(e.nr)),o=`Aufgabe `+T(e.nr)+(a&&a.kopf.includes(`·`)?` – `+a.kopf.split(`·`).slice(1).join(`·`).replace(/\(.*?\)/,``).trim():``)+`: `+(i?k(i.punkte):`?`)+` von `+(i?k(Math.round(i.max*100)/100):`?`)+` P.`;i&&i.abzug>.004&&(o+=` (davon −`+k(Math.round(i.abzug*100)/100)+` P. Rechtschreibung)`),r.push(o+`
`+(e.begruendung||``).trim())}),F()===`Umfangreich`){let t=(e.aufgaben||[]).filter(e=>e.operator);t.length&&r.push(`Operatorerfüllung:
`+t.map(e=>`Aufgabe `+T(e.nr)+`: `+e.operator).join(`
`))}let i=e.fehler||[],a=`Rechtschreibung und Sprache: `;return t.abzug>.004?a+=`Abzug `+k(t.abzug)+` von höchstens `+k(t.hoechstabzug)+` P. (`+k(t.fehlerDichte)+` Fehler je 100 Wörter).`:i.length?a+=`kein Punktabzug, aber ein paar Stellen zum Nachschauen.`:a+=`keine Auffälligkeiten.`,i.length&&(a+=`
`+i.slice(0,12).map(e=>`• `+(e.wort||``)+` → `+(e.korrektur||``)).join(`
`),i.length>12&&(a+=`
• … und `+(i.length-12)+` weitere`)),e.sprachfeedback&&(a+=`
`+e.sprachfeedback.trim()),r.push(a),e.zusammenfassung&&r.push(e.zusammenfassung.trim()),r.push(`Gesamt: `+k(t.gesamt)+` von `+k(t.max)+` Punkten.`),r.filter(Boolean).map(_e).join(`

`)}function Nt(e){let t=e.split(/\n{2,}/).map(e=>`<p>`+O(e).replace(/\n/g,`<br>`)+`</p>`).join(``),n=String(C.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim();return C.kiHinweis&&n&&(t+=`<p><em><small>`+O(n)+`</small></em></p>`),t}function Pt(e){let t=[],n=0,r=-1,i=!1,a=!1;for(let o=0;o<e.length;o++){let s=e[o];if(i){a?a=!1:s===`\\`?a=!0:s===`"`&&(i=!1);continue}if(s===`"`){n>0&&(i=!0);continue}s===`{`?(n===0&&(r=o),n++):s===`}`&&n>0&&(n--,n===0&&r>=0&&(t.push(e.slice(r,o+1)),r=-1))}return t}function Ft(e,t){let n=[],r=[],i=/```(?:json)?\s*([\s\S]*?)```/g,a;for(;(a=i.exec(e))!==null;)r.push(a[1]);if(r.push(e.replace(/```(?:json)?\s*[\s\S]*?```/g,``)),r.forEach(e=>{let r=e.trim();if(r){try{let e=JSON.parse(r),i=Array.isArray(e)?e:e[t]||(e.nr==null?null:[e]);i&&n.push(...i);return}catch{}Pt(r).forEach(e=>{try{let r=JSON.parse(e),i=Array.isArray(r)?r:r[t]||(r.nr==null?null:[r]);i&&n.push(...i)}catch{}})}}),!n.length)throw Error(`Kein verwertbares JSON gefunden.`);return n}function It(e,t){let n=new Set,r=[],i=e=>/^\s*\d+\s*$/.test(String(e))?Number(e):T(e);return e.forEach(e=>{let t=i(e.nr);n.has(t)&&r.push(t),n.add(t)}),{fehlend:t.filter(e=>!n.has(i(e))),doppelt:r}}async function Lt(e){let t=await Je(location.href),n=t.querySelector(`form#manualgradingform`)||[...t.forms].find(e=>e.querySelector(`input[name$="-mark"]`));if(!n&&!e)return await new Promise(e=>setTimeout(e,900)),Lt(!0);if(!n)throw Error(`Bewertungsformular nicht gefunden`);return{dok:t,form:n}}async function Rt(e,t,n){let{form:r}=await Lt(!1),i=Ye(r),a=[],o=0;if(e.forEach(e=>{let r=i.has(e.markfeld),s=!e.kommentarfeld||i.has(e.kommentarfeld);if(!r||!s){o++,n(`✗ Abgabe `+e.nr+`: `+(r?`Kommentarfeld`:`Punktefeld`)+` nicht auf der Seite`);return}t||(i.set(e.markfeld,k(e.punkte)),e.kommentarfeld&&i.set(e.kommentarfeld,e.feedbackHtml)),a.push(e)}),t)return n(a.length+` von `+e.length+` Abgaben vollständig vorhanden.`),{ok:a.length,fehler:o,trocken:!0};if(!a.length)return{ok:0,fehler:e.length};await Xe(r,i,location.href);let{form:s}=await Lt(!1),c=0,l=o;return a.forEach(e=>{let t=s.querySelector(`input[name="`+CSS.escape(e.markfeld)+`"]`),r=t?j(t.value):null;r!==null&&Math.abs(r-e.punkte)<.005?(c++,n(`✓ Abgabe `+e.nr+` — `+k(e.punkte)+` P. eingetragen`)):(l++,n(`✗ Abgabe `+e.nr+` — steht auf `+(r==null?`keinem Wert`:k(r))+` statt `+k(e.punkte)))}),{ok:c,fehler:l}}let zt=u===`bearbeiten`?[[`horizont`,`1 · Horizont`],[`vorlage`,`2 · Layout-Vorlage`],[`einst`,`⚙`]]:[[`korrektur`,`1 · Bewerten`],[`horizont`,`2 · Horizont`],[`einst`,`⚙`]],W=D(`div`,`mag-panel`);W.innerHTML=`
    <div class="mag-kopf">
      <img class="mag-kopfbild" alt="">
      <div class="mag-titelblock">
        <span class="mag-titel">Freitext Grader <span class="mag-version"></span></span>
        <span class="mag-untertitel"></span>
      </div>
      <button class="mag-ikon" data-tu="zu" title="Schließen">✕</button>
    </div>
    <div class="mag-banner" hidden></div>
    <div class="mag-reiter">

    </div>

    <div class="mag-inhalt" data-panel="horizont">
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier entsteht der Erwartungshorizont dieser Aufgabe – der Maßstab, nach dem die KI später alle Antworten bewertet. Du kopierst einen Prompt, lässt die KI den Horizont schreiben und trägst ihn in die Aufgabe ein. Das geschieht einmal je Aufgabe; danach bleibt er in der Aufgabe gespeichert, auch beim Export.</p>
      </details>
      <div class="mag-status" data-rolle="hstatus"></div>
      <details class="mag-details" data-rolle="hbisher" hidden>
        <summary>Gespeicherten Horizont ansehen</summary>
        <pre class="mag-hinweis" style="white-space:pre-wrap;max-height:220px;overflow:auto;"></pre>
      </details>
      <div class="mag-modus" data-rolle="hmodus" hidden>
        <div class="mag-rahmen-titel">Diese Aufgabe</div>
        <label>Modus</label>
        <select data-rolle="hmodussel">
          <option value="kurztest">Kurztest – kurze Antworten, schnelle Bewertung</option>
          <option value="klausur">Klausur – Teilaufgaben, Portionen, Review</option>
        </select>
        <div class="mag-hinweis" data-rolle="hmodushinweis"></div>
        <label>Feedbacklänge</label>
        <select data-rolle="hfeedbacksel"></select>
        <div class="mag-hinweis" data-rolle="hfeedbackhinweis"></div>
        <div class="mag-zeile3">
          <div><label>Fach</label><input type="text" data-rolle="hfach" placeholder="z. B. Chemie"></div>
          <div><label>Jahrgang</label><select data-rolle="hjahrgang"></select></div>
          <div><label>Niveau</label><select data-rolle="hniveau">
            <option value="G">gymnasial</option><option value="M">mittel</option><option value="E">einfach</option>
          </select></div>
        </div>
        <div class="mag-hinweis" data-rolle="hrahmenhinweis"></div>
        <details class="mag-details mag-mehr">
          <summary>Was gehört hierher – und was nicht?</summary>
          <p class="mag-hinweis">Alles in diesem Kasten gehört <strong>zur Aufgabe</strong>: Es bestimmt, wie der
          Erwartungshorizont aussieht (z. B. welche Formulierungen für Jahrgang 9 als richtig gelten), und wird
          zusammen mit dem Horizont in der Aufgabe gespeichert. So gilt es auch in Zufallspools, beim Export
          und bei Kolleginnen und Kollegen.</p>
          <p class="mag-hinweis"><strong>Rechtschreibung, Punkteschritte und Anrede (Du/Sie)</strong> legst du
          erst <strong>beim Bewerten</strong> fest – sie gehören zur Bewertung einer Lerngruppe, nicht zur Aufgabe.</p>
        </details>
      </div>
      <details class="mag-details mag-hilfe" data-rolle="hhilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Der Erwartungshorizont sagt der KI später beim Bewerten, was eine
        richtige Antwort ist. So entsteht er:</p>
        <p class="mag-hinweis"><strong>1 · Horizont-Prompt kopieren:</strong> Die Erweiterung nimmt
        Aufgabenstellung, Punkte und die Angaben unter „Diese Aufgabe" und baut daraus einen Prompt, mit dem die KI den
        Erwartungshorizont schreibt. Mit den Antworten der Lernenden hat er nichts zu tun – die
        kommen erst beim Bewerten.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Verweist die
        Aufgabe auf Material, fragt die KI danach. Sie zeigt den Horizont zuerst als lesbaren Text –
        prüfen, ggf. ändern lassen, dann mit „ok" antworten. Erst dann kommt ein Codeblock: diesen hier einfügen.</p>
        <p class="mag-hinweis"><strong>3 · Eintragen:</strong> Der Horizont wird im Feld
        „Informationen für Bewerter/innen" dieser Aufgabe gespeichert. Schülerinnen und Schüler sehen ihn nicht.</p>
      </details>
      <label data-rolle="hschritt1">1 · Prompt zum Erstellen des Erwartungshorizonts kopieren</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-primary" data-tu="hprompt">📋 Horizont-Prompt kopieren</button>
        <button class="mag-btn mag-btn-rand" data-tu="hedit" title="Prompt anpassen">✏️</button>
      </div>
      <div class="mag-hinweis" data-rolle="hmaterial" hidden></div>
      <label>2 · Erwartungshorizont der KI einfügen</label>
      <div class="mag-hinweis">Die Erweiterung hat bewusst keinen eigenen KI-Zugang: Du wählst die KI,
      und Aufgaben gehen nur dorthin, wo du sie einfügst. Den Codeblock der KI vollständig hier
      einfügen – er wird sofort geprüft und angezeigt. Gespeichert wird erst in Schritt 3.
      Den lesbaren Text vor dem „ok" brauchst du hier nicht, nur den Codeblock danach.</div>
      <textarea data-rolle="hjson" rows="5" placeholder='{ "aufgaben": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="hpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-liste" data-rolle="hliste"></div>
      <div class="mag-protokoll" data-rolle="hlog" hidden></div>
      <div class="mag-reihe" data-rolle="hknoepfe" hidden></div>
      <details class="mag-details">
        <summary>Kein Bearbeitungsrecht? Horizont hier behalten</summary>
        <p class="mag-hinweis">Wer Fragen nicht bearbeiten darf, klebt den fertigen Horizont
        hierher. Er bleibt dann in der Erweiterung statt in der Frage.</p>
        <textarea data-rolle="hlokal" rows="4" placeholder="Erwartungshorizont …"></textarea>
        <button class="mag-btn mag-btn-rand" data-tu="hlokalsichern">Hier speichern</button>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="vorlage" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier gestaltest du das Aussehen der Aufgabe für die Lernenden – ein
        Zusatz nach Geschmack, für die Bewertung nicht nötig. Er erscheint, sobald die Aufgabe einen
        Erwartungshorizont hat, weil Teilaufgaben, Anforderungsbereiche und Punkte von dort kommen.
        Du kannst die Aufgabenstellung, die Antwortvorlage oder beides gestalten.</p>
        <p class="mag-hinweis"><strong>Aufgabenstellung gestalten:</strong> Der Fragetext kommt in
        farbige Karten – eine Karte je Teilaufgabe, vorn eine Marke (1, 2a, 2b; im Kurztest a, b),
        hinten die Punkte. Eine Kurztest-Aufgabe ohne Teile bekommt eine Karte. Links steht der Anforderungsbereich, der Operator wird fett in der AFB-Farbe
        hervorgehoben (AFB I grün, II orange, III rot). Der Wortlaut bleibt gleich.</p>
        <p class="mag-hinweis"><strong>Antwortvorlage gestalten:</strong> Statt eines leeren weißen
        Eingabefelds sehen die Lernenden einen Antwortkasten mit Kopfzeile – einen je Teilaufgabe, mit
        derselben Marke wie in der Aufgabenstellung. So schreiben sie jede Antwort an die richtige Stelle, und die Erweiterung kann sie
        beim Bewerten sicher zuordnen. Die Kopfzeile zählt beim Bewerten nicht als Schülertext.</p>
        <p class="mag-hinweis"><strong>Nichts wird automatisch gespeichert.</strong> Die Erweiterung
        fügt das Layout nur in das geöffnete Formular ein. Gefällt es dir, speicherst du mit
        „Änderungen speichern". Sonst „Abbrechen" – dann bleibt die Aufgabe, wie sie war.</p>
      </details>
      <div class="mag-status" data-rolle="vstatus"></div>
      <label>Was möchtest du gestalten?</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAufgabe"> Aufgabenstellung</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAntwort"> Antwortvorlage</label>
      <div class="mag-hinweis">Beides zusammen ist der Normalfall: Aufgabe und Antwortkasten tragen dann
      dieselbe Marke (1, 2a, 2b …), dieselbe AFB-Farbe und dieselben Punkte.</div>

      <div data-rolle="lseca" hidden>
        <div class="mag-hinweis">Der Fragetext kommt ins AFB-Kartendesign. Text und Bilder bleiben
        erhalten, nur die Gestaltung ändert sich. Material (M1, M2 …) bleibt außerhalb der Karten.</div>
        <label class="mag-haken" data-rolle="lpunktezeile"><input type="checkbox" data-opt="kartePunkte"> Punkte je Teilaufgabe anzeigen</label>
        <div class="mag-hinweis" data-rolle="lpunktehinweis">Moodle zeigt nur die Gesamtpunktzahl der Aufgabe. Bei mehreren
        Teilaufgaben sehen die Lernenden so, wie viel jede einzelne bringt.</div>
        <div class="mag-hinweis" data-rolle="lahinweise"></div>
        <label>Vorschau – so sieht die Aufgabe aus</label>
        <div class="mag-vorschau" data-rolle="lavorschau"></div>
      </div>

      <div data-rolle="lsecv" hidden>
        <label class="mag-haken"><input type="checkbox" data-opt="afbFarben"> Farben nach Anforderungsbereich</label>
        <div class="mag-hinweis">AFB I grün, AFB II orange, AFB III rot. Ohne Häkchen: neutrales Grau.</div>
        <label class="mag-haken"><input type="checkbox" data-opt="vorlagePunkte"> Punkte anzeigen</label>
        <div class="mag-hinweis">z. B. „(2 Punkte)" – die Lernenden sehen, wie ausführlich sie antworten sollten.</div>
        <label class="mag-haken"><input type="checkbox" data-opt="vorlageAfb"> Anforderungsbereich anzeigen</label>
        <div class="mag-hinweis">z. B. „AFB II" – nur, wenn er bekannt ist (Klausur: aus dem Horizont;
        Kurztest: wenn „AFB …" in der Aufgabenstellung steht).</div>
        <div class="mag-hinweis" data-rolle="vformat" hidden></div>
        <label>Vorschau – so sieht das Eingabefeld aus</label>
        <div class="mag-vorschau" data-rolle="vvorschau"></div>
      </div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="lein">Ins Formular einfügen</button>
      </div>
      <p class="mag-hinweis">Eingefügt wird nur ins Formular. Speichern mit „Änderungen speichern" –
      oder „Abbrechen", wenn es dir nicht gefällt.</p>
    </div>

    <div class="mag-inhalt" data-panel="korrektur" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier werden alle Antworten zu dieser Aufgabe mit KI-Hilfe bewertet und
        danach mit Punkten und Rückmeldung in Moodle eingetragen. Maßstab ist der Erwartungshorizont
        der Aufgabe (Reiter „Horizont").</p>
      </details>
      <details class="mag-details mag-hilfe" data-rolle="khilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis"><strong>1 · Bewertungsprompt kopieren:</strong> Die Erweiterung packt
        Erwartungshorizont, die Angaben unter „Für diese Bewertung" und alle Antworten in einen Prompt. Namen gehen nicht mit –
        die Antworten sind nur nummeriert.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Die KI fragt
        zuerst: <em>gemeinsam durchgehen</em> (Arbeit für Arbeit, du kannst jede ändern – empfohlen) oder
        <em>automatisch</em>. Die KI beurteilt nur: Stufe je Aufgabe, Sprachfehler, Begründung,
        Rückmeldung. Sie rechnet keine Punkte.</p>
        <p class="mag-hinweis"><strong>3 · Antwort der KI hier einfügen.</strong> Die Erweiterung rechnet
        Punkte und Rechtschreibabzug und zeigt jede Bewertung zur Kontrolle („bisher → neu").</p>
        <p class="mag-hinweis"><strong>4 · Eintragen.</strong> Gemeinsam besprochene Arbeiten lassen sich
        direkt eintragen. Automatisch bewertete musst du einmal ansehen – überspringen geht nur mit
        ausdrücklicher Bestätigung.</p>
      </details>
      <div class="mag-status" data-rolle="kstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Für diese Bewertung</div>
        <label>Anrede im Feedback</label>
        <select data-rolle="kanrede">
          <option value="auto">Automatisch nach Jahrgang</option>
          <option value="du">Du</option><option value="sie">Sie</option>
        </select>
        <div class="mag-hinweis" data-rolle="anredehinweis"></div>
        <label data-rolle="krslabel">Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl</label>
        <select data-rolle="krs">
          <option value="0">0 % – kein Abzug</option><option value="5">5 %</option>
          <option value="10">10 %</option><option value="15">15 %</option>
          <option value="20">20 %</option><option value="25">25 %</option><option value="30">30 %</option>
        </select>
        <div class="mag-hinweis" data-rolle="rshinweis"></div>
        <label>Punkteschritte</label>
        <select data-opt="punkteschritte">
          <option value="0.25">0,25</option><option value="0.5">0,5</option><option value="1">1 – nur ganze Punkte</option>
        </select>
        <details class="mag-details mag-mehr">
          <summary>Was bedeuten Anrede, Rechtschreibung, Punkteschritte und die Angaben aus dem Horizont?</summary>
          <p class="mag-hinweis"><strong>Anrede:</strong> „Automatisch" schreibt bis Jahrgang 10 „Du hast …",
          ab Jahrgang 11 „Sie haben …".</p>
          <p class="mag-hinweis"><strong>Rechtschreibung:</strong> So viel Prozent der Gesamtpunktzahl kann die
          Sprache höchstens kosten. Die Erweiterung merkt sich einen Wert für die Sekundarstufe I (bis Jahrgang 10)
          und einen für die Oberstufe. Auch bei 0 % bekommen die Lernenden eine Rückmeldung zur Sprache.</p>
          <p class="mag-hinweis"><strong>Punkteschritte:</strong> Auf diese Schritte wird die Punktzahl je Aufgabe gerundet.</p>
          <p class="mag-hinweis"><strong>Fach, Jahrgang, Niveau, Feedbacklänge:</strong> Der Horizont regelt die
          Bewertung. Diese Angaben kommen aus dem gespeicherten Horizont der Aufgabe. Ändern heißt: im Reiter
          Horizont einen neuen Horizont erstellen und eintragen.</p>
        </details>
        <div class="mag-rahmen-titel" style="margin-top:8px">Aus dem gespeicherten Horizont dieser Aufgabe</div>
        <div data-rolle="krahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zuhorizont">im Reiter Horizont ändern</button>
      </div>
      <label>Abgaben je Durchgang</label>
      <select data-rolle="kgroesse"></select>
      <div class="mag-hinweis" data-rolle="kgroessehinweis"></div>
      <div class="mag-hinweis">Eine KI kann pro Antwort nur begrenzt viel Text schreiben. Bei vielen oder
      langen Arbeiten bricht sie sonst mitten im Ergebnis ab oder wird ungenau. Deshalb teilt die
      Erweiterung die Lerngruppe in Portionen – den Vorschlag rechnet sie aus der Textlänge. Geteilt
      wird immer nach Personen, nie nach Aufgaben: Jede Arbeit wird als Ganzes bewertet.</div>
      <label>1 · Bewertungsprompt mit allen Antworten kopieren</label>
      <div class="mag-reihe" data-rolle="kknoepfe"></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kedit">✏️ Prompt anpassen</button>
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="krohdaten">📋 Rohdaten</button>
      </div>
      <label>2 · Ergebnis der KI einfügen</label>
      <div class="mag-hinweis">Hier den Codeblock einfügen, den die KI am Ende ausgibt – nicht den Text
      davor. <strong>Bei mehreren Teilen:</strong> Teil 1 kopieren → in die KI → Ergebnis hier einfügen.
      Dann Teil 2 im <em>selben</em> KI-Chat einfügen und sein Ergebnis <em>unter</em> das erste in dieses
      Feld setzen – alle Teile untereinander. Die Erweiterung setzt sie zusammen und meldet, welche
      Arbeiten noch fehlen.</div>
      <textarea data-rolle="kjson" rows="5" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="kpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-hinweis" data-rolle="rsabgleich" hidden></div>
      <div class="mag-liste" data-rolle="kliste"></div>
      <div class="mag-protokoll" data-rolle="klog" hidden></div>
      <div class="mag-reihe" data-rolle="keintragen" hidden>
        <button class="mag-btn mag-btn-ok" data-tu="kschreiben">Alle eintragen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="einst" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier steht nur, was für <strong>alle</strong> Aufgaben gleich ist. Alles andere
        steht dort, wo es gebraucht wird: Fach, Jahrgang, Niveau, Modus und Feedbacklänge im Reiter
        „Horizont" (gehören zur Aufgabe), Anrede, Rechtschreibung und Punkteschritte beim Bewerten im Reiter
        „Bewerten" (gehören zur Bewertung einer Lerngruppe, nicht zur Aufgabe).</p>
      </details>
      <div class="mag-status" data-rolle="estatus"></div>
      <p class="mag-hinweis">Diese Einstellungen gelten überall in der Erweiterung – auf der
      Bewertungsseite einer Aufgabe ebenso wie auf der Kurztest-Übersicht.</p>
      <label class="mag-haken"><input type="checkbox" data-opt="kiHinweis"> KI-Hinweis unter das Feedback</label>
      <label>Text des KI-Hinweises</label>
      <textarea data-opt="kiHinweisText" rows="3"></textarea>
      <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kistandard">Standardtext einsetzen</button>
      <details class="mag-details mag-mehr">
        <summary>Was bedeutet „KI-Hinweis“?</summary>
        <p class="mag-hinweis">Unter jedes eingetragene Feedback setzt die Erweiterung diesen Satz, kursiv
        und klein. Er kommt von der Erweiterung, nicht von der KI. Den Wortlaut kannst du ändern.</p>
      </details>
      <label class="mag-haken"><input type="checkbox" data-opt="entferneQuellen"> Quellenangaben entfernen</label>
      <details class="mag-details mag-mehr">
        <summary>Was bedeutet „Quellenangaben entfernen“?</summary>
        <p class="mag-hinweis">Manche KI-Chats hängen Quellenmarken wie [1] oder 【4†source】 an. Mit Häkchen
        entfernt die Erweiterung sie aus dem Feedback, bevor es eingetragen wird.</p>
      </details>
      <label class="mag-haken"><input type="checkbox" data-opt="kompaktPrompt"> Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <details class="mag-details mag-mehr">
        <summary>Was bedeutet „Kompakter Prompt“?</summary>
        <p class="mag-hinweis">Der Bewertungsprompt verweist für die Bewertungslogik auf die Skills
        „2-didaktik-bewertung" und „3-moodle-erweiterungen", statt sie auszuschreiben – spart mehrere Tausend
        Zeichen. <strong>Nur einschalten, wenn die verwendete KI diese Skills wirklich kennt.</strong> Den
        Prompt selbst kannst du im Reiter Bewerten unter „✏️ Prompt anpassen" lesen und ändern.</p>
      </details>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="esichern">Speichern und zurück</button>
        <button class="mag-btn mag-btn-grau" data-tu="eabbruch">Verwerfen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="prompt" hidden>
      <label data-rolle="ptitel">Prompt bearbeiten</label>
      <textarea data-rolle="ptext" rows="16"></textarea>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="psichern">Speichern</button>
        <button class="mag-btn mag-btn-rand" data-tu="pzurueck">↺ Original</button>
        <button class="mag-btn mag-btn-grau" data-tu="pabbruch">Abbrechen</button>
      </div>
    </div>`,W.querySelector(`.mag-version`).textContent=e;let Bt=W.querySelector(`.mag-reiter`);zt.forEach((e,t)=>{let n=document.createElement(`button`);n.className=`mag-tab`+(t===0?` aktiv`:``),n.dataset.tab=e[0],n.textContent=e[1],Bt.appendChild(n)});function Vt(e,t,n){let r=document.createElement(`button`);return r.className=t,r.dataset.tu=n,r.textContent=e,r}let Ht=W.querySelector(`[data-rolle="hknoepfe"]`);u!==`bearbeiten`&&Ht.appendChild(Vt(`In die Frage eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));let Ut=D(`button`,`mag-knopf`);Ut.title=`Moodle AI Freitext Grader`;let Wt=document.createElement(`img`);Wt.className=`mag-knopf-bild`,Wt.alt=`Moodle AI Freitext Grader`;try{Wt.src=t.runtime.getURL(`icon/128.png`)}catch{Ut.textContent=`AI`}Wt.src&&Ut.appendChild(Wt);let G=e=>W.querySelector(`[data-rolle="`+e+`"]`),K=null,q=null,Gt=zt[0][0],Kt=!1,qt=!1,Jt=!1;if(typeof IntersectionObserver<`u`){let e=new IntersectionObserver(t=>t.forEach(t=>{t.isIntersecting&&(t.target.dataset.gesehen=`1`,e.unobserve(t.target))}),{threshold:.5}),t=G(`kliste`);t&&new MutationObserver(t=>t.forEach(t=>t.addedNodes.forEach(t=>{t.nodeType===1&&t.classList.contains(`mag-karte`)&&(Jt=!1,e.observe(t))}))).observe(t,{childList:!0})}function Yt(){return u===`bearbeiten`&&!new URLSearchParams(location.search).get(`id`)}function Xt(){let e=V();if(e.wer===`coach`)return`kurztest`;if(e.wer===`grader`)return`klausur`;let t=et();return!/(^|\n)\s*(?:[a-h]\)|aufgabe\s*\d|\d+[.)]\s)/i.test(t)&&(R()||0)<=3?`kurztest`:`klausur`}let J=u===`bearbeiten`?Xt():V().wer===`coach`?`kurztest`:`klausur`,Zt={kurztest:[[`Kurz`,`Kurz – 1–2 Sätze`],[`Mittel`,`Mittel – 3–5 Sätze (Standard)`]],klausur:[[`Mittel`,`Mittel – 3–4 Sätze je Teilaufgabe`],[`Ausführlich`,`Ausführlich – ein Absatz je Teilaufgabe (Standard)`],[`Umfangreich`,`Umfangreich – dazu Abschnitt Operatorerfüllung`]]},Qt={kurztest:`Mittel`,klausur:`Ausführlich`},Y=(()=>{let e=b(B()||C.horizontLokal||``);return e&&Zt[J].some(t=>t[0]===e)?e:Qt[J]})();function $t(){let e=G(`hfeedbacksel`);e&&(e.innerHTML=``,Zt[J].forEach(([t,n])=>{let r=document.createElement(`option`);r.value=t,r.textContent=n,e.appendChild(r)}),Zt[J].some(e=>e[0]===Y)||(Y=Qt[J]),e.value=Y,G(`hfeedbackhinweis`).textContent=J===`kurztest`?`Bei „Kurz" und „Mittel" passt die ganze Klasse meist in einen Durchgang.`:`Klausuren werden in Portionen bewertet; längeres Feedback heißt kleinere Portionen.`)}let X=null;u===`bearbeiten`&&Ht.appendChild(Vt(`3 · In die Aufgabe eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));function en(){let e=G(`hmodus`);if(e&&(e.hidden=!1,G(`hmodussel`).value=J,G(`hmodushinweis`).textContent=J===`kurztest`?`Kurztest: kurze Antworten, Horizont mit Kernaussage und „Auch richtig". Bewertet wird auf der Übersicht, alle Kurztest-Aufgaben eines Tests zusammen. Layout-Vorlage: ein Kasten „Deine Antwort".`:`Klausur: Horizont je Teilaufgabe mit Punkten, Operator und AFB, dazu eine Layout-Vorlage mit einem Kasten je Teilaufgabe. Bewertet wird auf der Einzelseite der Aufgabe, in Portionen, mit Review vor dem Eintragen.`,$t(),vt(),u===`bearbeiten`)){let e=Ht.querySelector(`[data-tu="hschreiben"]`);e&&(e.hidden=!1)}}G(`hfeedbacksel`).addEventListener(`change`,()=>{Y=G(`hfeedbacksel`).value,$()}),G(`hmodussel`).addEventListener(`change`,()=>{J=G(`hmodussel`).value,Y=Qt[J],K=null,X=null,G(`hliste`).innerHTML=``,G(`hknoepfe`).hidden=!0,Z(`hstatus`,`Modus: `+(J===`kurztest`?`Kurztest`:`Klausur`)+`. Bitte den Prompt jetzt (neu) kopieren.`),en()});function tn(){Ne(),N={fach:(G(`hfach`).value||``).trim(),jahrgang:G(`hjahrgang`).value||``,niveau:G(`hniveau`).value||`G`,ausHorizont:!!Ie().jahrgang},C.fach=N.fach,C.jahrgang=N.jahrgang,C.kursniveau=N.niveau,Q(),$()}[`hfach`,`hjahrgang`,`hniveau`].forEach(e=>{let t=G(e);t&&t.addEventListener(e===`hfach`?`input`:`change`,tn)});function nn(){u===`bewertung`&&G(`kjson`)&&G(`kjson`).value.trim()&&q&&On()}G(`kanrede`)&&G(`kanrede`).addEventListener(`change`,()=>{C.anredeWahl=G(`kanrede`).value,Q(),$(),nn()}),G(`krs`)&&G(`krs`).addEventListener(`change`,()=>{C[Ue(P().jahrgang)]=G(`krs`).value,Q(),$(),nn()}),en();function rn(e){let t=M(String(e||``).replace(/\r/g,``)).trim().split(/\n\s*\n/).filter(e=>e.trim()).map(e=>`<p>`+O(e.trim()).replace(/\n/g,`<br>`)+`</p>`).join(``);return`<p>`+n+`</p>`+v(Y)+t}function an(e,t){try{Z(t,`Ins Formular eingesetzt: `+Object.keys(e).map(t=>t+` (`+_(t,e[t])+`)`).join(`, `)+`. Wird mit „Änderungen speichern" zusammen mit der Frage gespeichert.`)}catch(e){Z(t,`Fehler: `+e.message,!0)}}function on(e){if(Kt)return;Kt=!0,qt=!0,e.hidden=!0;let t=new URLSearchParams(location.search),n=t.get(`id`),r=t.get(`slot`),i=t.get(`qid`),a=W.querySelector(`[data-panel="korrektur"]`);if(!a||!r||!i)return;a.classList.add(`mag-kurztest`);let o=a.querySelector(`.mag-wozu .mag-hinweis`);o&&(o.textContent=`Diese Frage ist ein Kurztest. Hier bewertest du ihre Antworten einzeln: Antworten laden, Prompt kopieren, Ergebnis der KI einfügen, eintragen. Maßstab ist der Erwartungshorizont der Aufgabe (Reiter „Horizont").`);let s=D(`div`,`mag-kurztest-weg`);a.appendChild(s);let c=w(`.que .qtext`),l=c?c.textContent.replace(/\s+/g,` `).trim().slice(0,60):`Diese Aufgabe`;try{Ve({einzel:{slot:r,qid:i,name:l},ziel:s,uebersicht:n?ze(n):null})}catch(e){s.textContent=`Der Kurztest-Weg ließ sich hier nicht starten: `+e.message}}function sn(){if(u===`bearbeiten`)return location.href;let e=new URLSearchParams(location.search),t=e.get(`qid`),n=e.get(`id`)||e.get(`cmid`);return t?location.origin+`/question/bank/editquestion/question.php?id=`+t+(n?`&cmid=`+n:``):null}function Z(e,t,n){let r=G(e);r&&(r.textContent=t||``,r.className=`mag-status`+(t?n?` fehler`:` ok`:``))}function cn(e){let t=G(e);return t.hidden=!1,t.innerHTML=``,e=>{t.appendChild(D(`div`,`mag-logzeile`,e)),t.scrollTop=t.scrollHeight}}function ln(){return new Promise(e=>{if(!(t!==void 0&&t.storage))return e();t.storage.local.get([`magSettings`],t=>{t.magSettings&&(C=Object.assign({},ce,t.magSettings)),e()})})}function Q(){t!==void 0&&t.storage&&t.storage.local.set({magSettings:C})}function un(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;e.type===`checkbox`?e.checked=!!C[t]:e.value=C[t]==null?``:C[t]}),$()}function dn(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;C[t]=e.type===`checkbox`?e.checked:e.value}),String(C.kiHinweisText||``).trim()||(C.kiHinweisText=je),C.promptHorizont=null,C.promptKorrektur=null,Q(),$()}function fn(){let e=P();return[e.fach||`⚠ Fach fehlt`,`Jahrgang `+(e.jahrgang||`⚠ fehlt`),`Niveau `+(bt[e.niveau||`G`]||e.niveau),`Feedback `+F()].join(` · `)}function pn(){let e=I();return!String(e.fach||``).trim()||!String(e.jahrgang||``).trim()}function mn(){if(u!==`bewertung`||!N)return Y&&u===`bewertung`&&Y!==F();let e=P(),t=I();return(t.fach||``)!==(e.fach||``)||String(t.jahrgang||``)!==String(e.jahrgang||``)||(t.niveau||`G`)!==(e.niveau||`G`)||x()!==F()}function hn(){let e=G(`krahmen`);if(e){let t=P();e.textContent=fn()+(u===`bewertung`&&!t.ausHorizont?`  –  Der Horizont enthält diese Angaben noch nicht; es gelten die zuletzt benutzten Werte. Feste Werte bekommt die Aufgabe mit einem neu eingetragenen Horizont.`:``)+(u===`bewertung`&&!oe()?`  –  Feedbacklänge: Standard.`:``)+(u===`bewertung`&&mn()?`  –  Im Reiter Horizont stehen Änderungen, die noch nicht eingetragen sind. Bewertet wird nach dem gespeicherten Horizont, bis du den neuen einträgst.`:``),e.parentElement.classList.toggle(`unvollstaendig`,pn())}let t=G(`kanrede`);t&&(t.value=C.anredeWahl||`auto`);let n=P().jahrgang,r=G(`krs`);r&&(r.value=He(n));let i=G(`krslabel`);i&&(i.textContent=`Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl – `+(Se(n)===`sek2`?`Oberstufe (ab Jahrgang 11)`:`Sekundarstufe I (bis Jahrgang 10)`));let a=I(),o=G(`hfach`);o&&document.activeElement!==o&&(o.value=a.fach||``);let s=G(`hjahrgang`);if(s){if(!s.options.length){let e=document.createElement(`option`);e.value=``,e.textContent=`–`,s.appendChild(e);for(let e=5;e<=13;e++){let t=document.createElement(`option`);t.value=String(e),t.textContent=String(e),s.appendChild(t)}}s.value=a.jahrgang||``}let c=G(`hniveau`);c&&(c.value=a.niveau||`G`);let l=G(`hrahmenhinweis`);if(l){let e=pn();l.textContent=e?`⚠ Bitte Fach und Jahrgang angeben – sie gehen in den Prompt und in den Horizont.`:u===`bewertung`?`Der Horizont regelt die Bewertung: Änderungen hier gelten erst, wenn du den neuen Horizont in Schritt 3 einträgst. Bis dahin wird nach dem gespeicherten Horizont bewertet.`:Ie().jahrgang?``:`Vorbelegt mit den zuletzt benutzten Werten – bitte prüfen.`,l.classList.toggle(`fehler`,e)}}function $(){hn();let e=G(`anredehinweis`);e&&(e.textContent=`Im Feedback steht „`+Te()+` …"`+((C.anredeWahl||`auto`)===`auto`?` (Jahrgang `+(P().jahrgang||`?`)+`).`:`.`));let t=G(`rshinweis`);t&&(t.textContent=ke(He(P().jahrgang),`der Gesamtpunktzahl`));let n=G(`vvorschau`),r=mt();n&&Ge(n,r||`<p class="mag-hinweis">Im Horizont sind keine Teilaufgaben erkennbar – daraus entstehen die Kästen.</p>`);let i=G(`vformat`);i&&(i.hidden=pt(),i.textContent=`Hinweis: Das Antwortformat dieser Aufgabe ist nicht „HTML-Editor". Beim Einfügen stellt die Erweiterung es auf „HTML-Editor" um – „Nur Text" kann kein Layout darstellen.`),vt();let a=G(`vhorizont`);a&&Ge(a,J===`kurztest`&&u===`bearbeiten`?X?rn(X):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`:K?yt(K):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`)}function gn(e){W.querySelectorAll(`.mag-inhalt`).forEach(t=>{t.hidden=t.dataset.panel!==e}),W.querySelectorAll(`.mag-tab`).forEach(t=>t.classList.toggle(`aktiv`,t.dataset.tab===e));let t=zt.some(t=>t[0]===e);W.querySelector(`.mag-reiter`).hidden=!t,t&&e!==`einst`&&(Gt=e),e===`vorlage`&&$(),e===`korrektur`&&En()}let _n=null;function vn(e,t,n,r){navigator.clipboard.writeText(e).then(()=>{let i=n+`  (`+e.length.toLocaleString(`de-DE`)+` Zeichen)`;if(Z(t,i),!r||!G(r))return;clearInterval(_n);let a=3;Z(t,i+` — weiter in `+a+` s`),_n=setInterval(()=>{if(a--,a>0)return Z(t,i+` — weiter in `+a+` s`);clearInterval(_n),_n=null,Z(t,i+` — jetzt die Antwort der KI einfügen.`);let e=G(r);e.focus(),e.scrollIntoView({block:`nearest`})},1e3)}).catch(()=>Z(t,`Kopieren fehlgeschlagen — Text bitte von Hand markieren.`,!0))}function yn(){let e=G(`hjson`).value.trim();if(!e)return Z(`hstatus`,`Bitte erst die Antwort der KI einfügen.`,!0);if(J===`kurztest`)return bn(e);try{let t=Ft(e,`aufgaben`).map(e=>({nr:T(e.nr),schlagwort:e.schlagwort||``,afb:e.afb||``,punkte:e.punkte==null?null:j(e.punkte),operator:e.operator||``,horizont:e.horizont||e.text||``})).filter(e=>/^\d{1,2}[a-h]?$/.test(e.nr)).sort((e,t)=>parseInt(e.nr,10)-parseInt(t.nr,10)||e.nr.localeCompare(t.nr));if(!t.length)throw Error(`Keine Aufgaben im JSON.`);let{doppelt:n}=It(t,t.map(e=>e.nr));if(n.length)throw Error(`Aufgabe `+n.join(`, `)+` kommt doppelt vor.`);let r=t.reduce((e,t)=>e+(t.punkte||0),0),i=R();K=t;let a=G(`hliste`);a.innerHTML=``,t.forEach(e=>{let t=D(`div`,`mag-karte`);t.appendChild(D(`div`,`mag-kartenkopf`,`Aufgabe `+e.nr+(e.afb?` · AFB `+e.afb:``)+(e.schlagwort?` · `+e.schlagwort:``)+(e.punkte==null?``:`  (`+k(e.punkte)+` P.)`)));let n=D(`textarea`,`mag-kartentext`);n.value=L(e.horizont),n.rows=5,n.addEventListener(`input`,()=>{e.horizont=n.value}),t.appendChild(n),a.appendChild(t)});let o=t.length+` Aufgaben gelesen.`;i&&Math.abs(r-i)>.005&&(o+=`  ⚠ Punktsumme `+k(r)+` weicht von der Fragenpunktzahl `+k(i)+` ab — die Erweiterung rechnet sie beim Bewerten um.`),u===`bearbeiten`&&(o+=`  Dann „3 · In die Aufgabe eintragen".`),Z(`hstatus`,o),G(`hknoepfe`).hidden=!1,$()}catch(e){Z(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}function bn(e){try{let t=Ft(e,`horizonte`).find(e=>e&&(e.text||e.horizont));if(!t)throw Error(`Kein Horizont im JSON (erwartet: "horizonte").`);X=String(t.text||t.horizont).trim();let n=G(`hliste`);n.innerHTML=``;let r=D(`div`,`mag-karte`);r.appendChild(D(`div`,`mag-kartenkopf`,`Kurztest-Horizont`));let i=D(`textarea`,`mag-kartentext`);i.value=X,i.rows=12,i.addEventListener(`input`,()=>{X=i.value}),r.appendChild(i),n.appendChild(r),Z(`hstatus`,`Horizont gelesen. Prüfen, bei Bedarf ändern, dann „In die Frage eintragen".`),G(`hknoepfe`).hidden=!1,en()}catch(e){Z(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function xn(e){if(J===`kurztest`){if(!X)return Z(`hstatus`,`Es liegt noch kein geprüfter Horizont vor.`,!0);let t={"graderinfo[text]":rn(X)};return Yt()?(an(t,`hstatus`),vt(),setTimeout(_t,50)):(await wn(t,e,cn(`hlog`),`hstatus`),!e&&u===`bearbeiten`&&Sn(t),vt(),setTimeout(_t,50))}if(Yt()&&K)return an({"graderinfo[text]":yt(K)},`hstatus`),vt(),setTimeout(_t,50);let t=`hstatus`;if(!K)return Z(t,`Es liegt noch kein geprüfter Horizont vor — bitte erst im Reiter „Horizont" die Antwort der KI einlesen und prüfen.`,!0);if(!sn())return Z(t,`Die Adresse der Frage lässt sich hier nicht bestimmen — bitte die Frage zum Bearbeiten öffnen.`,!0);let n=cn(`hlog`),r={"graderinfo[text]":yt(K)};await wn(r,e,n,t),!e&&u===`bearbeiten`&&Sn(r),vt(),setTimeout(_t,50)}function Sn(e){try{Object.keys(e).forEach(t=>_(t,e[t]))}catch{}}function Cn(){try{let e=[],t=``;if(C.layoutAufgabe!==!1){let t=ht();if(t.fehler)return Z(`vstatus`,t.fehler,!0);_(`questiontext[text]`,t.html),e.push(`Aufgabenstellung`)}if(C.layoutAntwort!==!1){let n=mt();if(!n)return Z(`vstatus`,`Für die Antwortvorlage fehlen die Teilaufgaben aus dem Horizont.`,!0);if(!pt()){let e=w(`[name="responseformat"]`);e.value=`editor`,e.dispatchEvent(new Event(`change`,{bubbles:!0})),t=` Das Antwortformat wurde auf „HTML-Editor" umgestellt – nur so wird das Layout dargestellt.`}_(`responsetemplate[text]`,n),e.push(`Antwortvorlage`)}if(!e.length)return Z(`vstatus`,`Bitte oben auswählen, was gestaltet werden soll.`,!0);Z(`vstatus`,e.join(` und `)+` ins Formular eingefügt.`+t+` Gefällt es dir, „Änderungen speichern" – sonst „Abbrechen".`),$()}catch(e){Z(`vstatus`,`Fehler: `+e.message,!0)}}async function wn(e,t,n,r){let i=Object.keys(e);try{if(Z(r,t?`Trockenlauf läuft …`:`Wird eingetragen …`),u!==`bearbeiten`){let a=sn(),o=[...(await Je(a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!o)throw Error(`Bearbeiten-Formular der Frage nicht erreichbar.`);let s=Ye(o);if(i.forEach(r=>{if(!s.has(r))throw Error(`Feld „`+r+`" nicht im Formular`);n((t?`✓ `:``)+`Feld `+r+` vorhanden`+(L(s.get(r)).length?` (enthält schon Text!)`:``)),t||s.set(r,e[r])}),t)return Z(r,`Alles vorhanden. Jetzt eintragen.`);let c=(o.querySelector(`[name="name"]`)||{}).value||``,l=await Ze(await Xe(o,s,a),c,a),u=[...(await Je(l||a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),d=0;return i.forEach(t=>{let r=u&&u.querySelector(`[name="`+CSS.escape(t)+`"]`),i=!!r&&Qe(r.value,e[t]);n((i?`✓ `:`✗ `)+t+(i?` eingetragen`:` NICHT angekommen`)),i||d++}),l||n(`⚠ Neue Fragenversion nicht auffindbar — Gegenprobe unsicher.`),Z(r,d?d+` Feld(er) nicht angekommen — Protokoll lesen.`:`In die Frage eingetragen und gegengeprüft.`,d>0)}let a=await $e(e,t);if(a.bericht.forEach(e=>n((t?`✓ `:``)+`Feld `+e.feld+` vorhanden`+(e.belegt?` (enthält schon Text!)`:``))),t)return Z(r,`Alles vorhanden. Jetzt eintragen.`);a.warnung&&n(`⚠ `+a.warnung);let o=0;if((a.ergebnis||[]).forEach(e=>{n((e.ok?`✓ `:`✗ `)+e.feld+(e.ok?` eingetragen`:` NICHT angekommen`)),e.ok||o++}),o)return Z(r,o+` Feld(er) nicht angekommen — Protokoll lesen.`,!0);n(`✓ gespeichert und gegengeprüft`),Nn(a.neueUrl),Z(r,a.neueUrl?`Eingetragen und gegengeprüft. Diese Seite zeigt jetzt einen veralteten Stand.`:`Eingetragen und gegengeprüft. Bitte die Frage neu öffnen — Moodle hat beim Speichern eine neue Version angelegt.`,!1)}catch(e){n(`✗ `+e.message),Z(r,`Fehler: `+e.message,!0)}}function Tn(e){let t=e.length?e.reduce((e,t)=>e+Ee(t.text),0)/e.length:0,n=Math.max(200,t*6);return Math.max(1,Math.min(30,Math.floor(22e3/n)))}function En(){let e=U(),t=G(`kgroesse`);t.options.length||([1,2,3,5,8,10,15,20,30].forEach(e=>t.appendChild(new Option(e+(e===1?` Abgabe`:` Abgaben`),e))),t.value=String(Tn(e)),t.addEventListener(`change`,En));let n=e.length?Math.round(e.reduce((e,t)=>e+Ee(t.text),0)/e.length):0;G(`kgroessehinweis`).textContent=e.length+` Abgaben, im Schnitt `+n+` Wörter. Vorschlag: `+Tn(e)+` je Durchgang.`;let r=B()||C.horizontLokal,i=parseInt(t.value,10)||5,a=Math.ceil(e.length/i)||1,o=G(`kknoepfe`);o.innerHTML=``;for(let t=0;t<a;t++){let n=t*i,s=Math.min(n+i,e.length),c=D(`button`,`mag-btn mag-btn-primary`,a===1?`📋 Bewertungsprompt kopieren`:`📋 Teil `+(t+1)+` kopieren (Arbeit `+(n+1)+`–`+s+`)`);c.addEventListener(`click`,()=>{if(!r)return Z(`kstatus`,`Kein Erwartungshorizont — bitte erst den Reiter „Horizont" verwenden.`,!0);vn(jt(e.slice(n,s),r,t+1,a),`kstatus`,a===1?`Prompt kopiert.`:`Teil `+(t+1)+` kopiert.`,`kjson`)}),o.appendChild(c)}}let Dn=!1;function On(){if(Kt)return;if(qt)return Z(`kstatus`,`Gesperrt: Antworten zu mehreren Fragen auf dieser Seite. Bitte jede Frage einzeln über die Übersicht öffnen.`,!0);let e=G(`kjson`).value.trim();if(!e)return Z(`kstatus`,`Bitte erst die Antworten der KI einfügen.`,!0);try{let t=U(),n=H(B()||C.horizontLokal),r=Ft(e,`bewertungen`).filter(e=>e&&e.nr!=null),{fehlend:i,doppelt:a}=It(r,t.map(e=>e.nr));if(a.length)throw Error(`Abgabe `+a.join(`, `)+` kommt doppelt vor.`);if(i.length&&!Dn){let e=G(`kliste`);e.innerHTML=``,G(`keintragen`).hidden=!0,q=null;let n=G(`rsabgleich`);n&&(n.hidden=!0);let r=t.length-i.length;Z(`kstatus`,`Teil erkannt: `+r+` von `+t.length+` Abgaben. Nächsten Teil einfach dazu einfügen — geprüft wird, sobald alle da sind. (Es fehlen: `+i.join(`, `)+`)`);let a=D(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`Trotzdem nur diese `+r+` prüfen`);a.addEventListener(`click`,()=>{Dn=!0,On()}),e.appendChild(a);return}let o=parseFloat(He(P().jahrgang))||0,s=parseFloat(C.punkteschritte)||.5,c=G(`kliste`);c.innerHTML=``;let l=G(`rsabgleich`);l&&(l.innerHTML=``,l.hidden=!0),q=[];let u=0;r.forEach(e=>{let r=t.find(t=>t.nr===Number(e.nr));if(!r)return;let i=rt(r,e,n,o,s),a=Mt(e,i,n);if(Math.abs(i.gesamt-r.ist)<.005&&!r.kommentarfeld){u++;return}q.push({nr:r.nr,markfeld:r.markfeld,kommentarfeld:r.kommentarfeld,punkte:i.gesamt,feedbackHtml:Nt(a),text:a});let l=D(`div`,`mag-karte`);e.besprochen===!0&&(l.dataset.gesehen=`1`,l.dataset.besprochen=`1`),l.appendChild(D(`div`,`mag-kartenkopf`,(e.besprochen===!0?`✓ besprochen · `:``)+`Arbeit `+r.nr+`:  bisher `+k(r.ist)+` → neu `+k(i.gesamt)+` von `+k(i.max)+` P.`+(i.abzug>.004?`   (−`+k(i.abzug)+` P. Sprache)`:``))),l.appendChild(D(`div`,`mag-kartenzeile`,i.teil.map(e=>`A`+e.nr+`: `+e.prozent+`%`).join(`   `)+`   ·   `+i.wortzahl+` Wörter, `+k(i.fehlerDichte)+` Fehler/100`+(i.fehlendeAufgaben.length?`   ·   ⚠ Aufgabe `+i.fehlendeAufgaben.join(`, `)+` von der KI nicht bewertet (0 %)`:``)));let d=D(`textarea`,`mag-kartentext`);d.value=a,d.rows=6;let f=q[q.length-1];d.addEventListener(`input`,()=>{f.text=d.value,f.feedbackHtml=Nt(d.value)}),l.appendChild(d),c.appendChild(l)});let d=r.filter(e=>e.besprochen===!0).length,f=q.length+` Arbeiten vorbereitet.`+(d===r.length?` Alle gemeinsam besprochen – du kannst direkt eintragen.`:d?` `+d+` besprochen, `+(r.length-d)+` automatisch bewertet – diese bitte ansehen.`:` Automatisch bewertet – bitte jede Arbeit einmal ansehen.`);u&&(f+=`  `+u+` ohne Änderung übersprungen.`),i.length&&(f+=`  ⚠ Es fehlen die Abgaben `+i.join(`, `)+` — bitte den fehlenden Teil nachreichen.`),Z(`kstatus`,f,i.length>0),G(`keintragen`).hidden=q.length===0}catch(e){Z(`kstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function kn(e){if(!q||!q.length)return;let t=cn(`klog`);try{Z(`kstatus`,e?`Trockenlauf läuft …`:`Wird eingetragen …`);let n=await Rt(q,e,t);if(e)return Z(`kstatus`,n.fehler?n.fehler+` Abgabe(n) nicht auf der Seite — Protokoll lesen.`:`Alles vorhanden. Jetzt eintragen.`,n.fehler>0);if(t(`— `+n.ok+` eingetragen · `+n.fehler+` fehlgeschlagen —`),n.fehler)Z(`kstatus`,n.fehler+` fehlgeschlagen — Protokoll lesen.`,!0);else{let e=new URLSearchParams(location.search),t=e.get(`id`),r=Be(await Le(t),e.get(`slot`),e.get(`qid`)),i=null,a=`Fenster schließt`;r&&r.naechste?(i=Re(t,r.naechste),a=`Weiter zur Klausur-Frage `+(r.index+2)+` von `+r.gesamt):r&&(i=ze(t),a=`Alle Klausur-Fragen bewertet — zurück zur Übersicht`);let o=3,s=n.ok+` Bewertungen eingetragen und gegengeprüft.`;Z(`kstatus`,s+` `+a+` in `+o+` s …`);let c=setInterval(()=>{if(o--,o>0)return Z(`kstatus`,s+` `+a+` in `+o+` s …`);clearInterval(c),jn.zu(),i?location.href=i:location.reload()},1e3)}}catch(e){t(`✗ `+e.message),Z(`kstatus`,`Fehler: `+e.message,!0)}}let An=`horizont`,jn={einst:()=>{un(),gn(`einst`)},zueinst:()=>{un(),gn(`einst`)},zuhorizont:()=>gn(`horizont`),zu:()=>{W.classList.remove(`offen`),Ut.classList.remove(`versteckt`)},hprompt:()=>vn(Et(),`hstatus`,`Prompt kopiert.`,`hjson`),hedit:()=>Pn(`horizont`),hpruefen:yn,hschreiben:()=>xn(!1),hlokalsichern:()=>{C.horizontLokal=G(`hlokal`).value.trim(),Q(),Z(`hstatus`,C.horizontLokal?`Horizont in der Erweiterung gespeichert (nicht in der Frage).`:`Gespeicherter Horizont gelöscht.`),En()},lein:()=>Cn(),kedit:()=>Pn(`korrektur`),kpruefen:On,kschreiben:()=>{let e=E(`.mag-karte`,G(`kliste`)).filter(e=>e.dataset.gesehen!==`1`).length,t=W.querySelector(`[data-tu="kschreiben"]`);if(e&&!Jt)return Jt=!0,t&&(t.textContent=`⚠ Ja, `+e+` ungeprüft eintragen`),Z(`kstatus`,`⚠ `+e+` automatisch bewertete Arbeit(en) noch nicht angesehen. Bitte durchblättern. Willst du sie ungeprüft eintragen, bestätige das mit dem Knopf unten.`,!0);Jt=!1,t&&(t.textContent=`Alle eintragen`),kn(!1)},krohdaten:()=>vn(JSON.stringify({stand:new Date().toLocaleString(`de-DE`),fach:P().fach,jahrgang:P().jahrgang,gesamtpunkte:R(),aufgabenstellung:et(),horizont:L(B()||C.horizontLokal),abgaben:U().map(e=>{let t=nt(e.rohHtml,e.text);return{nr:e.nr,ist:e.ist,max:e.max,gegliedert:t.gegliedert,aufgaben:t.aufgaben}})},null,2),`kstatus`,`Rohdaten kopiert.`),esichern:()=>{dn(),Z(`estatus`,``),gn(u===`bearbeiten`?`horizont`:Gt===`einst`?`korrektur`:Gt)},eabbruch:()=>{un(),Z(`estatus`,``)},kistandard:()=>{let e=G(`kitext`)||W.querySelector(`[data-opt="kiHinweisText"]`);e&&(e.value=je)},psichern:()=>{let e=G(`ptext`).value.trim(),t=e===(An===`horizont`?Ct():kt()).trim()?null:e;An===`horizont`?C.promptHorizont=t:C.promptKorrektur=t,Q(),gn(Gt)},pzurueck:()=>{G(`ptext`).value=An===`horizont`?Ct():kt()},pabbruch:()=>gn(Gt)},Mn=null;function Nn(e){let t=W.querySelector(`.mag-banner`);if(t.hidden=!1,t.className=`mag-banner warnung`,t.innerHTML=``,t.appendChild(D(`div`,null,`Moodle hat beim Speichern eine neue Fassung der Frage angelegt. Dieses Formular zeigt den alten Stand — hier nichts mehr speichern!`)),!e)return;let n=D(`button`,`mag-btn mag-btn-ok`,`Zur neuen Fassung der Frage`),r=D(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`hier bleiben`);n.addEventListener(`click`,()=>{location.href=e}),t.appendChild(n),t.appendChild(r);let i=8,a=D(`div`,`mag-hinweis`,`Wechsel in `+i+` Sekunden …`);t.appendChild(a),r.addEventListener(`click`,()=>{clearInterval(Mn),Mn=null,a.textContent=`Wechsel angehalten. Diese Seite bitte nicht mehr speichern.`,r.remove()}),Mn=setInterval(()=>{if(i--,i<=0){clearInterval(Mn),location.href=e;return}a.textContent=`Wechsel in `+i+` Sekunden …`},1e3)}function Pn(e){An=e,G(`ptitel`).textContent=e===`horizont`?`Prompt für den Erwartungshorizont`:`Prompt für die Korrektur`;let t=e===`horizont`?C.promptHorizont:C.promptKorrektur;G(`ptext`).value=t&&t.trim()||(e===`horizont`?Ct():kt()),gn(`prompt`)}W.addEventListener(`click`,e=>{let t=e.target.closest(`.mag-tab`);if(t)return _n&&=(clearInterval(_n),null),t.dataset.tab===`einst`?jn.einst():gn(t.dataset.tab);let n=e.target.closest(`[data-tu]`);n&&jn[n.dataset.tu]&&(e.preventDefault(),jn[n.dataset.tu]())}),W.addEventListener(`paste`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;if(t===`hjson`&&setTimeout(yn,0),t===`kjson`){let t=e.clipboardData&&e.clipboardData.getData(`text`);if(t){e.preventDefault();let n=e.target,r=n.value.replace(/\s+$/,``);n.value=r?r+`

`+t:t,n.scrollTop=n.scrollHeight}Dn=!1,setTimeout(On,0)}});let Fn=null;W.addEventListener(`input`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;t!==`hjson`&&t!==`kjson`||e.inputType===`insertFromPaste`||(t===`kjson`&&(Dn=!1),clearTimeout(Fn),Fn=setTimeout(()=>{e.target.value.trim()&&(t===`hjson`?yn:On)()},800))}),W.addEventListener(`change`,e=>{let t=e.target.closest(`[data-opt]`);t&&[`afbFarben`,`vorlagePunkte`,`vorlageAfb`,`kartePunkte`,`layoutAufgabe`,`layoutAntwort`,`punkteschritte`].includes(t.dataset.opt)&&(C[t.dataset.opt]=t.type===`checkbox`?t.checked:t.value,Q(),$(),t.dataset.opt===`punkteschritte`&&nn())}),Ut.addEventListener(`click`,()=>{W.classList.add(`offen`),Ut.classList.add(`versteckt`)}),ln().then(()=>{try{let e=W.querySelector(`.mag-kopfbild`);e&&(e.src=t.runtime.getURL(`icon/128.png`))}catch{let e=W.querySelector(`.mag-kopfbild`);e&&e.remove()}if(document.body.appendChild(Ut),document.body.appendChild(W),Ne(),u===`bearbeiten`){let e=Ie();N={fach:e.fach||C.fach||``,jahrgang:e.jahrgang||C.jahrgang||``,niveau:e.niveau||C.kursniveau||`G`,ausHorizont:!!e.jahrgang}}un(),G(`hlokal`).value=C.horizontLokal||``;let e=V(),n=W.querySelector(`.mag-banner`),r=u===`bewertung`?new Set(E(`.que .graderinfo`).map(e=>e.innerText.trim()).filter(Boolean)).size:0;if(qt=r>1,r>1){n.hidden=!1,n.textContent=`Auf dieser Seite stehen Antworten zu `+r+` verschiedenen Fragen (Zufallsfrage). Bitte über die Übersicht jede Frage einzeln öffnen — sonst würde alles gegen einen einzigen Horizont bewertet.`,G(`kstatus`)&&Z(`kstatus`,`Gesperrt: mehrere Fragen auf einer Seite (siehe oben).`,!0);let e=W.querySelector(`[data-tu="kschreiben"]`);e&&(e.disabled=!0)}else e.wer===`coach`&&u===`bewertung`?on(n):!e.horizont&&u===`bewertung`&&!C.horizontLokal&&(n.hidden=!1,n.textContent=`Diese Frage hat noch keinen Erwartungshorizont. Er lässt sich hier nachtragen.`);let i=W.querySelector(`.mag-untertitel`);i&&(i.textContent=u===`bearbeiten`?`Aufgabe vorbereiten`:`Antworten bewerten`);let a;if(a=u===`bewertung`&&!e.horizont&&!C.horizontLokal||u===`bearbeiten`?`horizont`:`korrektur`,gn(a),hn(),u===`bewertung`){let e=U().length;qt||Z(`kstatus`,e?e+` Arbeiten auf dieser Seite.`:`Keine Arbeiten gefunden.`),gt();let t=r>1?null:he(w(`.que`)),i=new URLSearchParams(location.search).get(`qid`);if(t&&t.gesamt>t.ist&&i){let r=new URLSearchParams(location.search).get(`id`);ge(i,e=>location.origin+`/question/bank/editquestion/question.php?id=`+e+(r?`&cmid=`+r:``)).then(r=>{if(!r)return;z=r.html;let i=V();J=i.wer===`coach`?`kurztest`:`klausur`;let a=b(z);Y=a&&Zt[J].some(e=>e[0]===a)?a:Qt[J],en(),$(),i.wer===`coach`&&!Kt&&on(n),qt||Z(`kstatus`,e+` Arbeiten auf dieser Seite. Maßstab ist der Horizont der neuesten Fragenfassung (v`+t.gesamt+`), nicht der ältere, den Moodle hier anzeigt.`),gt(),(!G(`kknoepfe`)||!W.querySelector(`[data-panel="korrektur"]`).hidden)&&En()}).catch(()=>{})}let a=G(`khilfe`);a&&(a.open=!C.khilfeGesehen,a.addEventListener(`toggle`,()=>{!a.open&&!C.khilfeGesehen&&(C.khilfeGesehen=!0,Q())}))}else{gt();let e=wt();e.length&&(G(`hmaterial`).hidden=!1,G(`hmaterial`).textContent=`In der Aufgabe stehen `+e.length+` Bild(er)/Datei(en): `+e.join(` · `)+` – bitte zusätzlich in den KI-Chat hochladen.`);let t=G(`hhilfe`);t&&(t.open=!C.hilfeGesehen,t.addEventListener(`toggle`,()=>{!t.open&&!C.hilfeGesehen&&(C.hilfeGesehen=!0,Q())})),W.classList.add(`offen`),Ut.classList.add(`versteckt`)}})}var He=e({matches:[`*://*/*mod/quiz/report.php*`,`*://*/*question/bank/editquestion/question.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){I(),location.pathname.includes(`/mod/quiz/report.php`)&&Ve()}}),Ue={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},L=class e extends Event{static EVENT_NAME=We(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function We(e){return`${t?.runtime?.id}:content:${e}`}var Ge=typeof globalThis.navigation?.addEventListener==`function`;function Ke(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Ge?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new L(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new L(e,t)),t=e)},1e3))}}}var qe=class e{static SCRIPT_STARTED_MESSAGE_TYPE=We(`wxt:content-script-started`);id;abortController;locationWatcher=Ke(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?We(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),Ue.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Je={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=He;return await e(new qe(`content`,t))}catch(e){throw Je.error(`The content script "content" crashed on startup!`,e),e}})()})();