(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`[moodle-ai-freitext: kurztest]`,r=`[moodle-ai-freitext: klausur]`,i=String.raw`moodle[-\s]?ai[-\s]?(?:(coach|grader)|freitext(?:[-\s]?grader)?\s*[:\-–]?\s*(kurztest|klausur))`,a=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*`,`i`),o=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*$`,`im`);function s(e){return e?e[1]?e[1].toLowerCase():/kurztest/i.test(e[2]||``)?`coach`:`grader`:null}function c(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – ERWARTUNGSHORIZONT ERSTELLEN
═══════════════════════════════════════════════════════

Für die unten stehenden Aufgaben brauchst du einen Erwartungshorizont – einen je
Aufgabe, in genau dem Format unten. Er wird anschließend in das Moodle-Feld
„Bewerterinformation" der Frage geschrieben und dort dauerhaft benutzt.

Steht bei einer Aufgabe „horizont_bisher", gibt es dort schon einen. Er ist der
**Ausgangspunkt, keine Vorlage zum Abschreiben**: Er wird ersetzt, weil an ihm etwas
nicht stimmt. Übernimm, was gut ist, und weiche dort ab, wo die Änderungswünsche der
Lehrkraft es verlangen – auch dann, wenn der bisherige Horizont das Gegenteil sagt.
Steht kein „horizont_bisher" dabei, schreibst du neu.

Die Kernaussage bekommen die Schülerinnen und Schüler zu sehen: Die Erweiterung setzt
sie bei unvollständigen Antworten als „So hättest du es schreiben können" unter die
Rückmeldung. Schreib sie deshalb als vollständige Musterantwort in einfacher Sprache –
Name und Funktion, ein bis zwei kurze Sätze.

WICHTIG – was NICHT hineingehört:
Keine Sprachregeln, kein Rechtschreibabzug, kein Feedback-Stil, keine Rolle, keine
Punktzahl. Das steht global in der Erweiterung. Im Horizont steht ausschließlich,
was für DIESE eine Aufgabe gilt. Sonst entstehen so viele Kopien der Regeln, wie es
Fragen gibt, und sie laufen auseinander.

FORMAT je Aufgabe:

Erwartungshorizont

Kernaussage:
<der eine Satz, der die volle Inhaltspunktzahl trägt>

Muss enthalten:
- <Teilaspekt 1>
- <Teilaspekt 2>

Auch richtig:
<gleichwertige Formulierungen, Synonyme, umgangssprachliche Varianten>

Inhalt:
100 % – <Bedingung>
 75 % – <Bedingung>            (nur wenn die Aufgabe eine solche Stufe hergibt)
 50 % – <Bedingung>
 25 % – <Bedingung>
  0 % – <Bedingung>

Reicht nicht:
<typische halbe Antwort und warum sie nicht reicht>

Häufiger Fehler:
<typischer Denkfehler – hilft später beim Feedback>

REGELN:
• Benutze nur die Stufen 100 / 75 / 50 / 25 / 0. Kein 90 – das ist im Projekt die
  Rechtschreibstufe und hat mit Inhalt nichts zu tun.
• Lass Stufen weg, die die Aufgabe nicht hergibt. Bei einer Aufzählung von drei
  Dingen sind 100 / 75 / 50 / 0 natürlicher als fünf Stufen.
• Die Antwort soll ein bis drei Sätze lang sein. Halte den Horizont entsprechend
  knapp – er ist kein Lehrbuchtext.
• „Auch richtig" ist der wichtigste Abschnitt. Denk daran, wie Vierzehnjährige
  formulieren, und nimm diese Varianten ausdrücklich auf.
• Der Operator der Aufgabe zählt: Bei „Nenne" reicht die Nennung, bei „Erkläre"
  muss ein Zusammenhang dastehen, bei „Vergleiche" beide Seiten.

AUSGABE:
Gib zuerst alle Horizonte als lesbaren Text aus, damit die Lehrkraft sie prüfen kann.
Frage dann: „Passt das so?"
Erst nach „ok" gibst du sie als JSON aus:

\`\`\`json
{
  "horizonte": [
    { "qid": "115576570", "frage": "alkoholischen Gärung (AFB I)",
      "text": "Erwartungshorizont\\n\\nKernaussage:\\n…" }
  ]
}
\`\`\`

„qid" übernimmst du unverändert aus den Daten unten.

═══════════════════════════════════════════════════════
AUFGABEN OHNE ERWARTUNGSHORIZONT
═══════════════════════════════════════════════════════

[MOODLE_AI_COACH_AUFGABEN]`}function l(e,t){let n=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!n)throw Error(`Feld „`+e+`" nicht im Formular`);n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0}));let r=n.id||``,i=r&&document.getElementById(r+`_ifr`);if(i&&i.contentDocument&&i.contentDocument.body)return i.contentDocument.body.innerHTML=t,i.contentDocument.body.dispatchEvent(new Event(`input`,{bubbles:!0})),`TinyMCE`;let a=r&&document.getElementById(r+`editable`);return a?(a.innerHTML=t,a.dispatchEvent(new Event(`input`,{bubbles:!0})),`Atto`):`Textfeld`}var u=e=>`freitextRundgang_`+e;function d(e,n){try{return t.storage.local.set({[u(e)]:{liste:n,stand:Date.now()}})}catch{return Promise.resolve()}}function f(e){return new Promise(n=>{try{t.storage.local.get([u(e)],t=>n(t&&t[u(e)]||null))}catch{n(null)}})}function p(e,t){return location.origin+location.pathname+`?id=`+e+`&mode=grading&slot=`+t.slot+`&qid=`+t.qid+`&grade=needsgrading&qperpage=100`}function m(e){return location.origin+location.pathname+`?id=`+e+`&mode=grading`}function h(e,t,n){if(!e||!e.liste||!e.liste.length)return null;let r=e.liste.findIndex(e=>String(e.slot)===String(t)&&String(e.qid)===String(n));return r<0?null:{index:r,gesamt:e.liste.length,naechste:e.liste[r+1]||null}}function g(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``;function i(){return!!document.querySelector(`[name="graderinfo[text]"]`)}function u(){return document.querySelectorAll(`input[id$="-mark"]`).length!==0&&!!(document.querySelector(`.qtype_essay_response`)||document.querySelector(`textarea[id$="-comment_id"]`)||document.querySelector(`textarea[name$="-comment"]`)||document.querySelector(`.ablock`))}let d=i()?`bearbeiten`:u()?`bewertung`:null;if(!d)return;let g=a,_=r,v=/rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%/i,y=/punkteschritte\s*[:\-]?\s*([\d.,]+)/i;function b(e,t,n){return`<p>[Rechtschreibung: `+A(e)+`%]</p><p>[Punkteschritte: `+A(t)+`]</p>`+(n?`<p>[Feedback: `+n+`]</p>`:``)}function x(e){let t=N(e).split(`
`).map(e=>e.trim()),n=[];for(let e of t)if(e&&(ne.test(e)||(n.push(e),n.length>=6)))break;return n.join(`
`)}function S(e){let t=x(e).match(v);return t?parseFloat(t[1].replace(`,`,`.`)):null}let C=/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im;function ee(e){let t=x(e).match(C);return t?t[1].charAt(0).toUpperCase()+t[1].slice(1).toLowerCase():null}function w(){if(d===`bearbeiten`&&Z!==void 0)return Z;let e=``;try{e=F()||T.horizontLokal||``}catch{}return ee(e)||T.feedbacklaenge}function te(e){let t=x(e).match(y);return t?j(t[1]):null}let ne=/^\s*[①-⑳⓪]?\s*Aufgabe\s+(\d+)\b/i,re={I:{kopf:`#eaf4ea`,feld:`#f5faf5`},II:{kopf:`#fdf2e0`,feld:`#fffaf0`},III:{kopf:`#fbe9e9`,feld:`#fdf3f3`},neutral:{kopf:`#eceff3`,feld:`#f8f9fb`}},ie=[[1,0],[2,1/3],[3.5,2/3],[1/0,1]],ae=[0,1/3,1/2,2/3,5/6,1],oe={fach:``,jahrgang:``,kursniveau:`G`,punkteschritte:`0.5`,rechtschreibung:`10`,feedbacklaenge:`Ausführlich`,afbFarben:!1,vorlagePunkte:!0,vorlageAfb:!0,kiHinweis:!0,entferneQuellen:!0,promptHorizont:null,promptKorrektur:null,horizontLokal:``,sprachabzugKurztest:`30`},T=JSON.parse(JSON.stringify(oe)),se=!1,E=(e,t)=>(t||document).querySelector(e),D=(e,t)=>[...(t||document).querySelectorAll(e)];function O(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r}function k(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function A(e){return String(e).replace(`.`,`,`)}function j(e){return parseFloat(String(e??``).replace(`,`,`.`))}function ce(e,t,n){let r=n||parseFloat(T.punkteschritte)||.5,i=Math.round(e/r)*r;return i=Math.max(0,Math.min(i,t)),Math.round(i*100)/100}function M(e){return(String(e||``).trim().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length}function le(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function ue(e){let t=String(e||``),n=le(t);t=g.test(n)?t.replace(n,n.replace(g,``)).replace(/^\s*\n/,``):t.replace(o,``).replace(/^\s*\n+/,``);for(let e=0;e<3;e++){let e=le(t);if(e&&(v.test(e)||y.test(e)||C.test(e)))t=t.replace(e,``).replace(/^\s*\n/,``);else break}return t}function de(e){return T.entferneQuellen?String(e||``).replace(/\[\w+:\d+\]/g,``).replace(/ {2,}/g,` `).trim():String(e||``)}function fe(){let e=parseInt(T.jahrgang,10);return!isNaN(e)&&e>=11?`Sie haben`:`Du hast`}function N(e){let t=String(e||``).replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi,`</$1>
`);return(new DOMParser().parseFromString(t,`text/html`).body.textContent||``).replace(/[ \t]+/g,` `).replace(/\n{3,}/g,`

`).trim()}function pe(e){return new DOMParser().parseFromString(String(e||``),`text/html`).body}function me(e,t){e.replaceChildren(...pe(t).childNodes)}let he=/^(DIV|P|H[1-6]|UL|OL|LI|TABLE|TBODY|TR|TD|TH|BLOCKQUOTE|SECTION|ARTICLE|PRE)$/;function ge(e){return String(e.textContent||``).replace(/\s+/g,` `).trim()}async function _e(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function ve(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&e.type!==`button`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}async function ye(e,t,n){let r=[...e.querySelectorAll(`input[type=submit],button[type=submit]`)].filter(e=>e.name&&e.name!==`cancel`),i=r.find(e=>e.name===`submitbutton`)||r[0];i&&t.set(i.name,i.value);let a=new URL(e.getAttribute(`action`)||n,n).href,o=await fetch(a,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:t.toString()});if(!o.ok)throw Error(`HTTP `+o.status+` beim Speichern`);return o}async function be(e,t,n){try{let r=new URL(e.url||n),i=r.searchParams.get(`lastchanged`),a=new URL(n).searchParams.get(`cmid`)||r.searchParams.get(`cmid`);if(i)return location.origin+`/question/bank/editquestion/question.php?id=`+i+(a?`&cmid=`+a:``);let o=[...new DOMParser().parseFromString(await e.clone().text(),`text/html`).querySelectorAll(`[data-itemtype="questionname"]`)].find(e=>(e.getAttribute(`data-value`)||``)===t);if(o&&o.getAttribute(`data-itemid`))return location.origin+`/question/bank/editquestion/question.php?id=`+o.getAttribute(`data-itemid`)+(a?`&cmid=`+a:``)}catch{}return null}function xe(e,t){let n=e=>N(e).replace(/\s+/g,` `).trim(),r=n(e),i=n(t);if(!r||!i)return!1;if(r===i)return!0;if(Math.abs(r.length-i.length)>Math.max(40,i.length*.2))return!1;let a=i.slice(Math.floor(i.length/2),Math.floor(i.length/2)+40);return r.includes(i.slice(0,40))&&(a.length<20||r.includes(a))}async function Se(e,t){let n=location.href,r=await _e(n),i=[...r.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!i)throw Error(r.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let a=ve(i),o=[];for(let n of Object.keys(e)){if(!a.has(n))throw Error(`Feld „`+n+`" nicht im Formular`);let r=a.get(n)||``;o.push({feld:n,belegt:N(r).length>0}),t||a.set(n,e[n])}if(t)return{bericht:o};let s=(i.querySelector(`[name="name"]`)||{}).value||``,c=await be(await ye(i,a,n),s,n),l=[...(await _e(c||n)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),u=[];for(let t of Object.keys(e)){let n=l&&l.querySelector(`[name="`+CSS.escape(t)+`"]`);u.push({feld:t,ok:!!n&&xe(n.value,e[t])})}return{bericht:o,ergebnis:u,neueUrl:c,warnung:c?null:`Die neue Fragenversion war nicht auffindbar — die Gegenprobe lief gegen den alten Stand und kann falsch sein.`}}function Ce(){if(d===`bearbeiten`){let e=E(`[name="questiontext[text]"]`);return e?N(e.value):``}let e=E(`.que .qtext`)||E(`.qtext`);return e?e.innerText.trim():``}function P(){if(d===`bearbeiten`){let e=E(`[name="defaultmark"]`);return e&&j(e.value)||0}let e=E(`input[name$="-maxmark"]`);if(e)return j(e.value)||0;let t=E(`.que .grade`),n=t&&t.innerText.match(/([\d.,]+)\s*$/);return n?j(n[1]):0}function F(){if(d===`bearbeiten`){let e=E(`[name="graderinfo[text]"]`);return e?e.value:``}let e=E(`.que .graderinfo`)||E(`.graderinfo`);return e?e.innerHTML:``}function we(){let e=N(F());return e?{horizont:!0,wer:s(le(e).match(g))}:{horizont:!1,wer:null}}function Te(e){let t=pe(ue(String(e||``))),n=[],r=null;if([...t.children].forEach(e=>{let t=ge(e),i=t.match(ne);if(i&&/^(H[1-6]|P|DIV)$/.test(e.tagName)&&t.length<200){r={nr:parseInt(i[1],10),kopf:t,html:``,text:``},n.push(r);return}r&&(r.html+=e.outerHTML,r.text+=N(e.outerHTML)+`
`)}),!n.length){let t=ue(N(e));return t?[{nr:1,kopf:`Aufgabe 1`,html:String(e||``),text:t,punkte:null,afb:null,ganzeArbeit:!0}]:[]}return n.forEach(e=>{e.text=e.text.trim();let t=e.kopf.match(/\(\s*([\d.,]+)\s*(?:P\.?|Punkte?)\s*\)/i);e.punkte=t?j(t[1]):null;let n=e.kopf.match(/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i);e.afb=n?n[1].replace(/\s/g,``):null}),n}function Ee(e){let t=e;for(let e=0;e<12&&t;e++)if(t=t.parentElement,t&&t.classList&&(t.classList.contains(`que`)||t.classList.contains(`content`)))return t;return null}function De(){return D(`input[id$="-mark"]`).map((e,t)=>{let n=Ee(e),r=n&&n.querySelector(`.qtype_essay_response`),i=n&&n.querySelector(`textarea[name$="-comment"]`),a=n&&n.querySelector(`input[name$="-maxmark"]`),o=r&&r.innerHTML||``,s=r?r.innerText.trim():``;return{nr:t+1,markfeld:e.name||``,kommentarfeld:i?i.name:``,ist:j(e.value)||0,max:a?j(a.value)||0:P(),rohHtml:o,text:s,anker:n&&n.id?`#`+n.id:``}}).filter(e=>e.markfeld)}function Oe(e,t){let n=pe(e),r=[],i=null,a=e=>{let t=[...e.children].filter(e=>he.test(e.tagName));if(!t.length){let t=ge(e);if(!t)return;let n=t.match(ne);n&&t.length<160?(i={nr:parseInt(n[1],10),text:``},r.push(i)):i&&(i.text+=t+`
`);return}t.forEach(a)};return a(n),r.length>=1?(r.forEach(e=>{e.text=e.text.trim()}),{gegliedert:!0,aufgaben:r,leer:r.every(e=>!e.text)}):{gegliedert:!1,aufgaben:[{nr:1,text:String(t||``).trim()}]}}function ke(e,t){if(t<40){let t=Math.min(Math.round(e),ae.length-1);return ae[t]}let n=t>0?e*100/t:0;for(let[e,t]of ie)if(n<=e)return t;return 1}function Ae(e){return(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0)}function je(e,t,n,r,i){let a=e.max||P()||0,o=(n||[]).filter(e=>e.punkte!=null).reduce((e,t)=>e+t.punkte,0),s=n&&n.length?n.map(e=>e.nr):(t.aufgaben||[]).map(e=>Number(e.nr)),c=Math.max(1,s.length),l=[],u=s.map(e=>{let r=(t.aufgaben||[]).find(t=>Number(t.nr)===e)||(l.push(e),{nr:e,prozent:0}),i=(n||[]).find(t=>t.nr===e),s;s=i&&i.punkte!=null&&o>0?a>0?i.punkte*a/o:i.punkte:a/c;let u=Math.max(0,Math.min(100,Number(r.prozent)||0));return{nr:e,max:s,prozent:u,roh:s*u/100}}),d=u.reduce((e,t)=>e+t.roh,0),f=a*(r??(parseFloat(T.rechtschreibung)||0))/100,p=Ae(t.fehler),m=M(e.text),h=ke(p,m),g=Math.min(f*h,d);u.forEach(e=>{let t=d>0?e.roh/d:0;e.abzug=g*t,e.netto=Math.max(0,e.roh-e.abzug)});let _=i||parseFloat(T.punkteschritte)||.5,v=ce(u.reduce((e,t)=>e+t.netto,0),a,_);u.forEach(e=>{e.punkte=Math.max(0,Math.floor(e.netto/_+1e-9)*_),e.rest=e.netto-e.punkte});let y=Math.round((v-u.reduce((e,t)=>e+t.punkte,0))/_),b=u.slice().sort((e,t)=>t.rest-e.rest);for(let e=0;y>0&&e<b.length*4;e++){let t=b[e%b.length];t.punkte+_<=t.max+1e-9&&(t.punkte+=_,y--)}for(let e=0;y<0&&e<b.length*4;e++){let t=b[b.length-1-e%b.length];t.punkte-_>=-1e-9&&(t.punkte-=_,y++)}return u.forEach(e=>{e.punkte=Math.round(e.punkte*100)/100}),{teil:u,wortzahl:m,fehlerGewichtet:p,fehlerDichte:m>0?Math.round(p*1e3/m)/10:0,hoechstabzug:Math.round(f*100)/100,abzug:Math.round(g*100)/100,gesamt:v,max:a,fehlendeAufgaben:l}}function Me(e){if(!T.afbFarben)return re.neutral;let t=String(e||``).toUpperCase().split(/[-–]/).pop().trim();return re[t]||re.neutral}function Ne(e){let t=k([`Aufgabe `+e.nr][0]);return T.vorlageAfb&&e.afb&&(t+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+k(e.afb)+`</span>`),e.schlagwort&&(t+=` · `+k(e.schlagwort)),T.vorlagePunkte&&e.punkte!=null&&(t+=` <span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+k(A(e.punkte))+(e.punkte===1?` Punkt`:` Punkte`)+`)</span>`),t}function I(e){return(e||[]).map(e=>{let t=Me(e.afb);return`<div style="border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:10px 0;"><div style="background:`+t.kopf+`;padding:9px 14px;font-size:16px;font-weight:bold;color:#33404d;border-bottom:1.5px solid #9e9e9e;">`+Ne(e)+`</div><div style="background:`+t.feld+`;padding:10px 14px;font-size:15px;line-height:1.45;"><p style="margin:0;">&nbsp;</p><p style="margin:0;">&nbsp;</p></div></div>`}).join(`
`)}function L(e){return((e||[]).some(e=>g.test(le(N(e.horizont))))?``:`<p>`+_+`</p>`+b(T.rechtschreibung,T.punkteschritte,d===`bearbeiten`?Z:w()))+(e||[]).map(e=>{let t=String(e.horizont||``).trim();return/<[a-z][\s\S]*>/i.test(t)||(t=`<p>`+k(t).replace(/\n{2,}/g,`</p><p>`).replace(/\n/g,`<br>`)+`</p>`),`<h4>`+Ne(e)+`</h4>`+t}).join(`
`)}let R={G:`G — gymnasial`,M:`M — mittel`,E:`E — einfach`};function z(){return[`Fach: `+(T.fach||`[nicht angegeben]`),`Jahrgang: `+(T.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(R[T.kursniveau]||T.kursniveau),`Feedbacklänge: `+w(),`Anrede im Feedback: `+fe()+` …`].join(`
`)}function B(){return`Du bist erfahrene Lehrkraft und erstellst den Erwartungshorizont für eine Klausur.

RAHMENDATEN
[MAG_RAHMENDATEN]

AUFGABENSTELLUNG (aus Moodle übernommen, Gesamtpunktzahl: [MAG_GESAMTPUNKTE])
[MAG_AUFGABEN]

WAS DU TUST
1. Zerlege die Aufgabenstellung in ihre Teilaufgaben. Übernimm die Nummerierung der
   Aufgabenstellung. Steht dort eine Punktzahl je Aufgabe, übernimm sie unverändert;
   fehlt sie, verteile die Gesamtpunktzahl begründet und weise darauf hin.
2. Bestimme je Aufgabe den Operator und die Anforderungsstufe AFB (I, II, III oder eine
   Spanne wie II-III).
3. Schreibe je Aufgabe einen Erwartungshorizont in dieser Reihenfolge:
   Kernaussage · Muss enthalten · Auch richtig · Inhalt in Stufen · Reicht nicht ·
   Häufiger Fehler.
   - Nur die Stufen 100 / 75 / 50 / 25 / 0 Prozent. Kein 90.
   - KEINE Sprachregeln, KEINEN Rechtschreibabzug, KEINE Punktzahlen in den Horizont —
     das steht global in der Erweiterung und würde sich sonst widersprechen.

   - „AUCH RICHTIG" ist der wichtigste Abschnitt und der am häufigsten misslungene.
     Gemeint sind NICHT ausformulierte Musterantworten, sondern die rauen, verkürzten
     Formulierungen, mit denen Lernende dieser Jahrgangsstufe dasselbe sagen — auch
     umgangssprachlich, auch ohne Fachbegriff.
     Schlecht: „Von links nach rechts werden die Atome kleiner, weil die Kernladung
     zunimmt und die Elektronen stärker angezogen werden." So schreibt eine Lehrkraft.
     Wer so antwortet, liegt ohnehin bei 100 % — der Eintrag hilft beim Bewerten nicht.
     Gut: „nach rechts wird es kleiner" · „der Kern zieht doller" · „es kommt eine
     Schale dazu, deshalb wird es dicker" · „mehr Protonen, gleiche Schale".
     Nenne mindestens vier solcher Fassungen je Aufgabe und schreibe dazu, welche
     abweichenden Wörter dasselbe meinen (etwa Ring, Bahn oder Ebene statt Schale).

   - JEDE STUFE HÄNGT AN ZÄHLBAREN BEDINGUNGEN, nie an Wörtern wie „überwiegend",
     „im Wesentlichen", „etwas unvollständig" oder „deutliche Lücken". Solche
     Formulierungen führen dazu, dass zwei Modelle dieselbe Antwort verschieden
     einstufen. Zähle stattdessen, was da sein muss: Trends, Aspekte, Teilaussagen.
     Beispiel: 100 — beide Trends beschrieben UND beide erklärt · 75 — beide
     beschrieben, einer erklärt · 50 — beide beschrieben, keiner erklärt ODER einer
     beschrieben und erklärt.
     Prüfe zum Schluss, dass jede denkbare Antwort genau EINER Stufe zuzuordnen ist:
     keine Lücke, keine Überschneidung.

   - „REICHT NICHT" enthält nur Antworten, die sachlich RICHTIG, aber zu wenig sind.
     Sachlich falsche Aussagen gehören nicht dorthin, sondern zu Stufe 0 und unter
     „Häufiger Fehler" — sonst liest ein Bewertungsmodell sie als fast richtig.
4. Gib je Aufgabe ein Schlagwort von zwei bis vier Wörtern an, das die Aufgabe benennt.

ARBEITSWEISE
Zeige mir zuerst je Aufgabe eine lesbare Übersicht (Nummer, Operator, AFB, Punkte,
Schlagwort, Erwartungshorizont) und frage nach, ob sie passt. Ändere, bis ich zustimme.
Stelle immer nur EINE Frage auf einmal.

ERST WENN ICH BESTÄTIGE, gib genau EINEN Codeblock aus — nichts davor, nichts danach:

\`\`\`json
{ "aufgaben": [
  { "nr": 1,
    "schlagwort": "kurzes Stichwort",
    "afb": "II-III",
    "punkte": 4,
    "operator": "Beschreibe / Erkläre",
    "horizont": "<p><strong>Kernaussage:</strong> …</p><p><strong>Muss enthalten:</strong> …</p>" }
] }
\`\`\`

Das Feld "horizont" ist HTML (erlaubt: p, br, ul, li, strong, em). Keine Überschrift für
die Aufgabe selbst — die setzt die Erweiterung. Keine Punktzahlen im Fließtext.`}function V(){let e=E(`[name="questiontext[text]"]`),t=e?e.value:(E(`.que .qtext`)||{}).innerHTML||``;if(!t)return[];let n=new DOMParser().parseFromString(t,`text/html`),r=[];return n.querySelectorAll(`img`).forEach(e=>r.push(`Bild: `+(e.getAttribute(`alt`)||decodeURIComponent((e.getAttribute(`src`)||``).split(`/`).pop().split(`?`)[0])||`ohne Namen`))),n.querySelectorAll(`a[href*="pluginfile"]`).forEach(e=>r.push(`Datei: `+(e.textContent.trim()||decodeURIComponent(e.getAttribute(`href`).split(`/`).pop().split(`?`)[0])))),r}function Pe(){let e=V();return`MATERIAL
Enthält die Aufgabe Material (M1, M2 …), werte es JETZT aus. Beim späteren Bewerten liegt das
Material NICHT mehr vor. Schreibe deshalb alle Werte und Aussagen aus dem Material, die eine
Antwort braucht, mit Quelle direkt in die Erwartungen (z. B. „M2, Tabelle: Siedetemperatur 78 °C"),
nicht nur „siehe M2". Nimm wörtliche Übernahmen aus dem Material ohne eigene Erklärung als
„Reicht nicht"-Fall auf, wo die Aufgabe eine Erklärung verlangt.`+(e.length?`

In der Aufgabe stehen Bilder/Dateien, die hier nur als Name ankommen:
- `+e.join(`
- `)+`
Die Lehrkraft lädt sie zusätzlich in den Chat hoch. Fehlen sie, frage danach, bevor du den Horizont schreibst.`:``)}function Fe(){if(d===`bearbeiten`&&X===`kurztest`){let e={qid:`diese-frage`,frage:(E(`[name="name"]`)||{}).value||`Diese Frage`,aufgabe:Ce(),max:P()},t=N(F());t&&(e.horizont_bisher=ue(t));let n=`Rahmendaten:
`+z()+`

`+Pe()+`

\`\`\`json
`+JSON.stringify([e],null,1)+"\n```";return c().replace(`[MOODLE_AI_COACH_AUFGABEN]`,n)}return((T.promptHorizont||``).trim()||B()).replace(`[MAG_RAHMENDATEN]`,z()).replace(`[MAG_GESAMTPUNKTE]`,A(P()||`?`)).replace(`[MAG_AUFGABEN]`,(Ce()||`[keine Aufgabenstellung gefunden]`)+`

`+Pe()+(N(F())?`

BISHERIGER HORIZONT (Ausgangspunkt, keine Vorlage zum Abschreiben – übernimm, was gut ist, und erstelle ihn im aktuellen Format neu):
`+ue(N(F())):``))}let H={Kurz:`ein bis zwei Sätze je Aufgabe`,Mittel:`drei bis vier Sätze je Aufgabe`,Ausführlich:`ein Absatz je Aufgabe mit konkretem Bezug auf die Antwort`,Umfangreich:`ein ausführlicher Absatz je Aufgabe, dazu ein eigener Abschnitt zur Operatorerfüllung`};function U(){return`Du bewertest Klausurantworten nach einem vorgegebenen Erwartungshorizont.

RAHMENDATEN
[MAG_RAHMENDATEN]

ERWARTUNGSHORIZONT (gilt für alle Abgaben)
[MAG_HORIZONT]

WICHTIG — WAS DU NICHT TUST
Du vergibst KEINE Punkte und rechnest NICHT. Die Erweiterung rechnet Punkte, Rundung,
Rechtschreibabzug und Gesamtsumme selbst. Du lieferst ausschließlich Prozentwerte,
gezählte Fehler und Begründungstexte OHNE Zahlenangaben. Schreibe in keiner Begründung
„x von y Punkten" — die Zahlen setzt die Erweiterung ein.

JE AUFGABE
Vergib einen Erfüllungsgrad in Prozent, nur diese Stufen: 100, 75, 50, 25, 0.
Verankere jede Einstufung an einer Formulierung des Erwartungshorizonts.
Prüfe dabei den Operator: Wer „erläutere" liest und nur beschreibt, erfüllt die Aufgabe
nicht vollständig, auch wenn der Inhalt stimmt.

JE ABGABE
Zähle die sprachlichen Fehler und gib sie EINZELN an — Wort, Korrektur, Kategorie.
Kategorien: satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache. Ein Satz ohne Prädikat, ein abgebrochener Satz oder ein
Satzbau, den man zweimal lesen muss, zählt als "schwer": true. Denselben Fehler im selben
Wort nur einmal zählen. Zähle vollständig — die Erweiterung leitet daraus den Abzug ab.

FEEDBACKTEXTE
Länge: [MAG_FBLAENGE]. Anrede: [MAG_ANREDE] … Sachlich, konkret, zugewandt.
Bei Sprachfehlern den fehlerhaften Satz wörtlich zitieren und richtig danebenschreiben,
nicht „achte auf die Satzstellung". Höchstens zwei bis drei Vorschläge.
Jede Aufgabe bekommt eine Begründung — auch eine vollständig richtige.

ABGABEN
[MAG_ABGABEN]

AUSGABE — genau EIN Codeblock, nichts davor, nichts danach:

\`\`\`json
{ "bewertungen": [
  { "nr": 1,
    "staerken": "was gut gelungen ist",
    "aufgaben": [ { "nr": 1, "prozent": 75, "begruendung": "…", "operator": "erfüllt" } ],
    "fehler": [ { "wort": "Atomradiuse", "korrektur": "Atomradien",
                  "kategorie": "rechtschreibung", "schwer": false } ],
    "sprachfeedback": "…",
    "zusammenfassung": "…" }
] }
\`\`\`

"nr" ist die Nummer der Abgabe aus dem Datenblock, nicht die des Schülers.
Liefere für JEDE Abgabe des Blocks einen Eintrag, auch für leere Abgaben
(dort alle Prozentwerte 0 und ein Hinweis in der Zusammenfassung).`}function Ie(e,t,n,r){let i=Te(t),a=i.length?i.map(e=>e.kopf+`
`+e.text).join(`

`):N(t),o=e.map(e=>{let t=Oe(e.rohHtml,e.text),n=`ABGABE `+e.nr+(t.gegliedert?``:`  (ohne Gliederung)`),r=t.gegliedert?t.aufgaben.map(e=>`  Aufgabe `+e.nr+`:
  `+(e.text||`(leer)`)).join(`
`):`  `+(e.text||`(leer)`);return n+`
`+r}).join(`

`),s=((T.promptKorrektur||``).trim()||U()).replace(`[MAG_RAHMENDATEN]`,z()).replace(`[MAG_HORIZONT]`,a||`[kein Horizont hinterlegt]`).replace(`[MAG_FBLAENGE]`,H[w()]||H.Ausführlich).replace(`[MAG_ANREDE]`,fe()).replace(`[MAG_ABGABEN]`,o);return r>1&&(s=`TEIL `+n+` VON `+r+` — bewerte NUR die unten stehenden Abgaben und gib nur für sie JSON aus. Warte auf den nächsten Teil.

`+s),s}function Le(e,t,n){let r=[];if(e.staerken&&r.push(e.staerken.trim()),(e.aufgaben||[]).forEach(e=>{let i=t.teil.find(t=>t.nr===e.nr),a=(n||[]).find(t=>t.nr===e.nr),o=`Aufgabe `+e.nr+(a&&a.kopf.includes(`·`)?` – `+a.kopf.split(`·`).slice(1).join(`·`).replace(/\(.*?\)/,``).trim():``)+`: `+(i?A(i.punkte):`?`)+` von `+(i?A(Math.round(i.max*100)/100):`?`)+` P.`;i&&i.abzug>.004&&(o+=` (davon −`+A(Math.round(i.abzug*100)/100)+` P. Rechtschreibung)`),r.push(o+`
`+(e.begruendung||``).trim())}),w()===`Umfangreich`){let t=(e.aufgaben||[]).filter(e=>e.operator);t.length&&r.push(`Operatorerfüllung:
`+t.map(e=>`Aufgabe `+e.nr+`: `+e.operator).join(`
`))}let i=e.fehler||[],a=`Rechtschreibung und Sprache: `;return t.abzug>.004?a+=`Abzug `+A(t.abzug)+` von höchstens `+A(t.hoechstabzug)+` P. (`+A(t.fehlerDichte)+` Fehler je 100 Wörter).`:i.length?a+=`kein Punktabzug, aber ein paar Stellen zum Nachschauen.`:a+=`keine Auffälligkeiten.`,i.length&&(a+=`
`+i.slice(0,12).map(e=>`• `+(e.wort||``)+` → `+(e.korrektur||``)).join(`
`),i.length>12&&(a+=`
• … und `+(i.length-12)+` weitere`)),e.sprachfeedback&&(a+=`
`+e.sprachfeedback.trim()),r.push(a),e.zusammenfassung&&r.push(e.zusammenfassung.trim()),r.push(`Gesamt: `+A(t.gesamt)+` von `+A(t.max)+` Punkten.`),r.filter(Boolean).map(de).join(`

`)}function Re(e){let t=e.split(/\n{2,}/).map(e=>`<p>`+k(e).replace(/\n/g,`<br>`)+`</p>`).join(``);return T.kiHinweis&&(t+=`<p><em><small>Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.</small></em></p>`),t}function ze(e){let t=[],n=0,r=-1,i=!1,a=!1;for(let o=0;o<e.length;o++){let s=e[o];if(i){a?a=!1:s===`\\`?a=!0:s===`"`&&(i=!1);continue}if(s===`"`){n>0&&(i=!0);continue}s===`{`?(n===0&&(r=o),n++):s===`}`&&n>0&&(n--,n===0&&r>=0&&(t.push(e.slice(r,o+1)),r=-1))}return t}function Be(e,t){let n=[],r=[],i=/```(?:json)?\s*([\s\S]*?)```/g,a;for(;(a=i.exec(e))!==null;)r.push(a[1]);if(r.push(e.replace(/```(?:json)?\s*[\s\S]*?```/g,``)),r.forEach(e=>{let r=e.trim();if(r){try{let e=JSON.parse(r),i=Array.isArray(e)?e:e[t]||(e.nr==null?null:[e]);i&&n.push(...i);return}catch{}ze(r).forEach(e=>{try{let r=JSON.parse(e),i=Array.isArray(r)?r:r[t]||(r.nr==null?null:[r]);i&&n.push(...i)}catch{}})}}),!n.length)throw Error(`Kein verwertbares JSON gefunden.`);return n}function Ve(e,t){let n=new Set,r=[];return e.forEach(e=>{let t=Number(e.nr);n.has(t)&&r.push(t),n.add(t)}),{fehlend:t.filter(e=>!n.has(e)),doppelt:r}}async function He(e){let t=await _e(location.href),n=t.querySelector(`form#manualgradingform`)||[...t.forms].find(e=>e.querySelector(`input[name$="-mark"]`));if(!n&&!e)return await new Promise(e=>setTimeout(e,900)),He(!0);if(!n)throw Error(`Bewertungsformular nicht gefunden`);return{dok:t,form:n}}async function Ue(e,t,n){let{form:r}=await He(!1),i=ve(r),a=[],o=0;if(e.forEach(e=>{let r=i.has(e.markfeld),s=!e.kommentarfeld||i.has(e.kommentarfeld);if(!r||!s){o++,n(`✗ Abgabe `+e.nr+`: `+(r?`Kommentarfeld`:`Punktefeld`)+` nicht auf der Seite`);return}t||(i.set(e.markfeld,A(e.punkte)),e.kommentarfeld&&i.set(e.kommentarfeld,e.feedbackHtml)),a.push(e)}),t)return n(a.length+` von `+e.length+` Abgaben vollständig vorhanden.`),{ok:a.length,fehler:o,trocken:!0};if(!a.length)return{ok:0,fehler:e.length};await ye(r,i,location.href);let{form:s}=await He(!1),c=0,l=o;return a.forEach(e=>{let t=s.querySelector(`input[name="`+CSS.escape(e.markfeld)+`"]`),r=t?j(t.value):null;r!==null&&Math.abs(r-e.punkte)<.005?(c++,n(`✓ Abgabe `+e.nr+` — `+A(e.punkte)+` P. eingetragen`)):(l++,n(`✗ Abgabe `+e.nr+` — steht auf `+(r==null?`keinem Wert`:A(r))+` statt `+A(e.punkte)))}),{ok:c,fehler:l}}let We=d===`bearbeiten`?[[`horizont`,`1 · Horizont`],[`vorlage`,`2 · Vorlage`],[`einst`,`⚙`]]:[[`korrektur`,`1 · Korrektur`],[`horizont`,`2 · Horizont`],[`einst`,`⚙`]],W=O(`div`,`mag-panel`);W.innerHTML=`
    <div class="mag-kopf">
      <img class="mag-kopfbild" alt="">
      <div class="mag-titelblock">
        <span class="mag-titel">Freitext Grader <span class="mag-version"></span></span>
        <span class="mag-untertitel"></span>
      </div>
      <button class="mag-ikon" data-tu="zu" title="Schließen">✕</button>
    </div>
    <div class="mag-banner" hidden></div>
    <div class="mag-reiter">

    </div>

    <div class="mag-inhalt" data-panel="horizont">
      <div class="mag-status" data-rolle="hstatus"></div>
      <div class="mag-modus" data-rolle="hmodus" hidden>
        <div class="mag-rahmen-titel">Diese Aufgabe</div>
        <label>Modus</label>
        <select data-rolle="hmodussel">
          <option value="kurztest">Kurztest – kurze Antworten, schnelle Bewertung</option>
          <option value="klausur">Klausur – Teilaufgaben, Portionen, Review</option>
        </select>
        <div class="mag-hinweis" data-rolle="hmodushinweis"></div>
        <label>Feedbacklänge</label>
        <select data-rolle="hfeedbacksel"></select>
        <div class="mag-hinweis" data-rolle="hfeedbackhinweis"></div>
      </div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt</div>
        <div data-rolle="hrahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <details class="mag-details mag-hilfe" data-rolle="hhilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Der Erwartungshorizont sagt der KI später beim Bewerten, was eine
        richtige Antwort ist. So entsteht er:</p>
        <p class="mag-hinweis"><strong>1 · Auftrag kopieren:</strong> Die Erweiterung nimmt
        Aufgabenstellung, Punkte und Einstellungen und baut daraus einen Auftrag (Prompt) für die KI.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT), den
        Horizont lesen und prüfen. Nach deinem „ok" gibt die KI einen Codeblock aus – diesen hier einfügen.</p>
        <p class="mag-hinweis"><strong>3 · Eintragen:</strong> Der Horizont wird im Feld
        „Informationen für Bewerter/innen" dieser Aufgabe gespeichert. Schülerinnen und Schüler sehen ihn nicht.</p>
      </details>
      <label>1 · Auftrag für die KI kopieren</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-primary" data-tu="hprompt">📋 Auftrag kopieren</button>
        <button class="mag-btn mag-btn-rand" data-tu="hedit" title="Auftrag (Prompt) anpassen">✏️</button>
      </div>
      <div class="mag-hinweis" data-rolle="hmaterial" hidden></div>
      <label>2 · Erwartungshorizont der KI einfügen</label>
      <div class="mag-hinweis">Die Erweiterung hat bewusst keinen eigenen KI-Zugang: Du wählst die KI,
      und Aufgaben gehen nur dorthin, wo du sie einfügst. Den Codeblock der KI vollständig hier
      einfügen – er wird sofort geprüft und angezeigt. Gespeichert wird erst in Schritt 3.</div>
      <textarea data-rolle="hjson" rows="5" placeholder='{ "aufgaben": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="hpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-liste" data-rolle="hliste"></div>
      <div class="mag-protokoll" data-rolle="hlog" hidden></div>
      <div class="mag-reihe" data-rolle="hknoepfe" hidden></div>
      <details class="mag-details">
        <summary>Kein Bearbeitungsrecht? Horizont hier behalten</summary>
        <p class="mag-hinweis">Wer Fragen nicht bearbeiten darf, klebt den fertigen Horizont
        hierher. Er bleibt dann in der Erweiterung statt in der Frage.</p>
        <textarea data-rolle="hlokal" rows="4" placeholder="Erwartungshorizont …"></textarea>
        <button class="mag-btn mag-btn-rand" data-tu="hlokalsichern">Hier speichern</button>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="vorlage" hidden>
      <div class="mag-status" data-rolle="vstatus"></div>
      <p class="mag-hinweis">Die Antwortvorlage wird den Lernenden beim Öffnen der Frage in
      das Eingabefeld geladen. Sie entsteht aus demselben Durchgang wie der Horizont.</p>
      <label>Aussehen</label>
      <label class="mag-haken"><input type="checkbox" data-opt="afbFarben"> Farben nach AFB statt neutral</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlagePunkte"> Punkte in der Kopfzeile</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlageAfb"> AFB in der Kopfzeile</label>
      <label>So sieht das Eingabefeld für die Lernenden aus</label>
      <div class="mag-vorschau" data-rolle="vvorschau"></div>
      <details class="mag-details">
        <summary>Und das steht dann im Erwartungshorizont der Frage</summary>
        <div class="mag-vorschau" data-rolle="vhorizont"></div>
      </details>
      <div class="mag-protokoll" data-rolle="vlog" hidden></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="beides">Beides eintragen</button>
      </div>
      <p class="mag-hinweis">Erwartungshorizont und Antwortvorlage gehen in <strong>einem</strong>
      Speichervorgang in die Frage. Getrennt einzutragen wäre riskant: Nach dem ersten
      Speichern zeigt diese Seite eine veraltete Fassung, und der zweite Schreibvorgang
      würde den ersten wieder überschreiben.</p>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-klein mag-btn-grau" data-tu="kopierh">📋 nur Horizont</button>
        <button class="mag-btn mag-btn-klein mag-btn-grau" data-tu="kopierv">📋 nur Antwortvorlage</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="korrektur" hidden>
      <div class="mag-status" data-rolle="kstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt und in die Rechnung</div>
        <div data-rolle="krahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <label>Abgaben je Durchgang</label>
      <select data-rolle="kgroesse"></select>
      <div class="mag-hinweis" data-rolle="kgroessehinweis"></div>
      <label>1 · Prompt für die KI</label>
      <div class="mag-reihe" data-rolle="kknoepfe"></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kedit">✏️ Prompt anpassen</button>
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="krohdaten">📋 Rohdaten</button>
      </div>
      <label>2 · Antworten der KI einfügen</label>
      <textarea data-rolle="kjson" rows="5" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="kpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-hinweis" data-rolle="rsabgleich" hidden></div>
      <div class="mag-liste" data-rolle="kliste"></div>
      <div class="mag-protokoll" data-rolle="klog" hidden></div>
      <div class="mag-reihe" data-rolle="keintragen" hidden>
        <button class="mag-btn mag-btn-ok" data-tu="kschreiben">Alle eintragen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="einst" hidden>
      <div class="mag-status" data-rolle="estatus"></div>
      <p class="mag-hinweis">Diese Angaben stehen später als Rahmendaten im Prompt und
      steuern, wie die Erweiterung rechnet. Bitte einmal durchsehen, bevor du den Prompt
      kopierst — nachträglich lässt sich ein Horizont nur neu erzeugen.</p>
      <label>Fach</label><input type="text" data-opt="fach" placeholder="z. B. Chemie">
      <label>Jahrgang</label><input type="text" data-opt="jahrgang" placeholder="z. B. 10">
      <div class="mag-hinweis" data-rolle="anredehinweis"></div>
      <label>Kursniveau</label>
      <select data-opt="kursniveau">
        <option value="G">G — gymnasial</option>
        <option value="M">M — mittel</option>
        <option value="E">E — einfach</option>
      </select>
      <label>Punkteschritte</label>
      <select data-opt="punkteschritte">
        <option value="0.25">0,25</option><option value="0.5">0,5 (Standard)</option>
        <option value="1">1,0 — nur ganze Punkte</option>
      </select>
      <label>Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl</label>
      <select data-opt="rechtschreibung">
        <option value="0">0 % — kein Abzug</option><option value="5">5 %</option>
        <option value="10">10 % (Standard Mittelstufe)</option><option value="15">15 %</option>
        <option value="20">20 %</option><option value="25">25 % (Oberstufe, Klausuren)</option>
        <option value="30">30 %</option>
      </select>
      <div class="mag-hinweis" data-rolle="rshinweis"></div>
      <label class="mag-haken"><input type="checkbox" data-opt="kiHinweis"> KI-Transparenzhinweis unter das Feedback</label>
      <label class="mag-haken"><input type="checkbox" data-opt="entferneQuellen"> Quellenangaben entfernen</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="esichern">Speichern und weiter</button>
        <button class="mag-btn mag-btn-grau" data-tu="eabbruch">Verwerfen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="prompt" hidden>
      <label data-rolle="ptitel">Prompt bearbeiten</label>
      <textarea data-rolle="ptext" rows="16"></textarea>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="psichern">Speichern</button>
        <button class="mag-btn mag-btn-rand" data-tu="pzurueck">↺ Original</button>
        <button class="mag-btn mag-btn-grau" data-tu="pabbruch">Abbrechen</button>
      </div>
    </div>`,W.querySelector(`.mag-version`).textContent=e;let Ge=W.querySelector(`.mag-reiter`);We.forEach((e,t)=>{let n=document.createElement(`button`);n.className=`mag-tab`+(t===0?` aktiv`:``),n.dataset.tab=e[0],n.textContent=e[1],Ge.appendChild(n)});function Ke(e,t,n){let r=document.createElement(`button`);return r.className=t,r.dataset.tu=n,r.textContent=e,r}let qe=W.querySelector(`[data-rolle="hknoepfe"]`);d===`bearbeiten`?qe.appendChild(Ke(`Weiter zur Antwortvorlage →`,`mag-btn mag-btn-ok`,`weiter`)):qe.appendChild(Ke(`In die Frage eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));let G=O(`button`,`mag-knopf`);G.title=`Moodle AI Freitext Grader`;let K=document.createElement(`img`);K.className=`mag-knopf-bild`,K.alt=`Moodle AI Freitext Grader`;try{K.src=t.runtime.getURL(`icon/128.png`)}catch{G.textContent=`AI`}K.src&&G.appendChild(K);let q=e=>W.querySelector(`[data-rolle="`+e+`"]`),Je=e=>W.querySelector(`[data-panel="`+e+`"]`),J=null,Y=null,Ye=We[0][0],Xe=!1,Ze=!1;if(typeof IntersectionObserver<`u`){let e=new IntersectionObserver(t=>t.forEach(t=>{t.isIntersecting&&(t.target.dataset.gesehen=`1`,e.unobserve(t.target))}),{threshold:.5}),t=q(`kliste`);t&&new MutationObserver(t=>t.forEach(t=>t.addedNodes.forEach(t=>{t.nodeType===1&&t.classList.contains(`mag-karte`)&&(Ze=!1,e.observe(t))}))).observe(t,{childList:!0})}function Qe(){return d===`bearbeiten`&&!new URLSearchParams(location.search).get(`id`)}function $e(){let e=we();if(e.wer===`coach`)return`kurztest`;if(e.wer===`grader`)return`klausur`;let t=Ce();return!/(^|\n)\s*(?:[a-h]\)|aufgabe\s*\d|\d+[.)]\s)/i.test(t)&&(P()||0)<=3?`kurztest`:`klausur`}let X=d===`bearbeiten`?$e():`klausur`,et={kurztest:[[`Kurz`,`Kurz – 1–2 Sätze`],[`Mittel`,`Mittel – 3–5 Sätze (Standard, wie bisher im Coach)`]],klausur:[[`Mittel`,`Mittel – 3–4 Sätze je Teilaufgabe`],[`Ausführlich`,`Ausführlich – ein Absatz je Teilaufgabe (Standard)`],[`Umfangreich`,`Umfangreich – dazu Abschnitt Operatorerfüllung`]]},tt={kurztest:`Mittel`,klausur:`Ausführlich`},Z=(()=>{let e=d===`bearbeiten`?ee(F()):null;return e&&et[X].some(t=>t[0]===e)?e:tt[X]})();function nt(){let e=q(`hfeedbacksel`);e&&(e.innerHTML=``,et[X].forEach(([t,n])=>{let r=document.createElement(`option`);r.value=t,r.textContent=n,e.appendChild(r)}),et[X].some(e=>e[0]===Z)||(Z=tt[X]),e.value=Z,q(`hfeedbackhinweis`).textContent=X===`kurztest`?`Bei „Kurz" und „Mittel" passt die ganze Klasse meist in einen Durchgang.`:`Klausuren werden in Portionen bewertet; längeres Feedback heißt kleinere Portionen.`)}let rt=null;d===`bearbeiten`&&qe.appendChild(Ke(`3 · In die Aufgabe eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));function it(){let e=q(`hmodus`);if(!e)return;e.hidden=d!==`bearbeiten`,q(`hmodussel`).value=X,q(`hmodushinweis`).textContent=X===`kurztest`?`Kurztest: kurze Antworten, Horizont mit Kernaussage und „Auch richtig". Bewertet wird auf der Übersicht, alle Kurztest-Aufgaben eines Tests zusammen.`:`Klausur: Horizont je Teilaufgabe mit Punkten, Operator und AFB, dazu eine Antwortvorlage. Bewertet wird auf der Einzelseite der Aufgabe, in Portionen, mit Review vor dem Eintragen.`,nt();let t=W.querySelector(`.mag-tab[data-tab="vorlage"]`);if(t&&(t.hidden=X===`kurztest`),d===`bearbeiten`){let e=qe.querySelector(`[data-tu="weiter"]`),t=qe.querySelector(`[data-tu="hschreiben"]`);e&&(e.hidden=X===`kurztest`),t&&(t.hidden=X!==`kurztest`)}}d===`bearbeiten`&&(q(`hfeedbacksel`).addEventListener(`change`,()=>{Z=q(`hfeedbacksel`).value}),q(`hmodussel`).addEventListener(`change`,()=>{X=q(`hmodussel`).value,Z=tt[X],J=null,rt=null,q(`hliste`).innerHTML=``,q(`hknoepfe`).hidden=!0,Q(`hstatus`,`Modus: `+(X===`kurztest`?`Kurztest`:`Klausur`)+`. Bitte den Prompt jetzt (neu) kopieren.`),it()})),it();function at(e){let t=ue(String(e||``).replace(/\r/g,``)).trim().split(/\n\s*\n/).filter(e=>e.trim()).map(e=>`<p>`+k(e.trim()).replace(/\n/g,`<br>`)+`</p>`).join(``);return`<p>`+n+`</p><p>[Rechtschreibung: `+A(T.rechtschreibung)+`%]</p><p>[Feedback: `+Z+`]</p>`+t}function ot(e,t){try{Q(t,`Ins Formular eingesetzt: `+Object.keys(e).map(t=>t+` (`+l(t,e[t])+`)`).join(`, `)+`. Wird mit „Änderungen speichern" zusammen mit der Frage gespeichert.`)}catch(e){Q(t,`Fehler: `+e.message,!0)}}function st(){if(d===`bearbeiten`)return location.href;let e=new URLSearchParams(location.search),t=e.get(`qid`),n=e.get(`id`)||e.get(`cmid`);return t?location.origin+`/question/bank/editquestion/question.php?id=`+t+(n?`&cmid=`+n:``):null}function Q(e,t,n){let r=q(e);r&&(r.textContent=t||``,r.className=`mag-status`+(t?n?` fehler`:` ok`:``))}function ct(e){let t=q(e);return t.hidden=!1,t.innerHTML=``,e=>{t.appendChild(O(`div`,`mag-logzeile`,e)),t.scrollTop=t.scrollHeight}}function lt(){return new Promise(e=>{if(!(t!==void 0&&t.storage))return e();t.storage.local.get([`magSettings`],t=>{t.magSettings&&(T=Object.assign({},oe,t.magSettings)),e()})})}function ut(){t!==void 0&&t.storage&&t.storage.local.set({magSettings:T})}function dt(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;e.type===`checkbox`?e.checked=!!T[t]:e.value=T[t]==null?``:T[t]}),gt()}function ft(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;T[t]=e.type===`checkbox`?e.checked:e.value}),T.promptHorizont=null,T.promptKorrektur=null,ut(),gt()}function pt(){let e=parseFloat(T.rechtschreibung)===0?`Rechtschreibung: kein Abzug`:`Rechtschreibung: `+T.rechtschreibung+` %`;return[T.fach||`⚠ Fach fehlt`,`Jahrgang `+(T.jahrgang||`⚠ fehlt`),`Niveau `+(R[T.kursniveau]||T.kursniveau).split(` `)[0],`Feedback `+w(),e,`Schritte `+A(T.punkteschritte)].join(` · `)}function mt(){return!String(T.fach||``).trim()||!String(T.jahrgang||``).trim()}function ht(){let e=pt(),t=mt();[`hrahmen`,`krahmen`].forEach(n=>{let r=q(n);r&&(r.textContent=e,r.parentElement.classList.toggle(`unvollstaendig`,t))})}function gt(){ht();let e=q(`anredehinweis`);e&&(e.textContent=`Im Feedback wird „`+fe()+` …" verwendet.`);let t=q(`rshinweis`);t&&(t.textContent=parseFloat(T.rechtschreibung)===0?`Kein Punktabzug — das Sprachfeedback wird trotzdem geschrieben.`:`Voller Abzug ab `+A(ie[2][0])+` Fehlern je 100 Wörtern; unter 40 Wörtern zählt die absolute Fehlerzahl.`);let n=q(`vvorschau`);n&&me(n,J?I(J):`<p class="mag-hinweis">Erst im Reiter „Horizont" die Antwort der KI einlesen.</p>`);let r=q(`vhorizont`);r&&me(r,J?L(J):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`)}function $(e){W.querySelectorAll(`.mag-inhalt`).forEach(t=>{t.hidden=t.dataset.panel!==e}),W.querySelectorAll(`.mag-tab`).forEach(t=>t.classList.toggle(`aktiv`,t.dataset.tab===e));let t=We.some(t=>t[0]===e);W.querySelector(`.mag-reiter`).hidden=!t,t&&e!==`einst`&&(Ye=e),e===`vorlage`&&gt(),e===`korrektur`&&wt()}let _t=null;function vt(e,t,n,r){navigator.clipboard.writeText(e).then(()=>{let i=n+`  (`+e.length.toLocaleString(`de-DE`)+` Zeichen)`;if(Q(t,i),!r||!q(r))return;clearInterval(_t);let a=3;Q(t,i+` — weiter in `+a+` s`),_t=setInterval(()=>{if(a--,a>0)return Q(t,i+` — weiter in `+a+` s`);clearInterval(_t),_t=null,Q(t,i+` — jetzt die Antwort der KI einfügen.`);let e=q(r);e.focus(),e.scrollIntoView({block:`nearest`})},1e3)}).catch(()=>Q(t,`Kopieren fehlgeschlagen — Text bitte von Hand markieren.`,!0))}function yt(){let e=q(`hjson`).value.trim();if(!e)return Q(`hstatus`,`Bitte erst die Antwort der KI einfügen.`,!0);if(d===`bearbeiten`&&X===`kurztest`)return bt(e);try{let t=Be(e,`aufgaben`).map(e=>({nr:Number(e.nr),schlagwort:e.schlagwort||``,afb:e.afb||``,punkte:e.punkte==null?null:j(e.punkte),operator:e.operator||``,horizont:e.horizont||e.text||``})).filter(e=>!isNaN(e.nr)).sort((e,t)=>e.nr-t.nr);if(!t.length)throw Error(`Keine Aufgaben im JSON.`);let{doppelt:n}=Ve(t,t.map(e=>e.nr));if(n.length)throw Error(`Aufgabe `+n.join(`, `)+` kommt doppelt vor.`);let r=t.reduce((e,t)=>e+(t.punkte||0),0),i=P();J=t;let a=q(`hliste`);a.innerHTML=``,t.forEach(e=>{let t=O(`div`,`mag-karte`);t.appendChild(O(`div`,`mag-kartenkopf`,`Aufgabe `+e.nr+(e.afb?` · AFB `+e.afb:``)+(e.schlagwort?` · `+e.schlagwort:``)+(e.punkte==null?``:`  (`+A(e.punkte)+` P.)`)));let n=O(`textarea`,`mag-kartentext`);n.value=N(e.horizont),n.rows=5,n.addEventListener(`input`,()=>{e.horizont=n.value}),t.appendChild(n),a.appendChild(t)});let o=t.length+` Aufgaben gelesen.`;i&&Math.abs(r-i)>.005&&(o+=`  ⚠ Punktsumme `+A(r)+` weicht von der Fragenpunktzahl `+A(i)+` ab — die Erweiterung rechnet sie beim Bewerten um.`),d===`bearbeiten`&&(o+=`  Weiter zu „3 · Vorlage" — dort siehst du beides und trägst es ein.`),Q(`hstatus`,o),q(`hknoepfe`).hidden=!1,gt()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}function bt(e){try{let t=Be(e,`horizonte`).find(e=>e&&(e.text||e.horizont));if(!t)throw Error(`Kein Horizont im JSON (erwartet: "horizonte").`);rt=String(t.text||t.horizont).trim();let n=q(`hliste`);n.innerHTML=``;let r=O(`div`,`mag-karte`);r.appendChild(O(`div`,`mag-kartenkopf`,`Kurztest-Horizont`));let i=O(`textarea`,`mag-kartentext`);i.value=rt,i.rows=12,i.addEventListener(`input`,()=>{rt=i.value}),r.appendChild(i),n.appendChild(r),Q(`hstatus`,`Horizont gelesen. Prüfen, bei Bedarf ändern, dann „In die Frage eintragen".`),q(`hknoepfe`).hidden=!1,it()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function xt(e){if(d===`bearbeiten`&&X===`kurztest`){if(!rt)return Q(`hstatus`,`Es liegt noch kein geprüfter Horizont vor.`,!0);let t={"graderinfo[text]":at(rt)};return Qe()?ot(t,`hstatus`):St(t,e,ct(`hlog`),`hstatus`)}if(Qe()&&J){let e={"graderinfo[text]":L(J)};return Je(`vorlage`)&&(e[`responsetemplate[text]`]=I(J)),ot(e,`vstatus`)}let t=d===`bearbeiten`,n=t?`vstatus`:`hstatus`;if(!J)return Q(n,`Es liegt noch kein geprüfter Horizont vor — bitte erst im Reiter „Horizont" die Antwort der KI einlesen und prüfen.`,!0);if(!st())return Q(n,`Die Adresse der Frage lässt sich hier nicht bestimmen — bitte die Frage zum Bearbeiten öffnen.`,!0);let r=ct(t?`vlog`:`hlog`),i={"graderinfo[text]":L(J)};d===`bearbeiten`&&Je(`vorlage`)&&(i[`responsetemplate[text]`]=I(J)),await St(i,e,r,n)}async function St(e,t,n,r){let i=Object.keys(e);try{if(Q(r,t?`Trockenlauf läuft …`:`Wird eingetragen …`),d!==`bearbeiten`){let a=st(),o=[...(await _e(a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!o)throw Error(`Bearbeiten-Formular der Frage nicht erreichbar.`);let s=ve(o);if(i.forEach(r=>{if(!s.has(r))throw Error(`Feld „`+r+`" nicht im Formular`);n((t?`✓ `:``)+`Feld `+r+` vorhanden`+(N(s.get(r)).length?` (enthält schon Text!)`:``)),t||s.set(r,e[r])}),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);let c=(o.querySelector(`[name="name"]`)||{}).value||``,l=await be(await ye(o,s,a),c,a),u=[...(await _e(l||a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),d=0;return i.forEach(t=>{let r=u&&u.querySelector(`[name="`+CSS.escape(t)+`"]`),i=!!r&&xe(r.value,e[t]);n((i?`✓ `:`✗ `)+t+(i?` eingetragen`:` NICHT angekommen`)),i||d++}),l||n(`⚠ Neue Fragenversion nicht auffindbar — Gegenprobe unsicher.`),Q(r,d?d+` Feld(er) nicht angekommen — Protokoll lesen.`:`In die Frage eingetragen und gegengeprüft.`,d>0)}let a=await Se(e,t);if(a.bericht.forEach(e=>n((t?`✓ `:``)+`Feld `+e.feld+` vorhanden`+(e.belegt?` (enthält schon Text!)`:``))),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);a.warnung&&n(`⚠ `+a.warnung);let o=0;if((a.ergebnis||[]).forEach(e=>{n((e.ok?`✓ `:`✗ `)+e.feld+(e.ok?` eingetragen`:` NICHT angekommen`)),e.ok||o++}),o)return Q(r,o+` Feld(er) nicht angekommen — Protokoll lesen.`,!0);n(`✓ gespeichert und gegengeprüft`),jt(a.neueUrl),Q(r,a.neueUrl?`Eingetragen und gegengeprüft. Diese Seite zeigt jetzt einen veralteten Stand.`:`Eingetragen und gegengeprüft. Bitte die Frage neu öffnen — Moodle hat beim Speichern eine neue Version angelegt.`,!1)}catch(e){n(`✗ `+e.message),Q(r,`Fehler: `+e.message,!0)}}function Ct(e){let t=e.length?e.reduce((e,t)=>e+M(t.text),0)/e.length:0,n=Math.max(200,t*6);return Math.max(1,Math.min(30,Math.floor(22e3/n)))}function wt(){let e=De(),t=q(`kgroesse`);t.options.length||([1,2,3,5,8,10,15,20,30].forEach(e=>t.appendChild(new Option(e+` Abgaben`,e))),t.value=String(Ct(e)),t.addEventListener(`change`,wt));let n=e.length?Math.round(e.reduce((e,t)=>e+M(t.text),0)/e.length):0;q(`kgroessehinweis`).textContent=e.length+` Abgaben, im Schnitt `+n+` Wörter. Vorschlag: `+Ct(e)+` je Durchgang.`;let r=F()||T.horizontLokal,i=parseInt(t.value,10)||5,a=Math.ceil(e.length/i)||1,o=q(`kknoepfe`);o.innerHTML=``;for(let t=0;t<a;t++){let n=t*i,s=Math.min(n+i,e.length),c=O(`button`,`mag-btn mag-btn-primary`,a===1?`📋 Prompt kopieren`:`📋 Teil `+(t+1)+` (Abgabe `+(n+1)+`–`+s+`)`);c.addEventListener(`click`,()=>{if(!r)return Q(`kstatus`,`Kein Erwartungshorizont — bitte erst den Reiter „Horizont" verwenden.`,!0);vt(Ie(e.slice(n,s),r,t+1,a),`kstatus`,a===1?`Prompt kopiert.`:`Teil `+(t+1)+` kopiert.`,`kjson`)}),o.appendChild(c)}}let Tt=!1;function Et(){if(Xe)return Q(`kstatus`,`Gesperrt: Antworten zu mehreren Fragen auf dieser Seite. Bitte jede Frage einzeln über die Übersicht öffnen.`,!0);let e=q(`kjson`).value.trim();if(!e)return Q(`kstatus`,`Bitte erst die Antworten der KI einfügen.`,!0);try{let t=De(),n=F()||T.horizontLokal,r=Te(n),i=Be(e,`bewertungen`).filter(e=>e&&e.nr!=null),{fehlend:a,doppelt:o}=Ve(i,t.map(e=>e.nr));if(o.length)throw Error(`Abgabe `+o.join(`, `)+` kommt doppelt vor.`);if(a.length&&!Tt){let e=q(`kliste`);e.innerHTML=``,q(`keintragen`).hidden=!0,Y=null;let n=q(`rsabgleich`);n&&(n.hidden=!0);let r=t.length-a.length;Q(`kstatus`,`Teil erkannt: `+r+` von `+t.length+` Abgaben. Nächsten Teil einfach dazu einfügen — geprüft wird, sobald alle da sind. (Es fehlen: `+a.join(`, `)+`)`);let i=O(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`Trotzdem nur diese `+r+` prüfen`);i.addEventListener(`click`,()=>{Tt=!0,Et()}),e.appendChild(i);return}let s=parseFloat(T.rechtschreibung)||0,c=S(n),l=te(n),u=c!=null&&!se?c:s,d=l??(parseFloat(T.punkteschritte)||.5),f=q(`kliste`);f.innerHTML=``;let p=q(`rsabgleich`);if(p){if(p.innerHTML=``,c!=null&&c!==s){p.hidden=!1,p.appendChild(O(`div`,null,`⚠ Im Horizont steht `+A(c)+` % Rechtschreibung, eingestellt sind `+A(s)+` %. Es gilt gerade: `+(se?A(s)+` % (Einstellung)`:A(c)+` % (Horizont)`)+`.`));let e=O(`button`,`mag-btn mag-btn-grau`,se?`Stattdessen den Horizont-Wert verwenden`:`Stattdessen `+A(s)+` % (Einstellung) verwenden`);e.addEventListener(`click`,()=>{se=!se,Et()}),p.appendChild(e)}else p.hidden=!0}Y=[];let m=0;i.forEach(e=>{let n=t.find(t=>t.nr===Number(e.nr));if(!n)return;let i=je(n,e,r,u,d),a=Le(e,i,r);if(Math.abs(i.gesamt-n.ist)<.005&&!n.kommentarfeld){m++;return}Y.push({nr:n.nr,markfeld:n.markfeld,kommentarfeld:n.kommentarfeld,punkte:i.gesamt,feedbackHtml:Re(a),text:a});let o=O(`div`,`mag-karte`);o.appendChild(O(`div`,`mag-kartenkopf`,`Abgabe `+n.nr+`:  `+A(n.ist)+` → `+A(i.gesamt)+` von `+A(i.max)+` P.`+(i.abzug>.004?`   (−`+A(i.abzug)+` P. Sprache)`:``))),o.appendChild(O(`div`,`mag-kartenzeile`,i.teil.map(e=>`A`+e.nr+`: `+e.prozent+`%`).join(`   `)+`   ·   `+i.wortzahl+` Wörter, `+A(i.fehlerDichte)+` Fehler/100`+(i.fehlendeAufgaben.length?`   ·   ⚠ Aufgabe `+i.fehlendeAufgaben.join(`, `)+` von der KI nicht bewertet (0 %)`:``)));let s=O(`textarea`,`mag-kartentext`);s.value=a,s.rows=6;let c=Y[Y.length-1];s.addEventListener(`input`,()=>{c.text=s.value,c.feedbackHtml=Re(s.value)}),o.appendChild(s),f.appendChild(o)});let h=Y.length+` Abgaben vorbereitet.`;m&&(h+=`  `+m+` ohne Änderung übersprungen.`),a.length&&(h+=`  ⚠ Es fehlen die Abgaben `+a.join(`, `)+` — bitte den fehlenden Teil nachreichen.`),Q(`kstatus`,h,a.length>0),q(`keintragen`).hidden=Y.length===0}catch(e){Q(`kstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function Dt(e){if(!Y||!Y.length)return;let t=ct(`klog`);try{Q(`kstatus`,e?`Trockenlauf läuft …`:`Wird eingetragen …`);let n=await Ue(Y,e,t);if(e)return Q(`kstatus`,n.fehler?n.fehler+` Abgabe(n) nicht auf der Seite — Protokoll lesen.`:`Alles vorhanden. Jetzt eintragen.`,n.fehler>0);if(t(`— `+n.ok+` eingetragen · `+n.fehler+` fehlgeschlagen —`),n.fehler)Q(`kstatus`,n.fehler+` fehlgeschlagen — Protokoll lesen.`,!0);else{let e=new URLSearchParams(location.search),t=e.get(`id`),r=h(await f(t),e.get(`slot`),e.get(`qid`)),i=null,a=`Fenster schließt`;r&&r.naechste?(i=p(t,r.naechste),a=`Weiter zur Klausur-Frage `+(r.index+2)+` von `+r.gesamt):r&&(i=m(t),a=`Alle Klausur-Fragen bewertet — zurück zur Übersicht`);let o=3,s=n.ok+` Bewertungen eingetragen und gegengeprüft.`;Q(`kstatus`,s+` `+a+` in `+o+` s …`);let c=setInterval(()=>{if(o--,o>0)return Q(`kstatus`,s+` `+a+` in `+o+` s …`);clearInterval(c),kt.zu(),i?location.href=i:location.reload()},1e3)}}catch(e){t(`✗ `+e.message),Q(`kstatus`,`Fehler: `+e.message,!0)}}let Ot=`horizont`,kt={einst:()=>{dt(),$(`einst`)},zueinst:()=>{dt(),$(`einst`)},zu:()=>{W.classList.remove(`offen`),G.classList.remove(`versteckt`)},hprompt:()=>vt(Fe(),`hstatus`,`Prompt kopiert.`,`hjson`),hedit:()=>Mt(`horizont`),hpruefen:yt,hschreiben:()=>xt(!1),hlokalsichern:()=>{T.horizontLokal=q(`hlokal`).value.trim(),ut(),Q(`hstatus`,T.horizontLokal?`Horizont in der Erweiterung gespeichert (nicht in der Frage).`:`Gespeicherter Horizont gelöscht.`),wt()},weiter:()=>$(`vorlage`),beides:()=>xt(!1),kopierh:()=>J?vt(L(J),`vstatus`,`Horizont-HTML kopiert.`):Q(`vstatus`,`Erst im Reiter „Horizont" die KI-Antwort einlesen.`,!0),kopierv:()=>J?vt(I(J),`vstatus`,`Antwortvorlage kopiert.`):Q(`vstatus`,`Erst im Reiter „Horizont" die KI-Antwort einlesen.`,!0),kedit:()=>Mt(`korrektur`),kpruefen:Et,kschreiben:()=>{let e=D(`.mag-karte`,q(`kliste`)),t=e.filter(e=>e.dataset.gesehen!==`1`).length;if(t&&!Ze)return Ze=!0,Q(`kstatus`,`⚠ `+t+` von `+e.length+` Bewertungen noch nicht angesehen. Bitte durchblättern — oder „Alle eintragen" noch einmal drücken, um trotzdem einzutragen.`,!0);Ze=!1,Dt(!1)},krohdaten:()=>vt(JSON.stringify({stand:new Date().toLocaleString(`de-DE`),fach:T.fach,jahrgang:T.jahrgang,gesamtpunkte:P(),aufgabenstellung:Ce(),horizont:N(F()||T.horizontLokal),abgaben:De().map(e=>{let t=Oe(e.rohHtml,e.text);return{nr:e.nr,ist:e.ist,max:e.max,gegliedert:t.gegliedert,aufgaben:t.aufgaben}})},null,2),`kstatus`,`Rohdaten kopiert.`),esichern:()=>{if(ft(),mt())return Q(`estatus`,`Fach und Jahrgang fehlen noch — beides steht im Prompt und bestimmt Anspruchsniveau und Anrede.`,!0);Q(`estatus`,``),$(d===`bearbeiten`?`horizont`:Ye===`einst`?`korrektur`:Ye)},eabbruch:()=>{dt(),Q(`estatus`,``)},psichern:()=>{let e=q(`ptext`).value.trim(),t=e===(Ot===`horizont`?B():U()).trim()?null:e;Ot===`horizont`?T.promptHorizont=t:T.promptKorrektur=t,ut(),$(Ye)},pzurueck:()=>{q(`ptext`).value=Ot===`horizont`?B():U()},pabbruch:()=>$(Ye)},At=null;function jt(e){let t=W.querySelector(`.mag-banner`);if(t.hidden=!1,t.className=`mag-banner warnung`,t.innerHTML=``,t.appendChild(O(`div`,null,`Moodle hat beim Speichern eine neue Fassung der Frage angelegt. Dieses Formular zeigt den alten Stand — hier nichts mehr speichern!`)),!e)return;let n=O(`button`,`mag-btn mag-btn-ok`,`Zur neuen Fassung der Frage`),r=O(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`hier bleiben`);n.addEventListener(`click`,()=>{location.href=e}),t.appendChild(n),t.appendChild(r);let i=8,a=O(`div`,`mag-hinweis`,`Wechsel in `+i+` Sekunden …`);t.appendChild(a),r.addEventListener(`click`,()=>{clearInterval(At),At=null,a.textContent=`Wechsel angehalten. Diese Seite bitte nicht mehr speichern.`,r.remove()}),At=setInterval(()=>{if(i--,i<=0){clearInterval(At),location.href=e;return}a.textContent=`Wechsel in `+i+` Sekunden …`},1e3)}function Mt(e){Ot=e,q(`ptitel`).textContent=e===`horizont`?`Prompt für den Erwartungshorizont`:`Prompt für die Korrektur`;let t=e===`horizont`?T.promptHorizont:T.promptKorrektur;q(`ptext`).value=t&&t.trim()||(e===`horizont`?B():U()),$(`prompt`)}W.addEventListener(`click`,e=>{let t=e.target.closest(`.mag-tab`);if(t)return _t&&=(clearInterval(_t),null),t.dataset.tab===`einst`?kt.einst():$(t.dataset.tab);let n=e.target.closest(`[data-tu]`);n&&kt[n.dataset.tu]&&(e.preventDefault(),kt[n.dataset.tu]())}),W.addEventListener(`paste`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;if(t===`hjson`&&setTimeout(yt,0),t===`kjson`){let t=e.clipboardData&&e.clipboardData.getData(`text`);if(t){e.preventDefault();let n=e.target,r=n.value.replace(/\s+$/,``);n.value=r?r+`

`+t:t,n.scrollTop=n.scrollHeight}Tt=!1,setTimeout(Et,0)}});let Nt=null;W.addEventListener(`input`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;t!==`hjson`&&t!==`kjson`||e.inputType===`insertFromPaste`||(t===`kjson`&&(Tt=!1),clearTimeout(Nt),Nt=setTimeout(()=>{e.target.value.trim()&&(t===`hjson`?yt:Et)()},800))}),W.addEventListener(`change`,e=>{let t=e.target.closest(`[data-opt]`);t&&[`afbFarben`,`vorlagePunkte`,`vorlageAfb`].includes(t.dataset.opt)&&(T[t.dataset.opt]=t.checked,ut(),gt())}),G.addEventListener(`click`,()=>{W.classList.add(`offen`),G.classList.add(`versteckt`)}),lt().then(()=>{try{let e=W.querySelector(`.mag-kopfbild`);e&&(e.src=t.runtime.getURL(`icon/128.png`))}catch{let e=W.querySelector(`.mag-kopfbild`);e&&e.remove()}document.body.appendChild(G),document.body.appendChild(W),dt(),q(`hlokal`).value=T.horizontLokal||``;let e=we(),n=W.querySelector(`.mag-banner`),r=d===`bewertung`?new Set(D(`.que .graderinfo`).map(e=>e.innerText.trim()).filter(Boolean)).size:0;if(Xe=r>1,r>1){n.hidden=!1,n.textContent=`Auf dieser Seite stehen Antworten zu `+r+` verschiedenen Fragen (Zufallsfrage). Bitte über die Übersicht jede Frage einzeln öffnen — sonst würde alles gegen einen einzigen Horizont bewertet.`,q(`kstatus`)&&Q(`kstatus`,`Gesperrt: mehrere Fragen auf einer Seite (siehe oben).`,!0);let e=W.querySelector(`[data-tu="kschreiben"]`);e&&(e.disabled=!0)}else e.wer===`coach`?(n.hidden=!1,n.textContent=`Diese Frage ist als Kurztest angelegt. Sie lässt sich hier trotzdem im Klausur-Weg bewerten.`):!e.horizont&&d===`bewertung`&&!T.horizontLokal&&(n.hidden=!1,n.textContent=`Diese Frage hat noch keinen Erwartungshorizont. Er lässt sich hier nachtragen.`);let i=W.querySelector(`.mag-untertitel`);i&&(i.textContent=d===`bearbeiten`?`Erwartungshorizont für diese Aufgabe`:`Freitextaufgaben bewerten`);let a;if(mt()&&d!==`bearbeiten`?(a=`einst`,Q(`estatus`,`Bitte einmal ausfüllen: Fach und Jahrgang fehlen. Beides geht als Rahmendatum in den Prompt.`,!0)):a=d===`bewertung`&&!e.horizont&&!T.horizontLokal||d===`bearbeiten`?`horizont`:`korrektur`,$(a),ht(),d===`bewertung`){let e=De().length;Q(`kstatus`,e?e+` Abgaben auf dieser Seite.`:`Keine Abgaben gefunden.`)}else{Q(`hstatus`,/moodle[-\s]?ai[-\s]?(coach|grader)/i.test(N(F()))?`Dieser Horizont stammt noch aus Coach oder Grader. Bitte neu erstellen – der alte geht als Vorlage in den Auftrag ein.`:e.horizont?`Diese Aufgabe hat bereits einen Erwartungshorizont — ein neuer ersetzt ihn.`:`Noch kein Erwartungshorizont in dieser Aufgabe.`+(mt()?` Tipp: Fach und Jahrgang im Zahnrad ⚙ eintragen – sie gehen in den Auftrag ein.`:``));let t=V();t.length&&(q(`hmaterial`).hidden=!1,q(`hmaterial`).textContent=`In der Aufgabe stehen `+t.length+` Bild(er)/Datei(en): `+t.join(` · `)+` – bitte zusätzlich in den KI-Chat hochladen.`);let n=q(`hhilfe`);n&&(n.open=!T.hilfeGesehen,n.addEventListener(`toggle`,()=>{!n.open&&!T.hilfeGesehen&&(T.hilfeGesehen=!0,ut())})),W.classList.add(`offen`),G.classList.add(`versteckt`)}})}function _(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``,r=new URLSearchParams(location.search);if(r.get(`mode`)!==`grading`||r.get(`slot`)||r.get(`includeauto`)===`1`)return;let i=r.get(`id`);if(!i)return;let o=location.origin+location.pathname,l=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),u=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},f=e=>Number(e).toFixed(2).replace(`.`,`,`),m=e=>String(Number(e)).replace(`.`,`,`),h=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function g(e,t,n){if(!e||typeof e!=`object`)return``;let r=t=>String(e[t]||``).trim(),i=r(`lob`),a=[[`Inhalt`,r(`inhalt`)],[`Rechtschreibung`,r(`rechtschreibung`)],[`Grammatik`,r(`grammatik`)],[`Tipp`,r(`tipp`)]].filter(([,e])=>e);if(!a.length&&!i)return``;if(!a.length)return`<p><strong><u>Feedback:</u></strong> `+h(i)+`</p>`;let o=a.map(([e])=>e),s=o.includes(`Grammatik`)?`Grammatik`:o.includes(`Rechtschreibung`)?`Rechtschreibung`:null,c=e=>`<span style="color:#767676;font-style:italic;"> (`+e+`)</span>`,l=!!(n&&n.gewicht>=5),u=e=>e>=5?`5 oder mehr Fehlerpunkte`:e===1?`1 Fehlerpunkt`:e+` Fehlerpunkte`,d=`<p><strong><u>Feedback</u></strong></p>`;return i&&(d+=`<p>`+h(i)+`</p>`),a.forEach(([e,r])=>{let i=``;n&&(e===`Inhalt`&&n.inhalt!=null?i=c(n.inhaltMax==null?f(n.inhalt)+` Punkte`:f(n.inhalt)+` von `+f(n.inhaltMax)+` Punkten`):e===s&&n.abzug&&(i=c(`−`+f(n.abzug)+` Punkte`+(n.gewicht==null?``:` — `+u(n.gewicht)+(l?`, höchste Stufe`:``))))),d+=`<p><u>`+e+`:</u> `+h(r)+i+`</p>`,e===`Inhalt`&&t&&(d+=`<p><u>So hättest du es schreiben können:</u> `+h(t)+`</p>`),e===s&&l&&(d+=`<p>In deiner Antwort häufen sich mehrere grundlegende Fehler — das ist die höchste Fehlerstufe. Es lohnt sich, gezielt daran zu arbeiten.</p>`)}),d}function _(e){let t=String(e||``).replace(/\r/g,``).match(/Kernaussage\s*:?\s*([\s\S]*?)(?=\n\s*(?:Muss enthalten|Auch richtig|Inhalt|Reicht nicht|Häufiger Fehler)\s*:|$)/i),n=t?t[1].replace(/\s+/g,` `).trim():``;return n.length>300?``:n}let v=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function y(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let b=e=>new Promise(t=>setTimeout(t,e)),x=(e,t,n)=>`${o}?id=${i}&mode=grading&slot=${e}&qid=${t}&grade=${n||`needsgrading`}&qperpage=100`,S=e=>`${l}/question/bank/editquestion/question.php?id=${e}&cmid=${i}`,C=e=>e&&e.slot&&e.qid?x(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``):null;async function ee(e){try{await navigator.clipboard.writeText(e)}catch{let t=v(`textarea`,`co-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}let w=n,te=a;function ne(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function re(e){return s(ne(e).match(te))}function ie(e){let t=String(e||``).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&te.test(t[n])&&(t[n]=t[n].replace(te,``).trim(),t[n]||t.splice(n,1)),t.join(`
`).trim()}let ae=/^\s*\[?\s*rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%?\s*\]?\s*$/i;function oe(e){return`[Rechtschreibung: ${m(e)}%]`}function T(e){let t=ne(ie(e)).match(ae);return t?parseFloat(t[1].replace(`,`,`.`)):null}function se(e){let t=ie(e).split(`
`),n=t.findIndex(e=>e.trim());n>-1&&ae.test(t[n].trim())&&t.splice(n,1);let r=t.findIndex(e=>e.trim());return r>-1&&/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/i.test(t[r])&&t.splice(r,1),t.join(`
`).trim()}function E(e,t){let n=e.split(`
`),r=(n[1]||``).trim();return ae.test(r)?e:(n.splice(1,0,oe(t)),n.join(`
`))}let D=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,O={maxSprachabzug:10,kiHinweisText:D,promptOverride:``,horizontPromptOverride:``,nurMitMarker:!1,kompaktPrompt:!1},k={...O},A=!1;function j(e){let t=k.maxSprachabzug??O.maxSprachabzug;return A?t:(e&&e.horizontProzent)??t}function ce(){return new Promise(e=>{try{t.storage.local.get([`coachOptionen`],t=>{k={...O,...t&&t.coachOptionen?t.coachOptionen:{}},e(k)})}catch{e(k)}})}function M(e){return k={...k,...e},new Promise(e=>{try{t.storage.local.set({coachOptionen:k},e)}catch{e()}})}let le=[0,1/3,1/2,2/3,5/6,1];function ue(e,t){let n=Math.min(Math.max(0,Math.round(e)),le.length-1),r=t??k.maxSprachabzug??O.maxSprachabzug;return le[n]*r}let de=e=>(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0);function fe(e,t,n,r){let i=de(n),a=ue(i,r),o=e*t/100-e*a/100;return{gewicht:i,abzug:a,inhaltPunkte:Math.round(e*t/100*100)/100,abzugPunkte:Math.round(e*a/100*100)/100,punkte:Math.max(0,Math.round(o*100)/100)}}function N(){let e=document.querySelector(`table`);return e?[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)||``).find(e=>/slot=/.test(e))||``,n=(t.match(/slot=(\d+)/)||[])[1],r=(t.match(/qid=(\d+)/)||[])[1];if(!n||!r)return null;let i=(e.cells[5]?e.cells[5].textContent.trim():``).match(/^(\d+)/);return{slot:n,qid:r,name:e.cells[2]?e.cells[2].textContent.trim():``,summe:i?+i[1]:null}}).filter(Boolean):[]}let pe=e=>e?e.innerHTML.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&amp;/g,`&`).replace(/&lt;/g,`<`).replace(/&gt;/g,`>`).replace(/&quot;/g,`"`).replace(/\s+/g,` `).trim():``,me=e=>e.querySelector(`textarea.qtype_essay_response, div.qtype_essay_response`),he=e=>(e.tagName===`TEXTAREA`?e.value||``:pe(e)).trim();async function ge(e,t){let n=null,r=new Set,i=[];for(let a=0;a<t;a++){a>0&&await b(500);let t=await y(x(e.slot,e.qid,`all`));if(n=t,[...t.querySelectorAll(`.que`)].forEach(e=>{let t=(e.id||``).match(/^question-(\d+)-(\d+)$/),n=t?t[1]:e.id;n&&!r.has(n)&&(r.add(n),i.push(e))}),e.summe!=null&&i.length>=e.summe)break}return{bloecke:i,letzterDoc:n}}async function _e(e,t){if(!e.length||!e.some(e=>me(e)))return null;let n=e[0],r=n.querySelector(`.graderinfo`),i=r?r.innerText.trim():``,a=F(n),o=null;if(a&&a.gesamt>a.ist)try{let e=await we(t.qid);e&&e.horizont&&(i=e.horizont,o=a.gesamt)}catch{}let s={name:t.name,qid:t.qid,slot:t.slot,aufgabe:pe(n.querySelector(`.qtext`)),zustaendig:re(i),horizontProzent:T(i),feedback:(i.match(/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel)\s*\]?\s*$/im)||[])[1]||`Mittel`,horizont:se(i),max:u((n.querySelector(`input[name$="-maxmark"]`)||{}).value)??1,...o?{horizont_aus_fassung:o}:{}},c=[];return e.forEach(e=>{let n=(e.id||``).match(/^question-(\d+)-(\d+)$/);if(!n)return;let r=me(e),i=e.querySelector(`input[name$="-mark"]`),a=e.querySelector(`textarea[name$="-comment"]`);if(!r||!i)return;let o=String(i.value||``).trim()!==``;c.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:n[1],antwort:he(r),max:u((e.querySelector(`input[name$="-maxmark"]`)||{}).value)??s.max,markfeld:i.name,kommentarfeld:a?a.name:null,hat_kommentar:!!(a&&a.value.trim()),schon_bewertet:o})}),{frage:s,versuche:c}}async function ve(e,t){let n=N();if(!n.length)throw Error(`Auf dieser Seite steht keine Fragenübersicht.`);let r={},a={},o=[],s=[],c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=[...n];return await Promise.all(Array.from({length:1},async()=>{for(;h.length;){let i=h.shift();try{let{bloecke:e}=await ge(i,8),n=await _e(e,i);if(!n)d++;else{let e=n.frage.name||i.slot+`|`+i.qid,s=n.frage.zustaendig,c=s===`grader`,d=k.nurMitMarker&&s!==`coach`;c||d?a[e]||(a[e]={...n.frage,grund:c?`grader`:`kein-marker`},c?f++:m++):(r[e]||(r[e]=n.frage,n.frage.horizont?s||p++:u++),n.versuche.forEach(e=>{if(e.schon_bewertet&&!t){l++;return}o.push(e)}))}}catch(e){s.push({frage:i.name,meldung:e.message})}c++,e(c,n.length,o.length)}})),o.forEach((e,t)=>{e.nr=t+1}),{meta:{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:(()=>{let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return e?e.textContent.trim():``})(),cmid:i,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.length,fragen_mit_horizont:Object.values(r).filter(e=>e.horizont).length,fragen_ohne_horizont:u,fragen_fuer_grader:f,fragen_ohne_marker:p,streng_uebersprungen:m,nur_mit_marker:!!k.nurMitMarker,keine_freitextfrage:d,antworten:o.length,uebersprungen:l,max_sprachabzug_prozent:k.maxSprachabzug},fragen:r,fremde:a,antworten:o,fehler:s}}function ye(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function be(e){let t=new Map;return(e||[]).forEach(e=>{let n=e.slot+`|`+e.qid;t.has(n)||t.set(n,{slot:e.slot,qid:e.qid,eintraege:[]}),t.get(n).eintraege.push(e)}),[...t.values()]}async function xe(e,t,n){let r=be(e),i=0,a=0,o=0;for(let e of r){try{let n=(await y(x(e.slot,e.qid,`all`))).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);let r=ye(n);e.eintraege.forEach(e=>{let n=[];r.has(e.markfeld)||n.push(`Punktefeld`),e.text&&e.kommentarfeld&&!r.has(e.kommentarfeld)&&n.push(`Kommentarfeld`),n.length?(a++,t(`✗ ${n.join(` und `)} fehlt — ${e.frage}`,C(e))):i++})}catch(n){a+=e.eintraege.length,t(`✗ Seite ${e.eintraege[0].frage}: ${n.message}`)}o++,n(o,r.length)}return{ok:i,fehler:a,gruppen:r.length,trocken:!0}}async function Se(e,t,n){let r=null,i=new URLSearchParams,a=new Set;for(let o=0;o<n;o++){o>0&&await b(500);let n=(await y(e)).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);r=n;let s=ye(n);if([...new Set(s.keys())].forEach(e=>{a.has(e)||(i.set(e,s.get(e)),a.add(e))}),t.every(e=>i.has(e)))break}return{form:r,felder:i}}async function Ce(e,t,n,r){let i=be(e),a=0,o=0,s=0,c=[];for(let e of i){try{let r=x(e.slot,e.qid,`all`),{form:i,felder:s}=await Se(r,e.eintraege.map(e=>e.markfeld),8),l=s,d=[];if(e.eintraege.forEach(e=>{if(!l.has(e.markfeld)){o++,c.push(e),n(`✗ Punktefeld nicht auf der Seite — ${e.frage}`,C(e));return}if(l.set(e.markfeld,f(e.punkte)),e.text&&e.kommentarfeld&&l.has(e.kommentarfeld)){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(k.kiHinweisText||D).trim();e&&(n+=`<p><em><small>`+h(e)+`</small></em></p>`)}l.set(e.kommentarfeld,n)}d.push(e)}),d.length){let e=[...i.elements].find(e=>e.type===`submit`&&e.name);e&&l.set(e.name,e.value);let t=new URL(i.getAttribute(`action`)||r,r).href,s=await fetch(t,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:l.toString()});if(!s.ok)throw Error(`HTTP `+s.status+` beim Speichern`);let p=d.slice(),m=new Map;for(let e=0;e<8&&p.length;e++){e>0&&await b(500);let t=await y(r);p=p.filter(e=>{let n=t.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`),r=n?u(n.value):null;return r!==null&&Math.abs(r-e.punkte)<.005?(m.set(e,r),!1):(m.set(e,r),!0)})}d.forEach(e=>{if(!p.includes(e))a++,n(`✓ ${e.frage} — ${f(e.punkte)} von ${f(e.max)}`,C(e));else{o++,c.push(e);let t=m.get(e);n(`✗ ${e.frage} — steht auf ${t==null?`keinem Wert`:f(t)} statt ${f(e.punkte)}`,C(e))}})}}catch(t){o+=e.eintraege.length,c.push(...e.eintraege),n(`✗ ${e.eintraege[0].frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,fehlgeschlagen:c}}async function P(e,t,n,r){let i=e,a=0,o=0,s=0;for(let e=1;e<=3&&i.length;e++){s=e,e>1&&(n(`↻ Versuch ${e}/3: ${i.length} Eintrag/Einträge erneut …`),await b(1500));let c=await Ce(i,t,n,r);a+=c.ok,o+=c.gruppen,i=c.fehlgeschlagen}return{ok:a,fehler:i.length,gruppen:o,versuche:s}}function F(e){let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function we(e){let t=[...(await y(S(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!t)return null;let n=[...(await y(new URL(t.getAttribute(`href`),S(e)).href)).querySelectorAll(`table tbody tr`)];if(!n.length)return null;let r=null;for(let e of n)for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){r=e[1];break}}if(!r||String(r)===String(e))return null;let i=(await y(S(r))).querySelector(`[name="graderinfo[text]"]`);if(!i)return null;let a=new DOMParser().parseFromString(String(i.value||``),`text/html`),o=(a.body?a.body.textContent:``).trim();return o?{qid:r,horizont:o}:null}function Te(e,t,n){let r=E(te.test(ne(t))?t:w+`
`+t,k.maxSprachabzug??O.maxSprachabzug);return De(e,()=>`<p>`+h(r).replace(/\n/g,`<br>`)+`</p>`,r,n)}function Ee(e){let t=`<p>`+w+`</p><p>`+oe(k.maxSprachabzug??O.maxSprachabzug)+`</p>`;return De(e,e=>t+(e||``),w,!1)}async function De(e,t,n,r){let i=S(e),a=await y(i),o=[...a.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`))||[...a.forms].find(e=>e.querySelector(`[name*="graderinfo"]`));if(!o)throw Error(a.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let s=ye(o),c=`graderinfo[text]`;if(!s.has(c))throw Error(`Feld „graderinfo[text]" nicht im Formular`);if(r)return{ok:!0,feld:c,vorher:s.get(c)||``};s.set(c,t(s.get(c)||``));let l=[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name===`submitbutton`)||[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name&&e.name!==`cancel`);if(!l)throw Error(`Kein Speichern-Knopf im Formular`);s.set(l.name,l.value);let u=new URL(o.getAttribute(`action`)||i,i).href,d=await fetch(u,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!d.ok)throw Error(`HTTP `+d.status+` beim Speichern`);let f=null;try{f=new URL(d.url).searchParams.get(`lastchanged`)}catch{}let p=(await y(f?S(f):i)).querySelector(`[name="${CSS.escape(c)}"]`),m=p?String(p.value||``).replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,h=String(n).replace(/\s+/g,` `).trim().slice(0,30);if(!m||!m.includes(h.slice(0,20)))throw Error(f?`Text nicht angekommen (geprüft an der neuen Fragenversion)`:`Nicht gegengeprüft: Moodle hat keine neue Fragen-Nummer zurückgemeldet. Sieh in der Frage selbst nach — gespeichert sein kann es trotzdem.`);return{ok:!0,feld:c,neueId:f}}let Oe=`[MOODLE_AI_COACH_DATEN]`;function ke(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – BEWERTUNG KURZER FREITEXTANTWORTEN
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:
1. „Willkommen beim Moodle AI Freitext Grader."
2. „Ich bewerte kurze Freitextantworten nach dem Erwartungshorizont, der in der
   Aufgabe hinterlegt ist, und schreibe jedem Schüler eine Rückmeldung zur Sprache.
   Entscheiden tust du."
3. „Der „Moodle AI Freitext Grader" wurde von T. Henken und A. Spielhoff entwickelt und ist unter der Lizenz
   CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen,
   solange du ihn nennst."

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Die Schülerinnen und Schüler haben eine Frage in ein bis drei Sätzen beantwortet.
Zu jeder Aufgabe steht unter „horizont" der Erwartungshorizont der Lehrkraft: die
Kernaussage, was enthalten sein muss, was auch als richtig gilt und – am wichtigsten –
eine Abstufung, welcher Prozentsatz wofür vergeben wird.

Deine Aufgabe hat zwei Teile, die STRIKT getrennt bleiben:
  1. INHALT  – wie gut trifft die Antwort den Erwartungshorizont?
  2. SPRACHE – welche Sprachfehler stehen im Text?

═══════════════════════════════════════════════════════
TEIL 1 – INHALT
═══════════════════════════════════════════════════════

Vergib einen Prozentwert nach der Abstufung, die im Horizont unter „Inhalt:" steht.
Halte dich an diese Stufen. Erfinde keine Zwischenwerte und keine eigene Skala –
die Lehrkraft hat für diese Aufgabe bereits entschieden.

Steht im Horizont ausnahmsweise keine Abstufung, benutze 100 / 75 / 50 / 25 / 0.

Grundregeln:
• Bewerte nur, was tatsächlich dasteht. Interpretiere nichts hinein.
• „Auch richtig" im Horizont ist verbindlich: Wer eine dort genannte Formulierung
  benutzt, bekommt die volle Stufe – auch umgangssprachlich.
• Fachlich richtige Zusätze, die nicht verlangt waren, geben keine Punkte, kosten
  aber auch keine.
• Eine Antwort in Stichworten statt in Sätzen ist inhaltlich nicht schlechter.
  Der Satzbau wird in Teil 2 bewertet, nicht hier.

═══════════════════════════════════════════════════════
TEIL 2 – SPRACHE
═══════════════════════════════════════════════════════

Du zählst die Fehler. Den Abzug rechnet die Erweiterung daraus selbst aus –
schreibe nirgends einen Abzug oder eine Punktzahl hin.

Zähle als Fehler, was eine strenge Deutschlehrkraft anstreichen würde:

SCHWER (zählt doppelt):
  • Satz ohne Prädikat oder abgebrochener Satz
  • Satzbau so falsch, dass man den Satz zweimal lesen muss

NORMAL (zählt einfach):
  • falscher Fall oder falscher Numerus („die Atome verbindet sich")
  • falsche Zeitform
  • Nomen kleingeschrieben oder Verb großgeschrieben
  • Fachbegriff falsch geschrieben
  • sonstiger Rechtschreibfehler
  • fehlender Punkt am Satzende oder fehlendes Komma vor dem Nebensatz
  • Umgangssprache statt Fachsprache („das Zeug", „macht kaputt")

Zählregeln:
• Derselbe Fehler im selben Wort zählt nur einmal, auch wenn das Wort mehrfach
  vorkommt.
• Zähle nur, was du benennen kannst. Ein Bauchgefühl ist kein Fehler.
• Eine leere Antwort hat keine Sprachfehler – dort ist der Inhalt 0 %.

Zur Einordnung, was mit deiner Zählung geschieht: Der Höchstabzug ist gerade auf
${k.maxSprachabzug??O.maxSprachabzug} % der Aufgabenpunkte eingestellt. 1 Fehler kostet ein Drittel davon,
2 Fehler die Hälfte, 3 zwei Drittel, 4 fünf Sechstel, ab 5 den vollen Abzug.

═══════════════════════════════════════════════════════
TEIL 3 – RÜCKMELDUNG
═══════════════════════════════════════════════════════

Das Feedback ist das eigentliche Produkt. Es lesen Schülerinnen und Schüler der
Mittelstufe, viele davon schreibschwach. Sie sollen daraus lernen — also schreibst du
wie eine Deutschlehrkraft, die einem Vierzehnjährigen etwas erklärt.

SPRACHE — so schreibst du:
• Kurze Hauptsätze. Ein Gedanke pro Satz. KEINE verschachtelten Sätze.
• Sag die Regel, nicht nur die Korrektur.
  Schwach: „Der Name wird großgeschrieben."
  Gut:     „Vor „Löschsand" kannst du „der" setzen. Solche Wörter sind Nomen. Nomen
            schreibt man groß: Löschsand."
• Stell falsch und richtig direkt gegenüber: löchsand → Löschsand.
  Lange Satzzitate sind für schwache Leser schwerer als ein Wortpaar.
• Kein Fachjargon ohne Erklärung. „Nomen", „Satzende", „Komma" sind bekannt;
  „Prädikat", „Kasus", „Numerus" erklärst du in eigenen Worten.
• Höchstens zwei Korrekturen je Zeile. Der Rest bleibt ungesagt — lieber weniger,
  das dafür verstanden.
• Freundlich und sachlich. Keine Floskeln, keine Emojis, kein Ausrufezeichen-Gewitter.

GLIEDERUNG — du schreibst KEINEN Fließtext, sondern füllst Felder:
Aus ihnen baut die Erweiterung selbst das fertige Feedback mit Überschrift, Umbrüchen
und Unterstreichungen. Schreib deshalb nirgends HTML, keine Sternchen, keine Zeilen-
umbrüche in die Felder.

  lob             – nur bei 95 % und mehr der Punkte: ein Satz Anerkennung,
                    konkret auf die Aufgabe bezogen („Du hast die Aufgabe zum
                    Löschsand richtig gut beantwortet.")
  inhalt          – was inhaltlich fehlte oder falsch war, und wie es richtig heißt.
                    Bei voller Punktzahl: was genau gut war.
  rechtschreibung – nur Rechtschreibung: Groß- und Kleinschreibung, falsch
                    geschriebene Wörter. Mit der Regel dahinter.
  grammatik       – nur Satzbau und Zeichensetzung: fehlende Punkte und Kommas,
                    Sätze ohne Trennung, falsche Fälle und Zeitformen.
  tipp            – freiwillig: EIN Merksatz für das nächste Mal. Nur, wenn er wirklich
                    hilft. Nicht bei jeder Antwort.

Felder, zu denen es nichts zu sagen gibt, lässt du weg. Eine Antwort ohne
Rechtschreibfehler bekommt keine Zeile „Rechtschreibung".

DIE DREI FÄLLE:

1. Volle Punktzahl, keine Sprachfehler → NUR das Feld „lob", sonst nichts.
   Beispiel: lob = „Das hast du super beantwortet — Name und Funktion sind richtig."

2. 95 % oder mehr, aber eine Kleinigkeit → zuerst „lob", dann die eine Zeile, die es
   betrifft. Erst loben, dann verbessern.
   Beispiel: lob = „Du hast die Aufgabe zum Löschsand richtig gut beantwortet."
             grammatik = „Am Satzende fehlt der Punkt."

3. Unter 95 % → kein Lob-Feld. Zuerst „inhalt", dann Rechtschreibung und Grammatik,
   wo nötig.

Die Musterlösung schreibst du NICHT. Liegt die Antwort unter 100 %, hängt die
Erweiterung von sich aus die Zeile „So hättest du es schreiben können: …" an und setzt
dort die Kernaussage aus dem Erwartungshorizont ein — wörtlich das, was die Lehrkraft
hinterlegt hat. Im Feld „inhalt" steht deshalb nur, WAS fehlte oder falsch war, nicht
die fertige Lösung.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert. Je Frage eine Kopfzeile mit der
Aufgabe und der Kernaussage aus dem Horizont, darunter die Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|
| 1 | „Hefe wandelt Zucker in Alkohol um" | 50 | 1 normal | Prozess nicht benannt |

• „Nr" ist die Zahl aus dem Feld „nr" – nicht deine eigene Zählung.
• „Sprachfehler": Anzahl und Art, zum Beispiel „2 normal, 1 schwer".
• „Begründung": ein Halbsatz, der sich auf die Abstufung im Horizont bezieht.
• Keine Punkte- und keine Abzugsspalte. Das rechnet die Erweiterung.

Halte danach an und schreibe:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 75.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir das JSON aus."

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok":

\`\`\`json
{
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "Du hast geschrieben, dass Hefe Zucker umwandelt. Das stimmt. Es fehlt, was dabei entsteht: Alkohol und Kohlenstoffdioxid.",
        "rechtschreibung": "Vor „Zucker" kannst du „der" setzen. Solche Wörter sind Nomen, und Nomen schreibt man groß: Zucker.",
        "grammatik": "Am Satzende fehlt der Punkt."
      } },
    { "frage": "Löschsand (AFB I)", "qubaid": "2433020", "slot": "6",
      "inhalt": 100, "fehler": [],
      "rueckmeldung": { "lob": "Das hast du super beantwortet — Name und Funktion sind richtig." } }
  ]
}
\`\`\`

• Ein Eintrag je Versuch. „qubaid" und „slot" unverändert aus den Daten.
• „inhalt" ist der Prozentwert aus der Abstufung des Horizonts.
• „fehler" ist die Liste der gezählten Sprachfehler, leer bei fehlerfreiem Text.
• „rueckmeldung" enthält die Felder aus Teil 3. Nur die füllen, zu denen es etwas zu
  sagen gibt; leere Felder ganz weglassen. Jedes Feld ist ein oder zwei ganze Sätze,
  ohne Zeilenumbruch und ohne Formatierungszeichen — Überschrift, Absätze und
  Unterstreichungen setzt die Erweiterung selbst.
• JEDER Eintrag bekommt eine Rückmeldung, auch die fehlerfreien: dort steht das
  Lob-Feld allein.
• Keine Punktzahlen, kein Abzug, keine Feldnamen.
• WICHTIG – Anführungszeichen im JSON: Willst du in einem Rückmeldungstext ein Wort
  hervorheben oder ein Zitat setzen, benutze dafür EINFACHE Anführungszeichen ('so')
  oder schreibe es ohne Anführungszeichen. Gerade doppelte Anführungszeichen ("so")
  NIEMALS in einem JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die
  JSON-Begrenzung und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Schreibe darunter: „Kopiere diesen Block in die Erweiterung, Reiter „2 · Eintragen" —
die Prüfung startet beim Einfügen von selbst."

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Hat die Lehrkraft in Schritt 1 Prozentwerte geändert, ist das mehr als eine
Einzelfallentscheidung: Der Horizont bildet ihren Maßstab an dieser Stelle nicht ab
und würde beim nächsten Durchgang denselben Fehler wieder erzeugen.

Deshalb NACH dem JSON – aber nur, wenn tatsächlich korrigiert wurde:

1. Nenne je betroffener Frage in einem Satz, welche Regel sich aus der Korrektur
   ergibt. Nicht „Nr. 7 wurde auf 100 gesetzt", sondern die dahinterliegende
   Entscheidung: „Beim Löschsand reicht ‚löscht Brände' für 100 % – der Metallbrand
   muss nicht genannt werden."
2. Sag dazu, was sich im Horizont ändern müsste: meist wandert ein Teilaspekt von
   „Muss enthalten" nach „Auch richtig", und die betroffene Prozentstufe entfällt
   oder wird neu beschrieben.
3. Biete an, die Horizonte dieser Fragen neu zu schreiben, mit dem Weg dorthin:
   „Reiter 3 · Horizont, Häkchen ‚Auch Fragen einbeziehen, die schon einen Horizont
   haben' setzen, Prompt kopieren – ich baue die Korrekturen dann direkt ein."
4. Merke dir die Korrekturen für diesen Fall, damit sie in den neuen Horizont
   einfließen, wenn der Horizont-Prompt gleich nachkommt.

Wurde nichts geändert, lässt du diesen Schritt ersatzlos weg – kein „hier gab es
nichts zu korrigieren".

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

- „fragen"    – je Frage: Aufgabentext, Maximalpunkte und der Erwartungshorizont
                aus dem Moodle-Feld „Bewerterinformation".
- „antworten" – je Versuch die Schülerantwort mit „nr", „qubaid" und „slot".

${Oe}`}function Ae(){return c()}function je(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – BEWERTUNG (KOMPAKTER PROMPT)
═══════════════════════════════════════════════════════

Falls du Zugriff auf die Skills „2-didaktik-bewertung“ und „3-moodle-erweiterungen“
von A. Spielhoff hast: Wende deren Bewertungslogik an — Inhalt strikt getrennt von
Sprache, die Abstufung im Horizont ist verbindlich (keine eigene Skala erfinden),
Sprachfehler zählen (schwer = doppelt) statt selbst Punkte abzuziehen, die
Feedback-Gliederung in Felder (lob/inhalt/rechtschreibung/grammatik/tipp) mit
kurzen, schülergerechten Sätzen für die Mittelstufe, und die drei Rückmeldungsfälle
(volle Punktzahl → nur Lob; ≥95 % → Lob zuerst; darunter → kein Lob).

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt“ ausschalten) statt zu raten — ohne die genauen Regeln (besonders
die Trennung Inhalt/Sprache und die Feld-Gliederung) sind falsche Bewertungen und
unpassendes Feedback wahrscheinlich.

Höchstabzug für Sprache ist gerade auf ${k.maxSprachabzug??O.maxSprachabzug} % der Aufgabenpunkte eingestellt:
1 Fehler kostet ein Drittel davon, 2 die Hälfte, 3 zwei Drittel, 4 fünf Sechstel,
ab 5 den vollen Abzug. Punkte NICHT selbst ausrechnen, nur Inhalt-Prozent und
Fehlerliste angeben — das rechnet die Erweiterung.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert, mit Kopfzeile (Aufgabe +
Kernaussage aus dem Horizont), dann eine Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Datensatz. Keine Punkte- und keine Abzugsspalte. Halte
danach an und frage: „Passt das so? Nenne mir die Nummern, die ich ändern soll, zum
Beispiel: 3 auf 75. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok“ ausgeben:

\`\`\`json
{
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "…",
        "rechtschreibung": "…",
        "grammatik": "…"
      } }
  ]
}
\`\`\`

Ein Eintrag je Versuch, „qubaid“/„slot“ unverändert übernehmen. „inhalt“ ist der
Prozentwert aus der Horizont-Abstufung. „fehler“ leer bei fehlerfreiem Text.
„rueckmeldung“ nur die Felder füllen, zu denen es etwas zu sagen gibt (leere Felder
weglassen), jedes ein bis zwei ganze Sätze ohne Formatierung. Musterlösung NICHT
selbst schreiben — das hängt die Erweiterung an. WICHTIG: Hebst du in einem
Rückmeldungstext ein Wort hervor, benutze dafür einfache Anführungszeichen ('so'),
nie gerade doppelte ("so") — die brechen das JSON, weil sie die JSON-Begrenzung
sind. Satz danach: „Kopiere diesen Block
in die Erweiterung, Reiter „2 · Eintragen“ — die Prüfung startet beim Einfügen von selbst.“

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Wurden in Schritt 1 Prozentwerte geändert, nenne je betroffener Frage in einem Satz
die dahinterliegende Regel (nicht „Nr. 7 auf 100", sondern z. B. „Beim Löschsand
reicht ‚löscht Brände' für 100 % – der Metallbrand muss nicht genannt werden"), sag
was sich im Horizont ändern müsste, und biete an, die Horizonte über Reiter 3 neu zu
schreiben. Ohne Korrektur diesen Schritt ersatzlos weglassen.

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: Aufgabentext, Maximalpunkte, Erwartungshorizont aus
„Bewerterinformation“. „antworten“ – je Versuch die Schülerantwort mit „nr“,
„qubaid“, „slot“.

${Oe}`}function Me(e){let t=(k.promptOverride||``).trim()||(k.kompaktPrompt?je():ke()),n=(Object.values(e&&e.fragen||{}).some(e=>e&&e.feedback===`Kurz`)?`FEEDBACKLÄNGE JE AUFGABE: Steht bei einer Aufgabe "feedback": "Kurz", gib für diese Aufgabe höchstens zwei Felder aus (inhalt und höchstens ein weiteres), je EIN kurzer Satz. Bei "Mittel" gilt das Format wie beschrieben.

`:``)+"```json\n"+JSON.stringify(e,null,1)+"\n```";return t.includes(Oe)?t.replace(Oe,n):t+`

`+n}function Ne(e){let t=(k.horizontPromptOverride||``).trim()||Ae(),n="```json\n"+JSON.stringify(e.map(e=>{let t={qid:e.qid,frage:e.name,aufgabe:e.aufgabe,max:e.max};return e.horizont&&(t.horizont_bisher=ie(e.horizont)),t}),null,1)+"\n```",r=String((typeof K==`function`?K():``)||``).trim(),i=r?`═══════════════════════════════════════════════════════
ÄNDERUNGSWÜNSCHE DER LEHRKRAFT
═══════════════════════════════════════════════════════

Diese Vorgaben haben Vorrang vor allem, was in „horizont_bisher" steht.
Wo sie einem bisherigen Horizont widersprechen, gilt der Wunsch.

`+r+`

`:``,a=`[MOODLE_AI_COACH_AUFGABEN]`,o=i+n;return t.includes(a)?t.replace(a,o):t+`

`+o}let I=v(`button`,`co-fab`);I.title=`Moodle AI Freitext Grader`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`AI Coach`,e.className=`co-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),I.textContent=`Co`}),I.appendChild(e)}catch{I.textContent=`Co`}document.body.appendChild(I);let L=v(`div`,`co-panel co-hidden`);L.innerHTML=`
    <div class="co-head">
      <div class="co-titelblock">
        <span class="co-title">Freitext Grader · Kurztest <span class="co-version"></span></span>
        <span class="co-untertitel">(Zufalls-)Freitexte als Kurztest bewerten</span>
      </div>
      <button class="co-close" title="Schließen">✕</button>
    </div>
    <div class="co-tabs">
      <button class="co-tab co-aktiv" data-tab="lesen">1 · Bewerten</button>
      <button class="co-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="co-tab" data-tab="horizont">3 · Horizont <span class="co-badge co-hidden"></span></button>
      <button class="co-tab" data-tab="opt">⚙</button>
    </div>

    <div class="co-body" data-panel="lesen">
      <p class="co-meta"></p>
      <label class="co-check"><input type="checkbox" class="co-bereits">
        Auch schon bewertete Versuche noch einmal vorlegen</label>
      <button class="co-go">Freitextaufgaben durchsuchen</button>
      <div class="co-progress co-hidden"><div class="co-bar"></div><span class="co-ptext"></span></div>
      <div class="co-result co-hidden">
        <p class="co-summary"></p>
        <p class="co-warn co-hidden"></p>
        <div class="co-prozentbox co-hidden"></div>
        <div class="co-zust co-hidden"></div>
        <button class="co-copy">📋 Prompt + Daten kopieren</button>
        <button class="co-copy2 co-zweit">📋 nur JSON</button>
        <p class="co-groesse"></p>
        <div class="co-list"></div>
      </div>
      <p class="co-error co-hidden"></p>
      <details class="co-details">
        <summary>Bewertungs-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit bewertet die KI die Schülerantworten.</strong>
        Hier steht der vollständige Prompt, den „📋 Prompt + Daten kopieren" verschickt —
        du kannst ihn lesen und ändern. „Standard einfügen" holt die mitgelieferte Fassung
        zurück. Der Platzhalter <code>[MOODLE_AI_COACH_DATEN]</code> wird beim Kopieren
        durch die Fragen und Antworten aus Moodle ersetzt.</p>
        <textarea class="co-prompt" rows="8"></textarea>
        <button class="co-promptstd co-zweit">Standard einfügen</button>
        <button class="co-promptsave co-zweit">Prompt speichern</button>
      </details>
    </div>

    <div class="co-body co-hidden" data-panel="eintrag">
      <p class="co-hinweis">Hier das Bewertungs-JSON der KI einfügen. Die Punkte rechnet
      die Erweiterung aus Inhalt und Fehlerzahl selbst.</p>
      <textarea class="co-json" rows="6" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <label class="co-check"><input type="checkbox" class="co-ki" checked>
        KI-Hinweis ans Feedback anhängen</label>
      <p class="co-kivorschau"></p>
      <button class="co-pruef co-hidden">🔍 Prüfen</button>
      <p class="co-pinfo co-hidden"></p>
      <div class="co-schreibknoepfe co-hidden">
        <button class="co-alle">Alle eintragen</button>
      </div>
      <div class="co-progress2 co-hidden"><div class="co-bar2"></div><span class="co-ptext2"></span></div>
      <p class="co-abschluss co-hidden"></p>
      <div class="co-log co-hidden"></div>
      <div class="co-vorschau"></div>
    </div>

    <div class="co-body co-hidden" data-panel="horizont">
      <p class="co-hinweis">Der Erwartungshorizont gehört in die Frage, nicht in die
      Erweiterung — einmal erstellt, gilt er dauerhaft und wandert beim Export mit.
      Hier wird er angelegt, wo er fehlt — oder für vorhandene neu geschrieben.</p>
      <div class="co-ohneliste"></div>
      <label class="co-check"><input type="checkbox" class="co-halle">
        Auch Fragen einbeziehen, die schon einen Horizont haben — <strong>der wird dabei
        überschrieben</strong></label>
      <label class="co-feldkopf">Was soll anders werden? (geht mit in den Prompt)</label>
      <textarea class="co-hwunsch" rows="3"
        placeholder="z. B.: Beim Löschsand müssen Metallbrände NICHT genannt werden — Name plus „löscht Brände“ reicht für 100 %."></textarea>
      <p class="co-hinweis">Ohne diese Zeilen sieht das Sprachmodell nur den bisherigen
      Horizont — und der sagt ja gerade das, was du ändern willst. Es schreibt ihn dann
      fort. Was hier steht, hat im Prompt Vorrang vor dem bisherigen Horizont.</p>
      <p class="co-hinweis">Beim Neuschreiben bekommt die KI den bisherigen Horizont mit,
      damit sie weiß, wovon sie abweicht. Ersetzt wird er erst, wenn du die Antwort in
      Schritt 2 einfügst und einträgst.</p>
      <p class="co-schritt">Schritt 1 — Prompt holen</p>
      <button class="co-hcopy">📋 Prompt für Erwartungshorizont kopieren</button>
      <details class="co-details">
        <summary>Horizont-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit schreibt die KI den Erwartungshorizont</strong>
        für Fragen, die noch keinen haben — also das, was später in der Frage steht und
        wonach der Bewertungs-Prompt dann bewertet. Hier steht der vollständige Prompt,
        den der Knopf oben kopiert. Der Platzhalter
        <code>[MOODLE_AI_COACH_AUFGABEN]</code> wird beim Kopieren durch die Aufgaben
        ohne Horizont ersetzt.</p>
        <textarea class="co-hprompt" rows="8"></textarea>
        <button class="co-hpromptstd co-zweit">Standard einfügen</button>
        <button class="co-hpromptsave co-zweit">Prompt speichern</button>
      </details>
      <p class="co-schritt">Schritt 2 — Antwort der KI einfügen</p>
      <textarea class="co-hjson" rows="5" placeholder='{ "horizonte": [ … ] }'></textarea>
      <button class="co-hpruef co-hidden">🔍 Prüfen</button>
      <p class="co-hinfo co-hidden"></p>
      <div class="co-hliste"></div>
      <div class="co-progress3 co-hidden"><div class="co-bar3"></div><span class="co-ptext3"></span></div>
      <p class="co-habschluss co-hidden"></p>
      <div class="co-hlog co-hidden"></div>
      <div class="co-hknoepfe co-hidden">
        <button class="co-hschreib">In die Aufgaben eintragen</button>
      </div>
    </div>

    <div class="co-body co-hidden" data-panel="opt">
      <label class="co-label">Maximaler Abzug für Sprache und Ausdruck (% der Aufgabenpunkte)
        <input type="text" class="co-abzug" value="30">
      </label>
      <p class="co-abzuginfo"></p>
      <label class="co-check"><input type="checkbox" class="co-nurmarker">
        Nur Fragen bewerten, die „[moodle-ai-coach]" im Erwartungshorizont tragen</label>
      <p class="co-hinweis">Fragen, deren Horizont mit <code>[moodle-ai-grader]</code>
      beginnt, überspringt der Coach <strong>immer</strong> — dafür ist dieses Häkchen
      nicht nötig. Es entscheidet nur über Fragen <em>ohne</em> Marker: aus (Standard)
      werden sie bewertet und im Ergebnis gemeldet, an bleiben sie liegen. Leg es um,
      wenn dein Bestand vollständig markiert ist.</p>
      <label class="co-check"><input type="checkbox" class="co-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <p class="co-hinweis">Verweist für die Bewertungslogik auf die Skills
      „2-didaktik-bewertung“ und „3-moodle-erweiterungen“ statt sie komplett
      auszuschreiben – spart pro Aufruf mehrere Tausend Zeichen. <strong>Nur
      einschalten, wenn du sicher bist, dass die verwendete KI diese Skills wirklich
      kennt</strong> (z. B. dein eigener Claude-Cowork-Zugang). Andere Lehrkräfte
      oder andere KI-Systeme lassen dieses Häkchen aus – die bekommen automatisch den
      vollständigen Prompt. Wirkt nur auf den Bewertungs-Prompt in Reiter 1, nicht
      auf den Horizont-Prompt in Reiter 3.</p>
      <label class="co-label">KI-Hinweis unter dem Feedback
        <textarea class="co-kitext" rows="3"></textarea>
      </label>
      <p class="co-hinweis">Die beiden Prompts stehen dort, wo sie gebraucht werden:
      der <strong>Bewertungs-Prompt</strong> in Reiter 1 (damit bewertet die KI die
      Antworten), der <strong>Horizont-Prompt</strong> in Reiter 3 (damit schreibt sie
      den Erwartungshorizont für Fragen, die noch keinen haben) — jeweils unter
      „Prompt anpassen". In beiden Feldern steht der volle Text zum Lesen und Ändern.</p>
      <button class="co-optsave">Speichern</button>
      <button class="co-optreset co-zweit">Alles zurücksetzen</button>
      <p class="co-optinfo co-hidden"></p>
    </div>`,document.body.appendChild(L),L.querySelector(`.co-version`).textContent=e;let R=e=>L.querySelector(e),z=null,B=null,V=null,Pe=`coachErnte_`+i;function Fe(){try{t.storage.local.set({[Pe]:z})}catch{}}try{t.storage.local.get([Pe],e=>{let t=e&&e[Pe];if(t&&!z){z=t;let e=R(`.co-meta`);e&&(e.textContent+=` · ${(t.antworten||[]).length} Antworten aus einem früheren Durchlauf geladen`)}})}catch{}I.addEventListener(`click`,()=>L.classList.toggle(`co-hidden`)),R(`.co-close`).addEventListener(`click`,()=>L.classList.add(`co-hidden`));function H(e){L.querySelectorAll(`.co-tab`).forEach(t=>t.classList.toggle(`co-aktiv`,t.dataset.tab===e)),L.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`co-hidden`,t.dataset.panel!==e))}let U=null;function Ie(){U&&=(clearTimeout(U),clearInterval(U),null)}L.querySelectorAll(`.co-tab`).forEach(e=>{e.addEventListener(`click`,()=>{Ie(),H(e.dataset.tab)})});function Le(){let e=u(R(`.co-abzug`).value);return e===null||e<0?O.maxSprachabzug:Math.min(100,e)}function Re(){let e=Le();R(`.co-abzuginfo`).textContent=e===0?`Sprache zählt nicht für die Punkte. Das Sprachfeedback wird trotzdem geschrieben.`:`Höchstabzug ${m(e)} %. Ein Fehler kostet ${m(Math.round(e/3*10)/10)} %, zwei ${m(Math.round(e/2*10)/10)} %, drei ${m(Math.round(e*2/3*10)/10)} %, vier ${m(Math.round(e*5/6*10)/10)} %, ab fünf ${m(e)} %. Schwere Fehler zählen doppelt.`}function ze(){let e=R(`.co-kivorschau`),t=(k.kiHinweisText||D).trim();if(!R(`.co-ki`).checked||!t){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}R(`.co-ki`).addEventListener(`change`,ze),R(`.co-abzug`).addEventListener(`input`,Re),R(`.co-abzug`).addEventListener(`change`,async()=>{Re(),await M({maxSprachabzug:Le()})}),R(`.co-nurmarker`).addEventListener(`change`,async e=>{await M({nurMitMarker:e.target.checked})}),ce().then(()=>{R(`.co-abzug`).value=m(k.maxSprachabzug??O.maxSprachabzug),R(`.co-kitext`).value=k.kiHinweisText||D,R(`.co-prompt`).value=k.promptOverride||ke(),R(`.co-hprompt`).value=k.horizontPromptOverride||Ae(),R(`.co-nurmarker`).checked=!!k.nurMitMarker,R(`.co-kompakt`).checked=!!k.kompaktPrompt,Re(),ze()});function Be(e){let t=R(`.co-optinfo`);t.textContent=e,t.classList.remove(`co-hidden`),setTimeout(()=>t.classList.add(`co-hidden`),3e3)}R(`.co-optsave`).addEventListener(`click`,async()=>{await M({maxSprachabzug:Le(),nurMitMarker:R(`.co-nurmarker`).checked,kompaktPrompt:R(`.co-kompakt`).checked,kiHinweisText:R(`.co-kitext`).value.trim()||D}),R(`.co-kitext`).value=k.kiHinweisText,Re(),ze(),Be(`Gespeichert ✓`),Ve(R(`.co-optsave`),`✓ Gespeichert`,`Speichern`),setTimeout(()=>H(`lesen`),900)});function Ve(e,t,n){e.textContent=t,setTimeout(()=>e.textContent=n,2e3)}R(`.co-promptstd`).addEventListener(`click`,()=>{R(`.co-prompt`).value=ke(),Ve(R(`.co-promptstd`),`✓ eingefügt`,`Standard einfügen`)}),R(`.co-promptsave`).addEventListener(`click`,async()=>{let e=R(`.co-prompt`).value.trim(),t=e===ke().trim()?``:e;await M({promptOverride:t}),Ve(R(`.co-promptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),R(`.co-hpromptstd`).addEventListener(`click`,()=>{R(`.co-hprompt`).value=Ae(),Ve(R(`.co-hpromptstd`),`✓ eingefügt`,`Standard einfügen`)}),R(`.co-hpromptsave`).addEventListener(`click`,async()=>{let e=R(`.co-hprompt`).value.trim(),t=e===Ae().trim()?``:e;await M({horizontPromptOverride:t}),Ve(R(`.co-hpromptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),R(`.co-optreset`).addEventListener(`click`,async()=>{await M({...O}),R(`.co-abzug`).value=m(O.maxSprachabzug),R(`.co-nurmarker`).checked=O.nurMitMarker,R(`.co-kompakt`).checked=O.kompaktPrompt,R(`.co-kitext`).value=D,R(`.co-prompt`).value=ke(),R(`.co-hprompt`).value=Ae(),Re(),ze(),Be(`Auf Standard zurückgesetzt — auch die Prompts in Reiter 1 und 3.`)}),R(`.co-meta`).textContent=(document.title||``).replace(/\s*\|.*$/,``).trim()||`Manuelle Bewertung`,R(`.co-go`).addEventListener(`click`,async()=>{let e=R(`.co-go`);e.disabled=!0,e.textContent=`läuft …`,R(`.co-error`).classList.add(`co-hidden`),R(`.co-result`).classList.add(`co-hidden`),R(`.co-progress`).classList.remove(`co-hidden`);try{z=await ve((e,t,n)=>{R(`.co-bar`).style.width=Math.round(e/t*100)+`%`,R(`.co-ptext`).textContent=`${e} / ${t} Fragen · ${n} Antworten`},R(`.co-bereits`).checked);let e=z.meta,t=Object.values(z.fragen).filter(e=>e.horizont),n=Object.values(z.fragen).filter(e=>!e.horizont),r=Object.values(z.fremde||{}),a=Object.values(z.fragen).filter(e=>e.horizont_aus_fassung).length;R(`.co-summary`).textContent=`${e.antworten} Antworten auf ${Object.keys(z.fragen).length} Freitextfragen · ${t.length} mit Horizont, ${n.length} ohne · ${e.uebersprungen} übersprungen`+(r.length?` · ${r.length} nicht für den Coach`:``)+(a?` · ${a} Horizont(e) aus der neuesten Fragenfassung geholt`:``);let o=R(`.co-warn`);n.length?(o.classList.remove(`co-hidden`),o.textContent=`⚠ ${n.length} Frage(n) haben keinen Erwartungshorizont. Sie sind im Prompt nicht enthalten — leg ihn in Reiter 3 an.`):o.classList.add(`co-hidden`);function s(){let e=R(`.co-prozentbox`);e.innerHTML=``;let t=k.maxSprachabzug??O.maxSprachabzug,n=Object.values(z.fragen).filter(e=>e.horizont&&e.horizontProzent!=null&&e.horizontProzent!==t);if(!n.length){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.appendChild(v(`div`,`co-zustkopf`,`⚠ ${n.length} Frage(n) tragen im Horizont eine andere Rechtschreibungs-Prozentzahl als aktuell eingestellt (${m(t)} %):`)),n.forEach(t=>e.appendChild(v(`div`,`co-logzeile`,`${t.name} — Horizont: ${m(t.horizontProzent)} %`))),e.appendChild(v(`div`,`co-hinweis`,A?`Es gilt gerade überall die eingestellte Prozentzahl (${m(t)} %).`:`Es gilt gerade je Frage der Wert aus dem Horizont — so, wie beim Erstellen des Erwartungshorizonts bewusst festgelegt.`));let r=v(`button`,`co-marker co-zweit`,A?`Stattdessen die Horizont-Werte verwenden`:`Stattdessen überall ${m(t)} % verwenden`);r.addEventListener(`click`,()=>{A=!A,s()}),e.appendChild(r)}s();let c=R(`.co-zust`);c.innerHTML=``;let l=Object.values(z.fragen).filter(e=>e.horizont&&!e.zustaendig);if(r.length||l.length){c.classList.remove(`co-hidden`);let e=r.filter(e=>e.grund===`grader`),t=r.filter(e=>e.grund!==`grader`);if(e.length){c.appendChild(v(`div`,`co-zustkopf`,`↷ ${e.length} Klausur-Frage(n) — werden auf ihrer Einzelseite bewertet, hier übersprungen.`));let t=e.map(e=>({slot:e.slot,qid:e.qid,name:e.name}));d(i,t),e.forEach(e=>{let t=v(`a`,`co-logzeile`,`→ `+e.name);t.href=p(i,e),c.appendChild(t)});let n=Object.keys(z.fragen||{}).length,r=v(`button`,`co-jetzt`,n?`Nach den Kurztests: weiter zur Klausur-Frage 1 von ${t.length}`:`Weiter zur Klausur-Frage 1 von ${t.length}`);if(r.addEventListener(`click`,()=>{location.href=p(i,t[0])}),c.appendChild(r),!n){let e=3,n=v(`div`,`co-logzeile`,`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`);c.appendChild(n);let r=setInterval(()=>{if(e--,e>0){n.textContent=`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`;return}clearInterval(r),location.href=p(i,t[0])},1e3);n.addEventListener(`click`,()=>{clearInterval(r),n.textContent=`Automatischer Sprung abgebrochen.`})}}if(t.length&&(c.appendChild(v(`div`,`co-zustkopf`,`↷ ${t.length} Frage(n) ohne Marker — übersprungen, weil „nur mit Marker" eingeschaltet ist (⚙).`)),t.forEach(e=>c.appendChild(v(`div`,`co-logzeile`,e.name)))),l.length){c.appendChild(v(`div`,`co-zustkopf`,`⚠ ${l.length} Frage(n) haben einen Horizont, aber keinen Marker — sie wurden mitbewertet. Trag den Marker nach, dann ist die Zuständigkeit dauerhaft geklärt.`)),l.forEach(e=>c.appendChild(v(`div`,`co-logzeile`,e.name)));let e=`${w} in ${l.length} Frage(n) nachtragen`,t=v(`button`,`co-marker co-zweit`,e),n=!1,r=null;t.addEventListener(`click`,async()=>{if(!n){n=!0,t.textContent=`Wirklich? Ändert die Fragen — noch einmal klicken`,r=setTimeout(()=>{n&&(n=!1,t.textContent=e)},8e3);return}r&&=(clearTimeout(r),null),t.disabled=!0;let i=v(`div`,`co-marklog`);c.appendChild(i);let a=0,o=[];for(let e=0;e<l.length;e++){let n=l[e];t.textContent=`Trage nach … ${e+1} von ${l.length}: ${n.name}`;let r=v(`div`,`co-logzeile`,`… ${n.name}`);i.appendChild(r),i.scrollTop=i.scrollHeight;try{await Ee(n.qid),a++,r.textContent=`✓ ${n.name}`}catch(e){o.push(`${n.name}: ${e.message}`),r.textContent=`✗ ${n.name}: ${e.message}`,r.classList.add(`co-logfehler`)}}t.textContent=`${a} nachgetragen`+(o.length?`, ${o.length} fehlgeschlagen`:``),a&&c.appendChild(v(`div`,`co-logzeile`,`Bitte „Freitextaufgaben durchsuchen" noch einmal laufen lassen — dann liest die Erweiterung den neuen Stand.`))}),c.appendChild(t);let i=v(`button`,`co-hneu co-zweit`,`Horizont neu schreiben`);i.title=`Springt zu Reiter 3 und nimmt diese Fragen in den Prompt auf`,i.addEventListener(`click`,()=>{R(`.co-halle`).checked=!0,q(),H(`horizont`),R(`.co-hcopy`).scrollIntoView({block:`nearest`})}),c.appendChild(i)}}else c.classList.add(`co-hidden`);let u=L.querySelector(`.co-badge`);u.classList.toggle(`co-hidden`,!n.length),u.textContent=n.length||``;let h=R(`.co-list`);h.innerHTML=``,Object.values(z.fragen).forEach(e=>{let t=v(`div`,`co-qname`);t.appendChild(v(`span`,e.horizont?`co-ok`:`co-fehlt`,e.horizont?`✓`:`✗`)),t.appendChild(v(`span`,`co-qtext`,` ${e.name} · ${f(e.max)} P.`)),h.appendChild(t),z.antworten.filter(t=>t.qid===e.qid).forEach(e=>{let t=v(`a`,`co-row`);t.href=C(e),t.target=`_blank`,t.rel=`noopener`,t.appendChild(v(`span`,`co-nr`,`#`+e.nr)),t.appendChild(v(`span`,`co-ans`,e.antwort.slice(0,90))),h.appendChild(t)})});let g=R(`.co-ohneliste`);g.innerHTML=``,n.length?(g.appendChild(v(`div`,`co-fehlendkopf`,`Ohne Erwartungshorizont:`)),n.forEach(e=>g.appendChild(v(`div`,`co-logzeile`,`${e.name} — ${e.aufgabe.slice(0,90)}`)))):(g.appendChild(v(`div`,`co-fehlendkopf`,`Alle Fragen haben einen Horizont. Willst du einen neuen für die Aufgaben schreiben?`)),g.appendChild(v(`div`,`co-logzeile`,`Setz dazu unten das Häkchen — der vorhandene Horizont wird beim Eintragen überschrieben.`))),!n.length&&t.length&&(R(`.co-halle`).checked=!0),q(),Fe();let _=Me(z).length;R(`.co-groesse`).textContent=`Prompt ≈ ${Math.round(_/1e3)} 000 Zeichen`,R(`.co-result`).classList.remove(`co-hidden`),z.fehler.length&&(R(`.co-error`).textContent=z.fehler.length+` Frage(n) konnten nicht geladen werden.`,R(`.co-error`).classList.remove(`co-hidden`))}catch(e){R(`.co-error`).textContent=`Fehler: `+e.message,R(`.co-error`).classList.remove(`co-hidden`)}finally{R(`.co-progress`).classList.add(`co-hidden`),e.disabled=!1,e.textContent=`Freitextaufgaben durchsuchen`}});function He(e){let t={meta:{...e.meta},fragen:{},antworten:[]};Object.entries(e.fragen).forEach(([e,n])=>{n.horizont&&(t.fragen[e]=n)});let n=new Set(Object.values(t.fragen).map(e=>e.qid));return t.antworten=e.antworten.filter(e=>n.has(e.qid)),t.meta.antworten=t.antworten.length,t}function Ue(e,t,n,r){let i=R(e);Ie();let a=3;i.textContent=`✓ Kopiert — weiter in ${a} s`,U=setInterval(()=>{if(a--,a>0){i.textContent=`✓ Kopiert — weiter in ${a} s`;return}Ie(),i.textContent=t,n&&H(n);let e=r&&R(r);e&&(e.focus(),e.scrollIntoView({block:`nearest`}))},1e3)}R(`.co-copy`).addEventListener(`click`,async()=>{z&&(await ee(Me(He(z))),Ue(`.co-copy`,`📋 Prompt + Daten kopieren`,`eintrag`,`.co-json`))}),R(`.co-copy2`).addEventListener(`click`,async()=>{z&&(await ee(JSON.stringify(He(z),null,1)),Ue(`.co-copy2`,`📋 nur JSON`,`eintrag`,`.co-json`))});let We=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Reiter 1 „Freitextaufgaben durchsuchen" laufen lassen.`;function W(e){let t=e.value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen.`);return JSON.parse(t)}R(`.co-pruef`).addEventListener(`click`,()=>{let e=R(`.co-pinfo`);e.classList.remove(`co-hidden`),R(`.co-schreibknoepfe`).classList.add(`co-hidden`),R(`.co-abschluss`).classList.add(`co-hidden`),R(`.co-log`).classList.add(`co-hidden`),R(`.co-vorschau`).innerHTML=``,B=null;try{if(!z)throw Error(We);let t=W(R(`.co-json`)).bewertungen||[];if(!t.length)throw Error(`Keine „bewertungen" im JSON gefunden.`);let n=new Map(z.antworten.map(e=>[e.qubaid+`|`+e.slot,e])),r=[];t.forEach((e,t)=>{let i=t+1;if(e.qubaid==null||e.slot==null)throw Error(`Eintrag ${i}: „qubaid" oder „slot" fehlt.`);let a=n.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Eintrag ${i}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesene Antwort. Stammt das JSON zu diesem Durchlauf?`);let o=Number(e.inhalt);if(isNaN(o)||o<0||o>100)throw Error(`Eintrag ${i}: „inhalt" ist kein Prozentwert (${e.inhalt}).`);let s=z.fragen&&z.fragen[a.frage]||{},c=fe(a.max,o,e.fehler,j(s)),l=o<100?_(s.horizont):``,u=g(e.rueckmeldung,l,{inhalt:c.inhaltPunkte,inhaltMax:a.max,abzug:c.abzugPunkte,gewicht:c.gewicht})||String(e.text||``).trim();r.push({...a,inhalt:o,fehler:e.fehler||[],text:u,punkte:c.punkte,gewicht:c.gewicht,abzug:c.abzug,rechnung:`Inhalt ${m(o)} % = ${f(c.inhaltPunkte)} · ${c.gewicht} Fehlerpunkt(e) → −${m(Math.round(c.abzug*10)/10)} % · = ${f(c.punkte)} von ${f(a.max)}`})}),B=r;let i=r.filter(e=>!e.text).length,a=new Set(r.map(e=>e.slot+`|`+e.qid)).size;e.className=`co-pinfo co-ok`,e.textContent=`✓ ${r.length} Bewertungen auf ${a} Fragenseiten — bereit. Punkte und Abzug wurden aus Inhalt und Fehlerzahl berechnet.`+(i?` ⚠ ${i} Eintrag/Einträge ohne Rückmeldungstext.`:``);let o=v(`div`,`co-rechnung`);r.forEach(e=>{let t=v(`a`,`co-logzeile co-vorschauzeile`),n=C(e);n&&(t.href=n,t.target=`_blank`,t.rel=`noopener`),t.appendChild(v(`span`,`co-vfrage`,e.frage)),t.appendChild(v(`span`,`co-vans`,`„`+e.antwort.slice(0,60)+`"`)),t.appendChild(v(`span`,`co-vpkt`,e.rechnung)),o.appendChild(t)}),R(`.co-vorschau`).appendChild(o),R(`.co-schreibknoepfe`).classList.remove(`co-hidden`),R(`.co-schreibknoepfe`).scrollIntoView({block:`nearest`})}catch(t){e.className=`co-pinfo co-error`,e.textContent=`Fehler: `+t.message}});function Ge(e){return(t,n)=>{let r=v(n?`a`:`div`,`co-logzeile`,t);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`),(t.startsWith(`✗`)||t.startsWith(`⚠`))&&r.classList.add(`co-logfehler`),e.appendChild(r),e.scrollTop=e.scrollHeight}}async function Ke(e){if(!B)return;let t=R(`.co-log`),n=R(`.co-abschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),R(`.co-progress2`).classList.remove(`co-hidden`),R(`.co-alle`).disabled=!0,R(`.co-progress2`).scrollIntoView({block:`nearest`});let r=Ge(t),i=(e,t)=>{R(`.co-bar2`).style.width=Math.round(e/t*100)+`%`,R(`.co-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await xe(B,r,i):await P(B,R(`.co-ki`).checked,r,i);if(t.prepend(v(`div`,`co-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`+(a.versuche>1?` · ${a.versuche} Versuche gebraucht`:``))),n.classList.remove(`co-hidden`),a.fehler>0)n.className=`co-abschluss co-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen. Trag noch nichts ein — stammt das JSON zu diesem Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach.`,e||(R(`.co-alle`).textContent=`Erneut versuchen`);else if(n.className=`co-abschluss co-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,e||(R(`.co-alle`).textContent=`Alle eintragen`),!e){let e=3,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),L.classList.add(`co-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);L.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message)}finally{R(`.co-progress2`).classList.add(`co-hidden`),R(`.co-alle`).disabled=!1}}R(`.co-alle`).addEventListener(`click`,()=>Ke(!1)),R(`.co-json`).addEventListener(`paste`,()=>setTimeout(()=>R(`.co-pruef`).click(),0)),R(`.co-hjson`).addEventListener(`paste`,()=>setTimeout(()=>R(`.co-hpruef`).click(),0)),[[`.co-json`,`.co-pruef`],[`.co-hjson`,`.co-hpruef`]].forEach(([e,t])=>{let n=null;R(e).addEventListener(`input`,r=>{r.inputType!==`insertFromPaste`&&(clearTimeout(n),n=setTimeout(()=>{R(e).value.trim()&&R(t).click()},800))})});function qe(){if(!z)return[];let e=Object.values(z.fragen);return R(`.co-halle`).checked?e:e.filter(e=>!e.horizont)}let G=`coachWunsch_`+i;function K(){let e=L.querySelector(`.co-hwunsch`);return e?e.value.trim():``}try{t.storage.local.get([G],e=>{let t=e&&e[G];t&&!K()&&(L.querySelector(`.co-hwunsch`).value=t)})}catch{}L.querySelector(`.co-hwunsch`).addEventListener(`input`,()=>{try{t.storage.local.set({[G]:K()})}catch{}});function q(){let e=qe().length,t=R(`.co-halle`).checked;R(`.co-hcopy`).textContent=t?`📋 Prompt zum Neuschreiben kopieren (${e} Frage${e===1?``:`n`})`:`📋 Prompt für Erwartungshorizont kopieren`}R(`.co-halle`).addEventListener(`change`,q),R(`.co-hcopy`).addEventListener(`click`,async()=>{if(!z){R(`.co-hinfo`).className=`co-hinfo co-error`,R(`.co-hinfo`).classList.remove(`co-hidden`),R(`.co-hinfo`).textContent=We;return}let e=qe();if(!e.length){R(`.co-hinfo`).className=`co-hinfo`,R(`.co-hinfo`).classList.remove(`co-hidden`),R(`.co-hinfo`).textContent=`Es fehlt kein Horizont. Setz das Häkchen darüber, wenn du die vorhandenen neu schreiben lassen willst.`;return}await ee(Ne(e));let t=R(`.co-hcopy`).textContent;Ue(`.co-hcopy`,t,`horizont`,`.co-hjson`)}),R(`.co-hpruef`).addEventListener(`click`,()=>{let e=R(`.co-hinfo`);e.classList.remove(`co-hidden`),R(`.co-hknoepfe`).classList.add(`co-hidden`),R(`.co-habschluss`).classList.add(`co-hidden`),R(`.co-hlog`).classList.add(`co-hidden`),R(`.co-hliste`).innerHTML=``,V=null;try{let t=W(R(`.co-hjson`)).horizonte||[];if(!t.length)throw Error(`Keine „horizonte" im JSON gefunden.`);let n=z?new Map(Object.values(z.fragen).map(e=>[String(e.qid),e])):new Map;V=t.map((e,t)=>{if(!e.qid)throw Error(`Horizont ${t+1}: „qid" fehlt.`);let r=n.get(String(e.qid)),i=String(e.text||``).trim();if(!i)throw Error(`Horizont ${t+1}: „text" ist leer.`);return{qid:String(e.qid),frage:e.frage||(r?r.name:`Frage `+e.qid),text:i,bekannt:!!r,hatteHorizont:!!(r&&r.horizont)}});let r=V.filter(e=>e.hatteHorizont).length,i=V.filter(e=>!e.bekannt).length;e.className=`co-hinfo co-ok`,e.textContent=`✓ ${V.length} Horizont(e) gelesen.`+(i?` ⚠ ${i} gehören zu keiner ausgelesenen Frage.`:``)+(r?` ⚠ ${r} würden einen vorhandenen Horizont überschreiben.`:``);let a=R(`.co-hliste`);V.forEach((e,t)=>{let n=v(`div`,`co-hcard`);n.appendChild(v(`div`,`co-fehlendkopf`,`${e.frage}  ·  qid ${e.qid}`));let r=v(`textarea`,`co-htext`);r.value=e.text,r.rows=10,r.addEventListener(`input`,()=>{V[t].text=r.value}),n.appendChild(r),a.appendChild(n)}),R(`.co-hknoepfe`).classList.remove(`co-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`co-hinfo co-error`,e.textContent=`Fehler: `+t.message}});async function Je(e){if(!V||!V.length)return;let t=R(`.co-hlog`),n=R(`.co-habschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),R(`.co-progress3`).classList.remove(`co-hidden`),R(`.co-hschreib`).disabled=!0,R(`.co-progress3`).scrollIntoView({block:`nearest`});let r=Ge(t),i=0,a=0,o=0;try{for(let t of V){try{let n=await Te(t.qid,t.text,e);i++,r(e?`✓ ${t.frage} — Feld „${n.feld}" vorhanden`+(n.vorher&&n.vorher.replace(/<[^>]*>/g,``).trim()?` (enthält schon Text!)`:``):`✓ ${t.frage} — Horizont eingetragen`)}catch(e){a++,r(`✗ ${t.frage}: ${e.message}`)}o++,R(`.co-bar3`).style.width=Math.round(o/V.length*100)+`%`,R(`.co-ptext3`).textContent=`${o} / ${V.length} Fragen`}t.prepend(v(`div`,`co-logkopf`,e?`${i} Fragen erreichbar · ${a} nicht`:`${i} Horizonte eingetragen · ${a} fehlgeschlagen`)),n.classList.remove(`co-hidden`),n.className=`co-habschluss `+(a?`co-abfehler`:`co-abok`),n.textContent=a?`⚠ ${a} Frage(n) konnten nicht geschrieben werden. Sieh ins Protokoll.`:e?`✓ Alle ${i} Fragen sind erreichbar und haben das Feld. Du kannst eintragen.`:`✓ ${i} Horizonte stehen jetzt in den Fragen. Führe Reiter 1 noch einmal aus, dann sind sie im Bewertungs-Prompt dabei.`,n.scrollIntoView({block:`nearest`}),!a&&!e&&(n.textContent+=` Weiter zu Reiter 1 in 3 s …`,Ie(),U=setTimeout(()=>{U=null,H(`lesen`)},3e3))}finally{R(`.co-progress3`).classList.add(`co-hidden`),R(`.co-hschreib`).disabled=!1}}R(`.co-hschreib`).addEventListener(`click`,()=>{let e=V?V.length:0;if(!e)return;let t=R(`.co-habschluss`);t.classList.remove(`co-hidden`),t.className=`co-habschluss co-abfrage`,t.innerHTML=``,t.appendChild(v(`div`,null,`Der Erwartungshorizont wird in ${e} Frage(n) der Fragensammlung geschrieben. Das ändert die Fragen selbst, nicht nur eine Bewertung.`));let n=v(`button`,`co-jetzt`,`Ja, in ${e} Frage(n) eintragen`);t.appendChild(n),n.addEventListener(`click`,()=>{t.classList.add(`co-hidden`),Je(!1)})})}var v=e({matches:[`*://*/*mod/quiz/report.php*`,`*://*/*question/bank/editquestion/question.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){g(),location.pathname.includes(`/mod/quiz/report.php`)&&_()}}),y={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},b=class e extends Event{static EVENT_NAME=x(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function x(e){return`${t?.runtime?.id}:content:${e}`}var S=typeof globalThis.navigation?.addEventListener==`function`;function C(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),S?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new b(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new b(e,t)),t=e)},1e3))}}}var ee=class e{static SCRIPT_STARTED_MESSAGE_TYPE=x(`wxt:content-script-started`);id;abortController;locationWatcher=C(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?x(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),y.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},w={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=v;return await e(new ee(`content`,t))}catch(e){throw w.error(`The content script "content" crashed on startup!`,e),e}})()})();