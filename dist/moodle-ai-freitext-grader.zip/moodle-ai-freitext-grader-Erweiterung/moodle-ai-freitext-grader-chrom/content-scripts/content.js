(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`[moodle-ai-freitext: kurztest]`,r=`[moodle-ai-freitext: klausur]`,i=String.raw`moodle[-\s]?ai[-\s]?(?:(coach|grader)|freitext(?:[-\s]?grader)?\s*[:\-–]?\s*(kurztest|klausur))`,a=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*`,`i`),o=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*$`,`im`);function s(e){return e?e[1]?e[1].toLowerCase():/kurztest/i.test(e[2]||``)?`coach`:`grader`:null}function c(e){let t=s((String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``).match(a));return t===`coach`?`kurztest`:t===`grader`?`klausur`:null}var l={Kurz:`FEEDBACKLÄNGE: KURZ (ein bis zwei Sätze an die Schülerin / den Schüler)
Die Bewertungsstufen bleiben genauso scharf wie sonst – die Feedbacklänge ändert nichts
an der Punktvergabe. Kürzer werden nur die Teile, aus denen die Rückmeldung entsteht:
• „Reicht nicht" und „Häufiger Fehler" je höchstens ein Eintrag in einem Satz.
• Füge nach „Häufiger Fehler" diesen Abschnitt an:

Wichtigster Hinweis:
<der eine Satz, den jemand mit unvollständiger Antwort am dringendsten braucht>`,Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis fünf Sätze an die Schülerin / den Schüler)
„Reicht nicht" und „Häufiger Fehler" liefern den Stoff für die Rückmeldung. Schreibe zu
jedem Eintrag einen Halbsatz, warum es nicht reicht bzw. was stattdessen richtig ist.`},u={Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis vier Sätze je Teilaufgabe)
Die Abschnitte oben genügen. „Reicht nicht" und „Häufiger Fehler" je ein bis zwei Einträge.`,Ausführlich:`FEEDBACKLÄNGE: AUSFÜHRLICH (ein Absatz je Teilaufgabe mit Bezug auf die Antwort)
Ergänze je Aufgabe nach „Häufiger Fehler" diesen Abschnitt:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt – so formuliert, dass die Bewertung ihn als
Begründung aufgreifen kann.</p>`,Umfangreich:`FEEDBACKLÄNGE: UMFANGREICH (ausführlicher Absatz je Teilaufgabe, dazu ein eigener
Abschnitt „Operatorerfüllung" im Feedback)
Ergänze je Aufgabe nach „Häufiger Fehler" diese beiden Abschnitte:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt.</p>
<p><strong>Operatorerfüllung:</strong> was der Operator in DIESER Aufgabe konkret verlangt
(z. B. „Erläutere": Ursache nennen, Wirkung nennen, beides mit „weil/dadurch" verknüpfen)
und woran man eine Verfehlung erkennt (z. B. nur beschrieben, nicht verknüpft).</p>`};function d(e,t){let n=e===`kurztest`?l:u,r=e===`kurztest`?`Mittel`:`Ausführlich`;return n[t]||n[r]}function f(){return`FEEDBACKLÄNGE JE AUFGABE
Bei jeder Aufgabe steht „feedback". Es gilt der passende Block:

[Kurz]
${l.Kurz}

[Mittel]
${l.Mittel}`}var p=/\bM\s?\d{1,2}\b|\bMaterial|\bAbb(?:ildung|\.)|\bTabelle|\bDiagramm|\bGrafik|\bTextauszug|\bQuelle\b/i;function m(e,t){return t&&t.length>0||(e||[]).some(e=>p.test(String(e||``)))}function h(e,t){if(!m(e,t))return``;let n=t||[];return`MATERIAL
Die Aufgabe verweist auf Material (M1, Abbildung, Tabelle …).
• Liegt das Material hier im Chat nicht vollständig vor, FRAGE ZUERST danach und schreibe
  den Horizont erst, wenn es da ist. Rate keine Werte.
• Werte das Material JETZT aus. Beim späteren Bewerten liegt es NICHT mehr vor. Schreibe alle
  Werte und Aussagen, die eine Antwort braucht, mit Quelle direkt in die Erwartungen
  (z. B. „M2, Tabelle: Siedetemperatur 78 °C"), nicht nur „siehe M2".
• Wörtliche Übernahmen aus dem Material ohne eigene Erklärung sind ein „Reicht nicht"-Fall,
  wo die Aufgabe eine Erklärung verlangt.`+(n.length?`

In der Aufgabe stehen Bilder/Dateien, die hier nur als Name ankommen:
- `+n.join(`
- `)+`
Die Lehrkraft lädt sie zusätzlich in den Chat hoch.`:``)}function ee(e){return`• Nur die Stufen 100 / 75 / 50 / 25 / 0 Prozent. Lass Stufen weg, die die Aufgabe nicht
  hergibt (bei einer Aufzählung von drei Dingen etwa 100 / 75 / 50 / 0).
• JEDE STUFE HÄNGT AN ZÄHLBAREN BEDINGUNGEN („beide Teilaspekte", „Name ohne Funktion"),
  nie an Wörtern wie „überwiegend", „im Wesentlichen" oder „deutliche Lücken". Solche
  Wörter führen dazu, dass dieselbe Antwort verschieden eingestuft wird. Prüfe zum
  Schluss: Jede denkbare Antwort gehört zu genau EINER Stufe – keine Lücke, keine
  Überschneidung.
• „AUCH RICHTIG" ist der wichtigste Abschnitt. Gemeint sind nicht ausformulierte
  Musterantworten, sondern die rauen, verkürzten Fassungen, mit denen ${e?`Lernende der Jahrgangsstufe `+e:`Lernende dieser Jahrgangsstufe`}
  dasselbe sagen – auch umgangssprachlich, auch ohne Fachbegriff. Mindestens vier,
  dazu Wörter, die dasselbe meinen (etwa Ring, Bahn oder Ebene statt Schale).
• Der OPERATOR zählt: Schreibe in die 100-%-Bedingung, was er hier verlangt. Bei „Nenne"
  reicht die Nennung, bei „Beschreibe" der Sachverhalt, bei „Erkläre/Erläutere" muss ein
  Zusammenhang (weil, dadurch) dastehen, bei „Vergleiche" beide Seiten, bei
  „Beurteile/Bewerte" ein begründetes Urteil.
• STICHPUNKTE gelten als vollständige Antwort, solange sie den Inhalt tragen. Verlangt der
  Operator einen Zusammenhang, den Stichpunkte nicht zeigen, lege in den Stufen fest,
  wo sie landen.
• ZUSATZWISSEN: Fachlich richtige Zusätze, die nicht verlangt sind, heben keine Stufe.
  Lege keine Stufe an, die für Zusatzwissen mehr gibt.
• „REICHT NICHT" enthält nur Antworten, die sachlich RICHTIG, aber zu wenig sind.
  Sachlich Falsches gehört zu 0 % und unter „Häufiger Fehler" – sonst liest die
  Bewertung es als fast richtig.
• NICHT in den Horizont: Sprachregeln, Rechtschreibabzug, Feedback-Stil, Rolle,
  Punktzahlen, allgemeine Bewertungsregeln. Das steht im Bewertungsprompt der
  Erweiterung. Im Horizont steht nur, was für DIESE Aufgabe gilt.`}var g=`WOZU DER HORIZONT DIENT
Mit diesem Horizont bewertet später eine KI die Antworten einer ganzen Lerngruppe.
Gleiche Antworten sollen immer dieselbe Stufe bekommen – egal welches Modell bewertet
und wie oft. Das gelingt nur, wenn der Horizont keinen Ermessensspielraum lässt.`;function te(e={}){let t=!!e.einzeln,n=e.stufe===`gemischt`?f():d(`kurztest`,e.stufe);return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KURZTEST)
═══════════════════════════════════════════════════════

Für ${t?`die Aufgabe unten brauchst du einen Erwartungshorizont`:`die Aufgaben unten brauchst du je einen Erwartungshorizont`}
in genau dem Format unten. Er wird in Moodle im Feld „Informationen für Bewerter/innen"
der Aufgabe gespeichert und bei jeder Bewertung benutzt.

${g}

BISHERIGER HORIZONT
Steht ${t?`bei der Aufgabe`:`bei einer Aufgabe`} „horizont_bisher", ist das ein älterer Horizont. Er ist
Ausgangspunkt, keine Vorlage zum Abschreiben: Übernimm, was fachlich gut ist, und
schreibe ihn im Format unten neu. Sag der Lehrkraft ZUERST in zwei, drei Sätzen, dass
ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst.${t?``:` Stehen unten Änderungswünsche der Lehrkraft, haben sie
Vorrang – auch wenn der bisherige Horizont das Gegenteil sagt.`}
Steht kein „horizont_bisher" dabei, schreibst du neu.

KERNAUSSAGE = MUSTERANTWORT
Die Kernaussage sehen die Schülerinnen und Schüler: Bei unvollständigen Antworten setzt
die Erweiterung sie als „So hättest du es schreiben können" unter die Rückmeldung.
Schreibe sie als vollständige Musterantwort in einfacher Sprache – ein bis zwei kurze
Sätze, so wie eine gute Schülerin oder ein guter Schüler sie schreiben würde.

FORMAT${t?``:` je Aufgabe`}

Erwartungshorizont

Kernaussage:
<Musterantwort, ein bis zwei kurze Sätze>

Muss enthalten:
- <Teilaspekt 1>
- <Teilaspekt 2>

Auch richtig:
<gleichwertige Formulierungen, Synonyme, umgangssprachliche Varianten>

Inhalt:
100 % – <Bedingung>
 75 % – <Bedingung>
 50 % – <Bedingung>
 25 % – <Bedingung>
  0 % – <Bedingung>

Reicht nicht:
<sachlich richtige, aber zu knappe Antwort und warum sie nicht reicht>

Häufiger Fehler:
<typischer Denkfehler und was stattdessen richtig ist>

Teile:                          (nur wenn die Aufgabe Teile a, b … hat)
a) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)
b) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)

REGELN
${ee(e.jahrgang)}
• TEILE: Hat die Aufgabe Teile (a, b …), gehört der Abschnitt „Teile:" dazu. Die Punkte
  aller Teile ergeben zusammen genau „max". Die Stufen unter „Inhalt" gelten für die
  ganze Aufgabe und nennen, welche Teile erfüllt sein müssen.
• Die Schülerantworten sind ein bis drei Sätze lang. Halte den Horizont entsprechend
  knapp – er ist kein Lehrbuchtext.

${n}

AUSGABE
Gib zuerst ${t?`den Horizont`:`alle Horizonte`} als lesbaren Text aus, damit die Lehrkraft prüfen kann.
Frage dann: „Passt das so? Wenn ja, antworte mit ok." Ändere, bis die Lehrkraft
zustimmt. Erst nach „ok" gibst du genau EINEN Codeblock aus:

\`\`\`json
{
  "horizonte": [
    { "qid": "115576570", "frage": "Edelgasregel",
      "text": "Erwartungshorizont\\n\\nKernaussage:\\n…" }
  ]
}
\`\`\`

„qid" übernimmst du unverändert aus den Daten unten.

═══════════════════════════════════════════════════════
${t?`DIESE AUFGABE`:`AUFGABEN`}
═══════════════════════════════════════════════════════

[MOODLE_AI_COACH_AUFGABEN]`}function ne(e={}){let t=e.fach?e.fach+`lehrkraft`:`Fachlehrkraft`,n=[e.jahrgang?`Jahrgang `+e.jahrgang:``,e.niveau?`Niveau `+e.niveau:``].filter(Boolean).join(`, `);return`ROLLE
Du bist ${t} und bewertest Schülerantworten${n?` (`+n+`)`:``} streng nach einem
festen Erwartungshorizont.

ZENTRALE BEWERTUNGSREGEL
Bewerte alle folgenden Antworten strikt nach demselben Maßstab. Fachlich gleiche
Antworten bekommen dieselbe Stufe – egal, an welcher Stelle sie stehen und wie die
Antworten davor ausgefallen sind.

ORGANISATIONSREGEL
Die Antworten stammen von verschiedenen Schülerinnen und Schülern. Bewerte jede für sich,
ohne sie untereinander zu vergleichen, aber mit identischem Maßstab.

GRUNDREGELN
• Bewerte nur, was tatsächlich dasteht. Interpretiere keine fehlenden Aussagen hinein.
• Maßstab ist ausschließlich der Erwartungshorizont. Eigenes Fachwissen nutzt du nur, um
  zu erkennen, ob eine abweichende Formulierung dasselbe meint.
• Eine Stufe gibt es nur für klar erkennbare, fachlich richtige Aussagen. Liegt eine
  Antwort zwischen zwei Stufen, gilt die niedrigere – nenne den Grund in der Begründung.
• Andere fachlich korrekte Formulierungen mit demselben Inhalt bekommen dieselbe Stufe.
  „Auch richtig" im Horizont ist verbindlich, auch umgangssprachlich.
• Fachlich richtige Zusätze, die nicht verlangt waren, bringen nichts – sie kosten aber
  auch nichts.
• Fachlich richtige Stichpunkte werden bewertet wie ganze Sätze, außer der Horizont
  sagt für diese Aufgabe etwas anderes.
• Der Operator zählt: Die volle Stufe gibt es nur, wenn die Antwort die geforderte
  Tiefe hat. Anforderungsbereiche: AFB I = Reproduktion, AFB II = Reorganisation /
  Transfer, AFB III = Reflexion / Bewertung.
• Teilpunkte entstehen nur über die Stufen des Horizonts. Punkte rechnet die
  Erweiterung.`}function _(e,t){let n=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!n)throw Error(`Feld „`+e+`" nicht im Formular`);n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0}));let r=n.id||``,i=r&&document.getElementById(r+`_ifr`);if(i&&i.contentDocument&&i.contentDocument.body)return i.contentDocument.body.innerHTML=t,i.contentDocument.body.dispatchEvent(new Event(`input`,{bubbles:!0})),`TinyMCE`;let a=r&&document.getElementById(r+`editable`);return a?(a.innerHTML=t,a.dispatchEvent(new Event(`input`,{bubbles:!0})),`Atto`):`Textfeld`}function v(e){let t=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!t)return``;let n=t.id||``,r=n&&document.getElementById(n+`_ifr`);if(r&&r.contentDocument&&r.contentDocument.body)return r.contentDocument.body.innerHTML;let i=n&&document.getElementById(n+`editable`);return i?i.innerHTML:t.value||``}var y={I:{op:`#2e7d32`,block:`#eaf4ea`,feld:`#f5faf5`},II:{op:`#b45309`,block:`#fdf2e0`,feld:`#fffaf0`},III:{op:`#c62828`,block:`#fbe9e9`,feld:`#fdf3f3`},neutral:{op:`#33404d`,block:`#eceff3`,feld:`#f8f9fb`}},re=/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i,b=/\s*\(\s*AFB\s*I{1,3}(?:\s*[-–]\s*I{1,3})?\s*\)\s*/gi,x=/^\s*(?:Aufgabe\s*)?(\d{1,2})?\s*([a-h])?\s*[.):]\s*|^\s*[①-⑳]\s*/i,ie=/^\s*(?:Aufgabe\s*)?(\d{1,2})\s*([a-h])?\s*[.):]\s*/i,ae=/^\s*([a-h])\s*\)\s*/i,S=/^\s*([①-⑳])/,oe=/^\s*(?:M\s?\d+\b|Material\b)/i,se=/^(Nenne|Benenne|Gib|Beschreibe|Erkläre|Erläutere|Begründe|Vergleiche|Beurteile|Bewerte|Diskutiere|Erörtere|Stelle|Skizziere|Zeichne|Berechne|Ermittle|Bestimme|Formuliere|Deute|Interpretiere|Analysiere|Untersuche|Entwickle|Plane|Prüfe|Überprüfe|Ordne|Fasse|Werte|Leite|Definiere|Charakterisiere|Gliedere|Zeige|Notiere|Markiere|Kennzeichne|Ergänze|Wende|Übertrage|Gestalte|Entwirf|Nimm)\b/,ce=`①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳`;function C(e){let t=String(e||``).match(re);return t?t[1].replace(/\s+/g,``):``}function le(e){let t=String(e||``).toUpperCase().split(/[-–]/).pop().trim();return y[t]?t:null}function ue(e){return y[le(e)]||y.neutral}function de(e){return/#B9C7DA/i.test(String(e||``))}function fe(e){return String(e??``).replace(/\s+/g,``).toLowerCase()}function w(e){return String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function T(e){return String(e).replace(`.`,`,`)}function E(e){return`<span style="display:inline-block;min-width:22px;height:22px;line-height:20px;padding:0 5px;box-sizing:border-box;border:1.5px solid #33404d;border-radius:11px;background:#fff;color:#222;font-weight:700;font-size:13px;text-align:center;">`+w(e)+`</span>`}function D(e){return e==null||e===``?``:`<span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+w(T(e))+(Number(e)===1?` Punkt`:` Punkte`)+`)</span>`}function pe({label:e,titel:t,afb:n,punkte:r,farbig:i,zeigeAfb:a,zeigePunkte:o}){let s=i?ue(n):y.neutral,c=(e?E(e)+` · `:``)+w(t||`Deine Antwort`);return a&&n&&(c+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+w(n)+`</span>`),o&&r!=null&&(c+=` `+D(r)),`<div style="border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:10px 0;"><div style="background:`+s.block+`;padding:9px 14px;font-size:16px;font-weight:bold;color:#33404d;border-bottom:1.5px solid #9e9e9e;">`+c+`</div><div style="background:`+s.feld+`;padding:10px 14px;font-size:15px;line-height:1.45;"><p style="margin:0;">&nbsp;</p><p style="margin:0;">&nbsp;</p></div></div>`}function me(e,t){let n=ue(t);return`<div style="display:flex;border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:6px 0 10px;"><div style="width:40px;flex-shrink:0;background:#B9C7DA;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:4px;padding:10px 4px;"><span style="font-size:10px;font-weight:bold;line-height:1.2;text-align:center;color:#6b6b6b;">`+(t?`AFB<br>`+w(t):``)+`</span></div><div style="flex:1;"><div style="padding:10px 14px 8px;background:`+n.block+`;font-size:15px;line-height:1.6;border-radius:0 12px 12px 0;">`+e+`</div></div></div>`}function O(e,t,n,r){let i=e.ownerDocument,a=i.createTreeWalker(e,4),o;for(;(o=a.nextNode())&&!o.data.trim(););let s=!1;if(o){let e=o.data.replace(b,` `).replace(/^\s+/,``).replace(x,``),t=(e.match(/^\s*/)||[``])[0];e=e.slice(t.length);let r=e.match(se),a=i.createDocumentFragment();if(r){let t=i.createElement(`span`);t.setAttribute(`style`,`font-weight:700;color:`+n+`;`),t.textContent=r[1],a.appendChild(t),a.appendChild(i.createTextNode(e.slice(r[1].length))),s=!0}else a.appendChild(i.createTextNode(e));o.parentNode.replaceChild(a,o)}let c=e.innerHTML.replace(b,` `).trim(),l=t?E(t)+` `:``,u=r==null?``:` `+D(r);return c=/^<p[\s>]/i.test(c)?c.replace(/^(<p[^>]*>)/i,`$1`+l):l+c,/<\/p>\s*$/i.test(c)?c=c.replace(/<\/p>\s*$/i,u+`</p>`):c+=u,{html:c,opGefunden:s}}function he(e){let t=new DOMParser().parseFromString(`<div id="w">`+String(e||``)+`</div>`,`text/html`),n=[...t.getElementById(`w`).childNodes].filter(e=>e.nodeType===1||e.nodeType===3&&e.data.trim()),r=e=>(e.textContent||``).replace(/ /g,` `),i=[],a=null,o=``,s=0;if(n.forEach(e=>{let t=r(e),n=null,c;if((c=t.match(ie))?(o=c[1],n=c[1]+(c[2]?c[2].toLowerCase():``)):(c=t.match(ae))?n=o+c[1].toLowerCase():(c=t.match(S))&&(s=ce.indexOf(c[1])+1,o=String(s),n=o),n){a={typ:`aufgabe`,label:n,knoten:[e]},i.push(a);return}if(oe.test(t)||!a||a.typ===`frei`){(!a||a.typ!==`frei`||oe.test(t))&&(a={typ:`frei`,knoten:[]},i.push(a)),a.knoten.push(e);return}a.knoten.push(e)}),!i.some(e=>e.typ===`aufgabe`)){let e=n.find(e=>e.tagName===`OL`&&e.children.length>=2);if(e){let r=[];return n.forEach(t=>{t===e?[...e.children].forEach((e,t)=>r.push({typ:`aufgabe`,label:String(t+1),knoten:[...e.childNodes]})):r.push({typ:`frei`,knoten:[t]})}),{doc:t,segmente:r}}}return i.forEach((e,n)=>{if(e.typ!==`aufgabe`||!/^\d+$/.test(e.label))return;let a=i.slice(n+1).find(e=>e.typ===`aufgabe`);if(a&&a.label.startsWith(e.label)&&a.label!==e.label){e.typ=`frei`;let n=e.knoten[0],i=t.createTreeWalker(n,4),a;for(;(a=i.nextNode())&&!a.data.trim(););a&&(a.data=a.data.replace(ie,``)),!r(n).trim()&&!n.querySelector?.(`img,table`)&&e.knoten.shift()}}),{doc:t,segmente:i}}function ge(e,t={}){let{doc:n,segmente:r}=he(e),i=[],a=t.aufgaben||[],o=new Map(a.map(e=>[fe(e.nr),e])),s=r.filter(e=>e.typ===`aufgabe`),c=e=>{let t=n.createElement(`div`);return e.forEach(e=>t.appendChild(e.cloneNode(!0))),t};if(!s.length){let e=c(r.flatMap(e=>e.knoten)),n=a.length===1&&a[0].afb||t.gesamtAfb||C(e.textContent),o=O(e,``,ue(n).op,null);return o.opGefunden||i.push(`Kein Operator am Anfang erkannt – der Text steht unverändert in der Karte.`),n||i.push(`Kein AFB gefunden – die Karte bleibt neutral grau.`),a.length>1&&i.push(`Im Horizont stehen `+a.length+` Teilaufgaben, im Fragetext ist keine Nummerierung zu erkennen (z. B. „1.", „2a)", „b)").`),{html:me(o.html,n),gefunden:0,erwartet:a.length,hinweise:i}}a.length&&s.length!==a.length&&i.push(`Gefunden: `+s.length+` Teilaufgaben, im Horizont stehen `+a.length+`. Bitte die Vorschau genau prüfen.`);let l=0,u=0,d=0,f=r.map(e=>{let n=c(e.knoten);if(e.typ===`frei`)return n.innerHTML.replace(b,` `).replace(/<p[^>]*>(?:\s|&nbsp;|<br\s*\/?>)*<\/p>/gi,``).trim();let r=o.get(fe(e.label))||a[l]||{};l++;let i=r.afb||C(n.textContent)||t.gesamtAfb||``,s=t.punkte===!1||r.punkte==null?null:r.punkte;t.punkte!==!1&&s==null&&d++;let f=O(n,e.label,ue(i).op,s);return f.opGefunden||u++,me(f.html,i)}).join(`
`);return u&&i.push(u+` Teilaufgabe(n) ohne erkannten Operator am Anfang – dort ist nichts eingefärbt.`),d&&i.push(d+` Teilaufgabe(n) ohne Punkte im Horizont – dort steht keine Punktzahl.`),{html:f,gefunden:s.length,erwartet:a.length,hinweise:i,labels:s.map(e=>e.label)}}var k=e=>`freitextRundgang_`+e;function A(e,n){try{return t.storage.local.set({[k(e)]:{liste:n,stand:Date.now()}})}catch{return Promise.resolve()}}function _e(e){return new Promise(n=>{try{t.storage.local.get([k(e)],t=>n(t&&t[k(e)]||null))}catch{n(null)}})}function ve(e,t){return location.origin+location.pathname+`?id=`+e+`&mode=grading&slot=`+t.slot+`&qid=`+t.qid+`&grade=needsgrading&qperpage=100`}function ye(e){return location.origin+location.pathname+`?id=`+e+`&mode=grading`}function be(e,t,n){if(!e||!e.liste||!e.liste.length)return null;let r=e.liste.findIndex(e=>String(e.slot)===String(t)&&String(e.qid)===String(n));return r<0?null:{index:r,gesamt:e.liste.length,naechste:e.liste[r+1]||null}}function j(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``;function i(){return!!document.querySelector(`[name="graderinfo[text]"]`)}function l(){return document.querySelectorAll(`input[id$="-mark"]`).length!==0&&!!(document.querySelector(`.qtype_essay_response`)||document.querySelector(`textarea[id$="-comment_id"]`)||document.querySelector(`textarea[name$="-comment"]`)||document.querySelector(`.ablock`))}let u=i()?`bearbeiten`:l()?`bewertung`:null;if(!u)return;let f=a,p=r,m=/rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%/i,y=/punkteschritte\s*[:\-]?\s*([\d.,]+)/i;function re(e,t,n){return`<p>[Rechtschreibung: `+A(e)+`%]</p><p>[Punkteschritte: `+A(t)+`]</p>`+(n?`<p>[Feedback: `+n+`]</p>`:``)}function b(e){let t=N(e).split(`
`).map(e=>e.trim()),n=[];for(let e of t)if(e&&(se.test(e)||(n.push(e),n.length>=6)))break;return n.join(`
`)}function x(e){let t=b(e).match(m);return t?parseFloat(t[1].replace(`,`,`.`)):null}let ie=/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im;function ae(e){let t=b(e).match(ie);return t?t[1].charAt(0).toUpperCase()+t[1].slice(1).toLowerCase():null}function S(){if(u===`bearbeiten`&&X!==void 0)return X;let e=``;try{e=I()||T.horizontLokal||``}catch{}return ae(e)||T.feedbacklaenge}function oe(e){let t=b(e).match(y);return t?j(t[1]):null}let se=/^\s*[①-⑳⓪]?\s*(?:Aufgabe\s+(\d{1,2}\s*[a-h]?)(?![a-z])|(\d{1,2}[a-h]?)\s*·)/i,ce=e=>fe(e[1]||e[2]),le=[[1,0],[2,1/3],[3.5,2/3],[1/0,1]],ue=[0,1/3,1/2,2/3,5/6,1],w={fach:``,jahrgang:``,kursniveau:`G`,punkteschritte:`0.5`,rechtschreibung:`10`,feedbacklaenge:`Ausführlich`,afbFarben:!0,vorlagePunkte:!0,vorlageAfb:!0,kartePunkte:!0,layoutAufgabe:!0,layoutAntwort:!0,kiHinweis:!0,entferneQuellen:!0,promptHorizont:null,promptKorrektur:null,horizontLokal:``,sprachabzugKurztest:`30`},T=JSON.parse(JSON.stringify(w)),E=!1,D=(e,t)=>(t||document).querySelector(e),me=(e,t)=>[...(t||document).querySelectorAll(e)];function O(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r}function k(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function A(e){return String(e).replace(`.`,`,`)}function j(e){return parseFloat(String(e??``).replace(`,`,`.`))}function xe(e,t,n){let r=n||parseFloat(T.punkteschritte)||.5,i=Math.round(e/r)*r;return i=Math.max(0,Math.min(i,t)),Math.round(i*100)/100}function Se(e){return(String(e||``).trim().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length}function Ce(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function M(e){let t=String(e||``),n=Ce(t);t=f.test(n)?t.replace(n,n.replace(f,``)).replace(/^\s*\n/,``):t.replace(o,``).replace(/^\s*\n+/,``);for(let e=0;e<3;e++){let e=Ce(t);if(e&&(m.test(e)||y.test(e)||ie.test(e)))t=t.replace(e,``).replace(/^\s*\n/,``);else break}return t}function we(e){return T.entferneQuellen?String(e||``).replace(/\[\w+:\d+\]/g,``).replace(/ {2,}/g,` `).trim():String(e||``)}function Te(){let e=parseInt(T.jahrgang,10);return!isNaN(e)&&e>=11?`Sie haben`:`Du hast`}function N(e){let t=String(e||``).replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi,`</$1>
`);return(new DOMParser().parseFromString(t,`text/html`).body.textContent||``).replace(/[ \t]+/g,` `).replace(/\n{3,}/g,`

`).trim()}function Ee(e){return new DOMParser().parseFromString(String(e||``),`text/html`).body}function De(e,t){e.replaceChildren(...Ee(t).childNodes)}let Oe=/^(DIV|P|H[1-6]|UL|OL|LI|TABLE|TBODY|TR|TD|TH|BLOCKQUOTE|SECTION|ARTICLE|PRE)$/;function ke(e){return String(e.textContent||``).replace(/\s+/g,` `).trim()}async function Ae(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function je(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&e.type!==`button`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}async function Me(e,t,n){let r=[...e.querySelectorAll(`input[type=submit],button[type=submit]`)].filter(e=>e.name&&e.name!==`cancel`),i=r.find(e=>e.name===`submitbutton`)||r[0];i&&t.set(i.name,i.value);let a=new URL(e.getAttribute(`action`)||n,n).href,o=await fetch(a,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:t.toString()});if(!o.ok)throw Error(`HTTP `+o.status+` beim Speichern`);return o}async function Ne(e,t,n){try{let r=new URL(e.url||n),i=r.searchParams.get(`lastchanged`),a=new URL(n).searchParams.get(`cmid`)||r.searchParams.get(`cmid`);if(i)return location.origin+`/question/bank/editquestion/question.php?id=`+i+(a?`&cmid=`+a:``);let o=[...new DOMParser().parseFromString(await e.clone().text(),`text/html`).querySelectorAll(`[data-itemtype="questionname"]`)].find(e=>(e.getAttribute(`data-value`)||``)===t);if(o&&o.getAttribute(`data-itemid`))return location.origin+`/question/bank/editquestion/question.php?id=`+o.getAttribute(`data-itemid`)+(a?`&cmid=`+a:``)}catch{}return null}function Pe(e,t){let n=e=>N(e).replace(/\s+/g,` `).trim(),r=n(e),i=n(t);if(!r||!i)return!1;if(r===i)return!0;if(Math.abs(r.length-i.length)>Math.max(40,i.length*.2))return!1;let a=i.slice(Math.floor(i.length/2),Math.floor(i.length/2)+40);return r.includes(i.slice(0,40))&&(a.length<20||r.includes(a))}async function Fe(e,t){let n=location.href,r=await Ae(n),i=[...r.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!i)throw Error(r.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let a=je(i),o=[];for(let n of Object.keys(e)){if(!a.has(n))throw Error(`Feld „`+n+`" nicht im Formular`);let r=a.get(n)||``;o.push({feld:n,belegt:N(r).length>0}),t||a.set(n,e[n])}if(t)return{bericht:o};let s=(i.querySelector(`[name="name"]`)||{}).value||``,c=await Ne(await Me(i,a,n),s,n),l=[...(await Ae(c||n)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),u=[];for(let t of Object.keys(e)){let n=l&&l.querySelector(`[name="`+CSS.escape(t)+`"]`);u.push({feld:t,ok:!!n&&Pe(n.value,e[t])})}return{bericht:o,ergebnis:u,neueUrl:c,warnung:c?null:`Die neue Fragenversion war nicht auffindbar — die Gegenprobe lief gegen den alten Stand und kann falsch sein.`}}function P(){if(u===`bearbeiten`){let e=D(`[name="questiontext[text]"]`);return e?N(e.value):``}let e=D(`.que .qtext`)||D(`.qtext`);return e?e.innerText.trim():``}function F(){if(u===`bearbeiten`){let e=D(`[name="defaultmark"]`);return e&&j(e.value)||0}let e=D(`input[name$="-maxmark"]`);if(e)return j(e.value)||0;let t=D(`.que .grade`),n=t&&t.innerText.match(/([\d.,]+)\s*$/);return n?j(n[1]):0}function I(){if(u===`bearbeiten`)return v(`graderinfo[text]`);let e=D(`.que .graderinfo`)||D(`.graderinfo`);return e?e.innerHTML:``}function Ie(){let e=N(I());return e?{horizont:!0,wer:s(e.split(`
`).map(e=>e.trim()).filter(Boolean).slice(0,5).map(e=>e.match(f)).find(Boolean)||null)}:{horizont:!1,wer:null}}function Le(e){let t=Ee(M(String(e||``))),n=[],r=null;if([...t.children].forEach(e=>{let t=ke(e),i=t.match(se);if(i&&/^(H[1-6]|P|DIV)$/.test(e.tagName)&&t.length<200){r={nr:ce(i),kopf:t,html:``,text:``},n.push(r);return}r&&(r.html+=e.outerHTML,r.text+=N(e.outerHTML)+`
`)}),!n.length){let t=M(N(e));return t?[{nr:`1`,kopf:`Aufgabe 1`,html:String(e||``),text:t,punkte:null,afb:null,ganzeArbeit:!0}]:[]}return n.forEach(e=>{e.text=e.text.trim();let t=e.kopf.match(/\(\s*([\d.,]+)\s*(?:P\.?|Punkte?)\s*\)/i);e.punkte=t?j(t[1]):null;let n=e.kopf.match(/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i);e.afb=n?n[1].replace(/\s/g,``):null}),n}function Re(e){let t=e;for(let e=0;e<12&&t;e++)if(t=t.parentElement,t&&t.classList&&(t.classList.contains(`que`)||t.classList.contains(`content`)))return t;return null}function L(){return me(`input[id$="-mark"]`).map((e,t)=>{let n=Re(e),r=n&&n.querySelector(`.qtype_essay_response`),i=n&&n.querySelector(`textarea[name$="-comment"]`),a=n&&n.querySelector(`input[name$="-maxmark"]`),o=r&&r.innerHTML||``,s=r?r.innerText.trim():``;return{nr:t+1,markfeld:e.name||``,kommentarfeld:i?i.name:``,ist:j(e.value)||0,max:a?j(a.value)||0:F(),rohHtml:o,text:s,anker:n&&n.id?`#`+n.id:``}}).filter(e=>e.markfeld)}function R(e,t){let n=Ee(e),r=[],i=null,a=e=>{let t=[...e.children].filter(e=>Oe.test(e.tagName));if(!t.length){let t=ke(e);if(!t)return;let n=t.match(se);n&&t.length<160?(i={nr:ce(n),text:``},r.push(i)):i&&(i.text+=t+`
`);return}t.forEach(a)};return a(n),r.length>=1?(r.forEach(e=>{e.text=e.text.trim()}),{gegliedert:!0,aufgaben:r,leer:r.every(e=>!e.text)}):{gegliedert:!1,aufgaben:[{nr:`1`,text:String(t||``).trim()}]}}function z(e,t){if(t<40){let t=Math.min(Math.round(e),ue.length-1);return ue[t]}let n=t>0?e*100/t:0;for(let[e,t]of le)if(n<=e)return t;return 1}function B(e){return(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0)}function ze(e,t,n,r,i){let a=e.max||F()||0,o=(n||[]).filter(e=>e.punkte!=null).reduce((e,t)=>e+t.punkte,0),s=n&&n.length?n.map(e=>e.nr):(t.aufgaben||[]).map(e=>fe(e.nr)),c=Math.max(1,s.length),l=[],u=s.map(e=>{let r=(t.aufgaben||[]).find(t=>fe(t.nr)===e)||(l.push(e),{nr:e,prozent:0}),i=(n||[]).find(t=>t.nr===e),s;s=i&&i.punkte!=null&&o>0?a>0?i.punkte*a/o:i.punkte:a/c;let u=Math.max(0,Math.min(100,Number(r.prozent)||0));return{nr:e,max:s,prozent:u,roh:s*u/100}}),d=u.reduce((e,t)=>e+t.roh,0),f=a*(r??(parseFloat(T.rechtschreibung)||0))/100,p=B(t.fehler),m=Se(e.text),h=z(p,m),ee=Math.min(f*h,d);u.forEach(e=>{let t=d>0?e.roh/d:0;e.abzug=ee*t,e.netto=Math.max(0,e.roh-e.abzug)});let g=i||parseFloat(T.punkteschritte)||.5,te=xe(u.reduce((e,t)=>e+t.netto,0),a,g);u.forEach(e=>{e.punkte=Math.max(0,Math.floor(e.netto/g+1e-9)*g),e.rest=e.netto-e.punkte});let ne=Math.round((te-u.reduce((e,t)=>e+t.punkte,0))/g),_=u.slice().sort((e,t)=>t.rest-e.rest);for(let e=0;ne>0&&e<_.length*4;e++){let t=_[e%_.length];t.punkte+g<=t.max+1e-9&&(t.punkte+=g,ne--)}for(let e=0;ne<0&&e<_.length*4;e++){let t=_[_.length-1-e%_.length];t.punkte-g>=-1e-9&&(t.punkte-=g,ne++)}return u.forEach(e=>{e.punkte=Math.round(e.punkte*100)/100}),{teil:u,wortzahl:m,fehlerGewichtet:p,fehlerDichte:m>0?Math.round(p*1e3/m)/10:0,hoechstabzug:Math.round(f*100)/100,abzug:Math.round(ee*100)/100,gesamt:te,max:a,fehlendeAufgaben:l}}function V(e){let t=k(`Aufgabe `+e.nr);return e.afb&&(t+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+k(e.afb)+`</span>`),e.schlagwort&&(t+=` · `+k(e.schlagwort)),e.punkte!=null&&(t+=` <span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+k(A(e.punkte))+(Number(e.punkte)===1?` Punkt`:` Punkte`)+`)</span>`),t}function Be(){return{farbig:T.afbFarben!==!1,zeigeAfb:!!T.vorlageAfb,zeigePunkte:!!T.vorlagePunkte}}function Ve(e){return(e||[]).map(e=>pe(Object.assign({label:String(e.nr),titel:e.schlagwort||`Deine Antwort`,afb:e.afb,punkte:e.punkte},Be()))).join(`
`)}function He(e){let t=String(e||``).replace(/\r/g,``).match(/Teile\s*:\s*\n([\s\S]*?)(?:\n\s*\n|$)/i),n={};return t&&t[1].split(`
`).forEach(e=>{let t=e.match(/^\s*[-•]?\s*([a-h])\s*[).:]?\s.*?([\d]+(?:[.,]\d+)?)\s*Punkt/i);t&&(n[t[1].toLowerCase()]=j(t[2]))}),n}function Ue(){return Z||N(I()||``)}function We(){let e=v(`questiontext[text]`)||``,t=he(de(e)?``:e).segmente.filter(e=>e.typ===`aufgabe`),n=He(Ue()),r=C(N(e));return t.filter(e=>/^[a-h]$/.test(e.label)).map(e=>({nr:e.label,afb:C(e.knoten.map(e=>e.textContent||``).join(` `))||r,punkte:n[e.label]==null?null:n[e.label]}))}function Ge(){let e=We(),t=Be();if(e.length>=2)return e.map(e=>pe(Object.assign({label:e.nr,titel:`Deine Antwort`,afb:e.afb,punkte:e.punkte},t))).join(`
`);let n=v(`questiontext[text]`)||``;return pe(Object.assign({label:``,titel:`Deine Antwort`,afb:C(N(n)),punkte:F()||null},t))}function Ke(){if(q)return q;let e=Le(I());return!e.length||e[0].ganzeArbeit?null:e.map(e=>{let t=(e.kopf.match(/·\s*([^()]+?)\s*(?:\(|$)/)||[])[1]||``;return{nr:e.nr,afb:e.afb,punkte:e.punkte,schlagwort:t}})}function qe(){return!!(q||Z||N(I()||``).trim())}function Je(){if(u!==`bearbeiten`)return!0;let e=D(`[name="responseformat"]`);return!e||/editor/i.test(e.value||``)}function Ye(){if(u===`bearbeiten`&&Y===`kurztest`)return Ge();let e=Ke();return e?Ve(e):null}function Xe(){let e=v(`questiontext[text]`);if(!N(e||``).trim())return{fehler:`Die Aufgabenstellung ist noch leer.`};if(de(e))return{fehler:`Die Aufgabenstellung ist schon im Kartendesign gestaltet. Zum Neugestalten erst den ursprünglichen Text wiederherstellen (Moodle-Versionsverlauf der Frage).`};let t=Y===`kurztest`,n=t?We():Ke()||[],r=ge(e,{aufgaben:n,punkte:t?!0:T.kartePunkte!==!1,gesamtAfb:t?C(N(e)):``});return t&&n.length>=2&&n.some(e=>e.punkte==null)&&r.hinweise.push(`Im Horizont fehlen die Punkte je Teil (Abschnitt „Teile:"). Horizont neu erstellen, dann stehen sie dort.`),r}function Ze(){if(u!==`bearbeiten`||!K(`hstatus`))return;let e=I()||``,t=N(e).trim(),n=K(`hschritt1`),r=W.querySelector(`[data-tu="hprompt"]`),i=W.querySelector(`[data-tu="hschreiben"]`),a=K(`hbisher`);if(!t)return n&&(n.textContent=`1 · Prompt zum Erstellen des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`3 · In die Aufgabe eintragen`),a&&(a.hidden=!0),Q(`hstatus`,`Noch kein Erwartungshorizont in dieser Aufgabe.`+(Vt()?` Tipp: Fach und Jahrgang im Zahnrad ⚙ eintragen – sie gehen in den Prompt ein.`:``));let o=/moodle[-\s]?ai[-\s]?(coach|grader)/i.test(t),s=c(t),l=ae(e),d=[s===`kurztest`?`Kurztest`:s===`klausur`?`Klausur`:``,l?`Feedback `+l:``].filter(Boolean).join(`, `);if(Q(`hstatus`,o?`Dieser Horizont stammt noch aus Coach oder Grader. Bitte neu erstellen – der alte geht als Vorlage in den Prompt ein.`:`Diese Aufgabe hat schon einen Erwartungshorizont`+(d?` (`+d+`)`:``)+`. Der Prompt nimmt ihn als Vorlage mit; die KI sagt dir, was sie übernimmt und was sie ändert.`),n&&(n.textContent=`1 · Prompt zum Überarbeiten des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`3 · Vorhandenen Horizont in der Aufgabe ersetzen`),a){a.hidden=!1;let e=a.querySelector(`pre`);e&&(e.textContent=M(t))}}function Qe(){let e=K(`hstatus`)?K(`hstatus`).textContent:``;Ze(),e&&K(`hstatus`)&&(K(`hstatus`).textContent=e)}function H(){let e=W.querySelector(`.mag-tab[data-tab="vorlage"]`);if(e&&(e.hidden=!(u===`bearbeiten`&&qe())),!K(`lseca`))return;K(`lseca`).hidden=T.layoutAufgabe===!1,K(`lsecv`).hidden=T.layoutAntwort===!1;let t=Y===`kurztest`;K(`lpunktezeile`).hidden=t,K(`lpunktehinweis`).hidden=t;let n=W.querySelector(`[data-tu="lein"]`);if(n&&(n.disabled=T.layoutAufgabe===!1&&T.layoutAntwort===!1),T.layoutAufgabe!==!1){let e=Xe();e.fehler?(De(K(`lavorschau`),`<p class="mag-hinweis">`+k(e.fehler)+`</p>`),K(`lahinweise`).textContent=``):(De(K(`lavorschau`),e.html),K(`lahinweise`).textContent=e.hinweise.join(` `))}}function $e(e){return((e||[]).some(e=>f.test(Ce(N(e.horizont))))?``:`<p>`+p+`</p>`+re(T.rechtschreibung,T.punkteschritte,u===`bearbeiten`?X:S()))+(e||[]).map(e=>{let t=String(e.horizont||``).trim();return/<[a-z][\s\S]*>/i.test(t)||(t=`<p>`+k(t).replace(/\n{2,}/g,`</p><p>`).replace(/\n/g,`<br>`)+`</p>`),`<h4>`+V(e)+`</h4>`+t}).join(`
`)}let et={G:`G — gymnasial`,M:`M — mittel`,E:`E — einfach`};function tt(){return[`Fach: `+(T.fach||`[nicht angegeben]`),`Jahrgang: `+(T.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(et[T.kursniveau]||T.kursniveau),`Feedbacklänge: `+S(),`Anrede im Feedback: `+Te()+` …`].join(`
`)}function nt(){return[`Fach: `+(T.fach||`[nicht angegeben]`),`Jahrgang: `+(T.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(et[T.kursniveau]||T.kursniveau)].join(`
`)}function U(){return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KLAUSUR)
═══════════════════════════════════════════════════════

Du bist erfahrene Lehrkraft und erstellst den Erwartungshorizont für eine Klausur. Er
wird in Moodle im Feld „Informationen für Bewerter/innen" gespeichert; Schülerinnen und
Schüler sehen ihn nicht.

${g}

RAHMENDATEN
[MAG_RAHMENDATEN]

AUFGABENSTELLUNG (aus Moodle übernommen, Gesamtpunktzahl: [MAG_GESAMTPUNKTE])
[MAG_AUFGABEN]

WAS DU TUST
1. Zerlege die Aufgabenstellung in ihre Teilaufgaben. Übernimm die Nummerierung der
   Aufgabenstellung. Steht dort eine Punktzahl je Aufgabe, übernimm sie unverändert;
   fehlt sie, verteile die Gesamtpunktzahl begründet und weise darauf hin.
   Hat eine Aufgabe Teile (a, b …), ist JEDER TEIL eine eigene Aufgabe mit eigener
   Punktzahl, eigenem Operator und eigenem AFB: "nr": "2a", "2b". Eine übergeordnete
   Aufgabe 2 ohne eigene Punkte gibt es dann nicht. Die Punkte aller Einträge ergeben
   zusammen die Gesamtpunktzahl.
2. Bestimme je Aufgabe den Operator und den Anforderungsbereich AFB (I, II, III oder
   eine Spanne wie II-III).
3. Schreibe je Aufgabe einen Erwartungshorizont in dieser Reihenfolge:
   Kernaussage · Muss enthalten · Auch richtig · Inhalt in Stufen · Reicht nicht ·
   Häufiger Fehler.
4. Gib je Aufgabe ein Schlagwort von zwei bis vier Wörtern an, das die Aufgabe benennt.

REGELN
${ee(`[MAG_JAHRGANG]`)}

BEISPIEL „AUCH RICHTIG"
Schlecht: „Von links nach rechts werden die Atome kleiner, weil die Kernladung zunimmt
und die Elektronen stärker angezogen werden." So schreibt eine Lehrkraft – wer so
antwortet, liegt ohnehin bei 100 %.
Gut: „nach rechts wird es kleiner" · „der Kern zieht doller" · „es kommt eine Schale
dazu, deshalb wird es dicker" · „mehr Protonen, gleiche Schale".

BEISPIEL ZÄHLBARE STUFEN
100 — beide Trends beschrieben UND beide erklärt · 75 — beide beschrieben, einer
erklärt · 50 — beide beschrieben, keiner erklärt ODER einer beschrieben und erklärt.

[MAG_STUFE]

ARBEITSWEISE
Zeige mir zuerst je Aufgabe eine lesbare Übersicht (Nummer, Operator, AFB, Punkte,
Schlagwort, Erwartungshorizont) und frage: „Passt das so? Wenn ja, antworte mit ok."
Ändere, bis ich zustimme. Stelle immer nur EINE Frage auf einmal.

ERST WENN ICH BESTÄTIGE, gib genau EINEN Codeblock aus – nichts davor, nichts danach:

\`\`\`json
{ "aufgaben": [
  { "nr": "1",
    "schlagwort": "kurzes Stichwort",
    "afb": "I",
    "punkte": 2,
    "operator": "Nenne",
    "horizont": "<p><strong>Kernaussage:</strong> …</p><p><strong>Muss enthalten:</strong> …</p>" },
  { "nr": "2a", "schlagwort": "…", "afb": "II", "punkte": 3, "operator": "Erläutere", "horizont": "…" }
] }
\`\`\`

Das Feld "horizont" ist HTML (erlaubt: p, br, ul, li, strong, em). Jeder Abschnitt ist
ein eigenes <p> mit fettem Abschnittsnamen. Keine Überschrift für die Aufgabe selbst –
die setzt die Erweiterung. Keine Punktzahlen im Fließtext.`}function rt(){let e=D(`[name="questiontext[text]"]`),t=e?e.value:(D(`.que .qtext`)||{}).innerHTML||``;if(!t)return[];let n=new DOMParser().parseFromString(t,`text/html`),r=[];return n.querySelectorAll(`img`).forEach(e=>r.push(`Bild: `+(e.getAttribute(`alt`)||decodeURIComponent((e.getAttribute(`src`)||``).split(`/`).pop().split(`?`)[0])||`ohne Namen`))),n.querySelectorAll(`a[href*="pluginfile"]`).forEach(e=>r.push(`Datei: `+(e.textContent.trim()||decodeURIComponent(e.getAttribute(`href`).split(`/`).pop().split(`?`)[0])))),r}function it(){return h([P()],rt())}function at(){if(u===`bearbeiten`&&Y===`kurztest`){let e={qid:`diese-frage`,frage:(D(`[name="name"]`)||{}).value||`Diese Frage`,aufgabe:P(),max:F()},t=N(I());t&&(e.horizont_bisher=M(t));let n=it(),r=`Rahmendaten:
`+nt()+`

`+(n?n+`

`:``)+"```json\n"+JSON.stringify([e],null,1)+"\n```";return te({einzeln:!0,jahrgang:T.jahrgang,stufe:S()}).replace(`[MOODLE_AI_COACH_AUFGABEN]`,r)}let e=(T.promptHorizont||``).trim()||U(),t=d(`klausur`,S());e=e.includes(`[MAG_STUFE]`)?e.replace(`[MAG_STUFE]`,t):e+`

`+t;let n=it();return e.replace(`Lernende der Jahrgangsstufe [MAG_JAHRGANG]`,T.jahrgang?`Lernende der Jahrgangsstufe `+T.jahrgang:`Lernende dieser Jahrgangsstufe`).replace(`[MAG_RAHMENDATEN]`,nt()).replace(`[MAG_GESAMTPUNKTE]`,A(F()||`?`)).replace(`[MAG_AUFGABEN]`,(P()||`[keine Aufgabenstellung gefunden]`)+(n?`

`+n:``)+(N(I())?`

BISHERIGER HORIZONT (Ausgangspunkt, keine Vorlage zum Abschreiben – übernimm, was gut ist, und erstelle ihn im aktuellen Format neu. Sag mir ZUERST in zwei, drei Sätzen, dass ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst):
`+M(N(I())):``))}let ot={Kurz:`ein bis zwei Sätze je Aufgabe`,Mittel:`drei bis vier Sätze je Aufgabe`,Ausführlich:`ein Absatz je Aufgabe mit konkretem Bezug auf die Antwort`,Umfangreich:`ein ausführlicher Absatz je Aufgabe, dazu ein eigener Abschnitt zur Operatorerfüllung`};function st(){return`Du bewertest Klausurantworten nach einem vorgegebenen Erwartungshorizont.

[MAG_KOPF]

RAHMENDATEN
[MAG_RAHMENDATEN]

ERWARTUNGSHORIZONT (gilt für alle Abgaben)
[MAG_HORIZONT]

[MAG_MODUS]

WICHTIG — WAS DU NICHT TUST
Du vergibst KEINE Punkte und rechnest NICHT. Die Erweiterung rechnet Punkte, Rundung,
Rechtschreibabzug und Gesamtsumme selbst. Du lieferst ausschließlich Prozentwerte,
gezählte Fehler und Begründungstexte OHNE Zahlenangaben. Schreibe in keiner Begründung
„x von y Punkten" — die Zahlen setzt die Erweiterung ein.

JE AUFGABE
Vergib einen Erfüllungsgrad in Prozent, nur diese Stufen: 100, 75, 50, 25, 0.
Verankere jede Einstufung an einer Formulierung des Erwartungshorizonts.
Prüfe dabei den Operator: Wer „erläutere" liest und nur beschreibt, erfüllt die Aufgabe
nicht vollständig, auch wenn der Inhalt stimmt.

JE ABGABE
Zähle die sprachlichen Fehler und gib sie EINZELN an — Wort, Korrektur, Kategorie.
Kategorien: satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache. Ein Satz ohne Prädikat, ein abgebrochener Satz oder ein
Satzbau, den man zweimal lesen muss, zählt als "schwer": true. Denselben Fehler im selben
Wort nur einmal zählen. Zähle vollständig — die Erweiterung leitet daraus den Abzug ab.

FEEDBACKTEXTE
Länge: [MAG_FBLAENGE]. Anrede: [MAG_ANREDE] … Sachlich, konkret, zugewandt.
Bei Sprachfehlern den fehlerhaften Satz wörtlich zitieren und richtig danebenschreiben,
nicht „achte auf die Satzstellung". Höchstens zwei bis drei Vorschläge.
Jede Aufgabe bekommt eine Begründung — auch eine vollständig richtige.

ABGABEN
[MAG_ABGABEN]

AUSGABE — am Ende genau EIN Codeblock (im Modus AUTOMATISCH nichts davor, nichts danach):

\`\`\`json
{ "bewertungen": [
  { "nr": 1,
    "besprochen": true,
    "staerken": "was gut gelungen ist",
    "aufgaben": [ { "nr": 1, "prozent": 75, "begruendung": "…", "operator": "erfüllt" } ],
    "fehler": [ { "wort": "Atomradiuse", "korrektur": "Atomradien",
                  "kategorie": "rechtschreibung", "schwer": false } ],
    "sprachfeedback": "…",
    "zusammenfassung": "…" }
] }
\`\`\`

"nr" ist die Nummer der Abgabe aus dem Datenblock, nicht die des Schülers.
In "aufgaben" ist "nr" die Aufgabennummer wie im Datenblock (z. B. "1", "2a").
"besprochen": true nur für Arbeiten, die du im Modus GEMEINSAM mit der Lehrkraft durchgegangen
bist und die sie mit OK bestätigt hat; sonst false.
Liefere für JEDE Abgabe des Blocks einen Eintrag, auch für leere Abgaben
(dort alle Prozentwerte 0 und ein Hinweis in der Zusammenfassung).`}function ct(e,t){return(e||1)>1?`MODUS
Der Modus wurde in Teil 1 gewählt und gilt weiter. Frage NICHT erneut. Im Modus GEMEINSAM gehst
du diese Arbeiten wieder einzeln mit mir durch, im Modus AUTOMATISCH gibst du sofort das JSON aus.`:`MODUSFRAGE — STELLE SIE ZUERST UND WARTE
Bevor du irgendetwas bewertest, stelle GENAU DIESE EINE Frage und gib danach nichts weiter aus,
bis ich geantwortet habe:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir jede Arbeit einzeln, du bestätigst oder änderst, dann kommt die
     nächste. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alle Arbeiten und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl, kein stiller Standard. Triff keine Annahme.

MODUS GEMEINSAM — je Arbeit dieses Schema, dann warten:
  ABGABE [nr]
  Je Aufgabe: Antwort (gekürzt) · Stufe in % · Begründung (ein Satz, Bezug auf den Horizont)
  Sprachfehler: Wort → Korrektur (Kategorie)
  Rückmeldung an die Schülerin / den Schüler (so, wie sie eingetragen würde)
  Grobe Punkteschätzung (nur zur Orientierung – genau rechnet die Erweiterung)
  „1 OK – weiter · 2 Stufe ändern · 3 Rückmeldung ändern · 4 neu bewerten"
Erst nach OK kommt die nächste Arbeit. Nach der letzten Arbeit${t>1?` dieses Teils`:``} das JSON.`}function lt(e,t,n,r){let i=Le(t),a=i.length?i.map(e=>e.kopf+`
`+e.text).join(`

`):N(t),o=e.map(e=>{let t=R(e.rohHtml,e.text),n=`ABGABE `+e.nr+(t.gegliedert?``:`  (ohne Gliederung)`),r=t.gegliedert?t.aufgaben.map(e=>`  Aufgabe `+e.nr+`:
  `+(e.text||`(leer)`)).join(`
`):`  `+(e.text||`(leer)`);return n+`
`+r}).join(`

`),s=(T.promptKorrektur||``).trim(),c=ne({fach:T.fach,jahrgang:T.jahrgang,niveau:et[T.kursniveau]||T.kursniveau}),l=s||st();return l=(l.includes(`[MAG_KOPF]`)?l.replace(`[MAG_KOPF]`,c):c+`

`+l).replace(`[MAG_RAHMENDATEN]`,tt()).replace(`[MAG_HORIZONT]`,a||`[kein Horizont hinterlegt]`).replace(`[MAG_FBLAENGE]`,ot[S()]||ot.Ausführlich).replace(`[MAG_ANREDE]`,Te()).replace(`[MAG_ABGABEN]`,o).replace(`[MAG_MODUS]`,ct(n,r)),r>1&&(l=`TEIL `+n+` VON `+r+` — bewerte NUR die unten stehenden Abgaben und gib nur für sie JSON aus. Warte auf den nächsten Teil.

`+l),l}function ut(e,t,n){let r=[];if(e.staerken&&r.push(e.staerken.trim()),(e.aufgaben||[]).forEach(e=>{let i=t.teil.find(t=>t.nr===e.nr),a=(n||[]).find(t=>t.nr===e.nr),o=`Aufgabe `+e.nr+(a&&a.kopf.includes(`·`)?` – `+a.kopf.split(`·`).slice(1).join(`·`).replace(/\(.*?\)/,``).trim():``)+`: `+(i?A(i.punkte):`?`)+` von `+(i?A(Math.round(i.max*100)/100):`?`)+` P.`;i&&i.abzug>.004&&(o+=` (davon −`+A(Math.round(i.abzug*100)/100)+` P. Rechtschreibung)`),r.push(o+`
`+(e.begruendung||``).trim())}),S()===`Umfangreich`){let t=(e.aufgaben||[]).filter(e=>e.operator);t.length&&r.push(`Operatorerfüllung:
`+t.map(e=>`Aufgabe `+e.nr+`: `+e.operator).join(`
`))}let i=e.fehler||[],a=`Rechtschreibung und Sprache: `;return t.abzug>.004?a+=`Abzug `+A(t.abzug)+` von höchstens `+A(t.hoechstabzug)+` P. (`+A(t.fehlerDichte)+` Fehler je 100 Wörter).`:i.length?a+=`kein Punktabzug, aber ein paar Stellen zum Nachschauen.`:a+=`keine Auffälligkeiten.`,i.length&&(a+=`
`+i.slice(0,12).map(e=>`• `+(e.wort||``)+` → `+(e.korrektur||``)).join(`
`),i.length>12&&(a+=`
• … und `+(i.length-12)+` weitere`)),e.sprachfeedback&&(a+=`
`+e.sprachfeedback.trim()),r.push(a),e.zusammenfassung&&r.push(e.zusammenfassung.trim()),r.push(`Gesamt: `+A(t.gesamt)+` von `+A(t.max)+` Punkten.`),r.filter(Boolean).map(we).join(`

`)}function dt(e){let t=e.split(/\n{2,}/).map(e=>`<p>`+k(e).replace(/\n/g,`<br>`)+`</p>`).join(``);return T.kiHinweis&&(t+=`<p><em><small>Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.</small></em></p>`),t}function ft(e){let t=[],n=0,r=-1,i=!1,a=!1;for(let o=0;o<e.length;o++){let s=e[o];if(i){a?a=!1:s===`\\`?a=!0:s===`"`&&(i=!1);continue}if(s===`"`){n>0&&(i=!0);continue}s===`{`?(n===0&&(r=o),n++):s===`}`&&n>0&&(n--,n===0&&r>=0&&(t.push(e.slice(r,o+1)),r=-1))}return t}function pt(e,t){let n=[],r=[],i=/```(?:json)?\s*([\s\S]*?)```/g,a;for(;(a=i.exec(e))!==null;)r.push(a[1]);if(r.push(e.replace(/```(?:json)?\s*[\s\S]*?```/g,``)),r.forEach(e=>{let r=e.trim();if(r){try{let e=JSON.parse(r),i=Array.isArray(e)?e:e[t]||(e.nr==null?null:[e]);i&&n.push(...i);return}catch{}ft(r).forEach(e=>{try{let r=JSON.parse(e),i=Array.isArray(r)?r:r[t]||(r.nr==null?null:[r]);i&&n.push(...i)}catch{}})}}),!n.length)throw Error(`Kein verwertbares JSON gefunden.`);return n}function mt(e,t){let n=new Set,r=[];return e.forEach(e=>{let t=Number(e.nr);n.has(t)&&r.push(t),n.add(t)}),{fehlend:t.filter(e=>!n.has(e)),doppelt:r}}async function ht(e){let t=await Ae(location.href),n=t.querySelector(`form#manualgradingform`)||[...t.forms].find(e=>e.querySelector(`input[name$="-mark"]`));if(!n&&!e)return await new Promise(e=>setTimeout(e,900)),ht(!0);if(!n)throw Error(`Bewertungsformular nicht gefunden`);return{dok:t,form:n}}async function gt(e,t,n){let{form:r}=await ht(!1),i=je(r),a=[],o=0;if(e.forEach(e=>{let r=i.has(e.markfeld),s=!e.kommentarfeld||i.has(e.kommentarfeld);if(!r||!s){o++,n(`✗ Abgabe `+e.nr+`: `+(r?`Kommentarfeld`:`Punktefeld`)+` nicht auf der Seite`);return}t||(i.set(e.markfeld,A(e.punkte)),e.kommentarfeld&&i.set(e.kommentarfeld,e.feedbackHtml)),a.push(e)}),t)return n(a.length+` von `+e.length+` Abgaben vollständig vorhanden.`),{ok:a.length,fehler:o,trocken:!0};if(!a.length)return{ok:0,fehler:e.length};await Me(r,i,location.href);let{form:s}=await ht(!1),c=0,l=o;return a.forEach(e=>{let t=s.querySelector(`input[name="`+CSS.escape(e.markfeld)+`"]`),r=t?j(t.value):null;r!==null&&Math.abs(r-e.punkte)<.005?(c++,n(`✓ Abgabe `+e.nr+` — `+A(e.punkte)+` P. eingetragen`)):(l++,n(`✗ Abgabe `+e.nr+` — steht auf `+(r==null?`keinem Wert`:A(r))+` statt `+A(e.punkte)))}),{ok:c,fehler:l}}let _t=u===`bearbeiten`?[[`horizont`,`1 · Horizont`],[`vorlage`,`2 · Layout-Vorlage`],[`einst`,`⚙`]]:[[`korrektur`,`1 · Bewerten`],[`horizont`,`2 · Horizont`],[`einst`,`⚙`]],W=O(`div`,`mag-panel`);W.innerHTML=`
    <div class="mag-kopf">
      <img class="mag-kopfbild" alt="">
      <div class="mag-titelblock">
        <span class="mag-titel">Freitext Grader <span class="mag-version"></span></span>
        <span class="mag-untertitel"></span>
      </div>
      <button class="mag-ikon" data-tu="zu" title="Schließen">✕</button>
    </div>
    <div class="mag-banner" hidden></div>
    <div class="mag-reiter">

    </div>

    <div class="mag-inhalt" data-panel="horizont">
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier entsteht der Erwartungshorizont dieser Aufgabe – der Maßstab, nach dem die KI später alle Antworten bewertet. Du kopierst einen Prompt, lässt die KI den Horizont schreiben und trägst ihn in die Aufgabe ein. Das geschieht einmal je Aufgabe; danach bleibt er in der Aufgabe gespeichert, auch beim Export.</p>
      </details>
      <div class="mag-status" data-rolle="hstatus"></div>
      <details class="mag-details" data-rolle="hbisher" hidden>
        <summary>Gespeicherten Horizont ansehen</summary>
        <pre class="mag-hinweis" style="white-space:pre-wrap;max-height:220px;overflow:auto;"></pre>
      </details>
      <div class="mag-modus" data-rolle="hmodus" hidden>
        <div class="mag-rahmen-titel">Diese Aufgabe</div>
        <label>Modus</label>
        <select data-rolle="hmodussel">
          <option value="kurztest">Kurztest – kurze Antworten, schnelle Bewertung</option>
          <option value="klausur">Klausur – Teilaufgaben, Portionen, Review</option>
        </select>
        <div class="mag-hinweis" data-rolle="hmodushinweis"></div>
        <label>Feedbacklänge</label>
        <select data-rolle="hfeedbacksel"></select>
        <div class="mag-hinweis" data-rolle="hfeedbackhinweis"></div>
      </div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt</div>
        <div data-rolle="hrahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <details class="mag-details mag-hilfe" data-rolle="hhilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Der Erwartungshorizont sagt der KI später beim Bewerten, was eine
        richtige Antwort ist. So entsteht er:</p>
        <p class="mag-hinweis"><strong>1 · Horizont-Prompt kopieren:</strong> Die Erweiterung nimmt
        Aufgabenstellung, Punkte und Einstellungen und baut daraus einen Prompt, mit dem die KI den
        Erwartungshorizont schreibt. Mit den Antworten der Lernenden hat er nichts zu tun – die
        kommen erst beim Bewerten.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Verweist die
        Aufgabe auf Material, fragt die KI danach. Sie zeigt den Horizont zuerst als lesbaren Text –
        prüfen, ggf. ändern lassen, dann mit „ok" antworten. Erst dann kommt ein Codeblock: diesen hier einfügen.</p>
        <p class="mag-hinweis"><strong>3 · Eintragen:</strong> Der Horizont wird im Feld
        „Informationen für Bewerter/innen" dieser Aufgabe gespeichert. Schülerinnen und Schüler sehen ihn nicht.</p>
      </details>
      <label data-rolle="hschritt1">1 · Prompt zum Erstellen des Erwartungshorizonts kopieren</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-primary" data-tu="hprompt">📋 Horizont-Prompt kopieren</button>
        <button class="mag-btn mag-btn-rand" data-tu="hedit" title="Prompt anpassen">✏️</button>
      </div>
      <div class="mag-hinweis" data-rolle="hmaterial" hidden></div>
      <label>2 · Erwartungshorizont der KI einfügen</label>
      <div class="mag-hinweis">Die Erweiterung hat bewusst keinen eigenen KI-Zugang: Du wählst die KI,
      und Aufgaben gehen nur dorthin, wo du sie einfügst. Den Codeblock der KI vollständig hier
      einfügen – er wird sofort geprüft und angezeigt. Gespeichert wird erst in Schritt 3.
      Den lesbaren Text vor dem „ok" brauchst du hier nicht, nur den Codeblock danach.</div>
      <textarea data-rolle="hjson" rows="5" placeholder='{ "aufgaben": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="hpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-liste" data-rolle="hliste"></div>
      <div class="mag-protokoll" data-rolle="hlog" hidden></div>
      <div class="mag-reihe" data-rolle="hknoepfe" hidden></div>
      <details class="mag-details">
        <summary>Kein Bearbeitungsrecht? Horizont hier behalten</summary>
        <p class="mag-hinweis">Wer Fragen nicht bearbeiten darf, klebt den fertigen Horizont
        hierher. Er bleibt dann in der Erweiterung statt in der Frage.</p>
        <textarea data-rolle="hlokal" rows="4" placeholder="Erwartungshorizont …"></textarea>
        <button class="mag-btn mag-btn-rand" data-tu="hlokalsichern">Hier speichern</button>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="vorlage" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier gestaltest du das Aussehen der Aufgabe für die Lernenden – ein
        Zusatz nach Geschmack, für die Bewertung nicht nötig. Er erscheint, sobald die Aufgabe einen
        Erwartungshorizont hat, weil Teilaufgaben, Anforderungsbereiche und Punkte von dort kommen.
        Du kannst die Aufgabenstellung, die Antwortvorlage oder beides gestalten.</p>
        <p class="mag-hinweis"><strong>Aufgabenstellung gestalten:</strong> Der Fragetext kommt in
        farbige Karten – eine Karte je Teilaufgabe, vorn eine Marke (1, 2a, 2b; im Kurztest a, b),
        hinten die Punkte. Eine Kurztest-Aufgabe ohne Teile bekommt eine Karte. Links steht der Anforderungsbereich, der Operator wird fett in der AFB-Farbe
        hervorgehoben (AFB I grün, II orange, III rot). Der Wortlaut bleibt gleich.</p>
        <p class="mag-hinweis"><strong>Antwortvorlage gestalten:</strong> Statt eines leeren weißen
        Eingabefelds sehen die Lernenden einen Antwortkasten mit Kopfzeile – einen je Teilaufgabe, mit
        derselben Marke wie in der Aufgabenstellung. So schreiben sie jede Antwort an die richtige Stelle, und die Erweiterung kann sie
        beim Bewerten sicher zuordnen. Die Kopfzeile zählt beim Bewerten nicht als Schülertext.</p>
        <p class="mag-hinweis"><strong>Nichts wird automatisch gespeichert.</strong> Die Erweiterung
        fügt das Layout nur in das geöffnete Formular ein. Gefällt es dir, speicherst du mit
        „Änderungen speichern". Sonst „Abbrechen" – dann bleibt die Aufgabe, wie sie war.</p>
      </details>
      <div class="mag-status" data-rolle="vstatus"></div>
      <label>Was möchtest du gestalten?</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAufgabe"> Aufgabenstellung</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAntwort"> Antwortvorlage</label>
      <div class="mag-hinweis">Beides zusammen ist der Normalfall: Aufgabe und Antwortkasten tragen dann
      dieselbe Marke (1, 2a, 2b …), dieselbe AFB-Farbe und dieselben Punkte.</div>

      <div data-rolle="lseca" hidden>
        <div class="mag-hinweis">Der Fragetext kommt ins AFB-Kartendesign. Text und Bilder bleiben
        erhalten, nur die Gestaltung ändert sich. Material (M1, M2 …) bleibt außerhalb der Karten.</div>
        <label class="mag-haken" data-rolle="lpunktezeile"><input type="checkbox" data-opt="kartePunkte"> Punkte je Teilaufgabe anzeigen</label>
        <div class="mag-hinweis" data-rolle="lpunktehinweis">Moodle zeigt nur die Gesamtpunktzahl der Aufgabe. Bei mehreren
        Teilaufgaben sehen die Lernenden so, wie viel jede einzelne bringt.</div>
        <div class="mag-hinweis" data-rolle="lahinweise"></div>
        <label>Vorschau – so sieht die Aufgabe aus</label>
        <div class="mag-vorschau" data-rolle="lavorschau"></div>
      </div>

      <div data-rolle="lsecv" hidden>
        <label class="mag-haken"><input type="checkbox" data-opt="afbFarben"> Farben nach Anforderungsbereich</label>
        <div class="mag-hinweis">AFB I grün, AFB II orange, AFB III rot. Ohne Häkchen: neutrales Grau.</div>
        <label class="mag-haken"><input type="checkbox" data-opt="vorlagePunkte"> Punkte anzeigen</label>
        <div class="mag-hinweis">z. B. „(2 Punkte)" – die Lernenden sehen, wie ausführlich sie antworten sollten.</div>
        <label class="mag-haken"><input type="checkbox" data-opt="vorlageAfb"> Anforderungsbereich anzeigen</label>
        <div class="mag-hinweis">z. B. „AFB II" – nur, wenn er bekannt ist (Klausur: aus dem Horizont;
        Kurztest: wenn „AFB …" in der Aufgabenstellung steht).</div>
        <div class="mag-hinweis" data-rolle="vformat" hidden></div>
        <label>Vorschau – so sieht das Eingabefeld aus</label>
        <div class="mag-vorschau" data-rolle="vvorschau"></div>
      </div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="lein">Ins Formular einfügen</button>
      </div>
      <p class="mag-hinweis">Eingefügt wird nur ins Formular. Speichern mit „Änderungen speichern" –
      oder „Abbrechen", wenn es dir nicht gefällt.</p>
    </div>

    <div class="mag-inhalt" data-panel="korrektur" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Hier werden alle Antworten zu dieser Aufgabe mit KI-Hilfe bewertet und
        danach mit Punkten und Rückmeldung in Moodle eingetragen. Maßstab ist der Erwartungshorizont
        der Aufgabe (Reiter „Horizont").</p>
      </details>
      <details class="mag-details mag-hilfe" data-rolle="khilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis"><strong>1 · Bewertungsprompt kopieren:</strong> Die Erweiterung packt
        Erwartungshorizont, Einstellungen und alle Antworten in einen Prompt. Namen gehen nicht mit –
        die Antworten sind nur nummeriert.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Die KI fragt
        zuerst: <em>gemeinsam durchgehen</em> (Arbeit für Arbeit, du kannst jede ändern – empfohlen) oder
        <em>automatisch</em>. Die KI beurteilt nur: Stufe je Aufgabe, Sprachfehler, Begründung,
        Rückmeldung. Sie rechnet keine Punkte.</p>
        <p class="mag-hinweis"><strong>3 · Antwort der KI hier einfügen.</strong> Die Erweiterung rechnet
        Punkte und Rechtschreibabzug und zeigt jede Bewertung zur Kontrolle („bisher → neu").</p>
        <p class="mag-hinweis"><strong>4 · Eintragen.</strong> Gemeinsam besprochene Arbeiten lassen sich
        direkt eintragen. Automatisch bewertete musst du einmal ansehen – überspringen geht nur mit
        ausdrücklicher Bestätigung.</p>
      </details>
      <div class="mag-status" data-rolle="kstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-rahmen-titel">Diese Angaben gehen in den Prompt und in die Rechnung</div>
        <div data-rolle="krahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zueinst">ändern</button>
      </div>
      <label>Abgaben je Durchgang</label>
      <select data-rolle="kgroesse"></select>
      <div class="mag-hinweis" data-rolle="kgroessehinweis"></div>
      <div class="mag-hinweis">Eine KI kann pro Antwort nur begrenzt viel Text schreiben. Bei vielen oder
      langen Arbeiten bricht sie sonst mitten im Ergebnis ab oder wird ungenau. Deshalb teilt die
      Erweiterung die Lerngruppe in Portionen – den Vorschlag rechnet sie aus der Textlänge. Geteilt
      wird immer nach Personen, nie nach Aufgaben: Jede Arbeit wird als Ganzes bewertet.</div>
      <label>1 · Bewertungsprompt mit allen Antworten kopieren</label>
      <div class="mag-reihe" data-rolle="kknoepfe"></div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kedit">✏️ Prompt anpassen</button>
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="krohdaten">📋 Rohdaten</button>
      </div>
      <label>2 · Ergebnis der KI einfügen</label>
      <div class="mag-hinweis">Hier den Codeblock einfügen, den die KI am Ende ausgibt – nicht den Text
      davor. <strong>Bei mehreren Teilen:</strong> Teil 1 kopieren → in die KI → Ergebnis hier einfügen.
      Dann Teil 2 im <em>selben</em> KI-Chat einfügen und sein Ergebnis <em>unter</em> das erste in dieses
      Feld setzen – alle Teile untereinander. Die Erweiterung setzt sie zusammen und meldet, welche
      Arbeiten noch fehlen.</div>
      <textarea data-rolle="kjson" rows="5" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="kpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-hinweis" data-rolle="rsabgleich" hidden></div>
      <div class="mag-liste" data-rolle="kliste"></div>
      <div class="mag-protokoll" data-rolle="klog" hidden></div>
      <div class="mag-reihe" data-rolle="keintragen" hidden>
        <button class="mag-btn mag-btn-ok" data-tu="kschreiben">Alle eintragen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="einst" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="mag-hinweis">Grundangaben für alle Aufgaben: Fach, Jahrgang, Kursniveau, Anrede, Rechtschreibung. Sie stehen als Rahmendaten im Prompt und steuern die Rechnung. Was nur für eine Aufgabe gilt (Modus, Feedbacklänge), stellst du im Reiter „Horizont" der Aufgabe ein.</p>
      </details>
      <div class="mag-status" data-rolle="estatus"></div>
      <p class="mag-hinweis">Diese Angaben stehen später als Rahmendaten im Prompt und
      steuern, wie die Erweiterung rechnet. Bitte einmal durchsehen, bevor du den Prompt
      kopierst — nachträglich lässt sich ein Horizont nur neu erzeugen.</p>
      <label>Fach</label><input type="text" data-opt="fach" placeholder="z. B. Chemie">
      <label>Jahrgang</label><input type="text" data-opt="jahrgang" placeholder="z. B. 10">
      <div class="mag-hinweis" data-rolle="anredehinweis"></div>
      <label>Kursniveau</label>
      <select data-opt="kursniveau">
        <option value="G">G — gymnasial</option>
        <option value="M">M — mittel</option>
        <option value="E">E — einfach</option>
      </select>
      <label>Punkteschritte</label>
      <select data-opt="punkteschritte">
        <option value="0.25">0,25</option><option value="0.5">0,5 (Standard)</option>
        <option value="1">1,0 — nur ganze Punkte</option>
      </select>
      <label>Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl</label>
      <select data-opt="rechtschreibung">
        <option value="0">0 % — kein Abzug</option><option value="5">5 %</option>
        <option value="10">10 % (Standard Mittelstufe)</option><option value="15">15 %</option>
        <option value="20">20 %</option><option value="25">25 % (Oberstufe, Klausuren)</option>
        <option value="30">30 %</option>
      </select>
      <div class="mag-hinweis" data-rolle="rshinweis"></div>
      <label class="mag-haken"><input type="checkbox" data-opt="kiHinweis"> KI-Transparenzhinweis unter das Feedback</label>
      <label class="mag-haken"><input type="checkbox" data-opt="entferneQuellen"> Quellenangaben entfernen</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="esichern">Speichern und weiter</button>
        <button class="mag-btn mag-btn-grau" data-tu="eabbruch">Verwerfen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="prompt" hidden>
      <label data-rolle="ptitel">Prompt bearbeiten</label>
      <textarea data-rolle="ptext" rows="16"></textarea>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="psichern">Speichern</button>
        <button class="mag-btn mag-btn-rand" data-tu="pzurueck">↺ Original</button>
        <button class="mag-btn mag-btn-grau" data-tu="pabbruch">Abbrechen</button>
      </div>
    </div>`,W.querySelector(`.mag-version`).textContent=e;let vt=W.querySelector(`.mag-reiter`);_t.forEach((e,t)=>{let n=document.createElement(`button`);n.className=`mag-tab`+(t===0?` aktiv`:``),n.dataset.tab=e[0],n.textContent=e[1],vt.appendChild(n)});function yt(e,t,n){let r=document.createElement(`button`);return r.className=t,r.dataset.tu=n,r.textContent=e,r}let bt=W.querySelector(`[data-rolle="hknoepfe"]`);u!==`bearbeiten`&&bt.appendChild(yt(`In die Frage eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));let G=O(`button`,`mag-knopf`);G.title=`Moodle AI Freitext Grader`;let xt=document.createElement(`img`);xt.className=`mag-knopf-bild`,xt.alt=`Moodle AI Freitext Grader`;try{xt.src=t.runtime.getURL(`icon/128.png`)}catch{G.textContent=`AI`}xt.src&&G.appendChild(xt);let K=e=>W.querySelector(`[data-rolle="`+e+`"]`),q=null,J=null,St=_t[0][0],Ct=!1,wt=!1,Tt=!1;if(typeof IntersectionObserver<`u`){let e=new IntersectionObserver(t=>t.forEach(t=>{t.isIntersecting&&(t.target.dataset.gesehen=`1`,e.unobserve(t.target))}),{threshold:.5}),t=K(`kliste`);t&&new MutationObserver(t=>t.forEach(t=>t.addedNodes.forEach(t=>{t.nodeType===1&&t.classList.contains(`mag-karte`)&&(Tt=!1,e.observe(t))}))).observe(t,{childList:!0})}function Et(){return u===`bearbeiten`&&!new URLSearchParams(location.search).get(`id`)}function Dt(){let e=Ie();if(e.wer===`coach`)return`kurztest`;if(e.wer===`grader`)return`klausur`;let t=P();return!/(^|\n)\s*(?:[a-h]\)|aufgabe\s*\d|\d+[.)]\s)/i.test(t)&&(F()||0)<=3?`kurztest`:`klausur`}let Y=u===`bearbeiten`?Dt():`klausur`,Ot={kurztest:[[`Kurz`,`Kurz – 1–2 Sätze`],[`Mittel`,`Mittel – 3–5 Sätze (Standard)`]],klausur:[[`Mittel`,`Mittel – 3–4 Sätze je Teilaufgabe`],[`Ausführlich`,`Ausführlich – ein Absatz je Teilaufgabe (Standard)`],[`Umfangreich`,`Umfangreich – dazu Abschnitt Operatorerfüllung`]]},kt={kurztest:`Mittel`,klausur:`Ausführlich`},X=(()=>{let e=u===`bearbeiten`?ae(I()):null;return e&&Ot[Y].some(t=>t[0]===e)?e:kt[Y]})();function At(){let e=K(`hfeedbacksel`);e&&(e.innerHTML=``,Ot[Y].forEach(([t,n])=>{let r=document.createElement(`option`);r.value=t,r.textContent=n,e.appendChild(r)}),Ot[Y].some(e=>e[0]===X)||(X=kt[Y]),e.value=X,K(`hfeedbackhinweis`).textContent=Y===`kurztest`?`Bei „Kurz" und „Mittel" passt die ganze Klasse meist in einen Durchgang.`:`Klausuren werden in Portionen bewertet; längeres Feedback heißt kleinere Portionen.`)}let Z=null;u===`bearbeiten`&&bt.appendChild(yt(`3 · In die Aufgabe eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));function jt(){let e=K(`hmodus`);if(e&&(e.hidden=u!==`bearbeiten`,K(`hmodussel`).value=Y,K(`hmodushinweis`).textContent=Y===`kurztest`?`Kurztest: kurze Antworten, Horizont mit Kernaussage und „Auch richtig". Bewertet wird auf der Übersicht, alle Kurztest-Aufgaben eines Tests zusammen. Layout-Vorlage: ein Kasten „Deine Antwort".`:`Klausur: Horizont je Teilaufgabe mit Punkten, Operator und AFB, dazu eine Layout-Vorlage mit einem Kasten je Teilaufgabe. Bewertet wird auf der Einzelseite der Aufgabe, in Portionen, mit Review vor dem Eintragen.`,At(),H(),u===`bearbeiten`)){let e=bt.querySelector(`[data-tu="hschreiben"]`);e&&(e.hidden=!1)}}u===`bearbeiten`&&(K(`hfeedbacksel`).addEventListener(`change`,()=>{X=K(`hfeedbacksel`).value}),K(`hmodussel`).addEventListener(`change`,()=>{Y=K(`hmodussel`).value,X=kt[Y],q=null,Z=null,K(`hliste`).innerHTML=``,K(`hknoepfe`).hidden=!0,Q(`hstatus`,`Modus: `+(Y===`kurztest`?`Kurztest`:`Klausur`)+`. Bitte den Prompt jetzt (neu) kopieren.`),jt()})),jt();function Mt(e){let t=M(String(e||``).replace(/\r/g,``)).trim().split(/\n\s*\n/).filter(e=>e.trim()).map(e=>`<p>`+k(e.trim()).replace(/\n/g,`<br>`)+`</p>`).join(``);return`<p>`+n+`</p><p>[Rechtschreibung: `+A(T.rechtschreibung)+`%]</p><p>[Feedback: `+X+`]</p>`+t}function Nt(e,t){try{Q(t,`Ins Formular eingesetzt: `+Object.keys(e).map(t=>t+` (`+_(t,e[t])+`)`).join(`, `)+`. Wird mit „Änderungen speichern" zusammen mit der Frage gespeichert.`)}catch(e){Q(t,`Fehler: `+e.message,!0)}}function Pt(){if(u===`bearbeiten`)return location.href;let e=new URLSearchParams(location.search),t=e.get(`qid`),n=e.get(`id`)||e.get(`cmid`);return t?location.origin+`/question/bank/editquestion/question.php?id=`+t+(n?`&cmid=`+n:``):null}function Q(e,t,n){let r=K(e);r&&(r.textContent=t||``,r.className=`mag-status`+(t?n?` fehler`:` ok`:``))}function Ft(e){let t=K(e);return t.hidden=!1,t.innerHTML=``,e=>{t.appendChild(O(`div`,`mag-logzeile`,e)),t.scrollTop=t.scrollHeight}}function It(){return new Promise(e=>{if(!(t!==void 0&&t.storage))return e();t.storage.local.get([`magSettings`],t=>{t.magSettings&&(T=Object.assign({},w,t.magSettings)),e()})})}function Lt(){t!==void 0&&t.storage&&t.storage.local.set({magSettings:T})}function Rt(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;e.type===`checkbox`?e.checked=!!T[t]:e.value=T[t]==null?``:T[t]}),Ut()}function zt(){W.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;T[t]=e.type===`checkbox`?e.checked:e.value}),T.promptHorizont=null,T.promptKorrektur=null,Lt(),Ut()}function Bt(){let e=parseFloat(T.rechtschreibung)===0?`Rechtschreibung: kein Abzug`:`Rechtschreibung: `+T.rechtschreibung+` %`;return[T.fach||`⚠ Fach fehlt`,`Jahrgang `+(T.jahrgang||`⚠ fehlt`),`Niveau `+(et[T.kursniveau]||T.kursniveau).split(` `)[0],`Feedback `+S(),e,`Schritte `+A(T.punkteschritte)].join(` · `)}function Vt(){return!String(T.fach||``).trim()||!String(T.jahrgang||``).trim()}function Ht(){let e=Bt(),t=Vt();[`hrahmen`,`krahmen`].forEach(n=>{let r=K(n);r&&(r.textContent=e,r.parentElement.classList.toggle(`unvollstaendig`,t))})}function Ut(){Ht();let e=K(`anredehinweis`);e&&(e.textContent=`Im Feedback wird „`+Te()+` …" verwendet.`);let t=K(`rshinweis`);t&&(t.textContent=parseFloat(T.rechtschreibung)===0?`Kein Punktabzug — das Sprachfeedback wird trotzdem geschrieben.`:`Voller Abzug ab `+A(le[2][0])+` Fehlern je 100 Wörtern; unter 40 Wörtern zählt die absolute Fehlerzahl.`);let n=K(`vvorschau`),r=Ye();n&&De(n,r||`<p class="mag-hinweis">Im Horizont sind keine Teilaufgaben erkennbar – daraus entstehen die Kästen.</p>`);let i=K(`vformat`);i&&(i.hidden=Je(),i.textContent=`Hinweis: Das Antwortformat dieser Aufgabe ist nicht „HTML-Editor". Beim Einfügen stellt die Erweiterung es auf „HTML-Editor" um – „Nur Text" kann kein Layout darstellen.`),H();let a=K(`vhorizont`);a&&De(a,Y===`kurztest`&&u===`bearbeiten`?Z?Mt(Z):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`:q?$e(q):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`)}function $(e){W.querySelectorAll(`.mag-inhalt`).forEach(t=>{t.hidden=t.dataset.panel!==e}),W.querySelectorAll(`.mag-tab`).forEach(t=>t.classList.toggle(`aktiv`,t.dataset.tab===e));let t=_t.some(t=>t[0]===e);W.querySelector(`.mag-reiter`).hidden=!t,t&&e!==`einst`&&(St=e),e===`vorlage`&&Ut(),e===`korrektur`&&$t()}let Wt=null;function Gt(e,t,n,r){navigator.clipboard.writeText(e).then(()=>{let i=n+`  (`+e.length.toLocaleString(`de-DE`)+` Zeichen)`;if(Q(t,i),!r||!K(r))return;clearInterval(Wt);let a=3;Q(t,i+` — weiter in `+a+` s`),Wt=setInterval(()=>{if(a--,a>0)return Q(t,i+` — weiter in `+a+` s`);clearInterval(Wt),Wt=null,Q(t,i+` — jetzt die Antwort der KI einfügen.`);let e=K(r);e.focus(),e.scrollIntoView({block:`nearest`})},1e3)}).catch(()=>Q(t,`Kopieren fehlgeschlagen — Text bitte von Hand markieren.`,!0))}function Kt(){let e=K(`hjson`).value.trim();if(!e)return Q(`hstatus`,`Bitte erst die Antwort der KI einfügen.`,!0);if(u===`bearbeiten`&&Y===`kurztest`)return qt(e);try{let t=pt(e,`aufgaben`).map(e=>({nr:fe(e.nr),schlagwort:e.schlagwort||``,afb:e.afb||``,punkte:e.punkte==null?null:j(e.punkte),operator:e.operator||``,horizont:e.horizont||e.text||``})).filter(e=>/^\d{1,2}[a-h]?$/.test(e.nr)).sort((e,t)=>parseInt(e.nr,10)-parseInt(t.nr,10)||e.nr.localeCompare(t.nr));if(!t.length)throw Error(`Keine Aufgaben im JSON.`);let{doppelt:n}=mt(t,t.map(e=>e.nr));if(n.length)throw Error(`Aufgabe `+n.join(`, `)+` kommt doppelt vor.`);let r=t.reduce((e,t)=>e+(t.punkte||0),0),i=F();q=t;let a=K(`hliste`);a.innerHTML=``,t.forEach(e=>{let t=O(`div`,`mag-karte`);t.appendChild(O(`div`,`mag-kartenkopf`,`Aufgabe `+e.nr+(e.afb?` · AFB `+e.afb:``)+(e.schlagwort?` · `+e.schlagwort:``)+(e.punkte==null?``:`  (`+A(e.punkte)+` P.)`)));let n=O(`textarea`,`mag-kartentext`);n.value=N(e.horizont),n.rows=5,n.addEventListener(`input`,()=>{e.horizont=n.value}),t.appendChild(n),a.appendChild(t)});let o=t.length+` Aufgaben gelesen.`;i&&Math.abs(r-i)>.005&&(o+=`  ⚠ Punktsumme `+A(r)+` weicht von der Fragenpunktzahl `+A(i)+` ab — die Erweiterung rechnet sie beim Bewerten um.`),u===`bearbeiten`&&(o+=`  Dann „3 · In die Aufgabe eintragen".`),Q(`hstatus`,o),K(`hknoepfe`).hidden=!1,Ut()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}function qt(e){try{let t=pt(e,`horizonte`).find(e=>e&&(e.text||e.horizont));if(!t)throw Error(`Kein Horizont im JSON (erwartet: "horizonte").`);Z=String(t.text||t.horizont).trim();let n=K(`hliste`);n.innerHTML=``;let r=O(`div`,`mag-karte`);r.appendChild(O(`div`,`mag-kartenkopf`,`Kurztest-Horizont`));let i=O(`textarea`,`mag-kartentext`);i.value=Z,i.rows=12,i.addEventListener(`input`,()=>{Z=i.value}),r.appendChild(i),n.appendChild(r),Q(`hstatus`,`Horizont gelesen. Prüfen, bei Bedarf ändern, dann „In die Frage eintragen".`),K(`hknoepfe`).hidden=!1,jt()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function Jt(e){if(u===`bearbeiten`&&Y===`kurztest`){if(!Z)return Q(`hstatus`,`Es liegt noch kein geprüfter Horizont vor.`,!0);let t={"graderinfo[text]":Mt(Z)};return Et()?(Nt(t,`hstatus`),H()):(await Zt(t,e,Ft(`hlog`),`hstatus`),e||Yt(t),H(),setTimeout(Qe,50))}if(Et()&&q)return Nt({"graderinfo[text]":$e(q)},`hstatus`),H();let t=`hstatus`;if(!q)return Q(t,`Es liegt noch kein geprüfter Horizont vor — bitte erst im Reiter „Horizont" die Antwort der KI einlesen und prüfen.`,!0);if(!Pt())return Q(t,`Die Adresse der Frage lässt sich hier nicht bestimmen — bitte die Frage zum Bearbeiten öffnen.`,!0);let n=Ft(`hlog`),r={"graderinfo[text]":$e(q)};await Zt(r,e,n,t),!e&&u===`bearbeiten`&&Yt(r),H(),setTimeout(Qe,50)}function Yt(e){try{Object.keys(e).forEach(t=>_(t,e[t]))}catch{}}function Xt(){try{let e=[],t=``;if(T.layoutAufgabe!==!1){let t=Xe();if(t.fehler)return Q(`vstatus`,t.fehler,!0);_(`questiontext[text]`,t.html),e.push(`Aufgabenstellung`)}if(T.layoutAntwort!==!1){let n=Ye();if(!n)return Q(`vstatus`,`Für die Antwortvorlage fehlen die Teilaufgaben aus dem Horizont.`,!0);if(!Je()){let e=D(`[name="responseformat"]`);e.value=`editor`,e.dispatchEvent(new Event(`change`,{bubbles:!0})),t=` Das Antwortformat wurde auf „HTML-Editor" umgestellt – nur so wird das Layout dargestellt.`}_(`responsetemplate[text]`,n),e.push(`Antwortvorlage`)}if(!e.length)return Q(`vstatus`,`Bitte oben auswählen, was gestaltet werden soll.`,!0);Q(`vstatus`,e.join(` und `)+` ins Formular eingefügt.`+t+` Gefällt es dir, „Änderungen speichern" – sonst „Abbrechen".`),Ut()}catch(e){Q(`vstatus`,`Fehler: `+e.message,!0)}}async function Zt(e,t,n,r){let i=Object.keys(e);try{if(Q(r,t?`Trockenlauf läuft …`:`Wird eingetragen …`),u!==`bearbeiten`){let a=Pt(),o=[...(await Ae(a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!o)throw Error(`Bearbeiten-Formular der Frage nicht erreichbar.`);let s=je(o);if(i.forEach(r=>{if(!s.has(r))throw Error(`Feld „`+r+`" nicht im Formular`);n((t?`✓ `:``)+`Feld `+r+` vorhanden`+(N(s.get(r)).length?` (enthält schon Text!)`:``)),t||s.set(r,e[r])}),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);let c=(o.querySelector(`[name="name"]`)||{}).value||``,l=await Ne(await Me(o,s,a),c,a),u=[...(await Ae(l||a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),d=0;return i.forEach(t=>{let r=u&&u.querySelector(`[name="`+CSS.escape(t)+`"]`),i=!!r&&Pe(r.value,e[t]);n((i?`✓ `:`✗ `)+t+(i?` eingetragen`:` NICHT angekommen`)),i||d++}),l||n(`⚠ Neue Fragenversion nicht auffindbar — Gegenprobe unsicher.`),Q(r,d?d+` Feld(er) nicht angekommen — Protokoll lesen.`:`In die Frage eingetragen und gegengeprüft.`,d>0)}let a=await Fe(e,t);if(a.bericht.forEach(e=>n((t?`✓ `:``)+`Feld `+e.feld+` vorhanden`+(e.belegt?` (enthält schon Text!)`:``))),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);a.warnung&&n(`⚠ `+a.warnung);let o=0;if((a.ergebnis||[]).forEach(e=>{n((e.ok?`✓ `:`✗ `)+e.feld+(e.ok?` eingetragen`:` NICHT angekommen`)),e.ok||o++}),o)return Q(r,o+` Feld(er) nicht angekommen — Protokoll lesen.`,!0);n(`✓ gespeichert und gegengeprüft`),sn(a.neueUrl),Q(r,a.neueUrl?`Eingetragen und gegengeprüft. Diese Seite zeigt jetzt einen veralteten Stand.`:`Eingetragen und gegengeprüft. Bitte die Frage neu öffnen — Moodle hat beim Speichern eine neue Version angelegt.`,!1)}catch(e){n(`✗ `+e.message),Q(r,`Fehler: `+e.message,!0)}}function Qt(e){let t=e.length?e.reduce((e,t)=>e+Se(t.text),0)/e.length:0,n=Math.max(200,t*6);return Math.max(1,Math.min(30,Math.floor(22e3/n)))}function $t(){let e=L(),t=K(`kgroesse`);t.options.length||([1,2,3,5,8,10,15,20,30].forEach(e=>t.appendChild(new Option(e+` Abgaben`,e))),t.value=String(Qt(e)),t.addEventListener(`change`,$t));let n=e.length?Math.round(e.reduce((e,t)=>e+Se(t.text),0)/e.length):0;K(`kgroessehinweis`).textContent=e.length+` Abgaben, im Schnitt `+n+` Wörter. Vorschlag: `+Qt(e)+` je Durchgang.`;let r=I()||T.horizontLokal,i=parseInt(t.value,10)||5,a=Math.ceil(e.length/i)||1,o=K(`kknoepfe`);o.innerHTML=``;for(let t=0;t<a;t++){let n=t*i,s=Math.min(n+i,e.length),c=O(`button`,`mag-btn mag-btn-primary`,a===1?`📋 Bewertungsprompt kopieren`:`📋 Teil `+(t+1)+` kopieren (Arbeit `+(n+1)+`–`+s+`)`);c.addEventListener(`click`,()=>{if(!r)return Q(`kstatus`,`Kein Erwartungshorizont — bitte erst den Reiter „Horizont" verwenden.`,!0);Gt(lt(e.slice(n,s),r,t+1,a),`kstatus`,a===1?`Prompt kopiert.`:`Teil `+(t+1)+` kopiert.`,`kjson`)}),o.appendChild(c)}}let en=!1;function tn(){if(wt)return Q(`kstatus`,Ct?`Kurztest – bitte auf der Übersicht bewerten (Link oben).`:`Gesperrt: Antworten zu mehreren Fragen auf dieser Seite. Bitte jede Frage einzeln über die Übersicht öffnen.`,!0);let e=K(`kjson`).value.trim();if(!e)return Q(`kstatus`,`Bitte erst die Antworten der KI einfügen.`,!0);try{let t=L(),n=I()||T.horizontLokal,r=Le(n),i=pt(e,`bewertungen`).filter(e=>e&&e.nr!=null),{fehlend:a,doppelt:o}=mt(i,t.map(e=>e.nr));if(o.length)throw Error(`Abgabe `+o.join(`, `)+` kommt doppelt vor.`);if(a.length&&!en){let e=K(`kliste`);e.innerHTML=``,K(`keintragen`).hidden=!0,J=null;let n=K(`rsabgleich`);n&&(n.hidden=!0);let r=t.length-a.length;Q(`kstatus`,`Teil erkannt: `+r+` von `+t.length+` Abgaben. Nächsten Teil einfach dazu einfügen — geprüft wird, sobald alle da sind. (Es fehlen: `+a.join(`, `)+`)`);let i=O(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`Trotzdem nur diese `+r+` prüfen`);i.addEventListener(`click`,()=>{en=!0,tn()}),e.appendChild(i);return}let s=parseFloat(T.rechtschreibung)||0,c=x(n),l=oe(n),u=c!=null&&!E?c:s,d=l??(parseFloat(T.punkteschritte)||.5),f=K(`kliste`);f.innerHTML=``;let p=K(`rsabgleich`);if(p){if(p.innerHTML=``,c!=null&&c!==s){p.hidden=!1,p.appendChild(O(`div`,null,`⚠ Im Horizont steht `+A(c)+` % Rechtschreibung, eingestellt sind `+A(s)+` %. Es gilt gerade: `+(E?A(s)+` % (Einstellung)`:A(c)+` % (Horizont)`)+`.`));let e=O(`button`,`mag-btn mag-btn-grau`,E?`Stattdessen den Horizont-Wert verwenden`:`Stattdessen `+A(s)+` % (Einstellung) verwenden`);e.addEventListener(`click`,()=>{E=!E,tn()}),p.appendChild(e)}else p.hidden=!0}J=[];let m=0;i.forEach(e=>{let n=t.find(t=>t.nr===Number(e.nr));if(!n)return;let i=ze(n,e,r,u,d),a=ut(e,i,r);if(Math.abs(i.gesamt-n.ist)<.005&&!n.kommentarfeld){m++;return}J.push({nr:n.nr,markfeld:n.markfeld,kommentarfeld:n.kommentarfeld,punkte:i.gesamt,feedbackHtml:dt(a),text:a});let o=O(`div`,`mag-karte`);e.besprochen===!0&&(o.dataset.gesehen=`1`,o.dataset.besprochen=`1`),o.appendChild(O(`div`,`mag-kartenkopf`,(e.besprochen===!0?`✓ besprochen · `:``)+`Arbeit `+n.nr+`:  bisher `+A(n.ist)+` → neu `+A(i.gesamt)+` von `+A(i.max)+` P.`+(i.abzug>.004?`   (−`+A(i.abzug)+` P. Sprache)`:``))),o.appendChild(O(`div`,`mag-kartenzeile`,i.teil.map(e=>`A`+e.nr+`: `+e.prozent+`%`).join(`   `)+`   ·   `+i.wortzahl+` Wörter, `+A(i.fehlerDichte)+` Fehler/100`+(i.fehlendeAufgaben.length?`   ·   ⚠ Aufgabe `+i.fehlendeAufgaben.join(`, `)+` von der KI nicht bewertet (0 %)`:``)));let s=O(`textarea`,`mag-kartentext`);s.value=a,s.rows=6;let c=J[J.length-1];s.addEventListener(`input`,()=>{c.text=s.value,c.feedbackHtml=dt(s.value)}),o.appendChild(s),f.appendChild(o)});let h=i.filter(e=>e.besprochen===!0).length,ee=J.length+` Arbeiten vorbereitet.`+(h===i.length?` Alle gemeinsam besprochen – du kannst direkt eintragen.`:h?` `+h+` besprochen, `+(i.length-h)+` automatisch bewertet – diese bitte ansehen.`:` Automatisch bewertet – bitte jede Arbeit einmal ansehen.`);m&&(ee+=`  `+m+` ohne Änderung übersprungen.`),a.length&&(ee+=`  ⚠ Es fehlen die Abgaben `+a.join(`, `)+` — bitte den fehlenden Teil nachreichen.`),Q(`kstatus`,ee,a.length>0),K(`keintragen`).hidden=J.length===0}catch(e){Q(`kstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function nn(e){if(!J||!J.length)return;let t=Ft(`klog`);try{Q(`kstatus`,e?`Trockenlauf läuft …`:`Wird eingetragen …`);let n=await gt(J,e,t);if(e)return Q(`kstatus`,n.fehler?n.fehler+` Abgabe(n) nicht auf der Seite — Protokoll lesen.`:`Alles vorhanden. Jetzt eintragen.`,n.fehler>0);if(t(`— `+n.ok+` eingetragen · `+n.fehler+` fehlgeschlagen —`),n.fehler)Q(`kstatus`,n.fehler+` fehlgeschlagen — Protokoll lesen.`,!0);else{let e=new URLSearchParams(location.search),t=e.get(`id`),r=be(await _e(t),e.get(`slot`),e.get(`qid`)),i=null,a=`Fenster schließt`;r&&r.naechste?(i=ve(t,r.naechste),a=`Weiter zur Klausur-Frage `+(r.index+2)+` von `+r.gesamt):r&&(i=ye(t),a=`Alle Klausur-Fragen bewertet — zurück zur Übersicht`);let o=3,s=n.ok+` Bewertungen eingetragen und gegengeprüft.`;Q(`kstatus`,s+` `+a+` in `+o+` s …`);let c=setInterval(()=>{if(o--,o>0)return Q(`kstatus`,s+` `+a+` in `+o+` s …`);clearInterval(c),an.zu(),i?location.href=i:location.reload()},1e3)}}catch(e){t(`✗ `+e.message),Q(`kstatus`,`Fehler: `+e.message,!0)}}let rn=`horizont`,an={einst:()=>{Rt(),$(`einst`)},zueinst:()=>{Rt(),$(`einst`)},zu:()=>{W.classList.remove(`offen`),G.classList.remove(`versteckt`)},hprompt:()=>Gt(at(),`hstatus`,`Prompt kopiert.`,`hjson`),hedit:()=>cn(`horizont`),hpruefen:Kt,hschreiben:()=>Jt(!1),hlokalsichern:()=>{T.horizontLokal=K(`hlokal`).value.trim(),Lt(),Q(`hstatus`,T.horizontLokal?`Horizont in der Erweiterung gespeichert (nicht in der Frage).`:`Gespeicherter Horizont gelöscht.`),$t()},lein:()=>Xt(),kedit:()=>cn(`korrektur`),kpruefen:tn,kschreiben:()=>{let e=me(`.mag-karte`,K(`kliste`)).filter(e=>e.dataset.gesehen!==`1`).length,t=W.querySelector(`[data-tu="kschreiben"]`);if(e&&!Tt)return Tt=!0,t&&(t.textContent=`⚠ Ja, `+e+` ungeprüft eintragen`),Q(`kstatus`,`⚠ `+e+` automatisch bewertete Arbeit(en) noch nicht angesehen. Bitte durchblättern. Willst du sie ungeprüft eintragen, bestätige das mit dem Knopf unten.`,!0);Tt=!1,t&&(t.textContent=`Alle eintragen`),nn(!1)},krohdaten:()=>Gt(JSON.stringify({stand:new Date().toLocaleString(`de-DE`),fach:T.fach,jahrgang:T.jahrgang,gesamtpunkte:F(),aufgabenstellung:P(),horizont:N(I()||T.horizontLokal),abgaben:L().map(e=>{let t=R(e.rohHtml,e.text);return{nr:e.nr,ist:e.ist,max:e.max,gegliedert:t.gegliedert,aufgaben:t.aufgaben}})},null,2),`kstatus`,`Rohdaten kopiert.`),esichern:()=>{if(zt(),Vt())return Q(`estatus`,`Fach und Jahrgang fehlen noch — beides steht im Prompt und bestimmt Anspruchsniveau und Anrede.`,!0);Q(`estatus`,``),$(u===`bearbeiten`?`horizont`:St===`einst`?`korrektur`:St)},eabbruch:()=>{Rt(),Q(`estatus`,``)},psichern:()=>{let e=K(`ptext`).value.trim(),t=e===(rn===`horizont`?U():st()).trim()?null:e;rn===`horizont`?T.promptHorizont=t:T.promptKorrektur=t,Lt(),$(St)},pzurueck:()=>{K(`ptext`).value=rn===`horizont`?U():st()},pabbruch:()=>$(St)},on=null;function sn(e){let t=W.querySelector(`.mag-banner`);if(t.hidden=!1,t.className=`mag-banner warnung`,t.innerHTML=``,t.appendChild(O(`div`,null,`Moodle hat beim Speichern eine neue Fassung der Frage angelegt. Dieses Formular zeigt den alten Stand — hier nichts mehr speichern!`)),!e)return;let n=O(`button`,`mag-btn mag-btn-ok`,`Zur neuen Fassung der Frage`),r=O(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`hier bleiben`);n.addEventListener(`click`,()=>{location.href=e}),t.appendChild(n),t.appendChild(r);let i=8,a=O(`div`,`mag-hinweis`,`Wechsel in `+i+` Sekunden …`);t.appendChild(a),r.addEventListener(`click`,()=>{clearInterval(on),on=null,a.textContent=`Wechsel angehalten. Diese Seite bitte nicht mehr speichern.`,r.remove()}),on=setInterval(()=>{if(i--,i<=0){clearInterval(on),location.href=e;return}a.textContent=`Wechsel in `+i+` Sekunden …`},1e3)}function cn(e){rn=e,K(`ptitel`).textContent=e===`horizont`?`Prompt für den Erwartungshorizont`:`Prompt für die Korrektur`;let t=e===`horizont`?T.promptHorizont:T.promptKorrektur;K(`ptext`).value=t&&t.trim()||(e===`horizont`?U():st()),$(`prompt`)}W.addEventListener(`click`,e=>{let t=e.target.closest(`.mag-tab`);if(t)return Wt&&=(clearInterval(Wt),null),t.dataset.tab===`einst`?an.einst():$(t.dataset.tab);let n=e.target.closest(`[data-tu]`);n&&an[n.dataset.tu]&&(e.preventDefault(),an[n.dataset.tu]())}),W.addEventListener(`paste`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;if(t===`hjson`&&setTimeout(Kt,0),t===`kjson`){let t=e.clipboardData&&e.clipboardData.getData(`text`);if(t){e.preventDefault();let n=e.target,r=n.value.replace(/\s+$/,``);n.value=r?r+`

`+t:t,n.scrollTop=n.scrollHeight}en=!1,setTimeout(tn,0)}});let ln=null;W.addEventListener(`input`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;t!==`hjson`&&t!==`kjson`||e.inputType===`insertFromPaste`||(t===`kjson`&&(en=!1),clearTimeout(ln),ln=setTimeout(()=>{e.target.value.trim()&&(t===`hjson`?Kt:tn)()},800))}),W.addEventListener(`change`,e=>{let t=e.target.closest(`[data-opt]`);t&&[`afbFarben`,`vorlagePunkte`,`vorlageAfb`,`kartePunkte`,`layoutAufgabe`,`layoutAntwort`].includes(t.dataset.opt)&&(T[t.dataset.opt]=t.checked,Lt(),Ut())}),G.addEventListener(`click`,()=>{W.classList.add(`offen`),G.classList.add(`versteckt`)}),It().then(()=>{try{let e=W.querySelector(`.mag-kopfbild`);e&&(e.src=t.runtime.getURL(`icon/128.png`))}catch{let e=W.querySelector(`.mag-kopfbild`);e&&e.remove()}document.body.appendChild(G),document.body.appendChild(W),Rt(),K(`hlokal`).value=T.horizontLokal||``;let e=Ie(),n=W.querySelector(`.mag-banner`),r=u===`bewertung`?new Set(me(`.que .graderinfo`).map(e=>e.innerText.trim()).filter(Boolean)).size:0;if(wt=r>1,r>1){n.hidden=!1,n.textContent=`Auf dieser Seite stehen Antworten zu `+r+` verschiedenen Fragen (Zufallsfrage). Bitte über die Übersicht jede Frage einzeln öffnen — sonst würde alles gegen einen einzigen Horizont bewertet.`,K(`kstatus`)&&Q(`kstatus`,`Gesperrt: mehrere Fragen auf einer Seite (siehe oben).`,!0);let e=W.querySelector(`[data-tu="kschreiben"]`);e&&(e.disabled=!0)}else if(e.wer===`coach`&&u===`bewertung`){wt=!0,Ct=!0,n.hidden=!1,n.textContent=`Diese Frage ist ein Kurztest. Kurztests werden auf der Übersicht des Tests bewertet – alle Kurztest-Fragen zusammen in einem Prompt. `;let e=new URLSearchParams(location.search).get(`id`);if(e){let t=document.createElement(`a`);t.href=ye(e),t.textContent=`Zur Übersicht →`,t.className=`mag-btn mag-btn-ok mag-btn-klein`,n.appendChild(t)}K(`kstatus`)&&Q(`kstatus`,`Kurztest – bitte auf der Übersicht bewerten (Link oben).`,!0);let t=W.querySelector(`[data-tu="kschreiben"]`);t&&(t.disabled=!0)}else!e.horizont&&u===`bewertung`&&!T.horizontLokal&&(n.hidden=!1,n.textContent=`Diese Frage hat noch keinen Erwartungshorizont. Er lässt sich hier nachtragen.`);let i=W.querySelector(`.mag-untertitel`);i&&(i.textContent=u===`bearbeiten`?`Aufgabe vorbereiten`:`Antworten bewerten`);let a;if(Vt()&&u!==`bearbeiten`?(a=`einst`,Q(`estatus`,`Bitte einmal ausfüllen: Fach und Jahrgang fehlen. Beides geht als Rahmendatum in den Prompt.`,!0)):a=u===`bewertung`&&!e.horizont&&!T.horizontLokal||u===`bearbeiten`?`horizont`:`korrektur`,$(a),Ht(),u===`bewertung`){let e=L().length;wt||Q(`kstatus`,e?e+` Arbeiten auf dieser Seite.`:`Keine Arbeiten gefunden.`);let t=K(`khilfe`);t&&(t.open=!T.khilfeGesehen,t.addEventListener(`toggle`,()=>{!t.open&&!T.khilfeGesehen&&(T.khilfeGesehen=!0,Lt())}))}else{Ze();let e=rt();e.length&&(K(`hmaterial`).hidden=!1,K(`hmaterial`).textContent=`In der Aufgabe stehen `+e.length+` Bild(er)/Datei(en): `+e.join(` · `)+` – bitte zusätzlich in den KI-Chat hochladen.`);let t=K(`hhilfe`);t&&(t.open=!T.hilfeGesehen,t.addEventListener(`toggle`,()=>{!t.open&&!T.hilfeGesehen&&(T.hilfeGesehen=!0,Lt())})),W.classList.add(`offen`),G.classList.add(`versteckt`)}})}function xe(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``,r={G:`G — gymnasial`,M:`M — mittel`,E:`E — einfach`},i={};try{t.storage.local.get([`magSettings`]).then(e=>{let t=e&&e.magSettings||{};i={fach:t.fach||``,jahrgang:t.jahrgang||``,niveau:r[t.kursniveau]||t.kursniveau||``}}).catch(()=>{})}catch{}let o=new URLSearchParams(location.search);if(o.get(`mode`)!==`grading`||o.get(`slot`)||o.get(`includeauto`)===`1`)return;let c=o.get(`id`);if(!c)return;let l=location.origin+location.pathname,u=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),d=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},f=e=>Number(e).toFixed(2).replace(`.`,`,`),p=e=>String(Number(e)).replace(`.`,`,`),m=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function ee(e,t,n){if(!e||typeof e!=`object`)return``;let r=t=>String(e[t]||``).trim(),i=r(`lob`),a=[[`Inhalt`,r(`inhalt`)],[`Rechtschreibung`,r(`rechtschreibung`)],[`Grammatik`,r(`grammatik`)],[`Tipp`,r(`tipp`)]].filter(([,e])=>e);if(!a.length&&!i)return``;if(!a.length)return`<p><strong><u>Feedback:</u></strong> `+m(i)+`</p>`;let o=a.map(([e])=>e),s=o.includes(`Grammatik`)?`Grammatik`:o.includes(`Rechtschreibung`)?`Rechtschreibung`:null,c=e=>`<span style="color:#767676;font-style:italic;"> (`+e+`)</span>`,l=!!(n&&n.gewicht>=5),u=e=>e>=5?`5 oder mehr Fehlerpunkte`:e===1?`1 Fehlerpunkt`:e+` Fehlerpunkte`,d=`<p><strong><u>Feedback</u></strong></p>`;return i&&(d+=`<p>`+m(i)+`</p>`),a.forEach(([e,r])=>{let i=``;n&&(e===`Inhalt`&&n.inhalt!=null?i=c(n.inhaltMax==null?f(n.inhalt)+` Punkte`:f(n.inhalt)+` von `+f(n.inhaltMax)+` Punkten`):e===s&&n.abzug&&(i=c(`−`+f(n.abzug)+` Punkte`+(n.gewicht==null?``:` — `+u(n.gewicht)+(l?`, höchste Stufe`:``))))),d+=`<p><u>`+e+`:</u> `+m(r)+i+`</p>`,e===`Inhalt`&&t&&(d+=`<p><u>So hättest du es schreiben können:</u> `+m(t)+`</p>`),e===s&&l&&(d+=`<p>In deiner Antwort häufen sich mehrere grundlegende Fehler — das ist die höchste Fehlerstufe. Es lohnt sich, gezielt daran zu arbeiten.</p>`)}),d}function g(e){let t=String(e||``).replace(/\r/g,``).match(/Kernaussage\s*:?\s*([\s\S]*?)(?=\n\s*(?:Muss enthalten|Auch richtig|Inhalt|Reicht nicht|Häufiger Fehler|Wichtigster Hinweis|Teile)\s*:|$)/i),n=t?t[1].replace(/\s+/g,` `).trim():``;return n.length>300?``:n}let _=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function v(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let y=e=>new Promise(t=>setTimeout(t,e)),re=(e,t,n)=>`${l}?id=${c}&mode=grading&slot=${e}&qid=${t}&grade=${n||`needsgrading`}&qperpage=100`,b=e=>`${u}/question/bank/editquestion/question.php?id=${e}&cmid=${c}`,x=e=>e&&e.slot&&e.qid?re(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``):null;async function ie(e){try{await navigator.clipboard.writeText(e)}catch{let t=_(`textarea`,`co-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}let ae=n,S=a;function oe(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function se(e){return s(oe(e).match(S))}function ce(e){let t=String(e||``).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&S.test(t[n])&&(t[n]=t[n].replace(S,``).trim(),t[n]||t.splice(n,1)),t.join(`
`).trim()}let C=/^\s*\[?\s*rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%?\s*\]?\s*$/i;function le(e){return`[Rechtschreibung: ${p(e)}%]`}function ue(e){let t=oe(ce(e)).match(C);return t?parseFloat(t[1].replace(`,`,`.`)):null}function de(e){let t=ce(e).split(`
`),n=t.findIndex(e=>e.trim());n>-1&&C.test(t[n].trim())&&t.splice(n,1);let r=t.findIndex(e=>e.trim());return r>-1&&/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/i.test(t[r])&&t.splice(r,1),t.join(`
`).trim()}function fe(e,t){let n=e.split(`
`),r=(n[1]||``).trim();return C.test(r)?e:(n.splice(1,0,le(t)),n.join(`
`))}let w=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,T={maxSprachabzug:10,kiHinweisText:w,promptOverride:``,horizontPromptOverride:``,nurMitMarker:!1,kompaktPrompt:!1},E={...T},D=!1;function pe(e){let t=E.maxSprachabzug??T.maxSprachabzug;return D?t:(e&&e.horizontProzent)??t}function me(){return new Promise(e=>{try{t.storage.local.get([`coachOptionen`],t=>{E={...T,...t&&t.coachOptionen?t.coachOptionen:{}},e(E)})}catch{e(E)}})}function O(e){return E={...E,...e},new Promise(e=>{try{t.storage.local.set({coachOptionen:E},e)}catch{e()}})}let he=[0,1/3,1/2,2/3,5/6,1];function ge(e,t){let n=Math.min(Math.max(0,Math.round(e)),he.length-1),r=t??E.maxSprachabzug??T.maxSprachabzug;return he[n]*r}let k=e=>(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0);function _e(e,t,n,r){let i=k(n),a=ge(i,r),o=e*t/100-e*a/100;return{gewicht:i,abzug:a,inhaltPunkte:Math.round(e*t/100*100)/100,abzugPunkte:Math.round(e*a/100*100)/100,punkte:Math.max(0,Math.round(o*100)/100)}}function ye(){let e=document.querySelector(`table`);return e?[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)||``).find(e=>/slot=/.test(e))||``,n=(t.match(/slot=(\d+)/)||[])[1],r=(t.match(/qid=(\d+)/)||[])[1];if(!n||!r)return null;let i=(e.cells[5]?e.cells[5].textContent.trim():``).match(/^(\d+)/);return{slot:n,qid:r,name:e.cells[2]?e.cells[2].textContent.trim():``,summe:i?+i[1]:null}}).filter(Boolean):[]}let be=e=>e?e.innerHTML.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&amp;/g,`&`).replace(/&lt;/g,`<`).replace(/&gt;/g,`>`).replace(/&quot;/g,`"`).replace(/\s+/g,` `).trim():``,j=e=>e.querySelector(`textarea.qtype_essay_response, div.qtype_essay_response`),xe=/^\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/i,Se=/(^|\s)([a-h])\s*·\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/gi,Ce=e=>(e.tagName===`TEXTAREA`?e.value||``:be(e)).replace(Se,(e,t,n)=>(t?`
`:``)+n.toLowerCase()+`) `).replace(xe,``).trim().replace(/^(?:[a-h]\)\s*)+$/i,``);async function M(e,t){let n=null,r=new Set,i=[];for(let a=0;a<t;a++){a>0&&await y(500);let t=await v(re(e.slot,e.qid,`all`));if(n=t,[...t.querySelectorAll(`.que`)].forEach(e=>{let t=(e.id||``).match(/^question-(\d+)-(\d+)$/),n=t?t[1]:e.id;n&&!r.has(n)&&(r.add(n),i.push(e))}),e.summe!=null&&i.length>=e.summe)break}return{bloecke:i,letzterDoc:n}}async function we(e,t){if(!e.length||!e.some(e=>j(e)))return null;let n=e[0],r=n.querySelector(`.graderinfo`),i=r?r.innerText.trim():``,a=je(n),o=null;if(a&&a.gesamt>a.ist)try{let e=await Me(t.qid);e&&e.horizont&&(i=e.horizont,o=a.gesamt)}catch{}let s={name:t.name,qid:t.qid,slot:t.slot,aufgabe:be(n.querySelector(`.qtext`)),zustaendig:se(i),horizontProzent:ue(i),feedback:(i.match(/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel)\s*\]?\s*$/im)||[])[1]||`Mittel`,horizont:de(i),max:d((n.querySelector(`input[name$="-maxmark"]`)||{}).value)??1,...o?{horizont_aus_fassung:o}:{}},c=[];return e.forEach(e=>{let n=(e.id||``).match(/^question-(\d+)-(\d+)$/);if(!n)return;let r=j(e),i=e.querySelector(`input[name$="-mark"]`),a=e.querySelector(`textarea[name$="-comment"]`);if(!r||!i)return;let o=String(i.value||``).trim()!==``;c.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:n[1],antwort:Ce(r),max:d((e.querySelector(`input[name$="-maxmark"]`)||{}).value)??s.max,markfeld:i.name,kommentarfeld:a?a.name:null,hat_kommentar:!!(a&&a.value.trim()),schon_bewertet:o,bisher:o?d(i.value):null})}),{frage:s,versuche:c}}async function Te(e,t){let n=ye();if(!n.length)throw Error(`Auf dieser Seite steht keine Fragenübersicht.`);let r={},i={},a=[],o=[],s=0,l=0,u=0,d=0,f=0,p=0,m=0,h=[...n];return await Promise.all(Array.from({length:1},async()=>{for(;h.length;){let c=h.shift();try{let{bloecke:e}=await M(c,8),n=await we(e,c);if(!n)d++;else{let e=n.frage.name||c.slot+`|`+c.qid,o=n.frage.zustaendig,s=o===`grader`,d=E.nurMitMarker&&o!==`coach`;s||d?i[e]||(i[e]={...n.frage,grund:s?`grader`:`kein-marker`},s?f++:m++):(r[e]||(r[e]=n.frage,n.frage.horizont?o||p++:u++),n.versuche.forEach(e=>{if(e.schon_bewertet&&!t){l++;return}a.push(e)}))}}catch(e){o.push({frage:c.name,meldung:e.message})}s++,e(s,n.length,a.length)}})),a.forEach((e,t)=>{e.nr=t+1}),{meta:{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:(()=>{let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return e?e.textContent.trim():``})(),cmid:c,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.length,fragen_mit_horizont:Object.values(r).filter(e=>e.horizont).length,fragen_ohne_horizont:u,fragen_fuer_grader:f,fragen_ohne_marker:p,streng_uebersprungen:m,nur_mit_marker:!!E.nurMitMarker,keine_freitextfrage:d,antworten:a.length,uebersprungen:l,max_sprachabzug_prozent:E.maxSprachabzug},fragen:r,fremde:i,antworten:a,fehler:o}}function N(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function Ee(e){let t=new Map;return(e||[]).forEach(e=>{let n=e.slot+`|`+e.qid;t.has(n)||t.set(n,{slot:e.slot,qid:e.qid,eintraege:[]}),t.get(n).eintraege.push(e)}),[...t.values()]}async function De(e,t,n){let r=Ee(e),i=0,a=0,o=0;for(let e of r){try{let n=(await v(re(e.slot,e.qid,`all`))).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);let r=N(n);e.eintraege.forEach(e=>{let n=[];r.has(e.markfeld)||n.push(`Punktefeld`),e.text&&e.kommentarfeld&&!r.has(e.kommentarfeld)&&n.push(`Kommentarfeld`),n.length?(a++,t(`✗ ${n.join(` und `)} fehlt — ${e.frage}`,x(e))):i++})}catch(n){a+=e.eintraege.length,t(`✗ Seite ${e.eintraege[0].frage}: ${n.message}`)}o++,n(o,r.length)}return{ok:i,fehler:a,gruppen:r.length,trocken:!0}}async function Oe(e,t,n){let r=null,i=new URLSearchParams,a=new Set;for(let o=0;o<n;o++){o>0&&await y(500);let n=(await v(e)).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);r=n;let s=N(n);if([...new Set(s.keys())].forEach(e=>{a.has(e)||(i.set(e,s.get(e)),a.add(e))}),t.every(e=>i.has(e)))break}return{form:r,felder:i}}async function ke(e,t,n,r){let i=Ee(e),a=0,o=0,s=0,c=[];for(let e of i){try{let r=re(e.slot,e.qid,`all`),{form:i,felder:s}=await Oe(r,e.eintraege.map(e=>e.markfeld),8),l=s,u=[];if(e.eintraege.forEach(e=>{if(!l.has(e.markfeld)){o++,c.push(e),n(`✗ Punktefeld nicht auf der Seite — ${e.frage}`,x(e));return}if(l.set(e.markfeld,f(e.punkte)),e.text&&e.kommentarfeld&&l.has(e.kommentarfeld)){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(E.kiHinweisText||w).trim();e&&(n+=`<p><em><small>`+m(e)+`</small></em></p>`)}l.set(e.kommentarfeld,n)}u.push(e)}),u.length){let e=[...i.elements].find(e=>e.type===`submit`&&e.name);e&&l.set(e.name,e.value);let t=new URL(i.getAttribute(`action`)||r,r).href,s=await fetch(t,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:l.toString()});if(!s.ok)throw Error(`HTTP `+s.status+` beim Speichern`);let p=u.slice(),m=new Map;for(let e=0;e<8&&p.length;e++){e>0&&await y(500);let t=await v(r);p=p.filter(e=>{let n=t.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`),r=n?d(n.value):null;return r!==null&&Math.abs(r-e.punkte)<.005?(m.set(e,r),!1):(m.set(e,r),!0)})}u.forEach(e=>{if(!p.includes(e))a++,n(`✓ ${e.frage} — ${f(e.punkte)} von ${f(e.max)}`,x(e));else{o++,c.push(e);let t=m.get(e);n(`✗ ${e.frage} — steht auf ${t==null?`keinem Wert`:f(t)} statt ${f(e.punkte)}`,x(e))}})}}catch(t){o+=e.eintraege.length,c.push(...e.eintraege),n(`✗ ${e.eintraege[0].frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,fehlgeschlagen:c}}async function Ae(e,t,n,r){let i=e,a=0,o=0,s=0;for(let e=1;e<=3&&i.length;e++){s=e,e>1&&(n(`↻ Versuch ${e}/3: ${i.length} Eintrag/Einträge erneut …`),await y(1500));let c=await ke(i,t,n,r);a+=c.ok,o+=c.gruppen,i=c.fehlgeschlagen}return{ok:a,fehler:i.length,gruppen:o,versuche:s}}function je(e){let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function Me(e){let t=[...(await v(b(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!t)return null;let n=[...(await v(new URL(t.getAttribute(`href`),b(e)).href)).querySelectorAll(`table tbody tr`)];if(!n.length)return null;let r=null;for(let e of n)for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){r=e[1];break}}if(!r||String(r)===String(e))return null;let i=(await v(b(r))).querySelector(`[name="graderinfo[text]"]`);if(!i)return null;let a=new DOMParser().parseFromString(String(i.value||``),`text/html`),o=(a.body?a.body.textContent:``).trim();return o?{qid:r,horizont:o}:null}function Ne(e,t,n){let r=fe(S.test(oe(t))?t:ae+`
`+t,E.maxSprachabzug??T.maxSprachabzug);return Fe(e,()=>`<p>`+m(r).replace(/\n/g,`<br>`)+`</p>`,r,n)}function Pe(e){let t=`<p>`+ae+`</p><p>`+le(E.maxSprachabzug??T.maxSprachabzug)+`</p>`;return Fe(e,e=>t+(e||``),ae,!1)}async function Fe(e,t,n,r){let i=b(e),a=await v(i),o=[...a.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`))||[...a.forms].find(e=>e.querySelector(`[name*="graderinfo"]`));if(!o)throw Error(a.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let s=N(o),c=`graderinfo[text]`;if(!s.has(c))throw Error(`Feld „graderinfo[text]" nicht im Formular`);if(r)return{ok:!0,feld:c,vorher:s.get(c)||``};s.set(c,t(s.get(c)||``));let l=[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name===`submitbutton`)||[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name&&e.name!==`cancel`);if(!l)throw Error(`Kein Speichern-Knopf im Formular`);s.set(l.name,l.value);let u=new URL(o.getAttribute(`action`)||i,i).href,d=await fetch(u,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!d.ok)throw Error(`HTTP `+d.status+` beim Speichern`);let f=null;try{f=new URL(d.url).searchParams.get(`lastchanged`)}catch{}let p=(await v(f?b(f):i)).querySelector(`[name="${CSS.escape(c)}"]`),m=p?String(p.value||``).replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,h=String(n).replace(/\s+/g,` `).trim().slice(0,30);if(!m||!m.includes(h.slice(0,20)))throw Error(f?`Text nicht angekommen (geprüft an der neuen Fragenversion)`:`Nicht gegengeprüft: Moodle hat keine neue Fragen-Nummer zurückgemeldet. Sieh in der Frage selbst nach — gespeichert sein kann es trotzdem.`);return{ok:!0,feld:c,neueId:f}}let P=`[MOODLE_AI_COACH_DATEN]`;function F(){let e=E.maxSprachabzug??T.maxSprachabzug;return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:
1. „Willkommen beim Moodle AI Freitext Grader."
2. „Ich bewerte kurze Freitextantworten nach dem Erwartungshorizont, der in der
   Aufgabe hinterlegt ist, und schreibe jedem Schüler eine Rückmeldung zur Sprache.
   Entscheiden tust du."
3. „Der „Moodle AI Freitext Grader" wurde von T. Henken und A. Spielhoff entwickelt und ist unter der Lizenz
   CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen,
   solange du ihn nennst."

═══════════════════════════════════════════════════════
BEWERTUNGSMASSSTAB
═══════════════════════════════════════════════════════

${ne(i)}

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Die Schülerinnen und Schüler haben eine Frage in ein bis drei Sätzen beantwortet.
Zu jeder Aufgabe steht unter „horizont" der Erwartungshorizont der Lehrkraft: die
Kernaussage, was enthalten sein muss, was auch als richtig gilt und – am wichtigsten –
eine Abstufung, welcher Prozentsatz wofür vergeben wird.

Deine Aufgabe hat zwei Teile, die STRIKT getrennt bleiben:
  1. INHALT  – wie gut trifft die Antwort den Erwartungshorizont?
  2. SPRACHE – welche Sprachfehler stehen im Text?

═══════════════════════════════════════════════════════
TEIL 1 – INHALT
═══════════════════════════════════════════════════════

Vergib einen Prozentwert nach der Abstufung, die im Horizont unter „Inhalt:" steht.
Halte dich an diese Stufen. Erfinde keine Zwischenwerte und keine eigene Skala –
die Lehrkraft hat für diese Aufgabe bereits entschieden.

Steht im Horizont ausnahmsweise keine Abstufung, benutze 100 / 75 / 50 / 25 / 0.

Es gelten die Grundregeln oben. Dazu: Eine Antwort in Stichworten ist inhaltlich nicht
schlechter – der Satzbau wird in Teil 2 bewertet, nicht hier.

═══════════════════════════════════════════════════════
TEIL 2 – SPRACHE
═══════════════════════════════════════════════════════

Du zählst die Fehler. Den Abzug rechnet die Erweiterung daraus selbst aus –
schreibe nirgends einen Abzug oder eine Punktzahl hin.

Zähle als Fehler, was eine strenge Deutschlehrkraft anstreichen würde:

SCHWER (zählt doppelt):
  • Satz ohne Prädikat oder abgebrochener Satz
  • Satzbau so falsch, dass man den Satz zweimal lesen muss

NORMAL (zählt einfach):
  • falscher Fall oder falscher Numerus („die Atome verbindet sich")
  • falsche Zeitform
  • Nomen kleingeschrieben oder Verb großgeschrieben
  • Fachbegriff falsch geschrieben
  • sonstiger Rechtschreibfehler
  • fehlender Punkt am Satzende oder fehlendes Komma vor dem Nebensatz
  • Umgangssprache statt Fachsprache („das Zeug", „macht kaputt")

Zählregeln:
• Derselbe Fehler im selben Wort zählt nur einmal, auch wenn das Wort mehrfach
  vorkommt.
• Zähle nur, was du benennen kannst. Ein Bauchgefühl ist kein Fehler.
• Eine leere Antwort hat keine Sprachfehler – dort ist der Inhalt 0 %.

Zur Einordnung, was mit deiner Zählung geschieht: Der Höchstabzug ist gerade auf
${e} % der Aufgabenpunkte eingestellt. 1 Fehler kostet ein Drittel davon,
2 Fehler die Hälfte, 3 zwei Drittel, 4 fünf Sechstel, ab 5 den vollen Abzug.

═══════════════════════════════════════════════════════
TEIL 3 – RÜCKMELDUNG
═══════════════════════════════════════════════════════

Das Feedback ist das eigentliche Produkt. Es lesen Schülerinnen und Schüler der
Mittelstufe, viele davon schreibschwach. Sie sollen daraus lernen — also schreibst du
wie eine Deutschlehrkraft, die einem Vierzehnjährigen etwas erklärt.

SPRACHE — so schreibst du:
• Kurze Hauptsätze. Ein Gedanke pro Satz. KEINE verschachtelten Sätze.
• Sag die Regel, nicht nur die Korrektur.
  Schwach: „Der Name wird großgeschrieben."
  Gut:     „Vor „Löschsand" kannst du „der" setzen. Solche Wörter sind Nomen. Nomen
            schreibt man groß: Löschsand."
• Stell falsch und richtig direkt gegenüber: löchsand → Löschsand.
  Lange Satzzitate sind für schwache Leser schwerer als ein Wortpaar.
• Kein Fachjargon ohne Erklärung. „Nomen", „Satzende", „Komma" sind bekannt;
  „Prädikat", „Kasus", „Numerus" erklärst du in eigenen Worten.
• Höchstens zwei Korrekturen je Zeile. Der Rest bleibt ungesagt — lieber weniger,
  das dafür verstanden.
• Freundlich und sachlich. Keine Floskeln, keine Emojis, kein Ausrufezeichen-Gewitter.

GLIEDERUNG — du schreibst KEINEN Fließtext, sondern füllst Felder:
Aus ihnen baut die Erweiterung selbst das fertige Feedback mit Überschrift, Umbrüchen
und Unterstreichungen. Schreib deshalb nirgends HTML, keine Sternchen, keine Zeilen-
umbrüche in die Felder.

  lob             – nur bei 95 % und mehr der Punkte: ein Satz Anerkennung,
                    konkret auf die Aufgabe bezogen („Du hast die Aufgabe zum
                    Löschsand richtig gut beantwortet.")
  inhalt          – was inhaltlich fehlte oder falsch war, und wie es richtig heißt.
                    Bei voller Punktzahl: was genau gut war.
  rechtschreibung – nur Rechtschreibung: Groß- und Kleinschreibung, falsch
                    geschriebene Wörter. Mit der Regel dahinter.
  grammatik       – nur Satzbau und Zeichensetzung: fehlende Punkte und Kommas,
                    Sätze ohne Trennung, falsche Fälle und Zeitformen.
  tipp            – freiwillig: EIN Merksatz für das nächste Mal. Nur, wenn er wirklich
                    hilft. Nicht bei jeder Antwort.

Felder, zu denen es nichts zu sagen gibt, lässt du weg. Eine Antwort ohne
Rechtschreibfehler bekommt keine Zeile „Rechtschreibung".

DIE DREI FÄLLE:

1. Volle Punktzahl, keine Sprachfehler → NUR das Feld „lob", sonst nichts.
   Beispiel: lob = „Das hast du super beantwortet — Name und Funktion sind richtig."

2. 95 % oder mehr, aber eine Kleinigkeit → zuerst „lob", dann die eine Zeile, die es
   betrifft. Erst loben, dann verbessern.
   Beispiel: lob = „Du hast die Aufgabe zum Löschsand richtig gut beantwortet."
             grammatik = „Am Satzende fehlt der Punkt."

3. Unter 95 % → kein Lob-Feld. Zuerst „inhalt", dann Rechtschreibung und Grammatik,
   wo nötig.

Die Musterlösung schreibst du NICHT. Liegt die Antwort unter 100 %, hängt die
Erweiterung von sich aus die Zeile „So hättest du es schreiben können: …" an und setzt
dort die Kernaussage aus dem Erwartungshorizont ein — wörtlich das, was die Lehrkraft
hinterlegt hat. Im Feld „inhalt" steht deshalb nur, WAS fehlte oder falsch war, nicht
die fertige Lösung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert. Je Frage eine Kopfzeile mit der
Aufgabe und der Kernaussage aus dem Horizont, darunter die Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|
| 1 | „Hefe wandelt Zucker in Alkohol um" | 50 | 1 normal | Prozess nicht benannt |

• „Nr" ist die Zahl aus dem Feld „nr" – nicht deine eigene Zählung.
• „Sprachfehler": Anzahl und Art, zum Beispiel „2 normal, 1 schwer".
• „Begründung": ein Halbsatz, der sich auf die Abstufung im Horizont bezieht.
• Keine Punkte- und keine Abzugsspalte. Das rechnet die Erweiterung.

Halte danach an und schreibe:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 75.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir das JSON aus."

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok" (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH):

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "Du hast geschrieben, dass Hefe Zucker umwandelt. Das stimmt. Es fehlt, was dabei entsteht: Alkohol und Kohlenstoffdioxid.",
        "rechtschreibung": "Vor „Zucker" kannst du „der" setzen. Solche Wörter sind Nomen, und Nomen schreibt man groß: Zucker.",
        "grammatik": "Am Satzende fehlt der Punkt."
      } },
    { "frage": "Löschsand (AFB I)", "qubaid": "2433020", "slot": "6",
      "inhalt": 100, "fehler": [],
      "rueckmeldung": { "lob": "Das hast du super beantwortet — Name und Funktion sind richtig." } }
  ]
}
\`\`\`

• Ein Eintrag je Versuch. „qubaid" und „slot" unverändert aus den Daten.
• „inhalt" ist der Prozentwert aus der Abstufung des Horizonts.
• „fehler" ist die Liste der gezählten Sprachfehler, leer bei fehlerfreiem Text.
• „rueckmeldung" enthält die Felder aus Teil 3. Nur die füllen, zu denen es etwas zu
  sagen gibt; leere Felder ganz weglassen. Jedes Feld ist ein oder zwei ganze Sätze,
  ohne Zeilenumbruch und ohne Formatierungszeichen — Überschrift, Absätze und
  Unterstreichungen setzt die Erweiterung selbst.
• JEDER Eintrag bekommt eine Rückmeldung, auch die fehlerfreien: dort steht das
  Lob-Feld allein.
• Keine Punktzahlen, kein Abzug, keine Feldnamen.
• WICHTIG – Anführungszeichen im JSON: Willst du in einem Rückmeldungstext ein Wort
  hervorheben oder ein Zitat setzen, benutze dafür EINFACHE Anführungszeichen ('so')
  oder schreibe es ohne Anführungszeichen. Gerade doppelte Anführungszeichen ("so")
  NIEMALS in einem JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die
  JSON-Begrenzung und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Schreibe darunter: „Kopiere diesen Block in die Erweiterung, Reiter „2 · Eintragen" —
die Prüfung startet beim Einfügen von selbst."

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Hat die Lehrkraft in Schritt 1 Prozentwerte geändert, ist das mehr als eine
Einzelfallentscheidung: Der Horizont bildet ihren Maßstab an dieser Stelle nicht ab
und würde beim nächsten Durchgang denselben Fehler wieder erzeugen.

Deshalb NACH dem JSON – aber nur, wenn tatsächlich korrigiert wurde:

1. Nenne je betroffener Frage in einem Satz, welche Regel sich aus der Korrektur
   ergibt. Nicht „Nr. 7 wurde auf 100 gesetzt", sondern die dahinterliegende
   Entscheidung: „Beim Löschsand reicht ‚löscht Brände' für 100 % – der Metallbrand
   muss nicht genannt werden."
2. Sag dazu, was sich im Horizont ändern müsste: meist wandert ein Teilaspekt von
   „Muss enthalten" nach „Auch richtig", und die betroffene Prozentstufe entfällt
   oder wird neu beschrieben.
3. Biete an, die Horizonte dieser Fragen neu zu schreiben, mit dem Weg dorthin:
   „Reiter 3 · Horizont, Häkchen ‚Auch Fragen einbeziehen, die schon einen Horizont
   haben' setzen, Prompt kopieren – ich baue die Korrekturen dann direkt ein."
4. Merke dir die Korrekturen für diesen Fall, damit sie in den neuen Horizont
   einfließen, wenn der Horizont-Prompt gleich nachkommt.

Wurde nichts geändert, lässt du diesen Schritt ersatzlos weg – kein „hier gab es
nichts zu korrigieren".

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

- „fragen"    – je Frage: Aufgabentext, Maximalpunkte und der Erwartungshorizont
                aus dem Moodle-Feld „Bewerterinformation".
- „antworten" – je Versuch die Schülerantwort mit „nr", „qubaid" und „slot".

${P}`}function I(e){return te({einzeln:!1,stufe:e||`Mittel`})}function Ie(){let e=E.maxSprachabzug??T.maxSprachabzug;return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST (KOMPAKT)
═══════════════════════════════════════════════════════

${ne(i)}

Falls du Zugriff auf die Skills „2-didaktik-bewertung“ und „3-moodle-erweiterungen“
von A. Spielhoff hast: Wende deren Bewertungslogik an — Inhalt strikt getrennt von
Sprache, die Abstufung im Horizont ist verbindlich (keine eigene Skala erfinden),
Sprachfehler zählen (schwer = doppelt) statt selbst Punkte abzuziehen, die
Feedback-Gliederung in Felder (lob/inhalt/rechtschreibung/grammatik/tipp) mit
kurzen, schülergerechten Sätzen für die Mittelstufe, und die drei Rückmeldungsfälle
(volle Punktzahl → nur Lob; ≥95 % → Lob zuerst; darunter → kein Lob).

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt“ ausschalten) statt zu raten — ohne die genauen Regeln (besonders
die Trennung Inhalt/Sprache und die Feld-Gliederung) sind falsche Bewertungen und
unpassendes Feedback wahrscheinlich.

Höchstabzug für Sprache ist gerade auf ${e} % der Aufgabenpunkte eingestellt:
1 Fehler kostet ein Drittel davon, 2 die Hälfte, 3 zwei Drittel, 4 fünf Sechstel,
ab 5 den vollen Abzug. Punkte NICHT selbst ausrechnen, nur Inhalt-Prozent und
Fehlerliste angeben — das rechnet die Erweiterung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert, mit Kopfzeile (Aufgabe +
Kernaussage aus dem Horizont), dann eine Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Datensatz. Keine Punkte- und keine Abzugsspalte. Halte
danach an und frage: „Passt das so? Nenne mir die Nummern, die ich ändern soll, zum
Beispiel: 3 auf 75. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok“ (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH) ausgeben:

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "…",
        "rechtschreibung": "…",
        "grammatik": "…"
      } }
  ]
}
\`\`\`

Ein Eintrag je Versuch, „qubaid“/„slot“ unverändert übernehmen. „inhalt“ ist der
Prozentwert aus der Horizont-Abstufung. „fehler“ leer bei fehlerfreiem Text.
„rueckmeldung“ nur die Felder füllen, zu denen es etwas zu sagen gibt (leere Felder
weglassen), jedes ein bis zwei ganze Sätze ohne Formatierung. Musterlösung NICHT
selbst schreiben — das hängt die Erweiterung an. WICHTIG: Hebst du in einem
Rückmeldungstext ein Wort hervor, benutze dafür einfache Anführungszeichen ('so'),
nie gerade doppelte ("so") — die brechen das JSON, weil sie die JSON-Begrenzung
sind. Satz danach: „Kopiere diesen Block
in die Erweiterung, Reiter „2 · Eintragen“ — die Prüfung startet beim Einfügen von selbst.“

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Wurden in Schritt 1 Prozentwerte geändert, nenne je betroffener Frage in einem Satz
die dahinterliegende Regel (nicht „Nr. 7 auf 100", sondern z. B. „Beim Löschsand
reicht ‚löscht Brände' für 100 % – der Metallbrand muss nicht genannt werden"), sag
was sich im Horizont ändern müsste, und biete an, die Horizonte über Reiter 3 neu zu
schreiben. Ohne Korrektur diesen Schritt ersatzlos weglassen.

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: Aufgabentext, Maximalpunkte, Erwartungshorizont aus
„Bewerterinformation“. „antworten“ – je Versuch die Schülerantwort mit „nr“,
„qubaid“, „slot“.

${P}`}function Le(e){let t=(E.promptOverride||``).trim()||(E.kompaktPrompt?Ie():F()),n=(Object.values(e&&e.fragen||{}).some(e=>e&&e.feedback===`Kurz`)?`FEEDBACKLÄNGE JE AUFGABE: Steht bei einer Aufgabe "feedback": "Kurz", gib für diese Aufgabe höchstens zwei Felder aus (inhalt und höchstens ein weiteres), je EIN kurzer Satz. Bei "Mittel" gilt das Format wie beschrieben.

`:``)+"```json\n"+JSON.stringify(e,(e,t)=>e===`bisher`?void 0:t,1)+"\n```";return t.includes(P)?t.replace(P,n):t+`

`+n}function Re(e){let t=(E.horizontPromptOverride||``).trim(),n=new Set(e.map(e=>e.feedback===`Kurz`?`Kurz`:`Mittel`)),r=t||I(n.size>1?`gemischt`:[...n][0]),i="```json\n"+JSON.stringify(e.map(e=>{let t={qid:e.qid,frage:e.name,aufgabe:e.aufgabe,max:e.max};return n.size>1&&(t.feedback=e.feedback===`Kurz`?`Kurz`:`Mittel`),e.horizont&&(t.horizont_bisher=ce(e.horizont)),t}),null,1)+"\n```",a=String((typeof U==`function`?U():``)||``).trim(),o=a?`═══════════════════════════════════════════════════════
ÄNDERUNGSWÜNSCHE DER LEHRKRAFT
═══════════════════════════════════════════════════════

Diese Vorgaben haben Vorrang vor allem, was in „horizont_bisher" steht.
Wo sie einem bisherigen Horizont widersprechen, gilt der Wunsch.

`+a+`

`:``,s=`[MOODLE_AI_COACH_AUFGABEN]`,c=h(e.map(e=>e.aufgabe),[]),l=o+(c?c+`

`:``)+i;return r.includes(s)?r.replace(s,l):r+`

`+l}let L=_(`button`,`co-fab`);L.title=`Moodle AI Freitext Grader`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`AI Coach`,e.className=`co-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),L.textContent=`Co`}),L.appendChild(e)}catch{L.textContent=`Co`}document.body.appendChild(L);let R=_(`div`,`co-panel co-hidden`);R.innerHTML=`
    <div class="co-head">
      <div class="co-titelblock">
        <span class="co-title">Freitext Grader · Kurztest <span class="co-version"></span></span>
        <span class="co-untertitel">(Zufalls-)Freitexte als Kurztest bewerten</span>
      </div>
      <button class="co-close" title="Schließen">✕</button>
    </div>
    <div class="co-tabs">
      <button class="co-tab co-aktiv" data-tab="lesen">1 · Bewerten</button>
      <button class="co-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="co-tab" data-tab="horizont">3 · Horizont <span class="co-badge co-hidden"></span></button>
      <button class="co-tab" data-tab="opt">⚙</button>
    </div>

    <div class="co-body" data-panel="lesen">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Hier bewertest du alle Kurztest-Antworten dieses Tests auf einmal. Die Erweiterung sammelt die Antworten aller Versuche und baut daraus mit den Erwartungshorizonten einen Prompt. Diesen in die KI einfügen; deren Antwort kommt in Reiter 2.</p>
      </details>
      <p class="co-meta"></p>
      <label class="co-check"><input type="checkbox" class="co-bereits">
        Auch schon bewertete Versuche noch einmal vorlegen</label>
      <button class="co-go">Freitextaufgaben durchsuchen</button>
      <div class="co-progress co-hidden"><div class="co-bar"></div><span class="co-ptext"></span></div>
      <div class="co-result co-hidden">
        <p class="co-summary"></p>
        <p class="co-warn co-hidden"></p>
        <div class="co-prozentbox co-hidden"></div>
        <div class="co-zust co-hidden"></div>
        <button class="co-copy">📋 Prompt + Daten kopieren</button>
        <button class="co-copy2 co-zweit">📋 nur JSON</button>
        <p class="co-groesse"></p>
        <div class="co-list"></div>
      </div>
      <p class="co-error co-hidden"></p>
      <details class="co-details">
        <summary>Bewertungs-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit bewertet die KI die Schülerantworten.</strong>
        Hier steht der vollständige Prompt, den „📋 Prompt + Daten kopieren" verschickt —
        du kannst ihn lesen und ändern. „Standard einfügen" holt die mitgelieferte Fassung
        zurück. Der Platzhalter <code>[MOODLE_AI_COACH_DATEN]</code> wird beim Kopieren
        durch die Fragen und Antworten aus Moodle ersetzt.</p>
        <textarea class="co-prompt" rows="8"></textarea>
        <button class="co-promptstd co-zweit">Standard einfügen</button>
        <button class="co-promptsave co-zweit">Prompt speichern</button>
      </details>
    </div>

    <div class="co-body co-hidden" data-panel="eintrag">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Hier fügst du die Bewertung der KI ein. Die Erweiterung rechnet die Punkte aus Inhaltsstufe und Fehlerzahl selbst, zeigt alles zur Kontrolle und trägt Punkte und Rückmeldung je Versuch in Moodle ein.</p>
      </details>
      <p class="co-hinweis">Hier das Bewertungs-JSON der KI einfügen. Die Punkte rechnet
      die Erweiterung aus Inhalt und Fehlerzahl selbst.</p>
      <textarea class="co-json" rows="6" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <label class="co-check"><input type="checkbox" class="co-ki" checked>
        KI-Hinweis ans Feedback anhängen</label>
      <p class="co-kivorschau"></p>
      <button class="co-pruef co-hidden">🔍 Prüfen</button>
      <p class="co-pinfo co-hidden"></p>
      <div class="co-schreibknoepfe co-hidden">
        <button class="co-alle">Alle eintragen</button>
      </div>
      <div class="co-progress2 co-hidden"><div class="co-bar2"></div><span class="co-ptext2"></span></div>
      <p class="co-abschluss co-hidden"></p>
      <div class="co-log co-hidden"></div>
      <div class="co-vorschau"></div>
    </div>

    <div class="co-body co-hidden" data-panel="horizont">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Für Aufgaben, die noch keinen Erwartungshorizont haben: Prompt für mehrere Aufgaben auf einmal erstellen und die Horizonte eintragen. Einzelne Aufgaben gehen bequemer im Frageneditor (Aufgabe bearbeiten → Freitext Grader).</p>
      </details>
      <p class="co-hinweis">Der Erwartungshorizont gehört in die Frage, nicht in die
      Erweiterung — einmal erstellt, gilt er dauerhaft und wandert beim Export mit.
      Hier wird er angelegt, wo er fehlt — oder für vorhandene neu geschrieben.</p>
      <div class="co-ohneliste"></div>
      <label class="co-check"><input type="checkbox" class="co-halle">
        Auch Fragen einbeziehen, die schon einen Horizont haben — <strong>der wird dabei
        überschrieben</strong></label>
      <label class="co-feldkopf">Was soll anders werden? (geht mit in den Prompt)</label>
      <textarea class="co-hwunsch" rows="3"
        placeholder="z. B.: Beim Löschsand müssen Metallbrände NICHT genannt werden — Name plus „löscht Brände“ reicht für 100 %."></textarea>
      <p class="co-hinweis">Ohne diese Zeilen sieht das Sprachmodell nur den bisherigen
      Horizont — und der sagt ja gerade das, was du ändern willst. Es schreibt ihn dann
      fort. Was hier steht, hat im Prompt Vorrang vor dem bisherigen Horizont.</p>
      <p class="co-hinweis">Beim Neuschreiben bekommt die KI den bisherigen Horizont mit,
      damit sie weiß, wovon sie abweicht. Ersetzt wird er erst, wenn du die Antwort in
      Schritt 2 einfügst und einträgst.</p>
      <p class="co-schritt">Schritt 1 — Prompt holen</p>
      <button class="co-hcopy">📋 Prompt für Erwartungshorizont kopieren</button>
      <details class="co-details">
        <summary>Horizont-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit schreibt die KI den Erwartungshorizont</strong>
        für Fragen, die noch keinen haben — also das, was später in der Frage steht und
        wonach der Bewertungs-Prompt dann bewertet. Hier steht der vollständige Prompt,
        den der Knopf oben kopiert. Der Platzhalter
        <code>[MOODLE_AI_COACH_AUFGABEN]</code> wird beim Kopieren durch die Aufgaben
        ohne Horizont ersetzt.</p>
        <textarea class="co-hprompt" rows="8"></textarea>
        <button class="co-hpromptstd co-zweit">Standard einfügen</button>
        <button class="co-hpromptsave co-zweit">Prompt speichern</button>
      </details>
      <p class="co-schritt">Schritt 2 — Antwort der KI einfügen</p>
      <textarea class="co-hjson" rows="5" placeholder='{ "horizonte": [ … ] }'></textarea>
      <button class="co-hpruef co-hidden">🔍 Prüfen</button>
      <p class="co-hinfo co-hidden"></p>
      <div class="co-hliste"></div>
      <div class="co-progress3 co-hidden"><div class="co-bar3"></div><span class="co-ptext3"></span></div>
      <p class="co-habschluss co-hidden"></p>
      <div class="co-hlog co-hidden"></div>
      <div class="co-hknoepfe co-hidden">
        <button class="co-hschreib">In die Aufgaben eintragen</button>
      </div>
    </div>

    <div class="co-body co-hidden" data-panel="opt">
      <details class="co-details co-wozu">
        <summary>Wozu dieser Reiter?</summary>
        <p class="co-hinweis">Einstellungen für alle Kurztests, etwa der höchste Abzug für Sprache und eigene Prompt-Fassungen.</p>
      </details>
      <label class="co-label">Maximaler Abzug für Sprache und Ausdruck (% der Aufgabenpunkte)
        <input type="text" class="co-abzug" value="30">
      </label>
      <p class="co-abzuginfo"></p>
      <label class="co-check"><input type="checkbox" class="co-nurmarker">
        Nur Fragen bewerten, die „[moodle-ai-coach]" im Erwartungshorizont tragen</label>
      <p class="co-hinweis">Fragen, deren Horizont mit <code>[moodle-ai-grader]</code>
      beginnt, überspringt der Coach <strong>immer</strong> — dafür ist dieses Häkchen
      nicht nötig. Es entscheidet nur über Fragen <em>ohne</em> Marker: aus (Standard)
      werden sie bewertet und im Ergebnis gemeldet, an bleiben sie liegen. Leg es um,
      wenn dein Bestand vollständig markiert ist.</p>
      <label class="co-check"><input type="checkbox" class="co-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <p class="co-hinweis">Verweist für die Bewertungslogik auf die Skills
      „2-didaktik-bewertung“ und „3-moodle-erweiterungen“ statt sie komplett
      auszuschreiben – spart pro Aufruf mehrere Tausend Zeichen. <strong>Nur
      einschalten, wenn du sicher bist, dass die verwendete KI diese Skills wirklich
      kennt</strong> (z. B. dein eigener Claude-Cowork-Zugang). Andere Lehrkräfte
      oder andere KI-Systeme lassen dieses Häkchen aus – die bekommen automatisch den
      vollständigen Prompt. Wirkt nur auf den Bewertungs-Prompt in Reiter 1, nicht
      auf den Horizont-Prompt in Reiter 3.</p>
      <label class="co-label">KI-Hinweis unter dem Feedback
        <textarea class="co-kitext" rows="3"></textarea>
      </label>
      <p class="co-hinweis">Die beiden Prompts stehen dort, wo sie gebraucht werden:
      der <strong>Bewertungs-Prompt</strong> in Reiter 1 (damit bewertet die KI die
      Antworten), der <strong>Horizont-Prompt</strong> in Reiter 3 (damit schreibt sie
      den Erwartungshorizont für Fragen, die noch keinen haben) — jeweils unter
      „Prompt anpassen". In beiden Feldern steht der volle Text zum Lesen und Ändern.</p>
      <button class="co-optsave">Speichern</button>
      <button class="co-optreset co-zweit">Alles zurücksetzen</button>
      <p class="co-optinfo co-hidden"></p>
    </div>`,document.body.appendChild(R),R.querySelector(`.co-version`).textContent=e;let z=e=>R.querySelector(e),B=null,ze=null,V=null,Be=`coachErnte_`+c;function Ve(){try{t.storage.local.set({[Be]:B})}catch{}}try{t.storage.local.get([Be],e=>{let t=e&&e[Be];if(t&&!B){B=t;let e=z(`.co-meta`);e&&(e.textContent+=` · ${(t.antworten||[]).length} Antworten aus einem früheren Durchlauf geladen`)}})}catch{}L.addEventListener(`click`,()=>R.classList.toggle(`co-hidden`)),z(`.co-close`).addEventListener(`click`,()=>R.classList.add(`co-hidden`));function He(e){R.querySelectorAll(`.co-tab`).forEach(t=>t.classList.toggle(`co-aktiv`,t.dataset.tab===e)),R.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`co-hidden`,t.dataset.panel!==e))}let Ue=null;function We(){Ue&&=(clearTimeout(Ue),clearInterval(Ue),null)}R.querySelectorAll(`.co-tab`).forEach(e=>{e.addEventListener(`click`,()=>{We(),He(e.dataset.tab)})});function Ge(){let e=d(z(`.co-abzug`).value);return e===null||e<0?T.maxSprachabzug:Math.min(100,e)}function Ke(){let e=Ge();z(`.co-abzuginfo`).textContent=e===0?`Sprache zählt nicht für die Punkte. Das Sprachfeedback wird trotzdem geschrieben.`:`Höchstabzug ${p(e)} %. Ein Fehler kostet ${p(Math.round(e/3*10)/10)} %, zwei ${p(Math.round(e/2*10)/10)} %, drei ${p(Math.round(e*2/3*10)/10)} %, vier ${p(Math.round(e*5/6*10)/10)} %, ab fünf ${p(e)} %. Schwere Fehler zählen doppelt.`}function qe(){let e=z(`.co-kivorschau`),t=(E.kiHinweisText||w).trim();if(!z(`.co-ki`).checked||!t){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}z(`.co-ki`).addEventListener(`change`,qe),z(`.co-abzug`).addEventListener(`input`,Ke),z(`.co-abzug`).addEventListener(`change`,async()=>{Ke(),await O({maxSprachabzug:Ge()})}),z(`.co-nurmarker`).addEventListener(`change`,async e=>{await O({nurMitMarker:e.target.checked})}),me().then(()=>{z(`.co-abzug`).value=p(E.maxSprachabzug??T.maxSprachabzug),z(`.co-kitext`).value=E.kiHinweisText||w,z(`.co-prompt`).value=E.promptOverride||F(),z(`.co-hprompt`).value=E.horizontPromptOverride||I(),z(`.co-nurmarker`).checked=!!E.nurMitMarker,z(`.co-kompakt`).checked=!!E.kompaktPrompt,Ke(),qe()});function Je(e){let t=z(`.co-optinfo`);t.textContent=e,t.classList.remove(`co-hidden`),setTimeout(()=>t.classList.add(`co-hidden`),3e3)}z(`.co-optsave`).addEventListener(`click`,async()=>{await O({maxSprachabzug:Ge(),nurMitMarker:z(`.co-nurmarker`).checked,kompaktPrompt:z(`.co-kompakt`).checked,kiHinweisText:z(`.co-kitext`).value.trim()||w}),z(`.co-kitext`).value=E.kiHinweisText,Ke(),qe(),Je(`Gespeichert ✓`),Ye(z(`.co-optsave`),`✓ Gespeichert`,`Speichern`),setTimeout(()=>He(`lesen`),900)});function Ye(e,t,n){e.textContent=t,setTimeout(()=>e.textContent=n,2e3)}z(`.co-promptstd`).addEventListener(`click`,()=>{z(`.co-prompt`).value=F(),Ye(z(`.co-promptstd`),`✓ eingefügt`,`Standard einfügen`)}),z(`.co-promptsave`).addEventListener(`click`,async()=>{let e=z(`.co-prompt`).value.trim(),t=e===F().trim()?``:e;await O({promptOverride:t}),Ye(z(`.co-promptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),z(`.co-hpromptstd`).addEventListener(`click`,()=>{z(`.co-hprompt`).value=I(),Ye(z(`.co-hpromptstd`),`✓ eingefügt`,`Standard einfügen`)}),z(`.co-hpromptsave`).addEventListener(`click`,async()=>{let e=z(`.co-hprompt`).value.trim(),t=e===I().trim()?``:e;await O({horizontPromptOverride:t}),Ye(z(`.co-hpromptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),z(`.co-optreset`).addEventListener(`click`,async()=>{await O({...T}),z(`.co-abzug`).value=p(T.maxSprachabzug),z(`.co-nurmarker`).checked=T.nurMitMarker,z(`.co-kompakt`).checked=T.kompaktPrompt,z(`.co-kitext`).value=w,z(`.co-prompt`).value=F(),z(`.co-hprompt`).value=I(),Ke(),qe(),Je(`Auf Standard zurückgesetzt — auch die Prompts in Reiter 1 und 3.`)}),z(`.co-meta`).textContent=(document.title||``).replace(/\s*\|.*$/,``).trim()||`Manuelle Bewertung`,z(`.co-go`).addEventListener(`click`,async()=>{let e=z(`.co-go`);e.disabled=!0,e.textContent=`läuft …`,z(`.co-error`).classList.add(`co-hidden`),z(`.co-result`).classList.add(`co-hidden`),z(`.co-progress`).classList.remove(`co-hidden`);try{B=await Te((e,t,n)=>{z(`.co-bar`).style.width=Math.round(e/t*100)+`%`,z(`.co-ptext`).textContent=`${e} / ${t} Fragen · ${n} Antworten`},z(`.co-bereits`).checked);let e=B.meta,t=Object.values(B.fragen).filter(e=>e.horizont),n=Object.values(B.fragen).filter(e=>!e.horizont),r=Object.values(B.fremde||{}),i=Object.values(B.fragen).filter(e=>e.horizont_aus_fassung).length;z(`.co-summary`).textContent=`${e.antworten} Antworten auf ${Object.keys(B.fragen).length} Freitextfragen · ${t.length} mit Horizont, ${n.length} ohne · ${e.uebersprungen} übersprungen`+(r.length?` · ${r.length} nicht für den Coach`:``)+(i?` · ${i} Horizont(e) aus der neuesten Fragenfassung geholt`:``);let a=z(`.co-warn`);n.length?(a.classList.remove(`co-hidden`),a.textContent=`⚠ ${n.length} Frage(n) haben keinen Erwartungshorizont. Sie sind im Prompt nicht enthalten — leg ihn in Reiter 3 an.`):a.classList.add(`co-hidden`);function o(){let e=z(`.co-prozentbox`);e.innerHTML=``;let t=E.maxSprachabzug??T.maxSprachabzug,n=Object.values(B.fragen).filter(e=>e.horizont&&e.horizontProzent!=null&&e.horizontProzent!==t);if(!n.length){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.appendChild(_(`div`,`co-zustkopf`,`⚠ ${n.length} Frage(n) tragen im Horizont eine andere Rechtschreibungs-Prozentzahl als aktuell eingestellt (${p(t)} %):`)),n.forEach(t=>e.appendChild(_(`div`,`co-logzeile`,`${t.name} — Horizont: ${p(t.horizontProzent)} %`))),e.appendChild(_(`div`,`co-hinweis`,D?`Es gilt gerade überall die eingestellte Prozentzahl (${p(t)} %).`:`Es gilt gerade je Frage der Wert aus dem Horizont — so, wie beim Erstellen des Erwartungshorizonts bewusst festgelegt.`));let r=_(`button`,`co-marker co-zweit`,D?`Stattdessen die Horizont-Werte verwenden`:`Stattdessen überall ${p(t)} % verwenden`);r.addEventListener(`click`,()=>{D=!D,o()}),e.appendChild(r)}o();let s=z(`.co-zust`);s.innerHTML=``;let l=Object.values(B.fragen).filter(e=>e.horizont&&!e.zustaendig);if(r.length||l.length){s.classList.remove(`co-hidden`);let e=r.filter(e=>e.grund===`grader`),t=r.filter(e=>e.grund!==`grader`);if(e.length){s.appendChild(_(`div`,`co-zustkopf`,`↷ ${e.length} Klausur-Frage(n) — werden auf ihrer Einzelseite bewertet, hier übersprungen.`));let t=e.map(e=>({slot:e.slot,qid:e.qid,name:e.name}));A(c,t),e.forEach(e=>{let t=_(`a`,`co-logzeile`,`→ `+e.name);t.href=ve(c,e),s.appendChild(t)});let n=Object.keys(B.fragen||{}).length,r=_(`button`,`co-jetzt`,n?`Nach den Kurztests: weiter zur Klausur-Frage 1 von ${t.length}`:`Weiter zur Klausur-Frage 1 von ${t.length}`);if(r.addEventListener(`click`,()=>{location.href=ve(c,t[0])}),s.appendChild(r),!n){let e=3,n=_(`div`,`co-logzeile`,`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`);s.appendChild(n);let r=setInterval(()=>{if(e--,e>0){n.textContent=`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`;return}clearInterval(r),location.href=ve(c,t[0])},1e3);n.addEventListener(`click`,()=>{clearInterval(r),n.textContent=`Automatischer Sprung abgebrochen.`})}}if(t.length&&(s.appendChild(_(`div`,`co-zustkopf`,`↷ ${t.length} Frage(n) ohne Marker — übersprungen, weil „nur mit Marker" eingeschaltet ist (⚙).`)),t.forEach(e=>s.appendChild(_(`div`,`co-logzeile`,e.name)))),l.length){s.appendChild(_(`div`,`co-zustkopf`,`⚠ ${l.length} Frage(n) haben einen Horizont, aber keinen Marker — sie wurden mitbewertet. Trag den Marker nach, dann ist die Zuständigkeit dauerhaft geklärt.`)),l.forEach(e=>s.appendChild(_(`div`,`co-logzeile`,e.name)));let e=`${ae} in ${l.length} Frage(n) nachtragen`,t=_(`button`,`co-marker co-zweit`,e),n=!1,r=null;t.addEventListener(`click`,async()=>{if(!n){n=!0,t.textContent=`Wirklich? Ändert die Fragen — noch einmal klicken`,r=setTimeout(()=>{n&&(n=!1,t.textContent=e)},8e3);return}r&&=(clearTimeout(r),null),t.disabled=!0;let i=_(`div`,`co-marklog`);s.appendChild(i);let a=0,o=[];for(let e=0;e<l.length;e++){let n=l[e];t.textContent=`Trage nach … ${e+1} von ${l.length}: ${n.name}`;let r=_(`div`,`co-logzeile`,`… ${n.name}`);i.appendChild(r),i.scrollTop=i.scrollHeight;try{await Pe(n.qid),a++,r.textContent=`✓ ${n.name}`}catch(e){o.push(`${n.name}: ${e.message}`),r.textContent=`✗ ${n.name}: ${e.message}`,r.classList.add(`co-logfehler`)}}t.textContent=`${a} nachgetragen`+(o.length?`, ${o.length} fehlgeschlagen`:``),a&&s.appendChild(_(`div`,`co-logzeile`,`Bitte „Freitextaufgaben durchsuchen" noch einmal laufen lassen — dann liest die Erweiterung den neuen Stand.`))}),s.appendChild(t);let i=_(`button`,`co-hneu co-zweit`,`Horizont neu schreiben`);i.title=`Springt zu Reiter 3 und nimmt diese Fragen in den Prompt auf`,i.addEventListener(`click`,()=>{z(`.co-halle`).checked=!0,rt(),He(`horizont`),z(`.co-hcopy`).scrollIntoView({block:`nearest`})}),s.appendChild(i)}}else s.classList.add(`co-hidden`);let u=R.querySelector(`.co-badge`);u.classList.toggle(`co-hidden`,!n.length),u.textContent=n.length||``;let d=z(`.co-list`);d.innerHTML=``,Object.values(B.fragen).forEach(e=>{let t=_(`div`,`co-qname`);t.appendChild(_(`span`,e.horizont?`co-ok`:`co-fehlt`,e.horizont?`✓`:`✗`)),t.appendChild(_(`span`,`co-qtext`,` ${e.name} · ${f(e.max)} P.`)),d.appendChild(t),B.antworten.filter(t=>t.qid===e.qid).forEach(e=>{let t=_(`a`,`co-row`);t.href=x(e),t.target=`_blank`,t.rel=`noopener`,t.appendChild(_(`span`,`co-nr`,`#`+e.nr)),t.appendChild(_(`span`,`co-ans`,e.antwort.slice(0,90))),d.appendChild(t)})});let m=z(`.co-ohneliste`);m.innerHTML=``,n.length?(m.appendChild(_(`div`,`co-fehlendkopf`,`Ohne Erwartungshorizont:`)),n.forEach(e=>m.appendChild(_(`div`,`co-logzeile`,`${e.name} — ${e.aufgabe.slice(0,90)}`)))):(m.appendChild(_(`div`,`co-fehlendkopf`,`Alle Fragen haben einen Horizont. Willst du einen neuen für die Aufgaben schreiben?`)),m.appendChild(_(`div`,`co-logzeile`,`Setz dazu unten das Häkchen — der vorhandene Horizont wird beim Eintragen überschrieben.`))),!n.length&&t.length&&(z(`.co-halle`).checked=!0),rt(),Ve();let h=Le(B).length;z(`.co-groesse`).textContent=`Prompt ≈ ${Math.round(h/1e3)} 000 Zeichen`,z(`.co-result`).classList.remove(`co-hidden`),B.fehler.length&&(z(`.co-error`).textContent=B.fehler.length+` Frage(n) konnten nicht geladen werden.`,z(`.co-error`).classList.remove(`co-hidden`))}catch(e){z(`.co-error`).textContent=`Fehler: `+e.message,z(`.co-error`).classList.remove(`co-hidden`)}finally{z(`.co-progress`).classList.add(`co-hidden`),e.disabled=!1,e.textContent=`Freitextaufgaben durchsuchen`}});function Xe(e){let t={meta:{...e.meta},fragen:{},antworten:[]};Object.entries(e.fragen).forEach(([e,n])=>{n.horizont&&(t.fragen[e]=n)});let n=new Set(Object.values(t.fragen).map(e=>e.qid));return t.antworten=e.antworten.filter(e=>n.has(e.qid)),t.meta.antworten=t.antworten.length,t}function Ze(e,t,n,r){let i=z(e);We();let a=3;i.textContent=`✓ Kopiert — weiter in ${a} s`,Ue=setInterval(()=>{if(a--,a>0){i.textContent=`✓ Kopiert — weiter in ${a} s`;return}We(),i.textContent=t,n&&He(n);let e=r&&z(r);e&&(e.focus(),e.scrollIntoView({block:`nearest`}))},1e3)}z(`.co-copy`).addEventListener(`click`,async()=>{B&&(await ie(Le(Xe(B))),Ze(`.co-copy`,`📋 Prompt + Daten kopieren`,`eintrag`,`.co-json`))}),z(`.co-copy2`).addEventListener(`click`,async()=>{B&&(await ie(JSON.stringify(Xe(B),null,1)),Ze(`.co-copy2`,`📋 nur JSON`,`eintrag`,`.co-json`))});let Qe=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Reiter 1 „Freitextaufgaben durchsuchen" laufen lassen.`;function H(e){let t=e.value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen.`);return JSON.parse(t)}z(`.co-pruef`).addEventListener(`click`,()=>{let e=z(`.co-pinfo`);e.classList.remove(`co-hidden`),z(`.co-schreibknoepfe`).classList.add(`co-hidden`),z(`.co-abschluss`).classList.add(`co-hidden`),z(`.co-log`).classList.add(`co-hidden`),z(`.co-vorschau`).innerHTML=``,ze=null;try{if(!B)throw Error(Qe);let t=H(z(`.co-json`)),n=t.bewertungen||[];if(!n.length)throw Error(`Keine „bewertungen" im JSON gefunden.`);let r=new Map(B.antworten.map(e=>[e.qubaid+`|`+e.slot,e])),i=[];n.forEach((e,t)=>{let n=t+1;if(e.qubaid==null||e.slot==null)throw Error(`Eintrag ${n}: „qubaid" oder „slot" fehlt.`);let a=r.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Eintrag ${n}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesene Antwort. Stammt das JSON zu diesem Durchlauf?`);let o=Number(e.inhalt);if(isNaN(o)||o<0||o>100)throw Error(`Eintrag ${n}: „inhalt" ist kein Prozentwert (${e.inhalt}).`);let s=B.fragen&&B.fragen[a.frage]||{},c=_e(a.max,o,e.fehler,pe(s)),l=o<100?g(s.horizont):``,u=ee(e.rueckmeldung,l,{inhalt:c.inhaltPunkte,inhaltMax:a.max,abzug:c.abzugPunkte,gewicht:c.gewicht})||String(e.text||``).trim();i.push({...a,inhalt:o,fehler:e.fehler||[],text:u,punkte:c.punkte,gewicht:c.gewicht,abzug:c.abzug,rechnung:`Inhalt ${p(o)} % = ${f(c.inhaltPunkte)} · ${c.gewicht} Fehlerpunkt(e) → −${p(Math.round(c.abzug*10)/10)} % · = ${f(c.punkte)} von ${f(a.max)}`})}),ze=i;let a=i.filter(e=>!e.text).length,o=new Set(i.map(e=>e.slot+`|`+e.qid)).size;e.className=`co-pinfo co-ok`,e.textContent=`✓ ${i.length} Bewertungen auf ${o} Fragenseiten — bereit. Punkte und Abzug wurden aus Inhalt und Fehlerzahl berechnet.`+(a?` ⚠ ${a} Eintrag/Einträge ohne Rückmeldungstext.`:``);let s=i.filter(e=>e.bisher!=null),c=s.filter(e=>Math.abs(e.bisher-e.punkte)<.005).length,l=s.filter(e=>e.punkte-e.bisher>=.005).length,u=s.length-c-l;s.length&&(e.textContent+=` Vergleich mit der bisherigen Bewertung: ${c} gleich, ${l} höher, ${u} niedriger.`);let d=typeof t.besprochen==`boolean`?t.besprochen:null;d===!0&&(e.textContent+=` Mit der KI gemeinsam besprochen.`),d===!1&&(e.textContent+=` Automatisch bewertet – ein Blick in die Liste lohnt sich.`);let m=_(`div`,`co-rechnung`);i.forEach(e=>{let t=_(`a`,`co-logzeile co-vorschauzeile`),n=x(e);if(n&&(t.href=n,t.target=`_blank`,t.rel=`noopener`),t.appendChild(_(`span`,`co-vfrage`,e.frage)),t.appendChild(_(`span`,`co-vans`,`„`+e.antwort.slice(0,60)+`"`)),t.appendChild(_(`span`,`co-vpkt`,e.rechnung)),e.bisher!=null){let n=Math.abs(e.bisher-e.punkte)>=.005,r=_(`span`,`co-vbisher`+(n?` co-vanders`:``),`bisher `+f(e.bisher)+` → neu `+f(e.punkte));t.appendChild(r)}m.appendChild(t)}),z(`.co-vorschau`).appendChild(m),z(`.co-schreibknoepfe`).classList.remove(`co-hidden`),z(`.co-schreibknoepfe`).scrollIntoView({block:`nearest`})}catch(t){e.className=`co-pinfo co-error`,e.textContent=`Fehler: `+t.message}});function $e(e){return(t,n)=>{let r=_(n?`a`:`div`,`co-logzeile`,t);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`),(t.startsWith(`✗`)||t.startsWith(`⚠`))&&r.classList.add(`co-logfehler`),e.appendChild(r),e.scrollTop=e.scrollHeight}}async function et(e){if(!ze)return;let t=z(`.co-log`),n=z(`.co-abschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),z(`.co-progress2`).classList.remove(`co-hidden`),z(`.co-alle`).disabled=!0,z(`.co-progress2`).scrollIntoView({block:`nearest`});let r=$e(t),i=(e,t)=>{z(`.co-bar2`).style.width=Math.round(e/t*100)+`%`,z(`.co-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await De(ze,r,i):await Ae(ze,z(`.co-ki`).checked,r,i);if(t.prepend(_(`div`,`co-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`+(a.versuche>1?` · ${a.versuche} Versuche gebraucht`:``))),n.classList.remove(`co-hidden`),a.fehler>0)n.className=`co-abschluss co-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen. Trag noch nichts ein — stammt das JSON zu diesem Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach.`,e||(z(`.co-alle`).textContent=`Erneut versuchen`);else if(n.className=`co-abschluss co-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,e||(z(`.co-alle`).textContent=`Alle eintragen`),!e){let e=3,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),R.classList.add(`co-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);R.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message)}finally{z(`.co-progress2`).classList.add(`co-hidden`),z(`.co-alle`).disabled=!1}}z(`.co-alle`).addEventListener(`click`,()=>et(!1)),z(`.co-json`).addEventListener(`paste`,()=>setTimeout(()=>z(`.co-pruef`).click(),0)),z(`.co-hjson`).addEventListener(`paste`,()=>setTimeout(()=>z(`.co-hpruef`).click(),0)),[[`.co-json`,`.co-pruef`],[`.co-hjson`,`.co-hpruef`]].forEach(([e,t])=>{let n=null;z(e).addEventListener(`input`,r=>{r.inputType!==`insertFromPaste`&&(clearTimeout(n),n=setTimeout(()=>{z(e).value.trim()&&z(t).click()},800))})});function tt(){if(!B)return[];let e=Object.values(B.fragen);return z(`.co-halle`).checked?e:e.filter(e=>!e.horizont)}let nt=`coachWunsch_`+c;function U(){let e=R.querySelector(`.co-hwunsch`);return e?e.value.trim():``}try{t.storage.local.get([nt],e=>{let t=e&&e[nt];t&&!U()&&(R.querySelector(`.co-hwunsch`).value=t)})}catch{}R.querySelector(`.co-hwunsch`).addEventListener(`input`,()=>{try{t.storage.local.set({[nt]:U()})}catch{}});function rt(){let e=tt().length,t=z(`.co-halle`).checked;z(`.co-hcopy`).textContent=t?`📋 Prompt zum Neuschreiben kopieren (${e} Frage${e===1?``:`n`})`:`📋 Prompt für Erwartungshorizont kopieren`}z(`.co-halle`).addEventListener(`change`,rt),z(`.co-hcopy`).addEventListener(`click`,async()=>{if(!B){z(`.co-hinfo`).className=`co-hinfo co-error`,z(`.co-hinfo`).classList.remove(`co-hidden`),z(`.co-hinfo`).textContent=Qe;return}let e=tt();if(!e.length){z(`.co-hinfo`).className=`co-hinfo`,z(`.co-hinfo`).classList.remove(`co-hidden`),z(`.co-hinfo`).textContent=`Es fehlt kein Horizont. Setz das Häkchen darüber, wenn du die vorhandenen neu schreiben lassen willst.`;return}await ie(Re(e));let t=z(`.co-hcopy`).textContent;Ze(`.co-hcopy`,t,`horizont`,`.co-hjson`)}),z(`.co-hpruef`).addEventListener(`click`,()=>{let e=z(`.co-hinfo`);e.classList.remove(`co-hidden`),z(`.co-hknoepfe`).classList.add(`co-hidden`),z(`.co-habschluss`).classList.add(`co-hidden`),z(`.co-hlog`).classList.add(`co-hidden`),z(`.co-hliste`).innerHTML=``,V=null;try{let t=H(z(`.co-hjson`)).horizonte||[];if(!t.length)throw Error(`Keine „horizonte" im JSON gefunden.`);let n=B?new Map(Object.values(B.fragen).map(e=>[String(e.qid),e])):new Map;V=t.map((e,t)=>{if(!e.qid)throw Error(`Horizont ${t+1}: „qid" fehlt.`);let r=n.get(String(e.qid)),i=String(e.text||``).trim();if(!i)throw Error(`Horizont ${t+1}: „text" ist leer.`);return{qid:String(e.qid),frage:e.frage||(r?r.name:`Frage `+e.qid),text:i,bekannt:!!r,hatteHorizont:!!(r&&r.horizont)}});let r=V.filter(e=>e.hatteHorizont).length,i=V.filter(e=>!e.bekannt).length;e.className=`co-hinfo co-ok`,e.textContent=`✓ ${V.length} Horizont(e) gelesen.`+(i?` ⚠ ${i} gehören zu keiner ausgelesenen Frage.`:``)+(r?` ⚠ ${r} würden einen vorhandenen Horizont überschreiben.`:``);let a=z(`.co-hliste`);V.forEach((e,t)=>{let n=_(`div`,`co-hcard`);n.appendChild(_(`div`,`co-fehlendkopf`,`${e.frage}  ·  qid ${e.qid}`));let r=_(`textarea`,`co-htext`);r.value=e.text,r.rows=10,r.addEventListener(`input`,()=>{V[t].text=r.value}),n.appendChild(r),a.appendChild(n)}),z(`.co-hknoepfe`).classList.remove(`co-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`co-hinfo co-error`,e.textContent=`Fehler: `+t.message}});async function it(e){if(!V||!V.length)return;let t=z(`.co-hlog`),n=z(`.co-habschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),z(`.co-progress3`).classList.remove(`co-hidden`),z(`.co-hschreib`).disabled=!0,z(`.co-progress3`).scrollIntoView({block:`nearest`});let r=$e(t),i=0,a=0,o=0;try{for(let t of V){try{let n=await Ne(t.qid,t.text,e);i++,r(e?`✓ ${t.frage} — Feld „${n.feld}" vorhanden`+(n.vorher&&n.vorher.replace(/<[^>]*>/g,``).trim()?` (enthält schon Text!)`:``):`✓ ${t.frage} — Horizont eingetragen`)}catch(e){a++,r(`✗ ${t.frage}: ${e.message}`)}o++,z(`.co-bar3`).style.width=Math.round(o/V.length*100)+`%`,z(`.co-ptext3`).textContent=`${o} / ${V.length} Fragen`}t.prepend(_(`div`,`co-logkopf`,e?`${i} Fragen erreichbar · ${a} nicht`:`${i} Horizonte eingetragen · ${a} fehlgeschlagen`)),n.classList.remove(`co-hidden`),n.className=`co-habschluss `+(a?`co-abfehler`:`co-abok`),n.textContent=a?`⚠ ${a} Frage(n) konnten nicht geschrieben werden. Sieh ins Protokoll.`:e?`✓ Alle ${i} Fragen sind erreichbar und haben das Feld. Du kannst eintragen.`:`✓ ${i} Horizonte stehen jetzt in den Fragen. Führe Reiter 1 noch einmal aus, dann sind sie im Bewertungs-Prompt dabei.`,n.scrollIntoView({block:`nearest`}),!a&&!e&&(n.textContent+=` Weiter zu Reiter 1 in 3 s …`,We(),Ue=setTimeout(()=>{Ue=null,He(`lesen`)},3e3))}finally{z(`.co-progress3`).classList.add(`co-hidden`),z(`.co-hschreib`).disabled=!1}}z(`.co-hschreib`).addEventListener(`click`,()=>{let e=V?V.length:0;if(!e)return;let t=z(`.co-habschluss`);t.classList.remove(`co-hidden`),t.className=`co-habschluss co-abfrage`,t.innerHTML=``,t.appendChild(_(`div`,null,`Der Erwartungshorizont wird in ${e} Frage(n) der Fragensammlung geschrieben. Das ändert die Fragen selbst, nicht nur eine Bewertung.`));let n=_(`button`,`co-jetzt`,`Ja, in ${e} Frage(n) eintragen`);t.appendChild(n),n.addEventListener(`click`,()=>{t.classList.add(`co-hidden`),it(!1)})})}var Se=e({matches:[`*://*/*mod/quiz/report.php*`,`*://*/*question/bank/editquestion/question.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){j(),location.pathname.includes(`/mod/quiz/report.php`)&&xe()}}),Ce={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},M=class e extends Event{static EVENT_NAME=we(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function we(e){return`${t?.runtime?.id}:content:${e}`}var Te=typeof globalThis.navigation?.addEventListener==`function`;function N(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Te?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new M(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new M(e,t)),t=e)},1e3))}}}var Ee=class e{static SCRIPT_STARTED_MESSAGE_TYPE=we(`wxt:content-script-started`);id;abortController;locationWatcher=N(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?we(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),Ce.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},De={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Se;return await e(new Ee(`content`,t))}catch(e){throw De.error(`The content script "content" crashed on startup!`,e),e}})()})();