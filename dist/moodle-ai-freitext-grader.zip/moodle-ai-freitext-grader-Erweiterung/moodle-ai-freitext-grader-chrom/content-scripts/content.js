(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`[moodle-ai-freitext: kurztest]`,r=`[moodle-ai-freitext: klausur]`,i=String.raw`moodle[-\s]?ai[-\s]?(?:(coach|grader)|freitext(?:[-\s]?grader)?\s*[:\-–]?\s*(kurztest|klausur))`,a=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*`,`i`),o=new RegExp(String.raw`^\s*[\[(]?\s*`+i+String.raw`\s*[\])]?\s*[:.–-]?\s*$`,`im`);function s(e){return e?e[1]?e[1].toLowerCase():/kurztest/i.test(e[2]||``)?`coach`:`grader`:null}function c(e){let t=s((String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``).match(a));return t===`coach`?`kurztest`:t===`grader`?`klausur`:null}var l={Kurz:`FEEDBACKLÄNGE: KURZ (ein bis zwei Sätze an die Schülerin / den Schüler)
Die Bewertungsstufen bleiben genauso scharf wie sonst – die Feedbacklänge ändert nichts
an der Punktvergabe. Kürzer werden nur die Teile, aus denen die Rückmeldung entsteht:
• „Reicht nicht" und „Häufiger Fehler" je höchstens ein Eintrag in einem Satz.
• Füge nach „Häufiger Fehler" diesen Abschnitt an:

Wichtigster Hinweis:
<der eine Satz, den jemand mit unvollständiger Antwort am dringendsten braucht>`,Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis fünf Sätze an die Schülerin / den Schüler)
„Reicht nicht" und „Häufiger Fehler" liefern den Stoff für die Rückmeldung. Schreibe zu
jedem Eintrag einen Halbsatz, warum es nicht reicht bzw. was stattdessen richtig ist.`},u={Mittel:`FEEDBACKLÄNGE: MITTEL (drei bis vier Sätze je Teilaufgabe)
Die Abschnitte oben genügen. „Reicht nicht" und „Häufiger Fehler" je ein bis zwei Einträge.`,Ausführlich:`FEEDBACKLÄNGE: AUSFÜHRLICH (ein Absatz je Teilaufgabe mit Bezug auf die Antwort)
Ergänze je Aufgabe nach „Häufiger Fehler" diesen Abschnitt:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt – so formuliert, dass die Bewertung ihn als
Begründung aufgreifen kann.</p>`,Umfangreich:`FEEDBACKLÄNGE: UMFANGREICH (ausführlicher Absatz je Teilaufgabe, dazu ein eigener
Abschnitt „Operatorerfüllung" im Feedback)
Ergänze je Aufgabe nach „Häufiger Fehler" diese beiden Abschnitte:
<p><strong>Begründung je Stufe:</strong> für jede Stufe unter 100 % ein sachlicher Satz,
was gegenüber der vollen Leistung fehlt.</p>
<p><strong>Operatorerfüllung:</strong> was der Operator in DIESER Aufgabe konkret verlangt
(z. B. „Erläutere": Ursache nennen, Wirkung nennen, beides mit „weil/dadurch" verknüpfen)
und woran man eine Verfehlung erkennt (z. B. nur beschrieben, nicht verknüpft).</p>`};function d(e,t){let n=e===`kurztest`?l:u,r=e===`kurztest`?`Mittel`:`Ausführlich`;return n[t]||n[r]}function f(){return`FEEDBACKLÄNGE JE AUFGABE
Bei jeder Aufgabe steht „feedback". Es gilt der passende Block:

[Kurz]
${l.Kurz}

[Mittel]
${l.Mittel}`}var p=/\bM\s?\d{1,2}\b|\bMaterial|\bAbb(?:ildung|\.)|\bTabelle|\bDiagramm|\bGrafik|\bTextauszug|\bQuelle\b/i;function m(e,t){return t&&t.length>0||(e||[]).some(e=>p.test(String(e||``)))}function ee(e,t){if(!m(e,t))return``;let n=t||[];return`MATERIAL
Die Aufgabe verweist auf Material (M1, Abbildung, Tabelle …).
• Liegt das Material hier im Chat nicht vollständig vor, FRAGE ZUERST danach und schreibe
  den Horizont erst, wenn es da ist. Rate keine Werte.
• Werte das Material JETZT aus. Beim späteren Bewerten liegt es NICHT mehr vor. Schreibe alle
  Werte und Aussagen, die eine Antwort braucht, mit Quelle direkt in die Erwartungen
  (z. B. „M2, Tabelle: Siedetemperatur 78 °C"), nicht nur „siehe M2".
• Wörtliche Übernahmen aus dem Material ohne eigene Erklärung sind ein „Reicht nicht"-Fall,
  wo die Aufgabe eine Erklärung verlangt.`+(n.length?`

In der Aufgabe stehen Bilder/Dateien, die hier nur als Name ankommen:
- `+n.join(`
- `)+`
Die Lehrkraft lädt sie zusätzlich in den Chat hoch.`:``)}var h=`OFFENE AUFGABEN
Manche Aufgaben haben keine eine richtige Lösung: Es gibt mehrere vertretbare Positionen,
Deutungen oder Lösungswege (typisch bei „Nimm Stellung", „Erörtere", „Beurteile",
„Bewerte", „Diskutiere", „Setze dich auseinander", „Interpretiere", „Entwickle",
„Gestalte", „Entwirf", „Begründe deine Meinung"). Entscheide je Aufgabe, ob sie offen
ist. Wenn ja, behältst du die Abschnitte, füllst sie aber so:
• KERNAUSSAGE: eine mögliche gelungene Antwort. Sie zeigt, wie eine gute Antwort
  aufgebaut ist, nicht welche Meinung richtig ist. Beginne mit „Zum Beispiel:".
• MUSS ENTHALTEN: die Qualitätsmerkmale, die die Aufgabe verlangt, als zählbare Kriterien
  – etwa: eigene Position erkennbar · mindestens zwei Argumente, jedes mit Begründung
  (Behauptung + weil/denn/Beispiel) · mindestens ein Gegenargument aufgegriffen und
  entkräftet oder abgewogen · Urteil, das aus den Argumenten folgt · Bezug auf Fachbegriff,
  Theorie, Text oder Material, wo die Aufgabe ihn verlangt. Nimm nur Kriterien, die die
  Aufgabenstellung und ihr Operator wirklich fordern; bei Gestaltungsaufgaben die Vorgaben
  der Aufgabe (Form, Adressat, Umfang, Inhaltselemente).
• AUCH RICHTIG: mögliche Argumente bzw. Lösungsideen für VERSCHIEDENE Positionen, als
  Beispiele (mindestens drei je Seite, wo es Seiten gibt). Schließe immer mit dem Satz:
  „Jedes andere sachlich haltbare, auf die Aufgabe bezogene Argument zählt genauso."
• INHALT (Stufen): zählt erfüllte Kriterien, nie die Richtung der Meinung. Beispiel:
  100 — Position + zwei begründete Argumente + Gegenargument abgewogen + Urteil folgt
  daraus · 75 — eins davon fehlt · 50 — Position mit einem begründeten Argument, keine
  Abwägung · 25 — nur Meinung oder nur aufgezählte Argumente ohne Begründung · 0 — kein
  Bezug zur Aufgabe.
• REICHT NICHT: bloße Meinung ohne Begründung; aufgezählte Argumente ohne Urteil, wo ein
  Urteil verlangt ist; nur eine Seite, wo der Operator eine Abwägung verlangt.
• HÄUFIGER FEHLER: sachlich falsche Behauptungen als Argument (zählen nicht als
  Argument), Wiederholung derselben Begründung als zweites Argument, Urteil ohne Bezug zu
  den eigenen Argumenten.
• GLEICHBEHANDLUNG: Prüfe zum Schluss: Zwei gleich gut begründete Antworten mit
  entgegengesetzter Position landen in derselben Stufe. Kein Kriterium darf eine
  bestimmte Meinung voraussetzen.`;function g(e){return`• Nur die Stufen 100 / 75 / 50 / 25 / 0 Prozent. Lass Stufen weg, die die Aufgabe nicht
  hergibt (bei einer Aufzählung von drei Dingen etwa 100 / 75 / 50 / 0).
• JEDE STUFE HÄNGT AN ZÄHLBAREN BEDINGUNGEN („beide Teilaspekte", „Name ohne Funktion"),
  nie an Wörtern wie „überwiegend", „im Wesentlichen" oder „deutliche Lücken". Solche
  Wörter führen dazu, dass dieselbe Antwort verschieden eingestuft wird. Prüfe zum
  Schluss: Jede denkbare Antwort gehört zu genau EINER Stufe – keine Lücke, keine
  Überschneidung.
• „AUCH RICHTIG" ist der wichtigste Abschnitt. Gemeint sind nicht ausformulierte
  Musterantworten, sondern die rauen, verkürzten Fassungen, mit denen ${e?`Lernende der Jahrgangsstufe `+e:`Lernende dieser Jahrgangsstufe`}
  dasselbe sagen – auch umgangssprachlich, auch ohne Fachbegriff. Mindestens vier,
  dazu Wörter, die dasselbe meinen (etwa Ring, Bahn oder Ebene statt Schale).
• Der OPERATOR zählt: Schreibe in die 100-%-Bedingung, was er hier verlangt. Bei „Nenne"
  reicht die Nennung, bei „Beschreibe" der Sachverhalt, bei „Erkläre/Erläutere" muss ein
  Zusammenhang (weil, dadurch) dastehen, bei „Vergleiche" beide Seiten, bei
  „Beurteile/Bewerte" ein begründetes Urteil.
• STICHPUNKTE gelten als vollständige Antwort, solange sie den Inhalt tragen. Verlangt der
  Operator einen Zusammenhang, den Stichpunkte nicht zeigen, lege in den Stufen fest,
  wo sie landen.
• ZUSATZWISSEN: Fachlich richtige Zusätze, die nicht verlangt sind, heben keine Stufe.
  Lege keine Stufe an, die für Zusatzwissen mehr gibt.
• „REICHT NICHT" enthält nur Antworten, die sachlich RICHTIG, aber zu wenig sind.
  Sachlich Falsches gehört zu 0 % und unter „Häufiger Fehler" – sonst liest die
  Bewertung es als fast richtig.
• NICHT in den Horizont: Sprachregeln, Rechtschreibabzug, Feedback-Stil, Rolle,
  Punktzahlen, allgemeine Bewertungsregeln. Das steht im Bewertungsprompt der
  Erweiterung. Im Horizont steht nur, was für DIESE Aufgabe gilt.

${h}`}var _=`WOZU DER HORIZONT DIENT
Mit diesem Horizont bewertet später eine KI die Antworten einer ganzen Lerngruppe.
Gleiche Antworten sollen immer dieselbe Stufe bekommen – egal welches Modell bewertet
und wie oft. Das gelingt nur, wenn der Horizont keinen Ermessensspielraum lässt.`;function v(e={}){let t=!!e.einzeln,n=e.stufe===`gemischt`?f():d(`kurztest`,e.stufe);return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KURZTEST)
═══════════════════════════════════════════════════════

Für ${t?`die Aufgabe unten brauchst du einen Erwartungshorizont`:`die Aufgaben unten brauchst du je einen Erwartungshorizont`}
in genau dem Format unten. Er wird in Moodle im Feld „Informationen für Bewerter/innen"
der Aufgabe gespeichert und bei jeder Bewertung benutzt.

${_}

BISHERIGER HORIZONT
Steht ${t?`bei der Aufgabe`:`bei einer Aufgabe`} „horizont_bisher", ist das ein älterer Horizont. Er ist
Ausgangspunkt, keine Vorlage zum Abschreiben: Übernimm, was fachlich gut ist, und
schreibe ihn im Format unten neu. Sag der Lehrkraft ZUERST in zwei, drei Sätzen, dass
ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst.${t?``:` Stehen unten Änderungswünsche der Lehrkraft, haben sie
Vorrang – auch wenn der bisherige Horizont das Gegenteil sagt.`}
Steht kein „horizont_bisher" dabei, schreibst du neu.

KERNAUSSAGE = MUSTERANTWORT
Die Kernaussage sehen die Schülerinnen und Schüler: Bei unvollständigen Antworten setzt
die Erweiterung sie als „So hättest du es schreiben können" unter die Rückmeldung.
Schreibe sie als vollständige Musterantwort in einfacher Sprache – ein bis zwei kurze
Sätze, so wie eine gute Schülerin oder ein guter Schüler sie schreiben würde.

FORMAT${t?``:` je Aufgabe`}

Erwartungshorizont

Kernaussage:
<Musterantwort, ein bis zwei kurze Sätze>

Muss enthalten:
- <Teilaspekt 1>
- <Teilaspekt 2>

Auch richtig:
<gleichwertige Formulierungen, Synonyme, umgangssprachliche Varianten>

Inhalt:
100 % – <Bedingung>
 75 % – <Bedingung>
 50 % – <Bedingung>
 25 % – <Bedingung>
  0 % – <Bedingung>

Reicht nicht:
<sachlich richtige, aber zu knappe Antwort und warum sie nicht reicht>

Häufiger Fehler:
<typischer Denkfehler und was stattdessen richtig ist>

Teile:                          (nur wenn die Aufgabe Teile a, b … hat)
a) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)
b) <Teil in zwei, drei Wörtern> – <Punkte> Punkt(e)

REGELN
${g(e.jahrgang)}
• TEILE: Hat die Aufgabe Teile (a, b …), gehört der Abschnitt „Teile:" dazu. Die Punkte
  aller Teile ergeben zusammen genau „max". Die Stufen unter „Inhalt" gelten für die
  ganze Aufgabe und nennen, welche Teile erfüllt sein müssen.
• Die Schülerantworten sind ein bis drei Sätze lang. Halte den Horizont entsprechend
  knapp – er ist kein Lehrbuchtext.

${n}

AUSGABE
Gib zuerst ${t?`den Horizont`:`alle Horizonte`} als lesbaren Text aus, damit die Lehrkraft prüfen kann.
Frage dann: „Passt das so? Wenn ja, antworte mit ok." Ändere, bis die Lehrkraft
zustimmt. Erst nach „ok" gibst du genau EINEN Codeblock aus:

\`\`\`json
{
  "horizonte": [
    { "qid": "115576570", "frage": "Edelgasregel",
      "text": "Erwartungshorizont\\n\\nKernaussage:\\n…" }
  ]
}
\`\`\`

„qid" übernimmst du unverändert aus den Daten unten.

═══════════════════════════════════════════════════════
${t?`DIESE AUFGABE`:`AUFGABEN`}
═══════════════════════════════════════════════════════

[MOODLE_AI_COACH_AUFGABEN]`}function y(e={}){let t=e.fach?e.fach+`lehrkraft`:`Fachlehrkraft`,n=[e.jahrgang?`Jahrgang `+e.jahrgang:``,e.niveau?`Niveau `+e.niveau:``].filter(Boolean).join(`, `);return`ROLLE
Du bist ${t} und bewertest Schülerantworten${n?` (`+n+`)`:``} streng nach einem
festen Erwartungshorizont.${e.anrede?`

ANREDE
`+(e.anrede===`sie`?`Sprich die Schülerinnen und Schüler in jeder Rückmeldung mit „Sie" an („Sie haben …"). Beispiele in diesem Prompt, die „du" verwenden, überträgst du in die Sie-Form.`:`Sprich die Schülerinnen und Schüler in jeder Rückmeldung mit „du" an („Du hast …").`):``}

ZENTRALE BEWERTUNGSREGEL
Bewerte alle folgenden Antworten strikt nach demselben Maßstab. Fachlich gleiche
Antworten bekommen dieselbe Stufe – egal, an welcher Stelle sie stehen und wie die
Antworten davor ausgefallen sind.

ORGANISATIONSREGEL
Die Antworten stammen von verschiedenen Schülerinnen und Schülern. Bewerte jede für sich,
ohne sie untereinander zu vergleichen, aber mit identischem Maßstab.

GRUNDREGELN
• Bewerte nur, was tatsächlich dasteht. Interpretiere keine fehlenden Aussagen hinein.
• Maßstab ist ausschließlich der Erwartungshorizont. Eigenes Fachwissen nutzt du nur, um
  zu erkennen, ob eine abweichende Formulierung dasselbe meint.
• Eine Stufe gibt es nur für klar erkennbare, fachlich richtige Aussagen. Liegt eine
  Antwort zwischen zwei Stufen, gilt die niedrigere – nenne den Grund in der Begründung.
• Andere fachlich korrekte Formulierungen mit demselben Inhalt bekommen dieselbe Stufe.
  „Auch richtig" im Horizont ist verbindlich, auch umgangssprachlich.
• Fachlich richtige Zusätze, die nicht verlangt waren, bringen nichts – sie kosten aber
  auch nichts.
• Fachlich richtige Stichpunkte werden bewertet wie ganze Sätze, außer der Horizont
  sagt für diese Aufgabe etwas anderes.
• Der Operator zählt: Die volle Stufe gibt es nur, wenn die Antwort die geforderte
  Tiefe hat. Anforderungsbereiche: AFB I = Reproduktion, AFB II = Reorganisation /
  Transfer, AFB III = Reflexion / Bewertung.
• Teilpunkte entstehen nur über die Stufen des Horizonts. Punkte rechnet die
  Erweiterung.
• OFFENE AUFGABEN (Stellung nehmen, erörtern, beurteilen, interpretieren, gestalten …):
  Bewertet wird, wie gut die Antwort die Kriterien des Horizonts erfüllt – nie, welche
  Meinung sie vertritt. Gleich gut begründete Antworten bekommen dieselbe Stufe, auch
  wenn sie zu entgegengesetzten Urteilen kommen. Die Argumente unter „Auch richtig" sind
  Beispiele: Jedes andere sachlich haltbare, auf die Aufgabe bezogene Argument zählt
  genauso. Ein Argument zählt nur mit Begründung; eine bloße Behauptung ist keines. Die
  Rückmeldung nennt das fehlende Kriterium (z. B. „Das Gegenargument wird genannt, aber
  nicht abgewogen"), nicht ein bestimmtes Argument, das gefehlt habe.`}function te(e,t){let n=new DOMParser().parseFromString(String(t||``),`text/html`);n.querySelectorAll(`script, iframe, object, embed`).forEach(e=>e.remove()),n.querySelectorAll(`*`).forEach(e=>{[...e.attributes].forEach(t=>{(/^on/i.test(t.name)||/^\s*javascript:/i.test(t.value))&&e.removeAttribute(t.name)})});let r=e.ownerDocument||document;e.replaceChildren(...[...n.body.childNodes].map(e=>r.importNode(e,!0)))}function ne(e,t){let n=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!n)throw Error(`Feld „`+e+`" nicht im Formular`);n.value=t,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0}));let r=n.id||``,i=r&&document.getElementById(r+`_ifr`);if(i&&i.contentDocument&&i.contentDocument.body)return te(i.contentDocument.body,t),i.contentDocument.body.dispatchEvent(new Event(`input`,{bubbles:!0})),`TinyMCE`;let a=r&&document.getElementById(r+`editable`);return a?(te(a,t),a.dispatchEvent(new Event(`input`,{bubbles:!0})),`Atto`):`Textfeld`}function b(e){let t=document.querySelector(`[name="`+CSS.escape(e)+`"]`);if(!t)return``;let n=t.id||``,r=n&&document.getElementById(n+`_ifr`);if(r&&r.contentDocument&&r.contentDocument.body)return r.contentDocument.body.innerHTML;let i=n&&document.getElementById(n+`editable`);return i?i.innerHTML:t.value||``}var x={I:{op:`#2e7d32`,block:`#eaf4ea`,feld:`#f5faf5`},II:{op:`#b45309`,block:`#fdf2e0`,feld:`#fffaf0`},III:{op:`#c62828`,block:`#fbe9e9`,feld:`#fdf3f3`},neutral:{op:`#33404d`,block:`#eceff3`,feld:`#f8f9fb`}},re=/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i,S=/\s*\(\s*AFB\s*I{1,3}(?:\s*[-–]\s*I{1,3})?\s*\)\s*/gi,ie=/^\s*(?:Aufgabe\s*)?(\d{1,2})?\s*([a-h])?\s*[.):]\s*|^\s*[①-⑳]\s*/i,ae=/^\s*(?:Aufgabe\s*)?(\d{1,2})\s*([a-h])?\s*[.):]\s*/i,oe=/^\s*([a-h])\s*\)\s*/i,se=/^\s*([①-⑳])/,ce=/^\s*(?:M\s?\d+\b|Material\b)/i,C=/^(Nenne|Benenne|Gib|Beschreibe|Erkläre|Erläutere|Begründe|Vergleiche|Beurteile|Bewerte|Diskutiere|Erörtere|Stelle|Skizziere|Zeichne|Berechne|Ermittle|Bestimme|Formuliere|Deute|Interpretiere|Analysiere|Untersuche|Entwickle|Plane|Prüfe|Überprüfe|Ordne|Fasse|Werte|Leite|Definiere|Charakterisiere|Gliedere|Zeige|Notiere|Markiere|Kennzeichne|Ergänze|Wende|Übertrage|Gestalte|Entwirf|Nimm)\b/,w=`①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳`;function le(e){let t=String(e||``).match(re);return t?t[1].replace(/\s+/g,``):``}function ue(e){let t=String(e||``).toUpperCase().split(/[-–]/).pop().trim();return x[t]?t:null}function T(e){return x[ue(e)]||x.neutral}function de(e){return/#B9C7DA/i.test(String(e||``))}function E(e){return String(e??``).replace(/\s+/g,``).toLowerCase()}function D(e){return String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function O(e){return String(e).replace(`.`,`,`)}function k(e){return`<span style="display:inline-block;min-width:22px;height:22px;line-height:20px;padding:0 5px;box-sizing:border-box;border:1.5px solid #33404d;border-radius:11px;background:#fff;color:#222;font-weight:700;font-size:13px;text-align:center;">`+D(e)+`</span>`}function A(e){return e==null||e===``?``:`<span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+D(O(e))+(Number(e)===1?` Punkt`:` Punkte`)+`)</span>`}function fe({label:e,titel:t,afb:n,punkte:r,farbig:i,zeigeAfb:a,zeigePunkte:o}){let s=i?T(n):x.neutral,c=(e?k(e)+` · `:``)+D(t||`Deine Antwort`);return a&&n&&(c+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+D(n)+`</span>`),o&&r!=null&&(c+=` `+A(r)),`<div style="border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:10px 0;"><div style="background:`+s.block+`;padding:9px 14px;font-size:16px;font-weight:bold;color:#33404d;border-bottom:1.5px solid #9e9e9e;">`+c+`</div><div style="background:`+s.feld+`;padding:10px 14px;font-size:15px;line-height:1.45;"><p style="margin:0;">&nbsp;</p><p style="margin:0;">&nbsp;</p></div></div>`}function pe(e,t){let n=T(t);return`<div style="display:flex;border:1.5px solid #9e9e9e;border-radius:12px;overflow:hidden;margin:6px 0 10px;"><div style="width:40px;flex-shrink:0;background:#B9C7DA;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:4px;padding:10px 4px;"><span style="font-size:10px;font-weight:bold;line-height:1.2;text-align:center;color:#6b6b6b;">`+(t?`AFB<br>`+D(t):``)+`</span></div><div style="flex:1;"><div style="padding:10px 14px 8px;background:`+n.block+`;font-size:15px;line-height:1.6;border-radius:0 12px 12px 0;">`+e+`</div></div></div>`}function j(e,t,n,r){let i=e.ownerDocument,a=i.createTreeWalker(e,4),o;for(;(o=a.nextNode())&&!o.data.trim(););let s=!1;if(o){let e=o.data.replace(S,` `).replace(/^\s+/,``).replace(ie,``),t=(e.match(/^\s*/)||[``])[0];e=e.slice(t.length);let r=e.match(C),a=i.createDocumentFragment();if(r){let t=i.createElement(`span`);t.setAttribute(`style`,`font-weight:700;color:`+n+`;`),t.textContent=r[1],a.appendChild(t),a.appendChild(i.createTextNode(e.slice(r[1].length))),s=!0}else a.appendChild(i.createTextNode(e));o.parentNode.replaceChild(a,o)}let c=e.innerHTML.replace(S,` `).trim(),l=t?k(t)+` `:``,u=r==null?``:` `+A(r);return c=/^<p[\s>]/i.test(c)?c.replace(/^(<p[^>]*>)/i,`$1`+l):l+c,/<\/p>\s*$/i.test(c)?c=c.replace(/<\/p>\s*$/i,u+`</p>`):c+=u,{html:c,opGefunden:s}}function me(e){let t=new DOMParser().parseFromString(`<div id="w">`+String(e||``)+`</div>`,`text/html`),n=[...t.getElementById(`w`).childNodes].filter(e=>e.nodeType===1||e.nodeType===3&&e.data.trim()),r=e=>(e.textContent||``).replace(/ /g,` `),i=[],a=null,o=``,s=0;if(n.forEach(e=>{let t=r(e),n=null,c;if((c=t.match(ae))?(o=c[1],n=c[1]+(c[2]?c[2].toLowerCase():``)):(c=t.match(oe))?n=o+c[1].toLowerCase():(c=t.match(se))&&(s=w.indexOf(c[1])+1,o=String(s),n=o),n){a={typ:`aufgabe`,label:n,knoten:[e]},i.push(a);return}if(ce.test(t)||!a||a.typ===`frei`){(!a||a.typ!==`frei`||ce.test(t))&&(a={typ:`frei`,knoten:[]},i.push(a)),a.knoten.push(e);return}a.knoten.push(e)}),!i.some(e=>e.typ===`aufgabe`)){let e=n.find(e=>e.tagName===`OL`&&e.children.length>=2);if(e){let r=[];return n.forEach(t=>{t===e?[...e.children].forEach((e,t)=>r.push({typ:`aufgabe`,label:String(t+1),knoten:[...e.childNodes]})):r.push({typ:`frei`,knoten:[t]})}),{doc:t,segmente:r}}}return i.forEach((e,n)=>{if(e.typ!==`aufgabe`||!/^\d+$/.test(e.label))return;let a=i.slice(n+1).find(e=>e.typ===`aufgabe`);if(a&&a.label.startsWith(e.label)&&a.label!==e.label){e.typ=`frei`;let n=e.knoten[0],i=t.createTreeWalker(n,4),a;for(;(a=i.nextNode())&&!a.data.trim(););a&&(a.data=a.data.replace(ae,``)),!r(n).trim()&&!n.querySelector?.(`img,table`)&&e.knoten.shift()}}),{doc:t,segmente:i}}function he(e,t={}){let{doc:n,segmente:r}=me(e),i=[],a=t.aufgaben||[],o=new Map(a.map(e=>[E(e.nr),e])),s=r.filter(e=>e.typ===`aufgabe`),c=e=>{let t=n.createElement(`div`);return e.forEach(e=>t.appendChild(e.cloneNode(!0))),t};if(!s.length){let e=c(r.flatMap(e=>e.knoten)),n=a.length===1&&a[0].afb||t.gesamtAfb||le(e.textContent),o=j(e,``,T(n).op,null);return o.opGefunden||i.push(`Kein Operator am Anfang erkannt – der Text steht unverändert in der Karte.`),n||i.push(`Kein AFB gefunden – die Karte bleibt neutral grau.`),a.length>1&&i.push(`Im Horizont stehen `+a.length+` Teilaufgaben, im Fragetext ist keine Nummerierung zu erkennen (z. B. „1.", „2a)", „b)").`),{html:pe(o.html,n),gefunden:0,erwartet:a.length,hinweise:i}}a.length&&s.length!==a.length&&i.push(`Gefunden: `+s.length+` Teilaufgaben, im Horizont stehen `+a.length+`. Bitte die Vorschau genau prüfen.`);let l=0,u=0,d=0,f=r.map(e=>{let n=c(e.knoten);if(e.typ===`frei`)return n.innerHTML.replace(S,` `).replace(/<p[^>]*>(?:\s|&nbsp;|<br\s*\/?>)*<\/p>/gi,``).trim();let r=o.get(E(e.label))||a[l]||{};l++;let i=r.afb||le(n.textContent)||t.gesamtAfb||``,s=t.punkte===!1||r.punkte==null?null:r.punkte;t.punkte!==!1&&s==null&&d++;let f=j(n,e.label,T(i).op,s);return f.opGefunden||u++,pe(f.html,i)}).join(`
`);return u&&i.push(u+` Teilaufgabe(n) ohne erkannten Operator am Anfang – dort ist nichts eingefärbt.`),d&&i.push(d+` Teilaufgabe(n) ohne Punkte im Horizont – dort steht keine Punktzahl.`),{html:f,gefunden:s.length,erwartet:a.length,hinweise:i,labels:s.map(e=>e.label)}}async function ge(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function _e(e){if(!e)return null;let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function ve(e,t){let n=[...(await ge(t(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!n)return null;let r=await ge(new URL(n.getAttribute(`href`),t(e)).href),i=null;for(let e of r.querySelectorAll(`table tbody tr`))for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){i=e[1];break}}if(!i||String(i)===String(e))return null;let a=(await ge(t(i))).querySelector(`[name="graderinfo[text]"]`),o=a?String(a.value||``).trim():``;return o?{qid:i,html:o}:null}var ye={fach:/^\s*\[?\s*fach\s*:\s*([^\]\n]+?)\s*\]?\s*$/im,jahrgang:/^\s*\[?\s*jahrgang\s*:\s*(\d{1,2})\s*\]?\s*$/im,niveau:/^\s*\[?\s*(?:kurs)?niveau\s*:\s*(gymnasial|mittel|einfach|[GME])\b[^\]\n]*\]?\s*$/im,feedback:/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im},be=/^\s*\[?\s*(?:rechtschreibung\s*[:\-]?\s*\d{1,3}(?:[.,]\d+)?\s*%|punkteschritte\s*[:\-]?\s*[\d.,]+)\s*\]?\s*$/i;function xe(e){let t=String(e||``).trim();return t?be.test(t)||Object.values(ye).some(e=>new RegExp(e.source,`i`).test(t)):!1}function Se(e){let t=String(e||``).split(`
`).map(e=>e.trim()).filter(Boolean).slice(0,10).join(`
`),n={},r=t.match(ye.fach);r&&(n.fach=r[1].trim());let i=t.match(ye.jahrgang);i&&(n.jahrgang=i[1]);let a=t.match(ye.niveau);a&&(n.niveau=a[1].charAt(0).toUpperCase());let o=t.match(ye.feedback);return o&&(n.feedback=o[1].charAt(0).toUpperCase()+o[1].slice(1).toLowerCase()),n}var Ce={G:`gymnasial`,M:`mittel`,E:`einfach`};function we({fach:e,jahrgang:t,niveau:n,feedback:r}={}){return(e?`<p>[Fach: `+M(e)+`]</p>`:``)+(t?`<p>[Jahrgang: `+M(t)+`]</p>`:``)+(n?`<p>[Niveau: `+M(Ce[n]||n)+`]</p>`:``)+(r?`<p>[Feedback: `+M(r)+`]</p>`:``)}function Te(e){let t=parseInt(e,10);return!isNaN(t)&&t>=11?`sek2`:`sek1`}function Ee(e,t){return t===`du`?`du`:t===`sie`||Te(e)===`sek2`?`sie`:`du`}function M(e){return String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}var De=[[1,0],[2,1/3],[3.5,2/3],[1/0,1]],Oe=[0,1/3,1/2,2/3,5/6,1];function ke(e){return(String(e||``).trim().match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu)||[]).length}function Ae(e){return(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0)}function je(e,t){if(t<40)return Oe[Math.min(Math.max(0,Math.round(e)),Oe.length-1)];let n=t>0?e*100/t:0;for(let[e,t]of De)if(n<=e)return t;return 1}function Me(e,t){let n=Number(e)||0;return n?`Höchstens `+String(n).replace(`.`,`,`)+` % `+(t||`der Punkte`)+`. Kurze Antworten (unter 40 Wörtern): 1 Fehler kostet ein Drittel davon, ab 5 Fehlern alles. Längere Antworten nach Fehlerquotient: bis 1 Fehler je 100 Wörter nichts, ab 3,5 alles. Schwere Fehler zählen doppelt.`:`Sprache kostet keine Punkte. Eine Rückmeldung zur Sprache gibt es trotzdem.`}function Ne(e,t){return`Zur Einordnung, was mit deiner Zählung geschieht: Der Höchstabzug ist gerade auf
${String(Number(e)||0).replace(`.`,`,`)} % ${t||`der Punkte`} eingestellt. Bei Antworten unter 40 Wörtern kostet
1 Fehler ein Drittel davon, 2 die Hälfte, 3 zwei Drittel, 4 fünf Sechstel, ab 5 den vollen
Abzug. Bei längeren Antworten zählt der Fehlerquotient (Fehler je 100 Wörter): bis 1 kein
Abzug, bis 2 ein Drittel, bis 3,5 zwei Drittel, darüber der volle Abzug.`}var Pe=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,N=[`kiHinweis`,`kiHinweisText`,`entferneQuellen`,`kompaktPrompt`],Fe={kiHinweis:!0,kiHinweisText:Pe,entferneQuellen:!0,kompaktPrompt:!1};function Ie(e){return String(e??``).replace(/\[\w+:\d+\]/g,``).replace(/【[^】]*】/g,``).replace(/\[\d{1,2}\](?!\()/g,``).replace(/ {2,}/g,` `).replace(/ +([.,;:!?])/g,`$1`).trim()}function Le(e){if(typeof e==`string`)return Ie(e);if(Array.isArray(e))return e.map(Le);if(e&&typeof e==`object`){let t={};return Object.keys(e).forEach(n=>{t[n]=Le(e[n])}),t}return e}var Re=`BEWERTUNGSLOGIK (KOMPAKT)
Falls du Zugriff auf die Skills „2-didaktik-bewertung" und „3-moodle-erweiterungen"
von A. Spielhoff hast: Wende deren Klausur-Bewertungslogik an — Erfüllungsgrad je Aufgabe
nur in den Stufen 100, 75, 50, 25, 0, jede Stufe an einer Formulierung des Horizonts
verankert, Operator geprüft; Sprachfehler einzeln zählen (Wort, Korrektur, Kategorie:
satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache; schwer = doppelt); jede Aufgabe bekommt eine Begründung,
auch eine vollständig richtige. Du vergibst KEINE Punkte und schreibst keine Zahlen in
die Begründungen — das rechnet die Erweiterung.

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt" ausschalten) statt zu raten.`,P=e=>`freitextRundgang_`+e;function ze(e,n){try{return t.storage.local.set({[P(e)]:{liste:n,stand:Date.now()}})}catch{return Promise.resolve()}}function Be(e){return new Promise(n=>{try{t.storage.local.get([P(e)],t=>n(t&&t[P(e)]||null))}catch{n(null)}})}function Ve(e,t){return location.origin+location.pathname+`?id=`+e+`&mode=grading&slot=`+t.slot+`&qid=`+t.qid+`&grade=needsgrading&qperpage=100`}function He(e){return location.origin+location.pathname+`?id=`+e+`&mode=grading`}function Ue(e,t,n){if(!e||!e.liste||!e.liste.length)return null;let r=e.liste.findIndex(e=>String(e.slot)===String(t)&&String(e.qid)===String(n));return r<0?null:{index:r,gesamt:e.liste.length,naechste:e.liste[r+1]||null}}var We=`#dc2626`,F=`#eab308`,Ge=`#16a34a`,Ke=(e,t,n)=>`#`+[1,3,5].map(r=>Math.round(parseInt(e.substr(r,2),16)*(1-n)+parseInt(t.substr(r,2),16)*n).toString(16).padStart(2,`0`)).join(``),qe=e=>e<35?We:e<45?Ke(We,F,(e-35)/10):e<=55?F:e<65?Ke(F,Ge,(e-55)/10):Ge,Je=(e,t=1)=>Number(e).toFixed(t).replace(`.`,`,`),I=e=>String(Math.round(e*100)/100).replace(`.`,`,`);function Ye(e,t){let n=t=>e.every(e=>Math.abs(e/t-Math.round(e/t))<1e-6);for(let e of[1,.5,.25])if(n(e)&&t/e<=22)return e;for(let e of[.5,1,2,2.5,5,10,20,25,50])if(t/e<=22)return e;return Math.ceil(t/20)}function Xe(e,t,n={}){let r=e.filter(e=>Number.isFinite(e)),i=r.length;if(!i||!(t>0))return{svg:``,n:0};let a=n.schritt||Ye(r,t),o=[];for(let e=0;e<=t+1e-9;e+=a)o.push(Math.round(e*1e3)/1e3);o[o.length-1]<t-1e-9&&o.push(t);let s=o.map(()=>0);r.forEach(e=>{let t=0;o.forEach((n,r)=>{Math.abs(n-e)<Math.abs(o[t]-e)&&(t=r)}),s[t]++});let c=r.reduce((e,t)=>e+t,0)/i,l=Math.sqrt(r.reduce((e,t)=>e+(t-c)**2,0)/i),u=n.breite||400,d=n.hoehe||210,f=(u-30-10)/o.length,p=l>0?i*a/(l*Math.sqrt(2*Math.PI)):0,m=Math.max(2,...s,Math.ceil(p)),ee=e=>30+f*(o.length-1-e)+f/2,h=e=>12+(d-12-40)*(1-e/m),g=m<=6?1:m<=12?2:5,_=o.length>12?2:1,v=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${u} ${d}" width="100%" role="img" aria-label="Punkteverteilung" font-family="system-ui, sans-serif" font-size="11">`;for(let e=0;e<=m;e+=g)v+=`<line x1="30" x2="${u-10}" y1="${h(e)}" y2="${h(e)}" stroke="#e2e8f0"/><text x="25" y="${h(e)+4}" text-anchor="end" fill="#64748b">${e}</text>`;if(o.forEach((e,n)=>{let r=Math.min(f*.5,26);s[n]&&(v+=`<rect x="${ee(n)-r/2}" y="${h(s[n])}" width="${r}" height="${h(0)-h(s[n])}" rx="2" fill="${qe(e/t*100)}"><title>${I(e)} P: ${s[n]}</title></rect>`),(n%_===0||n===o.length-1)&&(v+=`<text x="${ee(n)}" y="${d-40+14}" text-anchor="middle" fill="#334155">${I(e)}</text>`)}),l>0){let e=``;for(let n=0;n<=120;n++){let r=-a/2+(t+a)*n/120,s=i*a/(l*Math.sqrt(2*Math.PI))*Math.exp(-((r-c)**2)/(2*l**2)),u=30+f*((o[o.length-1]-r)/a)+f/2;e+=(n?`L`:`M`)+u.toFixed(1)+`,`+h(s).toFixed(1)}v+=`<path d="${e}" fill="none" stroke="#1e293b" stroke-width="1.6"/>`}v+=`<line x1="30" x2="${u-10}" y1="${h(0)}" y2="${h(0)}" stroke="#94a3b8"/>`;let y=n.einheit||`Punkte`,te=n.wort||`Versuche`;return v+=`<text x="${(30+u-10)/2}" y="${d-6}" text-anchor="middle" fill="#64748b">${y} (max ${I(t)}) · Ø ${Je(c)} · Streuung ${Je(l)} · ${i} ${te}</text></svg>`,{svg:v,mittel:c,streuung:l,n:i,schritt:a}}function Ze(e){let t=new DOMParser().parseFromString(e,`image/svg+xml`);return document.importNode(t.documentElement,!0)}function Qe(e){"use strict";e||={};let r=t.runtime.getManifest?t.runtime.getManifest().version:``,i=Ce,o={};try{t.storage.local.get([`magSettings`]).then(e=>{let t=e&&e.magSettings||{},n=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t};o={fach:t.fach||``,jahrgang:t.jahrgang||``,niveau:t.kursniveau||``,rsSek1:n(t.rsSek1!==void 0&&t.rsSek1!==``?t.rsSek1:t.rechtschreibung),rsSek2:n(t.rsSek2!==void 0&&t.rsSek2!==``?t.rsSek2:25),anredeWahl:t.anredeWahl||`auto`},typeof ut==`function`&&ut()}).catch(()=>{})}catch{}let c=new URLSearchParams(location.search);if(c.get(`mode`)!==`grading`)return;let l=e.einzel||null,u=e.ziel||null;if(c.get(`slot`)&&!l||c.get(`includeauto`)===`1`)return;let d=c.get(`id`);if(!d)return;let f=location.origin+location.pathname,p=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),m=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},h=e=>Number(e).toFixed(2).replace(`.`,`,`),g=e=>String(Number(e)).replace(`.`,`,`),_=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function te(e,t,n){if(!e||typeof e!=`object`)return``;let r=t=>String(e[t]||``).trim(),i=r(`lob`),a=[[`Inhalt`,r(`inhalt`)],[`Rechtschreibung`,r(`rechtschreibung`)],[`Grammatik`,r(`grammatik`)],[`Tipp`,r(`tipp`)]].filter(([,e])=>e);if(!a.length&&!i)return``;if(!a.length)return`<p><strong><u>Feedback:</u></strong> `+_(i)+`</p>`;let o=a.map(([e])=>e),s=o.includes(`Grammatik`)?`Grammatik`:o.includes(`Rechtschreibung`)?`Rechtschreibung`:null,c=e=>`<span style="color:#767676;font-style:italic;"> (`+e+`)</span>`,l=!!(n&&n.gewicht>=5),u=e=>e>=5?`5 oder mehr Fehlerpunkte`:e===1?`1 Fehlerpunkt`:e+` Fehlerpunkte`,d=`<p><strong><u>Feedback</u></strong></p>`;return i&&(d+=`<p>`+_(i)+`</p>`),a.forEach(([e,r])=>{let i=``;n&&(e===`Inhalt`&&n.inhalt!=null?i=c(n.inhaltMax==null?h(n.inhalt)+` Punkte`:h(n.inhalt)+` von `+h(n.inhaltMax)+` Punkten`):e===s&&n.abzug&&(i=c(`−`+h(n.abzug)+` Punkte`+(n.gewicht==null?``:` — `+u(n.gewicht)+(l?`, höchste Stufe`:``))))),d+=`<p><u>`+e+`:</u> `+_(r)+i+`</p>`,e===`Inhalt`&&t&&(d+=`<p><u>So hättest du es schreiben können:</u> `+_(t)+`</p>`),e===s&&l&&(d+=`<p>In deiner Antwort häufen sich mehrere grundlegende Fehler — das ist die höchste Fehlerstufe. Es lohnt sich, gezielt daran zu arbeiten.</p>`)}),d}function ne(e){let t=String(e||``).replace(/\r/g,``).match(/Kernaussage\s*:?\s*([\s\S]*?)(?=\n\s*(?:Muss enthalten|Auch richtig|Inhalt|Reicht nicht|Häufiger Fehler|Wichtigster Hinweis|Teile)\s*:|$)/i),n=t?t[1].replace(/\s+/g,` `).trim():``;return n.length>300?``:n}let b=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function x(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let re=e=>new Promise(t=>setTimeout(t,e)),S=(e,t,n)=>`${f}?id=${d}&mode=grading&slot=${e}&qid=${t}&grade=${n||`needsgrading`}&qperpage=100`,ie=e=>`${p}/question/bank/editquestion/question.php?id=${e}&cmid=${d}`,ae=e=>e&&e.slot&&e.qid?S(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``):null;async function oe(e){try{await navigator.clipboard.writeText(e)}catch{let t=b(`textarea`,`co-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}let se=n,ce=a;function C(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function w(e){let t=String(e||``).split(`
`).map(e=>e.trim()).filter(Boolean);return s(t.slice(0,5).map(e=>e.match(ce)).find(Boolean)||null)||(t.some(e=>/^(?:[①-⑳]\s*)?Aufgabe\s+\d{1,2}\s*[a-h]?\b/i.test(e))?`grader`:t.some(e=>/^Kernaussage\s*:/i.test(e))?`coach`:null)}function le(e){let t=String(e||``).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&ce.test(t[n])&&(t[n]=t[n].replace(ce,``).trim(),t[n]||t.splice(n,1)),t.join(`
`).trim()}let ue=/^\s*\[?\s*rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%?\s*\]?\s*$/i;function T(e){let t=C(le(e)).match(ue);return t?parseFloat(t[1].replace(`,`,`.`)):null}function de(e){let t=le(e).split(`
`),n=t.findIndex(e=>e.trim());n>-1&&ue.test(t[n].trim())&&t.splice(n,1);for(let e=0;e<8;e++){let e=t.findIndex(e=>e.trim());if(e>-1&&xe(t[e]))t.splice(e,1);else break}return t.join(`
`).trim()}let E={maxSprachabzug:10,kiHinweisText:Pe,promptOverride:``,horizontPromptOverride:``,nurMitMarker:!1,kompaktPrompt:!1,kiHinweis:!0,entferneQuellen:!0},D={...E};function O(e){let t=Te(e)===`sek2`?`rsSek2`:`rsSek1`;return o&&o[t]!=null?o[t]:t===`rsSek2`?25:D.maxSprachabzug??E.maxSprachabzug}function k(){let e=W!==void 0&&W&&W.fragen?Object.values(W.fragen):[],t=t=>{let n={};return e.forEach(e=>{e[t]&&(n[e[t]]=(n[e[t]]||0)+1)}),Object.keys(n).sort((e,t)=>n[t]-n[e])[0]||``},n=t(`jahrgang`)||o.jahrgang||``,r=t(`niveau`)||o.niveau||``;return{fach:t(`fach`)||o.fach||``,jahrgang:n,niveau:i[r]||r,anrede:Ee(n,o.anredeWahl)}}function A(){return O(k().jahrgang)}function fe(e){let t=A();return e&&e.jahrgang?O(e.jahrgang):t}function pe(){return new Promise(e=>{try{t.storage.local.get([`coachOptionen`,`magSettings`],t=>{let n=t&&t.magSettings||{},r={};N.forEach(e=>{n[e]!==void 0&&(r[e]=n[e])}),D={...E,...t&&t.coachOptionen?t.coachOptionen:{},...r},e(D)})}catch{e(D)}})}function j(e){return D={...D,...e},new Promise(e=>{try{t.storage.local.get([`magSettings`],n=>{let r={...n&&n.magSettings||{}};N.forEach(e=>{r[e]=D[e]}),t.storage.local.set({coachOptionen:D,magSettings:r},e)})}catch{e()}})}function me(e,t,n){let r=n??A();return je(e,t)*r}function he(e,t,n,r,i){let a=Ae(n),o=me(a,ke(i),r),s=e*t/100-e*o/100;return{gewicht:a,abzug:o,inhaltPunkte:Math.round(e*t/100*100)/100,abzugPunkte:Math.round(e*o/100*100)/100,punkte:Math.max(0,Math.round(s*100)/100)}}function ge(){if(l)return[{slot:String(l.slot),qid:String(l.qid),name:l.name||`Diese Aufgabe`,summe:null}];let e=document.querySelector(`table`);return e?[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)||``).find(e=>/slot=/.test(e))||``,n=(t.match(/slot=(\d+)/)||[])[1],r=(t.match(/qid=(\d+)/)||[])[1];if(!n||!r)return null;let i=(e.cells[5]?e.cells[5].textContent.trim():``).match(/^(\d+)/);return{slot:n,qid:r,name:e.cells[2]?e.cells[2].textContent.trim():``,summe:i?+i[1]:null}}).filter(Boolean):[]}let _e=e=>e?e.innerHTML.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&amp;/g,`&`).replace(/&lt;/g,`<`).replace(/&gt;/g,`>`).replace(/&quot;/g,`"`).replace(/\s+/g,` `).trim():``,ve=e=>e.querySelector(`textarea.qtype_essay_response, div.qtype_essay_response`),ye=/^\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/i,be=/(^|\s)([a-h])\s*·\s*Deine Antwort(?:\s+AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?)?(?:\s+\(\s*[\d.,]+\s+Punkte?\s*\))?\s*/gi,we=/^\s*(?:[^\n]{0,120}?\s)?AFB\s+I{1,3}(?:\s*[-–]\s*I{1,3})?\s*·[^()\n]{0,80}\(\s*[\d.,]+\s+Punkte?\s*\)\s*/i,M=e=>(e.tagName===`TEXTAREA`?e.value||``:_e(e)).replace(we,``).replace(be,(e,t,n)=>(t?`
`:``)+n.toLowerCase()+`) `).replace(ye,``).trim().replace(/^(?:[a-h]\)\s*)+$/i,``);async function De(e,t){let n=null,r=new Set,i=[];for(let a=0;a<t;a++){a>0&&await re(500);let t=await x(S(e.slot,e.qid,`all`));if(n=t,[...t.querySelectorAll(`.que`)].forEach(e=>{let t=(e.id||``).match(/^question-(\d+)-(\d+)$/),n=t?t[1]:e.id;n&&!r.has(n)&&(r.add(n),i.push(e))}),e.summe!=null&&i.length>=e.summe)break}return{bloecke:i,letzterDoc:n}}async function Oe(e,t){if(!e.length||!e.some(e=>ve(e)))return null;let n=e[0],r=n.querySelector(`.graderinfo`),i=r?r.innerText.trim():``,a=F(n),o=null;if(a&&a.gesamt>a.ist)try{let e=await Ge(t.qid);e&&e.horizont&&(i=e.horizont,o=a.gesamt)}catch{}let s={name:t.name,qid:t.qid,slot:t.slot,aufgabe:_e(n.querySelector(`.qtext`)),zustaendig:w(i),vonFreitext:/moodle[-\s]?ai[-\s]?freitext/i.test(i),...(()=>{let e=Se(i);return{fach:e.fach||``,jahrgang:e.jahrgang||``,niveau:e.niveau||``}})(),horizontProzent:T(i),feedback:(i.match(/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel)\s*\]?\s*$/im)||[])[1]||`Mittel`,horizont:de(i),max:m((n.querySelector(`input[name$="-maxmark"]`)||{}).value)??1,...o?{horizont_aus_fassung:o}:{}},c=[];return e.forEach(e=>{let n=(e.id||``).match(/^question-(\d+)-(\d+)$/);if(!n)return;let r=ve(e),i=e.querySelector(`input[name$="-mark"]`),a=e.querySelector(`textarea[name$="-comment"]`);if(!r||!i)return;let o=String(i.value||``).trim()!==``;c.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:n[1],antwort:M(r),max:m((e.querySelector(`input[name$="-maxmark"]`)||{}).value)??s.max,markfeld:i.name,kommentarfeld:a?a.name:null,hat_kommentar:!!(a&&a.value.trim()),schon_bewertet:o,bisher:o?m(i.value):null})}),{frage:s,versuche:c}}async function Ie(e,t){let n=ge();if(!n.length)throw Error(`Auf dieser Seite steht keine Fragenübersicht.`);let r={},i={},a=[],o=[],s=0,c=0,u=0,f=0,p=0,m=0,ee=0,h=[...n];return await Promise.all(Array.from({length:1},async()=>{for(;h.length;){let d=h.shift();try{let{bloecke:e}=await De(d,l?3:8),n=await Oe(e,d);if(!n)f++;else{let e=n.frage.name||d.slot+`|`+d.qid,o=n.frage.zustaendig,s=o===`grader`,f=D.nurMitMarker&&o!==`coach`&&!l;s||f?i[e]||(i[e]={...n.frage,grund:s?`grader`:`kein-marker`},s?p++:ee++):(r[e]||(r[e]=n.frage,n.frage.horizont?o||m++:u++),n.versuche.forEach(e=>{if(e.schon_bewertet&&!t){c++;return}a.push(e)}))}}catch(e){o.push({frage:d.name,meldung:e.message})}s++,e(s,n.length,a.length)}})),a.forEach((e,t)=>{e.nr=t+1}),{meta:{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:(()=>{let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return e?e.textContent.trim():``})(),cmid:d,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.length,fragen_mit_horizont:Object.values(r).filter(e=>e.horizont).length,fragen_ohne_horizont:u,fragen_fuer_grader:p,fragen_ohne_marker:m,streng_uebersprungen:ee,nur_mit_marker:!!D.nurMitMarker,keine_freitextfrage:f,antworten:a.length,uebersprungen:c,max_sprachabzug_prozent:A()},fragen:r,fremde:i,antworten:a,fehler:o}}function Re(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function P(e){let t=new Map;return(e||[]).forEach(e=>{let n=e.slot+`|`+e.qid;t.has(n)||t.set(n,{slot:e.slot,qid:e.qid,eintraege:[]}),t.get(n).eintraege.push(e)}),[...t.values()]}async function Be(e,t,n){let r=P(e),i=0,a=0,o=0;for(let e of r){try{let n=(await x(S(e.slot,e.qid,`all`))).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);let r=Re(n);e.eintraege.forEach(e=>{let n=[];r.has(e.markfeld)||n.push(`Punktefeld`),e.text&&e.kommentarfeld&&!r.has(e.kommentarfeld)&&n.push(`Kommentarfeld`),n.length?(a++,t(`✗ ${n.join(` und `)} fehlt — ${e.frage}`,ae(e))):i++})}catch(n){a+=e.eintraege.length,t(`✗ Seite ${e.eintraege[0].frage}: ${n.message}`)}o++,n(o,r.length)}return{ok:i,fehler:a,gruppen:r.length,trocken:!0}}async function He(e,t,n){let r=null,i=new URLSearchParams,a=new Set;for(let o=0;o<n;o++){o>0&&await re(500);let n=(await x(e)).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);r=n;let s=Re(n);if([...new Set(s.keys())].forEach(e=>{a.has(e)||(i.set(e,s.get(e)),a.add(e))}),t.every(e=>i.has(e)))break}return{form:r,felder:i}}async function Ue(e,t,n,r){let i=P(e),a=0,o=0,s=0,c=[];for(let e of i){try{let r=S(e.slot,e.qid,`all`),{form:i,felder:s}=await He(r,e.eintraege.map(e=>e.markfeld),8),l=s,u=[];if(e.eintraege.forEach(e=>{if(!l.has(e.markfeld)){o++,c.push(e),n(`✗ Punktefeld nicht auf der Seite — ${e.frage}`,ae(e));return}if(l.set(e.markfeld,h(e.punkte)),e.text&&e.kommentarfeld&&l.has(e.kommentarfeld)){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(D.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim();e&&(n+=`<p><em><small>`+_(e)+`</small></em></p>`)}l.set(e.kommentarfeld,n)}u.push(e)}),u.length){let e=[...i.elements].find(e=>e.type===`submit`&&e.name);e&&l.set(e.name,e.value);let t=new URL(i.getAttribute(`action`)||r,r).href,s=await fetch(t,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:l.toString()});if(!s.ok)throw Error(`HTTP `+s.status+` beim Speichern`);let d=u.slice(),f=new Map;for(let e=0;e<8&&d.length;e++){e>0&&await re(500);let t=await x(r);d=d.filter(e=>{let n=t.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`),r=n?m(n.value):null;return r!==null&&Math.abs(r-e.punkte)<.005?(f.set(e,r),!1):(f.set(e,r),!0)})}u.forEach(e=>{if(!d.includes(e))a++,n(`✓ ${e.frage} — ${h(e.punkte)} von ${h(e.max)}`,ae(e));else{o++,c.push(e);let t=f.get(e);n(`✗ ${e.frage} — steht auf ${t==null?`keinem Wert`:h(t)} statt ${h(e.punkte)}`,ae(e))}})}}catch(t){o+=e.eintraege.length,c.push(...e.eintraege),n(`✗ ${e.eintraege[0].frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,fehlgeschlagen:c}}async function We(e,t,n,r){let i=e,a=0,o=0,s=0;for(let e=1;e<=3&&i.length;e++){s=e,e>1&&(n(`↻ Versuch ${e}/3: ${i.length} Eintrag/Einträge erneut …`),await re(1500));let c=await Ue(i,t,n,r);a+=c.ok,o+=c.gruppen,i=c.fehlgeschlagen}return{ok:a,fehler:i.length,gruppen:o,versuche:s}}function F(e){let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function Ge(e){let t=[...(await x(ie(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!t)return null;let n=[...(await x(new URL(t.getAttribute(`href`),ie(e)).href)).querySelectorAll(`table tbody tr`)];if(!n.length)return null;let r=null;for(let e of n)for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){r=e[1];break}}if(!r||String(r)===String(e))return null;let i=(await x(ie(r))).querySelector(`[name="graderinfo[text]"]`);if(!i)return null;let a=new DOMParser().parseFromString(String(i.value||``),`text/html`),o=(a.body?a.body.textContent:``).trim();return o?{qid:r,horizont:o}:null}function Ke(e,t,n){let r=ce.test(C(t))?t:se+`
`+t;return Je(e,()=>`<p>`+_(r).replace(/\n/g,`<br>`)+`</p>`,r,n)}function qe(e){let t=`<p>`+se+`</p>`;return Je(e,e=>t+(e||``),se,!1)}async function Je(e,t,n,r){let i=ie(e),a=await x(i),o=[...a.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`))||[...a.forms].find(e=>e.querySelector(`[name*="graderinfo"]`));if(!o)throw Error(a.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let s=Re(o),c=`graderinfo[text]`;if(!s.has(c))throw Error(`Feld „graderinfo[text]" nicht im Formular`);if(r)return{ok:!0,feld:c,vorher:s.get(c)||``};s.set(c,t(s.get(c)||``));let l=[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name===`submitbutton`)||[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name&&e.name!==`cancel`);if(!l)throw Error(`Kein Speichern-Knopf im Formular`);s.set(l.name,l.value);let u=new URL(o.getAttribute(`action`)||i,i).href,d=await fetch(u,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!d.ok)throw Error(`HTTP `+d.status+` beim Speichern`);let f=null;try{f=new URL(d.url).searchParams.get(`lastchanged`)}catch{}let p=(await x(f?ie(f):i)).querySelector(`[name="${CSS.escape(c)}"]`),m=p?String(p.value||``).replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,ee=String(n).replace(/\s+/g,` `).trim().slice(0,30);if(!m||!m.includes(ee.slice(0,20)))throw Error(f?`Text nicht angekommen (geprüft an der neuen Fragenversion)`:`Nicht gegengeprüft: Moodle hat keine neue Fragen-Nummer zurückgemeldet. Sieh in der Frage selbst nach — gespeichert sein kann es trotzdem.`);return{ok:!0,feld:c,neueId:f}}let I=`[MOODLE_AI_COACH_DATEN]`;function Ye(){let e=k().jahrgang;return e?`Jahrgang `+e:`Sekundarstufe I`}function Qe(){let e=k().jahrgang;return Te(e)===`sek2`?`Es lesen Schülerinnen und Schüler der Oberstufe (Jahrgang ${e}). Sie sollen daraus
lernen — also klar, fachlich genau und ohne Umschweife, wie eine Lehrkraft, die einer
Oberstufenschülerin etwas erklärt.`:`Es lesen Schülerinnen und Schüler ${e?`des Jahrgangs `+e:`der Mittelstufe`}, viele davon
schreibschwach. Sie sollen daraus lernen — also schreibst du wie eine Deutschlehrkraft, die
einem Kind dieses Alters etwas erklärt.`}function $e(){return D.kompaktPrompt?R():et()}function et(){let e=A();return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:
1. „Willkommen beim Moodle AI Freitext Grader."
2. „Ich bewerte kurze Freitextantworten nach dem Erwartungshorizont, der in der
   Aufgabe hinterlegt ist, und schreibe jedem Schüler eine Rückmeldung zur Sprache.
   Entscheiden tust du."
3. „Der „Moodle AI Freitext Grader" wurde von T. Henken und A. Spielhoff entwickelt und ist unter der
   MIT-Lizenz veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen,
   solange der Urhebervermerk erhalten bleibt."

═══════════════════════════════════════════════════════
BEWERTUNGSMASSSTAB
═══════════════════════════════════════════════════════

${y(k())}

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Die Schülerinnen und Schüler haben eine Frage in ein bis drei Sätzen beantwortet.
Zu jeder Aufgabe steht unter „horizont" der Erwartungshorizont der Lehrkraft: die
Kernaussage, was enthalten sein muss, was auch als richtig gilt und – am wichtigsten –
eine Abstufung, welcher Prozentsatz wofür vergeben wird.

Deine Aufgabe hat zwei Teile, die STRIKT getrennt bleiben:
  1. INHALT  – wie gut trifft die Antwort den Erwartungshorizont?
  2. SPRACHE – welche Sprachfehler stehen im Text?

═══════════════════════════════════════════════════════
TEIL 1 – INHALT
═══════════════════════════════════════════════════════

Vergib einen Prozentwert nach der Abstufung, die im Horizont unter „Inhalt:" steht.
Halte dich an diese Stufen. Erfinde keine Zwischenwerte und keine eigene Skala –
die Lehrkraft hat für diese Aufgabe bereits entschieden.

Steht im Horizont ausnahmsweise keine Abstufung, benutze 100 / 75 / 50 / 25 / 0.

Es gelten die Grundregeln oben. Dazu: Eine Antwort in Stichworten ist inhaltlich nicht
schlechter – der Satzbau wird in Teil 2 bewertet, nicht hier.

═══════════════════════════════════════════════════════
TEIL 2 – SPRACHE
═══════════════════════════════════════════════════════

Du zählst die Fehler. Den Abzug rechnet die Erweiterung daraus selbst aus –
schreibe nirgends einen Abzug oder eine Punktzahl hin.

Zähle als Fehler, was eine strenge Deutschlehrkraft anstreichen würde:

SCHWER (zählt doppelt):
  • Satz ohne Prädikat oder abgebrochener Satz
  • Satzbau so falsch, dass man den Satz zweimal lesen muss

NORMAL (zählt einfach):
  • falscher Fall oder falscher Numerus („die Atome verbindet sich")
  • falsche Zeitform
  • Nomen kleingeschrieben oder Verb großgeschrieben
  • Fachbegriff falsch geschrieben
  • sonstiger Rechtschreibfehler
  • fehlender Punkt am Satzende oder fehlendes Komma vor dem Nebensatz
  • Umgangssprache statt Fachsprache („das Zeug", „macht kaputt")

Zählregeln:
• Derselbe Fehler im selben Wort zählt nur einmal, auch wenn das Wort mehrfach
  vorkommt.
• Zähle nur, was du benennen kannst. Ein Bauchgefühl ist kein Fehler.
• Eine leere Antwort hat keine Sprachfehler – dort ist der Inhalt 0 %.

${Ne(e,`der Aufgabenpunkte`)}

═══════════════════════════════════════════════════════
TEIL 3 – RÜCKMELDUNG
═══════════════════════════════════════════════════════

Das Feedback ist das eigentliche Produkt. ${Qe()}

SPRACHE — so schreibst du:
• Kurze Hauptsätze. Ein Gedanke pro Satz. KEINE verschachtelten Sätze.
• Sag die Regel, nicht nur die Korrektur.
  Schwach: „Der Name wird großgeschrieben."
  Gut:     „Vor „Löschsand" kannst du „der" setzen. Solche Wörter sind Nomen. Nomen
            schreibt man groß: Löschsand."
• Stell falsch und richtig direkt gegenüber: löchsand → Löschsand.
  Lange Satzzitate sind für schwache Leser schwerer als ein Wortpaar.
• Kein Fachjargon ohne Erklärung. „Nomen", „Satzende", „Komma" sind bekannt;
  „Prädikat", „Kasus", „Numerus" erklärst du in eigenen Worten.
• Höchstens zwei Korrekturen je Zeile. Der Rest bleibt ungesagt — lieber weniger,
  das dafür verstanden.
• Freundlich und sachlich. Keine Floskeln, keine Emojis, kein Ausrufezeichen-Gewitter.

GLIEDERUNG — du schreibst KEINEN Fließtext, sondern füllst Felder:
Aus ihnen baut die Erweiterung selbst das fertige Feedback mit Überschrift, Umbrüchen
und Unterstreichungen. Schreib deshalb nirgends HTML, keine Sternchen, keine Zeilen-
umbrüche in die Felder.

  lob             – nur bei 95 % und mehr der Punkte: ein Satz Anerkennung,
                    konkret auf die Aufgabe bezogen („Du hast die Aufgabe zum
                    Löschsand richtig gut beantwortet.")
  inhalt          – was inhaltlich fehlte oder falsch war, und wie es richtig heißt.
                    Bei voller Punktzahl: was genau gut war.
  rechtschreibung – nur Rechtschreibung: Groß- und Kleinschreibung, falsch
                    geschriebene Wörter. Mit der Regel dahinter.
  grammatik       – nur Satzbau und Zeichensetzung: fehlende Punkte und Kommas,
                    Sätze ohne Trennung, falsche Fälle und Zeitformen.
  tipp            – freiwillig: EIN Merksatz für das nächste Mal. Nur, wenn er wirklich
                    hilft. Nicht bei jeder Antwort.

Felder, zu denen es nichts zu sagen gibt, lässt du weg. Eine Antwort ohne
Rechtschreibfehler bekommt keine Zeile „Rechtschreibung".

DIE DREI FÄLLE:

1. Volle Punktzahl, keine Sprachfehler → NUR das Feld „lob", sonst nichts.
   Beispiel: lob = „Das hast du super beantwortet — Name und Funktion sind richtig."

2. 95 % oder mehr, aber eine Kleinigkeit → zuerst „lob", dann die eine Zeile, die es
   betrifft. Erst loben, dann verbessern.
   Beispiel: lob = „Du hast die Aufgabe zum Löschsand richtig gut beantwortet."
             grammatik = „Am Satzende fehlt der Punkt."

3. Unter 95 % → kein Lob-Feld. Zuerst „inhalt", dann Rechtschreibung und Grammatik,
   wo nötig.

Die Musterlösung schreibst du NICHT. Liegt die Antwort unter 100 %, hängt die
Erweiterung von sich aus die Zeile „So hättest du es schreiben können: …" an und setzt
dort die Kernaussage aus dem Erwartungshorizont ein — wörtlich das, was die Lehrkraft
hinterlegt hat. Im Feld „inhalt" steht deshalb nur, WAS fehlte oder falsch war, nicht
die fertige Lösung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert. Je Frage eine Kopfzeile mit der
Aufgabe und der Kernaussage aus dem Horizont, darunter die Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|
| 1 | „Hefe wandelt Zucker in Alkohol um" | 50 | 1 normal | Prozess nicht benannt |

• „Nr" ist die Zahl aus dem Feld „nr" – nicht deine eigene Zählung.
• „Sprachfehler": Anzahl und Art, zum Beispiel „2 normal, 1 schwer".
• „Begründung": ein Halbsatz, der sich auf die Abstufung im Horizont bezieht.
• Keine Punkte- und keine Abzugsspalte. Das rechnet die Erweiterung.

Halte danach an und schreibe:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 75.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir das JSON aus."

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok" (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH):

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "Du hast geschrieben, dass Hefe Zucker umwandelt. Das stimmt. Es fehlt, was dabei entsteht: Alkohol und Kohlenstoffdioxid.",
        "rechtschreibung": "Vor „Zucker" kannst du „der" setzen. Solche Wörter sind Nomen, und Nomen schreibt man groß: Zucker.",
        "grammatik": "Am Satzende fehlt der Punkt."
      } },
    { "frage": "Löschsand (AFB I)", "qubaid": "2433020", "slot": "6",
      "inhalt": 100, "fehler": [],
      "rueckmeldung": { "lob": "Das hast du super beantwortet — Name und Funktion sind richtig." } }
  ]
}
\`\`\`

• Ein Eintrag je Versuch. „qubaid" und „slot" unverändert aus den Daten.
• „inhalt" ist der Prozentwert aus der Abstufung des Horizonts.
• „fehler" ist die Liste der gezählten Sprachfehler, leer bei fehlerfreiem Text.
• „rueckmeldung" enthält die Felder aus Teil 3. Nur die füllen, zu denen es etwas zu
  sagen gibt; leere Felder ganz weglassen. Jedes Feld ist ein oder zwei ganze Sätze,
  ohne Zeilenumbruch und ohne Formatierungszeichen — Überschrift, Absätze und
  Unterstreichungen setzt die Erweiterung selbst.
• JEDER Eintrag bekommt eine Rückmeldung, auch die fehlerfreien: dort steht das
  Lob-Feld allein.
• Keine Punktzahlen, kein Abzug, keine Feldnamen.
• WICHTIG – Anführungszeichen im JSON: Willst du in einem Rückmeldungstext ein Wort
  hervorheben oder ein Zitat setzen, benutze dafür EINFACHE Anführungszeichen ('so')
  oder schreibe es ohne Anführungszeichen. Gerade doppelte Anführungszeichen ("so")
  NIEMALS in einem JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die
  JSON-Begrenzung und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Schreibe darunter: „Kopiere diesen Block in die Erweiterung, unten im Reiter „1 · Bewerten" —
die Prüfung startet beim Einfügen von selbst."

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Hat die Lehrkraft in Schritt 1 Prozentwerte geändert, ist das mehr als eine
Einzelfallentscheidung: Der Horizont bildet ihren Maßstab an dieser Stelle nicht ab
und würde beim nächsten Durchgang denselben Fehler wieder erzeugen.

Deshalb NACH dem JSON – aber nur, wenn tatsächlich korrigiert wurde:

1. Nenne je betroffener Frage in einem Satz, welche Regel sich aus der Korrektur
   ergibt. Nicht „Nr. 7 wurde auf 100 gesetzt", sondern die dahinterliegende
   Entscheidung: „Beim Löschsand reicht ‚löscht Brände' für 100 % – der Metallbrand
   muss nicht genannt werden."
2. Sag dazu, was sich im Horizont ändern müsste: meist wandert ein Teilaspekt von
   „Muss enthalten" nach „Auch richtig", und die betroffene Prozentstufe entfällt
   oder wird neu beschrieben.
3. Biete an, die Horizonte dieser Fragen neu zu schreiben, mit dem Weg dorthin:
   „Reiter 2 · Horizonte, Häkchen ‚Auch Fragen einbeziehen, die schon einen Horizont
   haben' setzen, Prompt kopieren – ich baue die Korrekturen dann direkt ein."
4. Merke dir die Korrekturen für diesen Fall, damit sie in den neuen Horizont
   einfließen, wenn der Horizont-Prompt gleich nachkommt.

Wurde nichts geändert, lässt du diesen Schritt ersatzlos weg – kein „hier gab es
nichts zu korrigieren".

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

- „fragen"    – je Frage: Aufgabentext, Maximalpunkte und der Erwartungshorizont
                aus dem Moodle-Feld „Bewerterinformation".
- „antworten" – je Versuch die Schülerantwort mit „nr", „qubaid" und „slot".

${I}`}function L(e){return v({einzeln:!1,stufe:e||`Mittel`})}function R(){let e=A();return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – BEWERTUNG KURZTEST (KOMPAKT)
═══════════════════════════════════════════════════════

${y(k())}

Falls du Zugriff auf die Skills „2-didaktik-bewertung“ und „3-moodle-erweiterungen“
von A. Spielhoff hast: Wende deren Bewertungslogik an — Inhalt strikt getrennt von
Sprache, die Abstufung im Horizont ist verbindlich (keine eigene Skala erfinden),
Sprachfehler zählen (schwer = doppelt) statt selbst Punkte abzuziehen, die
Feedback-Gliederung in Felder (lob/inhalt/rechtschreibung/grammatik/tipp) mit
kurzen, schülergerechten Sätzen (${Ye()}), und die drei Rückmeldungsfälle
(volle Punktzahl → nur Lob; ≥95 % → Lob zuerst; darunter → kein Lob).

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt“ ausschalten) statt zu raten — ohne die genauen Regeln (besonders
die Trennung Inhalt/Sprache und die Feld-Gliederung) sind falsche Bewertungen und
unpassendes Feedback wahrscheinlich.

${Ne(e,`der Aufgabenpunkte`)}
Punkte NICHT selbst ausrechnen, nur Inhalt-Prozent und Fehlerliste angeben — das
rechnet die Erweiterung.

═══════════════════════════════════════════════════════
MODUSFRAGE – STELLE SIE ZUERST UND WARTE
═══════════════════════════════════════════════════════

Stelle nach der Begrüßung GENAU DIESE EINE Frage und gib danach nichts weiter aus, bis
die Lehrkraft geantwortet hat:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir alle Bewertungen als Tabelle, du kannst einzelne ändern,
     dann gebe ich das JSON aus. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alles und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl der Lehrkraft, kein stiller Standard.
Bei 1 folgst du Schritt 1 und Schritt 2. Bei 2 überspringst du Schritt 1.
Im JSON steht ganz oben "besprochen": true (Modus 1) oder false (Modus 2).

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert, mit Kopfzeile (Aufgabe +
Kernaussage aus dem Horizont), dann eine Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Datensatz. Keine Punkte- und keine Abzugsspalte. Halte
danach an und frage: „Passt das so? Nenne mir die Nummern, die ich ändern soll, zum
Beispiel: 3 auf 75. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok“ (Modus GEMEINSAM) bzw. sofort (Modus AUTOMATISCH) ausgeben:

\`\`\`json
{
  "besprochen": true,
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "…",
        "rechtschreibung": "…",
        "grammatik": "…"
      } }
  ]
}
\`\`\`

Ein Eintrag je Versuch, „qubaid“/„slot“ unverändert übernehmen. „inhalt“ ist der
Prozentwert aus der Horizont-Abstufung. „fehler“ leer bei fehlerfreiem Text.
„rueckmeldung“ nur die Felder füllen, zu denen es etwas zu sagen gibt (leere Felder
weglassen), jedes ein bis zwei ganze Sätze ohne Formatierung. Musterlösung NICHT
selbst schreiben — das hängt die Erweiterung an. WICHTIG: Hebst du in einem
Rückmeldungstext ein Wort hervor, benutze dafür einfache Anführungszeichen ('so'),
nie gerade doppelte ("so") — die brechen das JSON, weil sie die JSON-Begrenzung
sind. Satz danach: „Kopiere diesen Block
in die Erweiterung, unten im Reiter „1 · Bewerten“ — die Prüfung startet beim Einfügen von selbst.“

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Wurden in Schritt 1 Prozentwerte geändert, nenne je betroffener Frage in einem Satz
die dahinterliegende Regel (nicht „Nr. 7 auf 100", sondern z. B. „Beim Löschsand
reicht ‚löscht Brände' für 100 % – der Metallbrand muss nicht genannt werden"), sag
was sich im Horizont ändern müsste, und biete an, die Horizonte über den Reiter „2 · Horizonte“ neu zu
schreiben. Ohne Korrektur diesen Schritt ersatzlos weglassen.

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: Aufgabentext, Maximalpunkte, Erwartungshorizont aus
„Bewerterinformation“. „antworten“ – je Versuch die Schülerantwort mit „nr“,
„qubaid“, „slot“.

${I}`}function z(e){let t=(D.promptOverride||``).trim()||(D.kompaktPrompt?R():et()),n=(Object.values(e&&e.fragen||{}).some(e=>e&&e.feedback===`Kurz`)?`FEEDBACKLÄNGE JE AUFGABE: Steht bei einer Aufgabe "feedback": "Kurz", gib für diese Aufgabe höchstens zwei Felder aus (inhalt und höchstens ein weiteres), je EIN kurzer Satz. Bei "Mittel" gilt das Format wie beschrieben.

`:``)+"```json\n"+JSON.stringify(e,(e,t)=>e===`bisher`?void 0:t,1)+"\n```";return t.includes(I)?t.replace(I,n):t+`

`+n}function B(e){let t=(D.horizontPromptOverride||``).trim(),n=new Set(e.map(e=>e.feedback===`Kurz`?`Kurz`:`Mittel`)),r=t||L(n.size>1?`gemischt`:[...n][0]),i="```json\n"+JSON.stringify(e.map(e=>{let t={qid:e.qid,frage:e.name,aufgabe:e.aufgabe,max:e.max};return n.size>1&&(t.feedback=e.feedback===`Kurz`?`Kurz`:`Mittel`),e.horizont&&(t.horizont_bisher=le(e.horizont)),t}),null,1)+"\n```",a=String((typeof wt==`function`?wt():``)||``).trim(),o=a?`═══════════════════════════════════════════════════════
ÄNDERUNGSWÜNSCHE DER LEHRKRAFT
═══════════════════════════════════════════════════════

Diese Vorgaben haben Vorrang vor allem, was in „horizont_bisher" steht.
Wo sie einem bisherigen Horizont widersprechen, gilt der Wunsch.

`+a+`

`:``,s=`[MOODLE_AI_COACH_AUFGABEN]`,c=ee(e.map(e=>e.aufgabe),[]),l=o+(c?c+`

`:``)+i;return r.includes(s)?r.replace(s,l):r+`

`+l}let V=b(`button`,`co-fab`);V.title=`Moodle AI Freitext Grader`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`Freitext Grader`,e.className=`co-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),V.textContent=`Co`}),V.appendChild(e)}catch{V.textContent=`Co`}u||document.body.appendChild(V);let H=b(`div`,u?`co-panel co-eingebettet`:`co-panel co-hidden`);H.innerHTML=`
    <div class="co-head">
      <div class="co-titelblock">
        <span class="co-title">Freitext Grader · Kurztest <span class="co-version"></span></span>
        <span class="co-untertitel">Kurztests dieses Tests bewerten</span>
      </div>
      <button class="co-close" title="Schließen">✕</button>
    </div>
    <div class="co-tabs">
      <button class="co-tab co-aktiv" data-tab="lesen">1 · Bewerten</button>
      <button class="co-tab" data-tab="horizont">2 · Horizonte <span class="co-badge co-hidden"></span></button>
      <button class="co-tab" data-tab="opt">⚙</button>
    </div>

    <div class="co-body" data-panel="lesen">
      <details class="co-details co-wozu">
        <summary>So funktioniert's</summary>
        <p class="co-hinweis">Hier bewertest du alle Kurztest-Antworten dieses Tests auf einmal:
        Antworten laden, Bewertungsprompt kopieren und in die KI deiner Wahl einfügen (z. B. Claude,
        ChatGPT), die Antwort der KI unten einfügen, ansehen, eintragen. Punkte und Rechtschreibabzug
        rechnet die Erweiterung selbst. Namen gehen nicht an die KI.</p>
        <p class="co-hinweis">Klausur-Aufgaben in diesem Test werden erkannt und auf ihrer eigenen
        Bewertungsseite bewertet – der Link dorthin steht im Ergebnis.</p>
      </details>
      <p class="co-meta"></p>
      <div class="co-kasten">
        <div class="co-kastenzeile"><span class="co-kastenkurz"></span>
          <button class="co-kastenauf co-zweit co-klein">ändern</button></div>
        <div class="co-kastenfelder co-hidden">
        <label class="co-label">Anrede im Feedback
          <select class="co-anrede">
            <option value="auto">Automatisch nach Jahrgang</option>
            <option value="du">Du</option><option value="sie">Sie</option>
          </select>
        </label>
        <label class="co-label"><span class="co-abzuglabel">Rechtschreibung: Höchstabzug in % der Aufgabenpunkte</span>
          <select class="co-abzug">
            <option value="0">0 % – kein Abzug</option><option value="5">5 %</option>
            <option value="10">10 %</option><option value="15">15 %</option>
            <option value="20">20 %</option><option value="25">25 %</option><option value="30">30 %</option>
          </select>
        </label>
        <details class="co-details co-mehr">
          <summary>Was bedeuten Anrede und Rechtschreibung?</summary>
          <p class="co-hinweis"><strong>Anrede:</strong> „Automatisch" schreibt bis Jahrgang 10 „Du hast …",
          ab Jahrgang 11 „Sie haben …". Der Jahrgang steht im Erwartungshorizont der Aufgaben.</p>
          <p class="co-hinweis"><strong>Rechtschreibung:</strong> So viel Prozent der Aufgabenpunkte kann die
          Sprache höchstens kosten – getrennt für die Sekundarstufe I und die Oberstufe, dieselben Werte wie
          bei Klausuren. Auch bei 0 % gibt es eine Rückmeldung zur Sprache.</p>
          <p class="co-hinweis co-abzuginfo"></p>
        </details>
        <p class="co-kastenfuss"></p>
        </div>
      </div>
      <p class="co-schritt">1 · Antworten laden</p>
      <label class="co-check"><input type="checkbox" class="co-bereits">
        Auch schon bewertete Antworten neu bewerten</label>
      <button class="co-go">Kurztest-Aufgaben durchsuchen</button>
      <div class="co-progress co-hidden"><div class="co-bar"></div><span class="co-ptext"></span></div>
      <div class="co-result co-hidden">
        <p class="co-summary"></p>
        <div class="co-hinweisbox">
          <p class="co-hinweis co-hzhinweis co-hidden"></p>
          <p class="co-warn co-hidden"></p>
          <div class="co-prozentbox co-hidden"></div>
          <div class="co-zust co-hidden"></div>
        </div>
        <div class="co-uebersichtshinweis co-hidden">
          <p class="co-hinweis">Mehrere Kurztests lassen sich auch auf einmal bewerten: auf der Übersicht des
          Tests, alle Kurztest-Fragen zusammen in einem Prompt.</p>
          <a class="co-zweit co-uebersichtlink">Zur Übersicht →</a>
        </div>
        <p class="co-schritt">2 · Bewertungsprompt kopieren und in die KI einfügen</p>
        <button class="co-copy">📋 Bewertungsprompt kopieren</button>
        <p class="co-groesse"></p>
        <div class="co-list"></div>
      </div>
      <p class="co-error co-hidden"></p>
      <details class="co-details co-profi">
        <summary>Für Fortgeschrittene</summary>
        <button class="co-copy2 co-zweit">📋 Nur die Antworten kopieren (ohne Prompt)</button>
        <p class="co-hinweis"><strong>Bewertungsprompt anpassen.</strong> Hier steht der vollständige Prompt,
        den „Bewertungsprompt kopieren" verschickt. „Standard einfügen" holt die mitgelieferte Fassung
        zurück. Der Platzhalter <code>[MOODLE_AI_COACH_DATEN]</code> wird beim Kopieren durch die Fragen
        und Antworten aus Moodle ersetzt.</p>
        <textarea class="co-prompt" rows="8"></textarea>
        <button class="co-promptstd co-zweit">Standard einfügen</button>
        <button class="co-promptsave co-zweit">Prompt speichern</button>
      </details>
    </div>

    <div class="co-body" data-panel="eintrag">
      <p class="co-schritt">3 · Antwort der KI einfügen und eintragen</p>
      <p class="co-hinweis">Hier die Antwort der KI einfügen – den Teil im grauen Kasten am Ende ihrer
      Antwort. Die Erweiterung prüft ihn sofort und zeigt jede Bewertung zur Kontrolle.</p>
      <textarea class="co-json" rows="6" placeholder="Antwort der KI hier einfügen"></textarea>
      <label class="co-check"><input type="checkbox" class="co-ki" checked>
        KI-Hinweis unter das Feedback setzen</label>
      <p class="co-kivorschau co-hidden"></p>
      <button class="co-pruef co-hidden">🔍 Prüfen</button>
      <p class="co-pinfo co-hidden"></p>
      <div class="co-schreibknoepfe co-hidden">
        <button class="co-alle">Alle eintragen</button>
      </div>
      <div class="co-progress2 co-hidden"><div class="co-bar2"></div><span class="co-ptext2"></span></div>
      <p class="co-abschluss co-hidden"></p>
      <div class="co-log co-hidden"></div>
      <div class="co-vorschau"></div>
    </div>

    <div class="co-body co-hidden" data-panel="horizont">
      <details class="co-details co-wozu">
        <summary>So funktioniert's</summary>
        <p class="co-hinweis">Übersicht über alle Freitextaufgaben dieses Tests: Ist es ein Kurztest oder eine
        Klausur? Hat sie einen aktuellen Erwartungshorizont? Erstellt oder überarbeitet wird ein Horizont
        immer für <strong>eine</strong> Aufgabe – im Frageneditor oder auf ihrer Bewertungsseite (Reiter
        „Horizont"). Nur dort lassen sich Modus, Feedbacklänge, Fach, Jahrgang und Niveau einstellen.</p>
      </details>
      <p class="co-hinweis co-hzregel"><strong>Horizonte entstehen Aufgabe für Aufgabe.</strong> Öffne die
      Aufgabe über einen der Links unten – im Frageneditor oder auf ihrer Bewertungsseite – und erstelle
      oder überarbeite ihren Horizont dort im Reiter „Horizont“.</p>
      <div class="co-aufgabenliste"><p class="co-hinweis">Erst im Reiter „1 · Bewerten“ „Kurztest-Aufgaben durchsuchen" –
      dann stehen hier alle Aufgaben mit ihren Links.</p></div>
      <div class="co-hidden co-althorizont">
      <p class="co-hinweis">Der Erwartungshorizont gehört in die Frage, nicht in die
      Erweiterung — einmal erstellt, gilt er dauerhaft und wandert beim Export mit.
      Hier wird er angelegt, wo er fehlt — oder für vorhandene neu geschrieben.</p>
      <div class="co-ohneliste"></div>
      <label class="co-check"><input type="checkbox" class="co-halle">
        Auch Fragen einbeziehen, die schon einen Horizont haben — <strong>der wird dabei
        überschrieben</strong></label>
      <label class="co-feldkopf">Was soll anders werden? (geht mit in den Prompt)</label>
      <textarea class="co-hwunsch" rows="3"
        placeholder="z. B.: Beim Löschsand müssen Metallbrände NICHT genannt werden — Name plus „löscht Brände“ reicht für 100 %."></textarea>
      <p class="co-hinweis">Ohne diese Zeilen sieht das Sprachmodell nur den bisherigen
      Horizont — und der sagt ja gerade das, was du ändern willst. Es schreibt ihn dann
      fort. Was hier steht, hat im Prompt Vorrang vor dem bisherigen Horizont.</p>
      <p class="co-hinweis">Beim Neuschreiben bekommt die KI den bisherigen Horizont mit,
      damit sie weiß, wovon sie abweicht. Ersetzt wird er erst, wenn du die Antwort in
      Schritt 2 einfügst und einträgst.</p>
      <p class="co-schritt">Schritt 1 — Prompt holen</p>
      <button class="co-hcopy">📋 Prompt für Erwartungshorizont kopieren</button>
      <details class="co-details">
        <summary>Horizont-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit schreibt die KI den Erwartungshorizont</strong>
        für Fragen, die noch keinen haben — also das, was später in der Frage steht und
        wonach der Bewertungs-Prompt dann bewertet. Hier steht der vollständige Prompt,
        den der Knopf oben kopiert. Der Platzhalter
        <code>[MOODLE_AI_COACH_AUFGABEN]</code> wird beim Kopieren durch die Aufgaben
        ohne Horizont ersetzt.</p>
        <textarea class="co-hprompt" rows="8"></textarea>
        <button class="co-hpromptstd co-zweit">Standard einfügen</button>
        <button class="co-hpromptsave co-zweit">Prompt speichern</button>
      </details>
      <p class="co-schritt">Schritt 2 — Antwort der KI einfügen</p>
      <textarea class="co-hjson" rows="5" placeholder='{ "horizonte": [ … ] }'></textarea>
      <button class="co-hpruef co-hidden">🔍 Prüfen</button>
      <p class="co-hinfo co-hidden"></p>
      <div class="co-hliste"></div>
      <div class="co-progress3 co-hidden"><div class="co-bar3"></div><span class="co-ptext3"></span></div>
      <p class="co-habschluss co-hidden"></p>
      <div class="co-hlog co-hidden"></div>
      <div class="co-hknoepfe co-hidden">
        <button class="co-hschreib">In die Aufgaben eintragen</button>
      </div>
      </div>
    </div>

    <div class="co-body co-hidden" data-panel="opt">
      <details class="co-details co-wozu">
        <summary>So funktioniert's</summary>
        <p class="co-hinweis">Hier steht nur, was für alle Aufgaben gleich ist – es gilt überall in der
        Erweiterung, auf der Kurztest-Übersicht ebenso wie auf der Bewertungsseite einer Aufgabe.
        Anrede und Rechtschreibung stellst du beim Bewerten ein, Fach, Jahrgang und Feedbacklänge im
        Horizont der Aufgabe.</p>
      </details>
      <label class="co-check"><input type="checkbox" class="co-kian"> KI-Hinweis unter das Feedback</label>
      <label class="co-label">Text des KI-Hinweises
        <textarea class="co-kitext" rows="3"></textarea>
      </label>
      <button class="co-kistd co-zweit">Standardtext einsetzen</button>
      <details class="co-details co-mehr">
        <summary>Was bedeutet „KI-Hinweis“?</summary>
        <p class="co-hinweis">Unter jedes eingetragene Feedback setzt die Erweiterung diesen Satz, kursiv
        und klein. Er kommt von der Erweiterung, nicht von der KI. Den Wortlaut kannst du ändern.</p>
      </details>
      <details class="co-details co-profi">
        <summary>Für Fortgeschrittene</summary>
        <label class="co-check"><input type="checkbox" class="co-quellen"> Quellenangaben entfernen</label>
        <details class="co-details co-mehr">
          <summary>Was bedeutet „Quellenangaben entfernen“?</summary>
          <p class="co-hinweis">Manche KI-Chats hängen Quellenmarken wie [1] oder 【4†source】 an. Mit Häkchen
          entfernt die Erweiterung sie aus dem Feedback, bevor es eingetragen wird.</p>
        </details>
        <label class="co-check"><input type="checkbox" class="co-kompakt">
          Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
        <details class="co-details co-mehr">
          <summary>Was bedeutet „Kompakter Prompt“?</summary>
          <p class="co-hinweis">Der Bewertungsprompt verweist für die Bewertungslogik auf die Skills
          „2-didaktik-bewertung" und „3-moodle-erweiterungen", statt sie auszuschreiben – spart mehrere
          Tausend Zeichen. <strong>Nur einschalten, wenn die verwendete KI diese Skills wirklich
          kennt.</strong></p>
        </details>
        <label class="co-check"><input type="checkbox" class="co-nurmarker">
          Nur Aufgaben bewerten, die als Kurztest gekennzeichnet sind (nur Kurztest-Übersicht)</label>
        <details class="co-details co-mehr">
          <summary>Was bedeutet „Nur gekennzeichnete Aufgaben bewerten“?</summary>
          <p class="co-hinweis">Jeder Erwartungshorizont trägt in der ersten Zeile, ob die Aufgabe ein
          Kurztest oder eine Klausur ist. Klausur-Aufgaben werden auf der Übersicht <strong>immer</strong>
          übersprungen. Das Häkchen betrifft nur Aufgaben ohne diese Kennzeichnung: aus (Standard) werden
          sie bewertet, wenn ihr Horizont wie ein Kurztest aussieht; an bleiben sie liegen.</p>
        </details>
        <button class="co-optreset co-zweit">Alles auf Standard zurücksetzen</button>
      </details>
      <button class="co-optsave">Speichern und zurück</button>
      <button class="co-optverwerfen co-zweit">Verwerfen</button>
      <p class="co-optinfo co-hidden"></p>
    </div>`,(u||document.body).appendChild(H),H.querySelector(`.co-version`).textContent=r;let U=e=>H.querySelector(e),W=null,tt=null,G=null,nt=`coachErnte_`+d+(l?`_slot`+l.slot:``);function rt(){try{t.storage.local.set({[nt]:W})}catch{}}try{t.storage.local.get([nt],e=>{let t=e&&e[nt];if(t&&!W){W=t;let e=U(`.co-meta`);e&&(e.textContent+=` · ${(t.antworten||[]).length} Antworten aus einem früheren Durchlauf geladen`)}})}catch{}if(V.addEventListener(`click`,()=>H.classList.toggle(`co-hidden`)),u){H.querySelector(`.co-head`).classList.add(`co-hidden`),H.querySelector(`.co-tabs`).classList.add(`co-hidden`),H.querySelectorAll(`[data-panel="horizont"], [data-panel="opt"]`).forEach(e=>e.classList.add(`co-hidden`)),H.querySelector(`[data-panel="eintrag"]`).classList.remove(`co-hidden`);let t=H.querySelector(`[data-panel="lesen"] .co-wozu`);t&&t.classList.add(`co-hidden`);let n=H.querySelector(`[data-panel="eintrag"] .co-wozu`);n&&n.classList.add(`co-hidden`);let r=H.querySelector(`.co-go`);r&&(r.textContent=`Antworten dieser Aufgabe laden`);let i=H.querySelector(`.co-uebersichtshinweis`);if(i&&e.uebersicht){i.classList.remove(`co-hidden`);let t=i.querySelector(`.co-uebersichtlink`);t.href=e.uebersicht,H.querySelector(`[data-panel="lesen"]`).prepend(i)}}U(`.co-close`).addEventListener(`click`,()=>H.classList.add(`co-hidden`));function it(e){if(u){let t=H.querySelector(`[data-panel="`+e+`"]`);t&&(e===`lesen`||e===`eintrag`)&&t.scrollIntoView({behavior:`smooth`,block:`start`});return}let t=e===`lesen`||e===`eintrag`;if(H.querySelectorAll(`.co-tab`).forEach(n=>n.classList.toggle(`co-aktiv`,n.dataset.tab===(t?`lesen`:e))),H.querySelectorAll(`[data-panel]`).forEach(n=>n.classList.toggle(`co-hidden`,t?n.dataset.panel!==`lesen`&&n.dataset.panel!==`eintrag`:n.dataset.panel!==e)),e===`eintrag`){let e=H.querySelector(`[data-panel="eintrag"]`);e&&e.scrollIntoView({behavior:`smooth`,block:`start`})}}let at=null;function ot(){at&&=(clearTimeout(at),clearInterval(at),null)}H.querySelectorAll(`.co-tab`).forEach(e=>{e.addEventListener(`click`,()=>{ot(),it(e.dataset.tab)})});function st(){let e=m(U(`.co-abzug`).value);return e===null||e<0?E.maxSprachabzug:Math.min(100,e)}function ct(){let e=st();U(`.co-abzuginfo`).textContent=Me(e,`der Aufgabenpunkte`)}function lt(){let e=U(`.co-kivorschau`);(D.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim(),e.classList.add(`co-hidden`)}U(`.co-ki`).addEventListener(`change`,lt),U(`.co-abzug`).addEventListener(`input`,ct),U(`.co-abzug`).addEventListener(`change`,async()=>{ct(),await j({maxSprachabzug:st()});let e=Te(k().jahrgang)===`sek2`?`rsSek2`:`rsSek1`;o[e]=st(),await dt(e,String(st())),ut()});function ut(){let e=U(`.co-abzug`),t=k();e&&(e.value=String(A()),ct());let n=U(`.co-abzuglabel`);n&&(n.textContent=`Rechtschreibung: Höchstabzug in % der Aufgabenpunkte – `+(Te(t.jahrgang)===`sek2`?`Oberstufe (ab Jahrgang 11)`:`Sekundarstufe I (bis Jahrgang 10)`));let r=U(`.co-anrede`);r&&(r.value=o.anredeWahl||`auto`);let i=U(`.co-kastenkurz`);i&&(i.textContent=[t.anrede===`sie`?`Sie-Anrede`:`Du-Anrede`,`Rechtschreibung bis `+g(A())+` %`,t.jahrgang?`Jahrgang `+t.jahrgang:`Jahrgang aus den Horizonten`].join(` · `));let a=U(`.co-kastenfuss`);a&&(a.textContent=`Im Feedback steht „`+(t.anrede===`sie`?`Sie haben`:`Du hast`)+` …"`+(t.jahrgang?` · Jahrgang `+t.jahrgang:` · Jahrgang unbekannt (Horizont ohne Angabe)`)+`.`)}async function dt(e,n){try{let r=await t.storage.local.get([`magSettings`]),i=r&&r.magSettings||{};i[e]=n,await t.storage.local.set({magSettings:i})}catch{}}U(`.co-kastenauf`).addEventListener(`click`,()=>{let e=U(`.co-kastenfelder`).classList.toggle(`co-hidden`);U(`.co-kastenauf`).textContent=e?`ändern`:`fertig`}),U(`.co-anrede`).addEventListener(`change`,async()=>{o.anredeWahl=U(`.co-anrede`).value,await dt(`anredeWahl`,o.anredeWahl),ut()}),U(`.co-nurmarker`).addEventListener(`change`,async e=>{await j({nurMitMarker:e.target.checked})}),pe().then(()=>{ut(),U(`.co-kitext`).value=D.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,U(`.co-prompt`).value=D.promptOverride||$e(),U(`.co-hprompt`).value=D.horizontPromptOverride||L(),U(`.co-nurmarker`).checked=!!D.nurMitMarker,U(`.co-kompakt`).checked=!!D.kompaktPrompt,U(`.co-kian`).checked=D.kiHinweis!==!1,U(`.co-ki`).checked=D.kiHinweis!==!1,U(`.co-quellen`).checked=D.entferneQuellen!==!1,ct(),lt()}),U(`.co-kistd`).addEventListener(`click`,()=>{U(`.co-kitext`).value=Pe,pt(U(`.co-kistd`),`✓ Eingesetzt – mit „Speichern“ übernehmen`,`Standardtext einsetzen`)});function ft(e){let t=U(`.co-optinfo`);t.textContent=e,t.classList.remove(`co-hidden`),setTimeout(()=>t.classList.add(`co-hidden`),3e3)}U(`.co-optsave`).addEventListener(`click`,async()=>{await j({maxSprachabzug:st(),nurMitMarker:U(`.co-nurmarker`).checked,kompaktPrompt:U(`.co-kompakt`).checked,kiHinweis:U(`.co-kian`).checked,entferneQuellen:U(`.co-quellen`).checked,kiHinweisText:U(`.co-kitext`).value.trim()||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`}),U(`.co-ki`).checked=D.kiHinweis!==!1,D.promptOverride||(U(`.co-prompt`).value=$e()),U(`.co-kitext`).value=D.kiHinweisText,ct(),lt(),ft(`Gespeichert ✓`),pt(U(`.co-optsave`),`✓ Gespeichert`,`Speichern und zurück`),setTimeout(()=>it(`lesen`),900)});function pt(e,t,n){e.textContent=t,setTimeout(()=>e.textContent=n,2e3)}U(`.co-promptstd`).addEventListener(`click`,()=>{U(`.co-prompt`).value=$e(),pt(U(`.co-promptstd`),`✓ eingefügt`,`Standard einfügen`)}),U(`.co-promptsave`).addEventListener(`click`,async()=>{let e=U(`.co-prompt`).value.trim(),t=e===$e().trim()||e===et().trim()?``:e;await j({promptOverride:t}),pt(U(`.co-promptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),U(`.co-hpromptstd`).addEventListener(`click`,()=>{U(`.co-hprompt`).value=L(),pt(U(`.co-hpromptstd`),`✓ eingefügt`,`Standard einfügen`)}),U(`.co-hpromptsave`).addEventListener(`click`,async()=>{let e=U(`.co-hprompt`).value.trim(),t=e===L().trim()?``:e;await j({horizontPromptOverride:t}),pt(U(`.co-hpromptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),U(`.co-optverwerfen`).addEventListener(`click`,()=>{U(`.co-kian`).checked=D.kiHinweis!==!1,U(`.co-quellen`).checked=D.entferneQuellen!==!1,U(`.co-kompakt`).checked=!!D.kompaktPrompt,U(`.co-nurmarker`).checked=!!D.nurMitMarker,U(`.co-kitext`).value=D.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,ft(`Änderungen verworfen – die gespeicherten Einstellungen stehen wieder da.`)}),U(`.co-optreset`).addEventListener(`click`,async()=>{await j({...E,...Fe}),U(`.co-kian`).checked=!0,U(`.co-ki`).checked=!0,U(`.co-quellen`).checked=!0,U(`.co-abzug`).value=g(E.maxSprachabzug),U(`.co-nurmarker`).checked=E.nurMitMarker,U(`.co-kompakt`).checked=E.kompaktPrompt,U(`.co-kitext`).value=Pe,U(`.co-prompt`).value=$e(),U(`.co-hprompt`).value=L(),ct(),lt(),ft(`Auf Standard zurückgesetzt – auch die eigenen Prompts.`)}),U(`.co-meta`).textContent=(document.title||``).replace(/\s*\|.*$/,``).trim()||`Manuelle Bewertung`,U(`.co-go`).addEventListener(`click`,async()=>{let e=U(`.co-go`);e.disabled=!0,e.textContent=`läuft …`,U(`.co-error`).classList.add(`co-hidden`),U(`.co-result`).classList.add(`co-hidden`),U(`.co-progress`).classList.remove(`co-hidden`);try{W=await Ie((e,t,n)=>{U(`.co-bar`).style.width=Math.round(e/t*100)+`%`,U(`.co-ptext`).textContent=`${e} / ${t} Fragen · ${n} Antworten`},U(`.co-bereits`).checked);let e=W.meta,t=Object.values(W.fragen).filter(e=>e.horizont),n=Object.values(W.fragen).filter(e=>!e.horizont),r=Object.values(W.fremde||{}),i=Object.values(W.fragen).filter(e=>e.horizont_aus_fassung).length,a=(e,t,n)=>e+` `+(e===1?t:n),o=Object.keys(W.fragen).length;U(`.co-summary`).textContent=`${a(e.antworten,`Antwort`,`Antworten`)} zu ${a(o,`Kurztest-Aufgabe`,`Kurztest-Aufgaben`)} geladen.`+(e.uebersprungen?` ${a(e.uebersprungen,`schon bewertete Antwort`,`schon bewertete Antworten`)} nicht noch einmal.`:``)+(i?` Maßstab ist jeweils der neueste Horizont der Aufgabe.`:``),U(`.co-warn`).classList.add(`co-hidden`);function s(){let e=U(`.co-prozentbox`);e.innerHTML=``,e.classList.add(`co-hidden`)}s();let c=U(`.co-zust`);c.innerHTML=``;let u=Object.values(W.fragen).filter(e=>e.horizont&&!e.zustaendig);if(r.length||u.length){c.classList.remove(`co-hidden`);let e=r.filter(e=>e.grund===`grader`),t=r.filter(e=>e.grund!==`grader`);if(e.length){c.appendChild(b(`div`,`co-zustkopf`,e.length===1?`• 1 Klausur-Aufgabe wird auf ihrer eigenen Bewertungsseite bewertet:`:`• ${e.length} Klausur-Aufgaben werden auf ihrer eigenen Bewertungsseite bewertet:`));let t=e.map(e=>({slot:e.slot,qid:e.qid,name:e.name}));l||ze(d,t),e.forEach(e=>{let t=b(`a`,`co-logzeile`,`→ `+e.name);t.href=Ve(d,e),c.appendChild(t)});let n=Object.keys(W.fragen||{}).length,r=b(`button`,`co-jetzt`,n?t.length===1?`Nach den Kurztests: weiter zur Klausur-Aufgabe →`:`Nach den Kurztests: weiter zur Klausur-Aufgabe 1 von ${t.length} →`:t.length===1?`Weiter zur Klausur-Aufgabe →`:`Weiter zur Klausur-Aufgabe 1 von ${t.length} →`);if(r.addEventListener(`click`,()=>{location.href=Ve(d,t[0])}),c.appendChild(r),!n){let e=3,n=b(`div`,`co-logzeile`,`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`);c.appendChild(n);let r=setInterval(()=>{if(e--,e>0){n.textContent=`Nur Klausur-Fragen — Sprung zur ersten in ${e} s … (Klick hier bricht ab)`;return}clearInterval(r),location.href=Ve(d,t[0])},1e3);n.addEventListener(`click`,()=>{clearInterval(r),n.textContent=`Automatischer Sprung abgebrochen.`})}}if(t.length&&(c.appendChild(b(`div`,`co-zustkopf`,`• ${t.length===1?`1 Aufgabe ist`:t.length+` Aufgaben sind`} nicht als Kurztest gekennzeichnet und wurde(n) übersprungen (Einstellung unter ⚙ → Für Fortgeschrittene).`)),t.forEach(e=>c.appendChild(b(`div`,`co-logzeile`,e.name)))),u.length){c.appendChild(b(`div`,`co-zustkopf`,`• ${u.length===1?`1 Aufgabe ist`:u.length+` Aufgaben sind`} noch nicht als Kurztest gekennzeichnet (wird trotzdem mitbewertet):`)),u.forEach(e=>c.appendChild(b(`div`,`co-logzeile`,e.name)));let e=u.length===1?`Als Kurztest kennzeichnen`:`Alle ${u.length} als Kurztest kennzeichnen`,t=b(`button`,`co-marker co-zweit`,e),n=!1,r=null;t.addEventListener(`click`,async()=>{if(!n){n=!0,t.textContent=`Wirklich? Ändert die Fragen — noch einmal klicken`,r=setTimeout(()=>{n&&(n=!1,t.textContent=e)},8e3);return}r&&=(clearTimeout(r),null),t.disabled=!0;let i=b(`div`,`co-marklog`);c.appendChild(i);let a=0,o=[];for(let e=0;e<u.length;e++){let n=u[e];t.textContent=`Kennzeichne … ${e+1} von ${u.length}: ${n.name}`;let r=b(`div`,`co-logzeile`,`… ${n.name}`);i.appendChild(r),i.scrollTop=i.scrollHeight;try{await qe(n.qid),a++,r.textContent=`✓ ${n.name}`}catch(e){o.push(`${n.name}: ${e.message}`),r.textContent=`✗ ${n.name}: ${e.message}`,r.classList.add(`co-logfehler`)}}t.textContent=`${a} nachgetragen`+(o.length?`, ${o.length} fehlgeschlagen`:``),a&&c.appendChild(b(`div`,`co-logzeile`,`Bitte „Kurztest-Aufgaben durchsuchen" noch einmal laufen lassen — dann liest die Erweiterung den neuen Stand.`))}),c.appendChild(t)}}else c.classList.add(`co-hidden`);H.querySelector(`.co-badge`);let f=U(`.co-list`);f.innerHTML=``,Object.values(W.fragen).forEach(e=>{let t=b(`div`,`co-qname`);t.appendChild(b(`span`,e.horizont?`co-ok`:`co-fehlt`,e.horizont?`✓`:`✗`)),t.appendChild(b(`span`,`co-qtext`,` ${e.name} · ${h(e.max)} P.`)),f.appendChild(t),W.antworten.filter(t=>t.qid===e.qid).forEach(e=>{let t=b(`a`,`co-row`);t.href=ae(e),t.target=`_blank`,t.rel=`noopener`,t.appendChild(b(`span`,`co-nr`,`#`+e.nr)),t.appendChild(b(`span`,`co-ans`,e.antwort.slice(0,90))),f.appendChild(t)})});let p=U(`.co-ohneliste`);p.innerHTML=``,n.length?(p.appendChild(b(`div`,`co-fehlendkopf`,`Ohne Erwartungshorizont:`)),n.forEach(e=>p.appendChild(b(`div`,`co-logzeile`,`${e.name} — ${e.aufgabe.slice(0,90)}`)))):(p.appendChild(b(`div`,`co-fehlendkopf`,`Alle Fragen haben einen Horizont. Willst du einen neuen für die Aufgaben schreiben?`)),p.appendChild(b(`div`,`co-logzeile`,`Setz dazu unten das Häkchen — der vorhandene Horizont wird beim Eintragen überschrieben.`))),!n.length&&t.length&&(U(`.co-halle`).checked=!0),Tt(),gt(),ut(),rt();let m=z(W).length;U(`.co-groesse`).textContent=`Prompt ≈ ${Math.round(m/1e3)} 000 Zeichen`,U(`.co-result`).classList.remove(`co-hidden`),W.fehler.length&&(U(`.co-error`).textContent=W.fehler.length+` Frage(n) konnten nicht geladen werden.`,U(`.co-error`).classList.remove(`co-hidden`))}catch(e){U(`.co-error`).textContent=`Fehler: `+e.message,U(`.co-error`).classList.remove(`co-hidden`)}finally{U(`.co-progress`).classList.add(`co-hidden`),e.disabled=!1;let t=l?`Antworten dieser Aufgabe neu laden`:`Kurztest-Aufgaben durchsuchen`,n=W&&W.antworten?W.antworten.length:0;e.textContent=U(`.co-error`).classList.contains(`co-hidden`)?`✓ Fertig – ${n} Antworten geladen`:`⚠ Nicht fertig – siehe Meldung`,setTimeout(()=>{e.textContent=t},2500)}});function mt(e){let t={meta:{...e.meta},fragen:{},antworten:[]};Object.entries(e.fragen).forEach(([e,n])=>{n.horizont&&(t.fragen[e]=n)});let n=new Set(Object.values(t.fragen).map(e=>e.qid));return t.antworten=e.antworten.filter(e=>n.has(e.qid)),t.meta.antworten=t.antworten.length,t}function ht(e,t,n,r){let i=U(e);ot();let a=3;i.textContent=`✓ Kopiert — weiter in ${a} s`,at=setInterval(()=>{if(a--,a>0){i.textContent=`✓ Kopiert — weiter in ${a} s`;return}ot(),i.textContent=t,n&&it(n);let e=r&&U(r);e&&(e.focus(),e.scrollIntoView({block:`nearest`}))},1e3)}U(`.co-copy`).addEventListener(`click`,async()=>{W&&(await oe(z(mt(W))),ht(`.co-copy`,`📋 Bewertungsprompt kopieren`,`eintrag`,`.co-json`))}),U(`.co-copy2`).addEventListener(`click`,async()=>{W&&(await oe(JSON.stringify(mt(W),null,1)),ht(`.co-copy2`,`📋 nur JSON`,`eintrag`,`.co-json`))});function gt(){let e=U(`.co-aufgabenliste`);if(!e||!W)return;e.innerHTML=``;let t=e=>location.origin+`/question/bank/editquestion/question.php?id=`+e+(d?`&cmid=`+d:``),n=(e,n)=>{let r=b(`div`,`co-aufgabe`),i=e.horizont?e.vonFreitext?`Horizont aktuell`:`alter Horizont – bitte überarbeiten`:`kein Horizont`,a=[e.jahrgang?`Jg. `+e.jahrgang:``,e.feedback&&e.vonFreitext?`Feedback `+e.feedback:``].filter(Boolean).join(` · `);r.appendChild(b(`div`,`co-aufgabekopf`,e.name||`Aufgabe `+e.slot)),r.appendChild(b(`div`,`co-aufgabestatus`+(e.horizont&&e.vonFreitext?` co-ok`:` co-fehlt`),n+` · `+i+(a?` · `+a:``)));let o=b(`div`,`co-aufgabelinks`);if(e.qid){let n=b(`a`,`co-link`,`Im Frageneditor öffnen`);n.href=t(e.qid),n.target=`_blank`,n.rel=`noopener`,o.appendChild(n)}if(e.qid&&e.slot&&d){let t=b(`a`,`co-link`,`Auf der Bewertungsseite öffnen`);t.href=Ve(d,{slot:e.slot,qid:e.qid}),t.target=`_blank`,t.rel=`noopener`,o.appendChild(t)}return r.appendChild(o),r},r=Object.values(W.fragen||{}),i=Object.values(W.fremde||{});e.appendChild(b(`p`,`co-hinweis`,`Frageneditor: für Aufgaben, die noch nicht geschrieben wurden oder gestaltet werden sollen. Bewertungsseite: für schon geschriebene Tests – dort im Reiter „Horizont".`)),r.forEach(t=>e.appendChild(n(t,`Kurztest`))),i.forEach(t=>e.appendChild(n(t,t.grund===`grader`?`Klausur`:`nicht gekennzeichnet`))),!r.length&&!i.length&&e.appendChild(b(`p`,`co-hinweis`,`Keine Freitextaufgaben gefunden.`));let a=[...r,...i].filter(e=>!(e.horizont&&e.vonFreitext)).length,o=H.querySelector(`.co-badge`);o&&(o.textContent=a?String(a):``,o.classList.toggle(`co-hidden`,!a||!!l));let s=U(`.co-hzhinweis`);if(s&&(s.innerHTML=``,s.classList.toggle(`co-hidden`,!a||!!l),a&&!l)){let e=r.filter(e=>!e.horizont).length;s.appendChild(document.createTextNode(`• `+a+(a===1?` Aufgabe hat`:` Aufgaben haben`)+` keinen aktuellen Horizont`+(e?` (${e} gar keinen – ${e===1?`sie wird`:`sie werden`} nicht bewertet)`:``)+`. `));let t=b(`a`,null,`Zum Reiter „2 · Horizonte" →`);t.addEventListener(`click`,()=>it(`horizont`)),s.appendChild(t)}}let _t=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in im Reiter „1 · Bewerten“ „Kurztest-Aufgaben durchsuchen" laufen lassen.`;function vt(e){let t=e.value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen.`);return JSON.parse(t)}U(`.co-pruef`).addEventListener(`click`,()=>{let e=U(`.co-pinfo`);e.classList.remove(`co-hidden`),U(`.co-schreibknoepfe`).classList.add(`co-hidden`),U(`.co-abschluss`).classList.add(`co-hidden`),U(`.co-log`).classList.add(`co-hidden`),U(`.co-vorschau`).innerHTML=``,tt=null;try{if(!W)throw Error(_t);let t=vt(U(`.co-json`)),n=t.bewertungen||[];if(!n.length)throw Error(`Keine „bewertungen" im JSON gefunden.`);let r=new Map(W.antworten.map(e=>[e.qubaid+`|`+e.slot,e])),i=[];n.forEach((e,t)=>{let n=t+1;if(e.qubaid==null||e.slot==null)throw Error(`Eintrag ${n}: „qubaid" oder „slot" fehlt.`);let a=r.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Eintrag ${n}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesene Antwort. Stammt das JSON zu diesem Durchlauf?`);let o=Number(e.inhalt);if(isNaN(o)||o<0||o>100)throw Error(`Eintrag ${n}: „inhalt" ist kein Prozentwert (${e.inhalt}).`);let s=W.fragen&&W.fragen[a.frage]||{},c=he(a.max,o,e.fehler,fe(s),a.antwort),l=o<100?ne(s.horizont):``,u=te(D.entferneQuellen?Le(e.rueckmeldung):e.rueckmeldung,l,{inhalt:c.inhaltPunkte,inhaltMax:a.max,abzug:c.abzugPunkte,gewicht:c.gewicht})||String(e.text||``).trim();i.push({...a,inhalt:o,fehler:e.fehler||[],text:u,punkte:c.punkte,gewicht:c.gewicht,abzug:c.abzug,rechnung:`Inhalt ${g(o)} % = ${h(c.inhaltPunkte)} · ${c.gewicht} Fehlerpunkt(e) → −${g(Math.round(c.abzug*10)/10)} % · = ${h(c.punkte)} von ${h(a.max)}`})}),tt=i;let a=i.filter(e=>!e.text).length,o=new Set(i.map(e=>e.slot+`|`+e.qid)).size;e.className=`co-pinfo co-ok`,e.textContent=`✓ ${i.length} Bewertungen auf ${o} Fragenseiten — bereit. Punkte und Abzug wurden aus Inhalt und Fehlerzahl berechnet (Rechtschreib-Höchstabzug ${g(A())} %).`+(a?` ⚠ ${a} Eintrag/Einträge ohne Rückmeldungstext.`:``);let s=i.filter(e=>e.bisher!=null),c=s.filter(e=>Math.abs(e.bisher-e.punkte)<.005).length,l=s.filter(e=>e.punkte-e.bisher>=.005).length,u=s.length-c-l;s.length&&(e.textContent+=` Vergleich mit der bisherigen Bewertung: ${c} gleich, ${l} höher, ${u} niedriger.`);let d=typeof t.besprochen==`boolean`?t.besprochen:null;d===!0&&(e.textContent+=` Mit der KI gemeinsam besprochen.`),d===!1&&(e.textContent+=` Automatisch bewertet – ein Blick in die Liste lohnt sich.`);let f=b(`div`,`co-rechnung`);i.forEach(e=>{let t=b(`a`,`co-logzeile co-vorschauzeile`),n=ae(e);if(n&&(t.href=n,t.target=`_blank`,t.rel=`noopener`),t.appendChild(b(`span`,`co-vfrage`,e.frage)),t.appendChild(b(`span`,`co-vans`,`„`+e.antwort.slice(0,60)+`"`)),t.appendChild(b(`span`,`co-vpkt`,e.rechnung)),e.bisher!=null){let n=Math.abs(e.bisher-e.punkte)>=.005,r=b(`span`,`co-vbisher`+(n?` co-vanders`:``),`bisher `+h(e.bisher)+` → neu `+h(e.punkte));t.appendChild(r)}f.appendChild(t)}),U(`.co-vorschau`).appendChild(f);let p=yt(i);p&&U(`.co-vorschau`).prepend(p),U(`.co-schreibknoepfe`).classList.remove(`co-hidden`),U(`.co-schreibknoepfe`).scrollIntoView({block:`nearest`})}catch(t){e.className=`co-pinfo co-error`,e.textContent=`Fehler: `+t.message}});function yt(e){if(e.length<2)return null;let t=new Set(e.map(e=>Number(e.max))),n=t.size===1,r=n?Xe(e.map(e=>Number(e.punkte)),[...t][0],{wort:`Antworten`}):Xe(e.map(e=>Math.round(Number(e.punkte)/Number(e.max)*100)),100,{schritt:10,einheit:`Prozent der Punkte`,wort:`Antworten`});if(!r.n)return null;let i=b(`details`,`co-verteilung`);i.open=!0,i.appendChild(b(`summary`,null,`📊 Punkteverteilung dieser Bewertung`+(n?``:` (in % – Aufgaben mit verschiedener Höchstpunktzahl)`)));let a=b(`div`,`co-vtinhalt`);return a.appendChild(Ze(r.svg)),i.appendChild(a),i}function bt(e){return(t,n)=>{let r=b(n?`a`:`div`,`co-logzeile`,t);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`),(t.startsWith(`✗`)||t.startsWith(`⚠`))&&r.classList.add(`co-logfehler`),e.appendChild(r),e.scrollTop=e.scrollHeight}}async function xt(e){if(!tt)return;let t=U(`.co-log`),n=U(`.co-abschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),U(`.co-progress2`).classList.remove(`co-hidden`),U(`.co-alle`).disabled=!0,U(`.co-progress2`).scrollIntoView({block:`nearest`});let r=bt(t),i=(e,t)=>{U(`.co-bar2`).style.width=Math.round(e/t*100)+`%`,U(`.co-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await Be(tt,r,i):await We(tt,U(`.co-ki`).checked,r,i);if(t.prepend(b(`div`,`co-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`+(a.versuche>1?` · ${a.versuche} Versuche gebraucht`:``))),n.classList.remove(`co-hidden`),a.fehler>0)n.className=`co-abschluss co-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen. Trag noch nichts ein — stammt das JSON zu diesem Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach.`,e||(U(`.co-alle`).textContent=`Erneut versuchen`);else if(n.className=`co-abschluss co-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,e||(U(`.co-alle`).textContent=`Alle eintragen`),!e&&l)n.textContent=`✓ Fertig — ${a.ok} Einträge, keine Fehler. Die Seite lädt neu und zeigt die neuen Punkte …`,setTimeout(()=>location.reload(),2500);else if(!e){let e=3,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),H.classList.add(`co-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);H.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message)}finally{U(`.co-progress2`).classList.add(`co-hidden`),U(`.co-alle`).disabled=!1}}U(`.co-alle`).addEventListener(`click`,()=>xt(!1)),U(`.co-json`).addEventListener(`paste`,()=>setTimeout(()=>U(`.co-pruef`).click(),0)),U(`.co-hjson`).addEventListener(`paste`,()=>setTimeout(()=>U(`.co-hpruef`).click(),0)),[[`.co-json`,`.co-pruef`],[`.co-hjson`,`.co-hpruef`]].forEach(([e,t])=>{let n=null;U(e).addEventListener(`input`,r=>{r.inputType!==`insertFromPaste`&&(clearTimeout(n),n=setTimeout(()=>{U(e).value.trim()&&U(t).click()},800))})});function St(){if(!W)return[];let e=Object.values(W.fragen);return U(`.co-halle`).checked?e:e.filter(e=>!e.horizont)}let Ct=`coachWunsch_`+d;function wt(){let e=H.querySelector(`.co-hwunsch`);return e?e.value.trim():``}try{t.storage.local.get([Ct],e=>{let t=e&&e[Ct];t&&!wt()&&(H.querySelector(`.co-hwunsch`).value=t)})}catch{}H.querySelector(`.co-hwunsch`).addEventListener(`input`,()=>{try{t.storage.local.set({[Ct]:wt()})}catch{}});function Tt(){let e=St().length,t=U(`.co-halle`).checked;U(`.co-hcopy`).textContent=t?`📋 Prompt zum Neuschreiben kopieren (${e} Frage${e===1?``:`n`})`:`📋 Prompt für Erwartungshorizont kopieren`}U(`.co-halle`).addEventListener(`change`,Tt),U(`.co-hcopy`).addEventListener(`click`,async()=>{if(!W){U(`.co-hinfo`).className=`co-hinfo co-error`,U(`.co-hinfo`).classList.remove(`co-hidden`),U(`.co-hinfo`).textContent=_t;return}let e=St();if(!e.length){U(`.co-hinfo`).className=`co-hinfo`,U(`.co-hinfo`).classList.remove(`co-hidden`),U(`.co-hinfo`).textContent=`Es fehlt kein Horizont. Setz das Häkchen darüber, wenn du die vorhandenen neu schreiben lassen willst.`;return}await oe(B(e));let t=U(`.co-hcopy`).textContent;ht(`.co-hcopy`,t,`horizont`,`.co-hjson`)}),U(`.co-hpruef`).addEventListener(`click`,()=>{let e=U(`.co-hinfo`);e.classList.remove(`co-hidden`),U(`.co-hknoepfe`).classList.add(`co-hidden`),U(`.co-habschluss`).classList.add(`co-hidden`),U(`.co-hlog`).classList.add(`co-hidden`),U(`.co-hliste`).innerHTML=``,G=null;try{let t=vt(U(`.co-hjson`)).horizonte||[];if(!t.length)throw Error(`Keine „horizonte" im JSON gefunden.`);let n=W?new Map(Object.values(W.fragen).map(e=>[String(e.qid),e])):new Map;G=t.map((e,t)=>{if(!e.qid)throw Error(`Horizont ${t+1}: „qid" fehlt.`);let r=n.get(String(e.qid)),i=String(e.text||``).trim();if(!i)throw Error(`Horizont ${t+1}: „text" ist leer.`);return{qid:String(e.qid),frage:e.frage||(r?r.name:`Frage `+e.qid),text:i,bekannt:!!r,hatteHorizont:!!(r&&r.horizont)}});let r=G.filter(e=>e.hatteHorizont).length,i=G.filter(e=>!e.bekannt).length;e.className=`co-hinfo co-ok`,e.textContent=`✓ ${G.length} Horizont(e) gelesen.`+(i?` ⚠ ${i} gehören zu keiner ausgelesenen Frage.`:``)+(r?` ⚠ ${r} würden einen vorhandenen Horizont überschreiben.`:``);let a=U(`.co-hliste`);G.forEach((e,t)=>{let n=b(`div`,`co-hcard`);n.appendChild(b(`div`,`co-fehlendkopf`,`${e.frage}  ·  qid ${e.qid}`));let r=b(`textarea`,`co-htext`);r.value=e.text,r.rows=10,r.addEventListener(`input`,()=>{G[t].text=r.value}),n.appendChild(r),a.appendChild(n)}),U(`.co-hknoepfe`).classList.remove(`co-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`co-hinfo co-error`,e.textContent=`Fehler: `+t.message}});async function Et(e){if(!G||!G.length)return;let t=U(`.co-hlog`),n=U(`.co-habschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),U(`.co-progress3`).classList.remove(`co-hidden`),U(`.co-hschreib`).disabled=!0,U(`.co-progress3`).scrollIntoView({block:`nearest`});let r=bt(t),i=0,a=0,o=0;try{for(let t of G){try{let n=await Ke(t.qid,t.text,e);i++,r(e?`✓ ${t.frage} — Feld „${n.feld}" vorhanden`+(n.vorher&&n.vorher.replace(/<[^>]*>/g,``).trim()?` (enthält schon Text!)`:``):`✓ ${t.frage} — Horizont eingetragen`)}catch(e){a++,r(`✗ ${t.frage}: ${e.message}`)}o++,U(`.co-bar3`).style.width=Math.round(o/G.length*100)+`%`,U(`.co-ptext3`).textContent=`${o} / ${G.length} Fragen`}t.prepend(b(`div`,`co-logkopf`,e?`${i} Fragen erreichbar · ${a} nicht`:`${i} Horizonte eingetragen · ${a} fehlgeschlagen`)),n.classList.remove(`co-hidden`),n.className=`co-habschluss `+(a?`co-abfehler`:`co-abok`),n.textContent=a?`⚠ ${a} Frage(n) konnten nicht geschrieben werden. Sieh ins Protokoll.`:e?`✓ Alle ${i} Fragen sind erreichbar und haben das Feld. Du kannst eintragen.`:`✓ ${i} Horizonte stehen jetzt in den Fragen. Lass „Kurztest-Aufgaben durchsuchen“ noch einmal laufen, dann sind sie im Bewertungs-Prompt dabei.`,n.scrollIntoView({block:`nearest`}),!a&&!e&&(n.textContent+=` Weiter zu „1 · Bewerten“ in 3 s …`,ot(),at=setTimeout(()=>{at=null,it(`lesen`)},3e3))}finally{U(`.co-progress3`).classList.add(`co-hidden`),U(`.co-hschreib`).disabled=!1}}U(`.co-hschreib`).addEventListener(`click`,()=>{let e=G?G.length:0;if(!e)return;let t=U(`.co-habschluss`);t.classList.remove(`co-hidden`),t.className=`co-habschluss co-abfrage`,t.innerHTML=``,t.appendChild(b(`div`,null,`Der Erwartungshorizont wird in ${e} Frage(n) der Fragensammlung geschrieben. Das ändert die Fragen selbst, nicht nur eine Bewertung.`));let n=b(`button`,`co-jetzt`,`Ja, in ${e} Frage(n) eintragen`);t.appendChild(n),n.addEventListener(`click`,()=>{t.classList.add(`co-hidden`),Et(!1)})})}function $e(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``;function i(){return!!document.querySelector(`[name="graderinfo[text]"]`)}function l(){return document.querySelectorAll(`input[id$="-mark"]`).length!==0&&!!(document.querySelector(`.qtype_essay_response`)||document.querySelector(`textarea[id$="-comment_id"]`)||document.querySelector(`textarea[name$="-comment"]`)||document.querySelector(`.ablock`))}let u=i()?`bearbeiten`:l()?`bewertung`:null;if(!u)return;let f=a,p=r,m=/rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%/i,h=/punkteschritte\s*[:\-]?\s*([\d.,]+)/i;function te(e){let t=P();return we({fach:t.fach,jahrgang:t.jahrgang,niveau:t.niveau,feedback:e})}function x(e){let t=F(e).split(`
`).map(e=>e.trim()),n=[];for(let e of t)if(e&&(oe.test(e)||(n.push(e),n.length>=6)))break;return n.join(`
`)}let re=/^\s*\[?\s*feedback\s*[:\-]?\s*(kurz|mittel|ausführlich|umfangreich)\s*\]?\s*$/im;function S(e){let t=x(e).match(re);return t?t[1].charAt(0).toUpperCase()+t[1].slice(1).toLowerCase():null}function ie(){if(Z!==void 0&&Z)return Z;let e=``;try{e=B()||C.horizontLokal||``}catch{}return S(e)||`Ausführlich`}function ae(){let e=``;try{e=B()||C.horizontLokal||``}catch{}return!!S(e)}let oe=/^\s*[①-⑳⓪]?\s*(?:Aufgabe\s+(\d{1,2}\s*[a-h]?)(?![a-z])|(\d{1,2}[a-h]?)\s*·)/i,se=e=>E(e[1]||e[2]),ce={fach:``,jahrgang:``,kursniveau:`G`,punkteschritte:`0.5`,rechtschreibung:`10`,rsSek1:``,rsSek2:`25`,anredeWahl:`auto`,feedbacklaenge:`Ausführlich`,afbFarben:!0,vorlagePunkte:!0,vorlageAfb:!0,kartePunkte:!0,layoutAufgabe:!0,layoutAntwort:!0,kiHinweis:!0,kiHinweisText:Pe,entferneQuellen:!0,kompaktPrompt:!1,promptHorizont:null,promptKorrektur:null,horizontLokal:``,sprachabzugKurztest:`30`},C=JSON.parse(JSON.stringify(ce)),w=(e,t)=>(t||document).querySelector(e),ue=(e,t)=>[...(t||document).querySelectorAll(e)];function T(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r}function D(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function O(e){return String(e).replace(`.`,`,`)}function k(e){return parseFloat(String(e??``).replace(`,`,`.`))}function A(e,t,n){let r=n||parseFloat(C.punkteschritte)||.5,i=Math.round(e/r)*r;return i=Math.max(0,Math.min(i,t)),Math.round(i*100)/100}function pe(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function j(e){let t=String(e||``),n=pe(t);t=f.test(n)?t.replace(n,n.replace(f,``)).replace(/^\s*\n/,``):t.replace(o,``).replace(/^\s*\n+/,``);for(let e=0;e<8;e++){let e=pe(t);if(e&&(xe(e)||m.test(e)||h.test(e)||re.test(e)))t=t.replace(e,``).replace(/^\s*\n/,``);else break}return t}function ge(e){return C.entferneQuellen?Ie(e):String(e||``)}function ye(){return Ee(N().jahrgang,C.anredeWahl)}function be(){return ye()===`sie`?`Sie haben`:`Du hast`}let M=null,De=null;function Oe(){return De||={fach:C.fach||``,jahrgang:C.jahrgang||``,niveau:C.kursniveau||`G`},De}function N(){if(u!==`bewertung`)return P();let e=Le(),t=Oe();return{fach:e.fach||t.fach,jahrgang:e.jahrgang||t.jahrgang,niveau:e.niveau||t.niveau,ausHorizont:!!(e.fach||e.jahrgang||e.niveau)}}function Fe(){if(u!==`bewertung`)return ie();let e=``;try{e=B()||C.horizontLokal||``}catch{}return S(e)||(X===`kurztest`?`Mittel`:`Ausführlich`)}function Le(){let e=``;try{e=B()||C.horizontLokal||``}catch{}return Se(F(e))}function P(){if(M)return M;let e=Le();return{fach:e.fach||C.fach||``,jahrgang:e.jahrgang||C.jahrgang||``,niveau:e.niveau||C.kursniveau||`G`,ausHorizont:!!(e.fach||e.jahrgang||e.niveau)}}function ze(e){return Te(e)===`sek2`?C.rsSek2===``||C.rsSek2==null?`25`:String(C.rsSek2):C.rsSek1===``||C.rsSek1==null?String(C.rechtschreibung||`10`):String(C.rsSek1)}function We(e){return Te(e)===`sek2`?`rsSek2`:`rsSek1`}function F(e){let t=String(e||``).replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi,`</$1>
`);return(new DOMParser().parseFromString(t,`text/html`).body.textContent||``).replace(/[ \t]+/g,` `).replace(/\n{3,}/g,`

`).trim()}function Ge(e){return new DOMParser().parseFromString(String(e||``),`text/html`).body}function Ke(e,t){e.replaceChildren(...Ge(t).childNodes)}let qe=/^(DIV|P|H[1-6]|UL|OL|LI|TABLE|TBODY|TR|TD|TH|BLOCKQUOTE|SECTION|ARTICLE|PRE)$/;function Je(e){return String(e.textContent||``).replace(/\s+/g,` `).trim()}async function I(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}function Ye(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&e.type!==`button`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}async function Xe(e,t,n){let r=[...e.querySelectorAll(`input[type=submit],button[type=submit]`)].filter(e=>e.name&&e.name!==`cancel`),i=r.find(e=>e.name===`submitbutton`)||r[0];i&&t.set(i.name,i.value);let a=new URL(e.getAttribute(`action`)||n,n).href,o=await fetch(a,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:t.toString()});if(!o.ok)throw Error(`HTTP `+o.status+` beim Speichern`);return o}async function Ze(e,t,n){try{let r=new URL(e.url||n),i=r.searchParams.get(`lastchanged`),a=new URL(n).searchParams.get(`cmid`)||r.searchParams.get(`cmid`);if(i)return location.origin+`/question/bank/editquestion/question.php?id=`+i+(a?`&cmid=`+a:``);let o=[...new DOMParser().parseFromString(await e.clone().text(),`text/html`).querySelectorAll(`[data-itemtype="questionname"]`)].find(e=>(e.getAttribute(`data-value`)||``)===t);if(o&&o.getAttribute(`data-itemid`))return location.origin+`/question/bank/editquestion/question.php?id=`+o.getAttribute(`data-itemid`)+(a?`&cmid=`+a:``)}catch{}return null}function $e(e,t){let n=e=>F(e).replace(/\s+/g,` `).trim(),r=n(e),i=n(t);if(!r||!i)return!1;if(r===i)return!0;if(Math.abs(r.length-i.length)>Math.max(40,i.length*.2))return!1;let a=i.slice(Math.floor(i.length/2),Math.floor(i.length/2)+40);return r.includes(i.slice(0,40))&&(a.length<20||r.includes(a))}async function et(e,t){let n=location.href,r=await I(n),i=[...r.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!i)throw Error(r.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let a=Ye(i),o=[];for(let n of Object.keys(e)){if(!a.has(n))throw Error(`Feld „`+n+`" nicht im Formular`);let r=a.get(n)||``;o.push({feld:n,belegt:F(r).length>0}),t||a.set(n,e[n])}if(t)return{bericht:o};let s=(i.querySelector(`[name="name"]`)||{}).value||``,c=await Ze(await Xe(i,a,n),s,n),l=[...(await I(c||n)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),u=[];for(let t of Object.keys(e)){let n=l&&l.querySelector(`[name="`+CSS.escape(t)+`"]`);u.push({feld:t,ok:!!n&&$e(n.value,e[t])})}return{bericht:o,ergebnis:u,neueUrl:c,warnung:c?null:`Die neue Fragenversion war nicht auffindbar — die Gegenprobe lief gegen den alten Stand und kann falsch sein.`}}function L(){if(u===`bearbeiten`){let e=w(`[name="questiontext[text]"]`);return e?F(e.value):``}let e=w(`.que .qtext`)||w(`.qtext`);return e?e.innerText.trim():``}function R(){if(u===`bearbeiten`){let e=w(`[name="defaultmark"]`);return e&&k(e.value)||0}let e=w(`input[name$="-maxmark"]`);if(e)return k(e.value)||0;let t=w(`.que .grade`),n=t&&t.innerText.match(/([\d.,]+)\s*$/);return n?k(n[1]):0}let z=null;function B(){if(u===`bearbeiten`)return b(`graderinfo[text]`);if(z)return z;let e=w(`.que .graderinfo`)||w(`.graderinfo`);return e?e.innerHTML.replace(/^\s*<h\d[^>]*>[^<]*Bewerter[^<]*<\/h\d>/i,``):``}function V(){let e=F(B());if(!e)return{horizont:!1,wer:null};let t=s(e.split(`
`).map(e=>e.trim()).filter(Boolean).slice(0,5).map(e=>e.match(f)).find(Boolean)||null);return!t&&/Kernaussage\s*:/i.test(e)&&!e.split(`
`).some(e=>oe.test(e))&&(t=`coach`),{horizont:!0,wer:t}}function H(e){let t=Ge(j(String(e||``))),n=[],r=null;if([...t.children].forEach(e=>{let t=Je(e),i=t.match(oe);if(i&&/^(H[1-6]|P|DIV)$/.test(e.tagName)&&t.length<200){r={nr:se(i),kopf:t,html:``,text:``},n.push(r);return}r&&(r.html+=e.outerHTML,r.text+=F(e.outerHTML)+`
`)}),!n.length){let t=j(F(e));return t?[{nr:`1`,kopf:`Aufgabe 1`,html:String(e||``),text:t,punkte:null,afb:null,ganzeArbeit:!0}]:[]}return n.forEach(e=>{e.text=e.text.trim();let t=e.kopf.match(/\(\s*([\d.,]+)\s*(?:P\.?|Punkte?)\s*\)/i);e.punkte=t?k(t[1]):null;let n=e.kopf.match(/AFB\s*(I{1,3}(?:\s*[-–]\s*I{1,3})?)/i);e.afb=n?n[1].replace(/\s/g,``):null}),n}function U(e){let t=e;for(let e=0;e<12&&t;e++)if(t=t.parentElement,t&&t.classList&&(t.classList.contains(`que`)||t.classList.contains(`content`)))return t;return null}function W(){return ue(`input[id$="-mark"]`).map((e,t)=>{let n=U(e),r=n&&n.querySelector(`.qtype_essay_response`),i=n&&n.querySelector(`textarea[name$="-comment"]`),a=n&&n.querySelector(`input[name$="-maxmark"]`),o=r&&r.innerHTML||``,s=r?r.innerText.trim():``;return{nr:t+1,markfeld:e.name||``,kommentarfeld:i?i.name:``,ist:k(e.value)||0,max:a?k(a.value)||0:R(),rohHtml:o,text:s,anker:n&&n.id?`#`+n.id:``}}).filter(e=>e.markfeld)}function tt(e,t){let n=Ge(e),r=[],i=null,a=e=>{let t=[...e.children].filter(e=>qe.test(e.tagName));if(!t.length){let t=Je(e);if(!t)return;let n=t.match(oe);n&&t.length<160?(i={nr:se(n),text:``},r.push(i)):i&&(i.text+=t+`
`);return}t.forEach(a)};return a(n),r.length>=1?(r.forEach(e=>{e.text=e.text.trim()}),{gegliedert:!0,aufgaben:r,leer:r.every(e=>!e.text)}):{gegliedert:!1,aufgaben:[{nr:`1`,text:String(t||``).trim()}]}}function G(e,t,n,r,i){let a=e.max||R()||0,o=(n||[]).filter(e=>e.punkte!=null).reduce((e,t)=>e+t.punkte,0),s=n&&n.length?n.map(e=>e.nr):(t.aufgaben||[]).map(e=>E(e.nr)),c=Math.max(1,s.length),l=[],u=s.map(e=>{let r=(t.aufgaben||[]).find(t=>E(t.nr)===e)||(l.push(e),{nr:e,prozent:0}),i=(n||[]).find(t=>t.nr===e),s;s=i&&i.punkte!=null&&o>0?a>0?i.punkte*a/o:i.punkte:a/c;let u=Math.max(0,Math.min(100,Number(r.prozent)||0));return{nr:e,max:s,prozent:u,roh:s*u/100}}),d=u.reduce((e,t)=>e+t.roh,0),f=a*(r??(parseFloat(C.rechtschreibung)||0))/100,p=Ae(t.fehler),m=ke(e.text),ee=je(p,m),h=Math.min(f*ee,d);u.forEach(e=>{let t=d>0?e.roh/d:0;e.abzug=h*t,e.netto=Math.max(0,e.roh-e.abzug)});let g=i||parseFloat(C.punkteschritte)||.5,_=A(u.reduce((e,t)=>e+t.netto,0),a,g);u.forEach(e=>{e.punkte=Math.max(0,Math.floor(e.netto/g+1e-9)*g),e.rest=e.netto-e.punkte});let v=Math.round((_-u.reduce((e,t)=>e+t.punkte,0))/g),y=u.slice().sort((e,t)=>t.rest-e.rest);for(let e=0;v>0&&e<y.length*4;e++){let t=y[e%y.length];t.punkte+g<=t.max+1e-9&&(t.punkte+=g,v--)}for(let e=0;v<0&&e<y.length*4;e++){let t=y[y.length-1-e%y.length];t.punkte-g>=-1e-9&&(t.punkte-=g,v++)}return u.forEach(e=>{e.punkte=Math.round(e.punkte*100)/100}),{teil:u,wortzahl:m,fehlerGewichtet:p,fehlerDichte:m>0?Math.round(p*1e3/m)/10:0,hoechstabzug:Math.round(f*100)/100,abzug:Math.round(h*100)/100,gesamt:_,max:a,fehlendeAufgaben:l}}function nt(e){let t=D(`Aufgabe `+e.nr);return e.afb&&(t+=` <span style="font-size:13px;font-style:italic;font-weight:normal;color:#6b6b6b;">AFB `+D(e.afb)+`</span>`),e.schlagwort&&(t+=` · `+D(e.schlagwort)),e.punkte!=null&&(t+=` <span style="font-size:12px;font-weight:600;color:#6b6b6b;">(`+D(O(e.punkte))+(Number(e.punkte)===1?` Punkt`:` Punkte`)+`)</span>`),t}function rt(){return{farbig:C.afbFarben!==!1,zeigeAfb:!!C.vorlageAfb,zeigePunkte:!!C.vorlagePunkte}}function it(e){return(e||[]).map(e=>fe(Object.assign({label:String(e.nr),titel:e.schlagwort||`Deine Antwort`,afb:e.afb,punkte:e.punkte},rt()))).join(`
`)}function at(e){let t=String(e||``).replace(/\r/g,``).match(/Teile\s*:\s*\n([\s\S]*?)(?:\n\s*\n|$)/i),n={};return t&&t[1].split(`
`).forEach(e=>{let t=e.match(/^\s*[-•]?\s*([a-h])\s*[).:]?\s.*?([\d]+(?:[.,]\d+)?)\s*Punkt/i);t&&(n[t[1].toLowerCase()]=k(t[2]))}),n}function ot(){return Qt||F(B()||``)}function st(){let e=b(`questiontext[text]`)||``,t=me(de(e)?``:e).segmente.filter(e=>e.typ===`aufgabe`),n=at(ot()),r=le(F(e));return t.filter(e=>/^[a-h]$/.test(e.label)).map(e=>({nr:e.label,afb:le(e.knoten.map(e=>e.textContent||``).join(` `))||r,punkte:n[e.label]==null?null:n[e.label]}))}function ct(){let e=st(),t=rt();if(e.length>=2)return e.map(e=>fe(Object.assign({label:e.nr,titel:`Deine Antwort`,afb:e.afb,punkte:e.punkte},t))).join(`
`);let n=b(`questiontext[text]`)||``;return fe(Object.assign({label:``,titel:`Deine Antwort`,afb:le(F(n)),punkte:R()||null},t))}function lt(){if(J)return J;let e=H(B());return!e.length||e[0].ganzeArbeit?null:e.map(e=>{let t=(e.kopf.match(/·\s*([^()]+?)\s*(?:\(|$)/)||[])[1]||``;return{nr:e.nr,afb:e.afb,punkte:e.punkte,schlagwort:t}})}function ut(){return!!(J||Qt||F(B()||``).trim())}function dt(){if(u!==`bearbeiten`)return!0;let e=w(`[name="responseformat"]`);return!e||/editor/i.test(e.value||``)}function ft(){if(u===`bearbeiten`&&X===`kurztest`)return ct();let e=lt();return e?it(e):null}function pt(){let e=b(`questiontext[text]`);if(!F(e||``).trim())return{fehler:`Die Aufgabenstellung ist noch leer.`};if(de(e))return{fehler:`Die Aufgabenstellung ist schon im Kartendesign gestaltet. Zum Neugestalten erst den ursprünglichen Text wiederherstellen (Moodle-Versionsverlauf der Frage).`};let t=X===`kurztest`,n=t?st():lt()||[],r=he(e,{aufgaben:n,punkte:t?!0:C.kartePunkte!==!1,gesamtAfb:t?le(F(e)):``});return t&&n.length>=2&&n.some(e=>e.punkte==null)&&r.hinweise.push(`Im Horizont fehlen die Punkte je Teil (Abschnitt „Teile:"). Horizont neu erstellen, dann stehen sie dort.`),r}function mt(){if(!q(`hstatus`))return;let e=B()||``,t=F(e).trim(),n=q(`hschritt1`),r=K.querySelector(`[data-tu="hprompt"]`),i=K.querySelector(`[data-tu="hschreiben"]`),a=q(`hbisher`);if(!t)return n&&(n.textContent=`1 · Prompt zum Erstellen des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`Horizont eintragen`),a&&(a.hidden=!0),Q(`hstatus`,`Noch kein Erwartungshorizont in dieser Aufgabe.`+(yn()?` Bitte unter „Diese Aufgabe" Fach und Jahrgang angeben.`:``));let o=/moodle[-\s]?ai[-\s]?(coach|grader)/i.test(t),s=c(t),l=S(e),u=[s===`kurztest`?`Kurztest`:s===`klausur`?`Klausur`:``,l?`Feedback `+l:``].filter(Boolean).join(`, `);if(Q(`hstatus`,o?`Dieser Horizont stammt noch aus Coach oder Grader. Bitte neu erstellen – der alte geht als Vorlage in den Prompt ein.`:`Diese Aufgabe hat schon einen Erwartungshorizont`+(u?` (`+u+`)`:``)+`. Der Prompt nimmt ihn als Vorlage mit; die KI sagt dir, was sie übernimmt und was sie ändert.`),n&&(n.textContent=`1 · Prompt zum Überarbeiten des Erwartungshorizonts kopieren`),r&&(r.textContent=`📋 Horizont-Prompt kopieren`),i&&(i.textContent=`Vorhandenen Horizont ersetzen`),a){a.hidden=!1;let e=a.querySelector(`pre`);e&&(e.textContent=j(t))}}function ht(){let e=q(`hstatus`)?q(`hstatus`).textContent:``;mt(),e&&q(`hstatus`)&&(q(`hstatus`).textContent=e),$()}function gt(){let e=K.querySelector(`.mag-tab[data-tab="vorlage"]`);if(e&&(e.hidden=!(u===`bearbeiten`&&ut())),!q(`lseca`))return;q(`lseca`).hidden=C.layoutAufgabe===!1,q(`lsecv`).hidden=C.layoutAntwort===!1;let t=X===`kurztest`;q(`lpunktezeile`).hidden=t,q(`lpunktehinweis`).hidden=t;let n=K.querySelector(`[data-tu="lein"]`);if(n&&(n.disabled=C.layoutAufgabe===!1&&C.layoutAntwort===!1),C.layoutAufgabe!==!1){let e=pt();e.fehler?(Ke(q(`lavorschau`),`<p class="mag-hinweis">`+D(e.fehler)+`</p>`),q(`lahinweise`).textContent=``):(Ke(q(`lavorschau`),e.html),q(`lahinweise`).textContent=e.hinweise.join(` `))}}function _t(e){return((e||[]).some(e=>f.test(pe(F(e.horizont))))?``:`<p>`+p+`</p>`+te(Z))+(e||[]).map(e=>{let t=String(e.horizont||``).trim();return/<[a-z][\s\S]*>/i.test(t)||(t=`<p>`+D(t).replace(/\n{2,}/g,`</p><p>`).replace(/\n/g,`<br>`)+`</p>`),`<h4>`+nt(e)+`</h4>`+t}).join(`
`)}let vt=Ce;function yt(){let e=N();return[`Fach: `+(e.fach||`[nicht angegeben]`),`Jahrgang: `+(e.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(vt[e.niveau]||e.niveau),`Feedbacklänge: `+Fe(),`Anrede im Feedback: `+be()+` …`].join(`
`)}function bt(){let e=P();return[`Fach: `+(e.fach||`[nicht angegeben]`),`Jahrgang: `+(e.jahrgang||`[nicht angegeben]`),`Kursniveau: `+(vt[e.niveau]||e.niveau)].join(`
`)}function xt(){return`═══════════════════════════════════════════════════════
MOODLE AI FREITEXT GRADER – ERWARTUNGSHORIZONT (KLAUSUR)
═══════════════════════════════════════════════════════

Du bist erfahrene Lehrkraft und erstellst den Erwartungshorizont für eine Klausur. Er
wird in Moodle im Feld „Informationen für Bewerter/innen" gespeichert; Schülerinnen und
Schüler sehen ihn nicht.

${_}

RAHMENDATEN
[MAG_RAHMENDATEN]

AUFGABENSTELLUNG (aus Moodle übernommen, Gesamtpunktzahl: [MAG_GESAMTPUNKTE])
[MAG_AUFGABEN]

WAS DU TUST
1. Zerlege die Aufgabenstellung in ihre Teilaufgaben. Übernimm die Nummerierung der
   Aufgabenstellung. Steht dort eine Punktzahl je Aufgabe, übernimm sie unverändert;
   fehlt sie, verteile die Gesamtpunktzahl begründet und weise darauf hin.
   Hat eine Aufgabe Teile (a, b …), ist JEDER TEIL eine eigene Aufgabe mit eigener
   Punktzahl, eigenem Operator und eigenem AFB: "nr": "2a", "2b". Eine übergeordnete
   Aufgabe 2 ohne eigene Punkte gibt es dann nicht. Die Punkte aller Einträge ergeben
   zusammen die Gesamtpunktzahl.
2. Bestimme je Aufgabe den Operator und den Anforderungsbereich AFB (I, II, III oder
   eine Spanne wie II-III).
3. Schreibe je Aufgabe einen Erwartungshorizont in dieser Reihenfolge:
   Kernaussage · Muss enthalten · Auch richtig · Inhalt in Stufen · Reicht nicht ·
   Häufiger Fehler.
4. Gib je Aufgabe ein Schlagwort von zwei bis vier Wörtern an, das die Aufgabe benennt.

REGELN
${g(`[MAG_JAHRGANG]`)}

BEISPIEL „AUCH RICHTIG"
Schlecht: „Von links nach rechts werden die Atome kleiner, weil die Kernladung zunimmt
und die Elektronen stärker angezogen werden." So schreibt eine Lehrkraft – wer so
antwortet, liegt ohnehin bei 100 %.
Gut: „nach rechts wird es kleiner" · „der Kern zieht doller" · „es kommt eine Schale
dazu, deshalb wird es dicker" · „mehr Protonen, gleiche Schale".

BEISPIEL ZÄHLBARE STUFEN
100 — beide Trends beschrieben UND beide erklärt · 75 — beide beschrieben, einer
erklärt · 50 — beide beschrieben, keiner erklärt ODER einer beschrieben und erklärt.

[MAG_STUFE]

ARBEITSWEISE
Zeige mir zuerst je Aufgabe eine lesbare Übersicht (Nummer, Operator, AFB, Punkte,
Schlagwort, Erwartungshorizont) und frage: „Passt das so? Wenn ja, antworte mit ok."
Ändere, bis ich zustimme. Stelle immer nur EINE Frage auf einmal.

ERST WENN ICH BESTÄTIGE, gib genau EINEN Codeblock aus – nichts davor, nichts danach:

\`\`\`json
{ "aufgaben": [
  { "nr": "1",
    "schlagwort": "kurzes Stichwort",
    "afb": "I",
    "punkte": 2,
    "operator": "Nenne",
    "horizont": "<p><strong>Kernaussage:</strong> …</p><p><strong>Muss enthalten:</strong> …</p>" },
  { "nr": "2a", "schlagwort": "…", "afb": "II", "punkte": 3, "operator": "Erläutere", "horizont": "…" }
] }
\`\`\`

Das Feld "horizont" ist HTML (erlaubt: p, br, ul, li, strong, em). Jeder Abschnitt ist
ein eigenes <p> mit fettem Abschnittsnamen. Keine Überschrift für die Aufgabe selbst –
die setzt die Erweiterung. Keine Punktzahlen im Fließtext.`}function St(){let e=w(`[name="questiontext[text]"]`),t=e?e.value:(w(`.que .qtext`)||{}).innerHTML||``;if(!t)return[];let n=new DOMParser().parseFromString(t,`text/html`),r=[];return n.querySelectorAll(`img`).forEach(e=>r.push(`Bild: `+(e.getAttribute(`alt`)||decodeURIComponent((e.getAttribute(`src`)||``).split(`/`).pop().split(`?`)[0])||`ohne Namen`))),n.querySelectorAll(`a[href*="pluginfile"]`).forEach(e=>r.push(`Datei: `+(e.textContent.trim()||decodeURIComponent(e.getAttribute(`href`).split(`/`).pop().split(`?`)[0])))),r}function Ct(){return ee([L()],St())}function wt(){if(X===`kurztest`){let e={qid:`diese-frage`,frage:(w(`[name="name"]`)||{}).value||`Diese Frage`,aufgabe:L(),max:R()},t=F(B());t&&(e.horizont_bisher=j(t));let n=Ct(),r=`Rahmendaten:
`+bt()+`

`+(n?n+`

`:``)+"```json\n"+JSON.stringify([e],null,1)+"\n```";return v({einzeln:!0,jahrgang:P().jahrgang,stufe:ie()}).replace(`[MOODLE_AI_COACH_AUFGABEN]`,r)}let e=(C.promptHorizont||``).trim()||xt(),t=d(`klausur`,ie());e=e.includes(`[MAG_STUFE]`)?e.replace(`[MAG_STUFE]`,t):e+`

`+t;let n=Ct();return e.replace(`Lernende der Jahrgangsstufe [MAG_JAHRGANG]`,P().jahrgang?`Lernende der Jahrgangsstufe `+P().jahrgang:`Lernende dieser Jahrgangsstufe`).replace(`[MAG_RAHMENDATEN]`,bt()).replace(`[MAG_GESAMTPUNKTE]`,O(R()||`?`)).replace(`[MAG_AUFGABEN]`,(L()||`[keine Aufgabenstellung gefunden]`)+(n?`

`+n:``)+(F(B())?`

BISHERIGER HORIZONT (Ausgangspunkt, keine Vorlage zum Abschreiben – übernimm, was gut ist, und erstelle ihn im aktuellen Format neu. Sag mir ZUERST in zwei, drei Sätzen, dass ein bisheriger Horizont vorliegt, was du übernimmst und was du änderst):
`+j(F(B())):``))}let Tt={Kurz:`ein bis zwei Sätze je Aufgabe`,Mittel:`drei bis vier Sätze je Aufgabe`,Ausführlich:`ein Absatz je Aufgabe mit konkretem Bezug auf die Antwort`,Umfangreich:`ein ausführlicher Absatz je Aufgabe, dazu ein eigener Abschnitt zur Operatorerfüllung`};function Et(){return`Du bewertest Klausurantworten nach einem vorgegebenen Erwartungshorizont.

[MAG_KOPF]

RAHMENDATEN
[MAG_RAHMENDATEN]

ERWARTUNGSHORIZONT (gilt für alle Abgaben)
[MAG_HORIZONT]

[MAG_MODUS]

WICHTIG — WAS DU NICHT TUST
Du vergibst KEINE Punkte und rechnest NICHT. Die Erweiterung rechnet Punkte, Rundung,
Rechtschreibabzug und Gesamtsumme selbst. Du lieferst ausschließlich Prozentwerte,
gezählte Fehler und Begründungstexte OHNE Zahlenangaben. Schreibe in keiner Begründung
„x von y Punkten" — die Zahlen setzt die Erweiterung ein.

JE AUFGABE
Vergib einen Erfüllungsgrad in Prozent, nur diese Stufen: 100, 75, 50, 25, 0.
Verankere jede Einstufung an einer Formulierung des Erwartungshorizonts.
Prüfe dabei den Operator: Wer „erläutere" liest und nur beschreibt, erfüllt die Aufgabe
nicht vollständig, auch wenn der Inhalt stimmt.

JE ABGABE
Zähle die sprachlichen Fehler und gib sie EINZELN an — Wort, Korrektur, Kategorie.
Kategorien: satzbau · kasus · zeitform · grossschreibung · fachbegriff · rechtschreibung ·
zeichensetzung · umgangssprache. Ein Satz ohne Prädikat, ein abgebrochener Satz oder ein
Satzbau, den man zweimal lesen muss, zählt als "schwer": true. Denselben Fehler im selben
Wort nur einmal zählen. Zähle vollständig — die Erweiterung leitet daraus den Abzug ab.
${Ne(ze(N().jahrgang),`der Gesamtpunktzahl`)}

FEEDBACKTEXTE
Länge: [MAG_FBLAENGE]. Anrede: [MAG_ANREDE] … Sachlich, konkret, zugewandt.
Bei Sprachfehlern den fehlerhaften Satz wörtlich zitieren und richtig danebenschreiben,
nicht „achte auf die Satzstellung". Höchstens zwei bis drei Vorschläge.
Jede Aufgabe bekommt eine Begründung — auch eine vollständig richtige.

ABGABEN
[MAG_ABGABEN]

AUSGABE — am Ende genau EIN Codeblock (im Modus AUTOMATISCH nichts davor, nichts danach):

\`\`\`json
{ "bewertungen": [
  { "nr": 1,
    "besprochen": true,
    "staerken": "was gut gelungen ist",
    "aufgaben": [ { "nr": 1, "prozent": 75, "begruendung": "…", "operator": "erfüllt" } ],
    "fehler": [ { "wort": "Atomradiuse", "korrektur": "Atomradien",
                  "kategorie": "rechtschreibung", "schwer": false } ],
    "sprachfeedback": "…",
    "zusammenfassung": "…" }
] }
\`\`\`

"nr" ist die Nummer der Abgabe aus dem Datenblock, nicht die des Schülers.
In "aufgaben" ist "nr" die Aufgabennummer wie im Datenblock (z. B. "1", "2a").
"besprochen": true nur für Arbeiten, die du im Modus GEMEINSAM mit der Lehrkraft durchgegangen
bist und die sie mit OK bestätigt hat; sonst false.
Liefere für JEDE Abgabe des Blocks einen Eintrag, auch für leere Abgaben
(dort alle Prozentwerte 0 und ein Hinweis in der Zusammenfassung).`}function Dt(){let e=Et();if(!C.kompaktPrompt)return e;let t=e.indexOf(`WICHTIG — WAS DU NICHT TUST`),n=e.indexOf(`FEEDBACKTEXTE`);return t<0||n<t?e:e.slice(0,t)+Re+`
`+Ne(ze(N().jahrgang),`der Gesamtpunktzahl`)+`

`+e.slice(n)}function Ot(e,t){return(e||1)>1?`MODUS
Der Modus wurde in Teil 1 gewählt und gilt weiter. Frage NICHT erneut. Im Modus GEMEINSAM gehst
du diese Arbeiten wieder einzeln mit mir durch, im Modus AUTOMATISCH gibst du sofort das JSON aus.`:`MODUSFRAGE — STELLE SIE ZUERST UND WARTE
Bevor du irgendetwas bewertest, stelle GENAU DIESE EINE Frage und gib danach nichts weiter aus,
bis ich geantwortet habe:

„Wie sollen wir vorgehen?
  1. GEMEINSAM – Ich zeige dir jede Arbeit einzeln, du bestätigst oder änderst, dann kommt die
     nächste. (empfohlen)
  2. AUTOMATISCH – Ich bewerte alle Arbeiten und gebe sofort das JSON aus.
Antworte mit 1 oder 2."

AUTOMATISCH ist eine bewusste Wahl, kein stiller Standard. Triff keine Annahme.

MODUS GEMEINSAM — je Arbeit dieses Schema, dann warten:
  ABGABE [nr]
  Je Aufgabe: Antwort (gekürzt) · Stufe in % · Begründung (ein Satz, Bezug auf den Horizont)
  Sprachfehler: Wort → Korrektur (Kategorie)
  Rückmeldung an die Schülerin / den Schüler (so, wie sie eingetragen würde)
  Grobe Punkteschätzung (nur zur Orientierung – genau rechnet die Erweiterung)
  „1 OK – weiter · 2 Stufe ändern · 3 Rückmeldung ändern · 4 neu bewerten"
Erst nach OK kommt die nächste Arbeit. Nach der letzten Arbeit${t>1?` dieses Teils`:``} das JSON.`}function kt(e,t,n,r){let i=H(t),a=i.length?i.map(e=>e.kopf+`
`+e.text).join(`

`):F(t),o=e.map(e=>{let t=tt(e.rohHtml,e.text),n=`ABGABE `+e.nr+(t.gegliedert?``:`  (ohne Gliederung)`),r=t.gegliedert?t.aufgaben.map(e=>`  Aufgabe `+e.nr+`:
  `+(e.text||`(leer)`)).join(`
`):`  `+(e.text||`(leer)`);return n+`
`+r}).join(`

`),s=(C.promptKorrektur||``).trim(),c=N(),l=y({fach:c.fach,jahrgang:c.jahrgang,niveau:vt[c.niveau]||c.niveau,anrede:ye()}),u=s||Dt();return u=(u.includes(`[MAG_KOPF]`)?u.replace(`[MAG_KOPF]`,l):l+`

`+u).replace(`[MAG_RAHMENDATEN]`,yt()).replace(`[MAG_HORIZONT]`,a||`[kein Horizont hinterlegt]`).replace(`[MAG_FBLAENGE]`,Tt[Fe()]||Tt.Ausführlich).replace(`[MAG_ANREDE]`,be()).replace(`[MAG_ABGABEN]`,o).replace(`[MAG_MODUS]`,Ot(n,r)),r>1&&(u=`TEIL `+n+` VON `+r+` — bewerte NUR die unten stehenden Abgaben und gib nur für sie JSON aus. Warte auf den nächsten Teil.

`+u),u}function At(e,t,n){let r=[];if(e.staerken&&r.push(e.staerken.trim()),(e.aufgaben||[]).forEach(e=>{let i=t.teil.find(t=>t.nr===E(e.nr)),a=(n||[]).find(t=>t.nr===E(e.nr)),o=`Aufgabe `+E(e.nr)+(a&&a.kopf.includes(`·`)?` – `+a.kopf.split(`·`).slice(1).join(`·`).replace(/\(.*?\)/,``).trim():``)+`: `+(i?O(i.punkte):`?`)+` von `+(i?O(Math.round(i.max*100)/100):`?`)+` P.`;i&&i.abzug>.004&&(o+=` (davon −`+O(Math.round(i.abzug*100)/100)+` P. Rechtschreibung)`),r.push(o+`
`+(e.begruendung||``).trim())}),Fe()===`Umfangreich`){let t=(e.aufgaben||[]).filter(e=>e.operator);t.length&&r.push(`Operatorerfüllung:
`+t.map(e=>`Aufgabe `+E(e.nr)+`: `+e.operator).join(`
`))}let i=e.fehler||[],a=`Rechtschreibung und Sprache: `;return t.abzug>.004?a+=`Abzug `+O(t.abzug)+` von höchstens `+O(t.hoechstabzug)+` P. (`+O(t.fehlerDichte)+` Fehler je 100 Wörter).`:i.length?a+=`kein Punktabzug, aber ein paar Stellen zum Nachschauen.`:a+=`keine Auffälligkeiten.`,i.length&&(a+=`
`+i.slice(0,12).map(e=>`• `+(e.wort||``)+` → `+(e.korrektur||``)).join(`
`),i.length>12&&(a+=`
• … und `+(i.length-12)+` weitere`)),e.sprachfeedback&&(a+=`
`+e.sprachfeedback.trim()),r.push(a),e.zusammenfassung&&r.push(e.zusammenfassung.trim()),r.push(`Gesamt: `+O(t.gesamt)+` von `+O(t.max)+` Punkten.`),r.filter(Boolean).map(ge).join(`

`)}function jt(e){let t=e.split(/\n{2,}/).map(e=>`<p>`+D(e).replace(/\n/g,`<br>`)+`</p>`).join(``),n=String(C.kiHinweisText||`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`).trim();return C.kiHinweis&&n&&(t+=`<p><em><small>`+D(n)+`</small></em></p>`),t}function Mt(e){let t=[],n=0,r=-1,i=!1,a=!1;for(let o=0;o<e.length;o++){let s=e[o];if(i){a?a=!1:s===`\\`?a=!0:s===`"`&&(i=!1);continue}if(s===`"`){n>0&&(i=!0);continue}s===`{`?(n===0&&(r=o),n++):s===`}`&&n>0&&(n--,n===0&&r>=0&&(t.push(e.slice(r,o+1)),r=-1))}return t}function Nt(e,t){let n=[],r=[],i=/```(?:json)?\s*([\s\S]*?)```/g,a;for(;(a=i.exec(e))!==null;)r.push(a[1]);if(r.push(e.replace(/```(?:json)?\s*[\s\S]*?```/g,``)),r.forEach(e=>{let r=e.trim();if(r){try{let e=JSON.parse(r),i=Array.isArray(e)?e:e[t]||(e.nr==null?null:[e]);i&&n.push(...i);return}catch{}Mt(r).forEach(e=>{try{let r=JSON.parse(e),i=Array.isArray(r)?r:r[t]||(r.nr==null?null:[r]);i&&n.push(...i)}catch{}})}}),!n.length)throw Error(`Kein verwertbares JSON gefunden.`);return n}function Pt(e,t){let n=new Set,r=[],i=e=>/^\s*\d+\s*$/.test(String(e))?Number(e):E(e);return e.forEach(e=>{let t=i(e.nr);n.has(t)&&r.push(t),n.add(t)}),{fehlend:t.filter(e=>!n.has(i(e))),doppelt:r}}async function Ft(e){let t=await I(location.href),n=t.querySelector(`form#manualgradingform`)||[...t.forms].find(e=>e.querySelector(`input[name$="-mark"]`));if(!n&&!e)return await new Promise(e=>setTimeout(e,900)),Ft(!0);if(!n)throw Error(`Bewertungsformular nicht gefunden`);return{dok:t,form:n}}async function It(e,t,n){let{form:r}=await Ft(!1),i=Ye(r),a=[],o=0;if(e.forEach(e=>{let r=i.has(e.markfeld),s=!e.kommentarfeld||i.has(e.kommentarfeld);if(!r||!s){o++,n(`✗ Abgabe `+e.nr+`: `+(r?`Kommentarfeld`:`Punktefeld`)+` nicht auf der Seite`);return}t||(i.set(e.markfeld,O(e.punkte)),e.kommentarfeld&&i.set(e.kommentarfeld,e.feedbackHtml)),a.push(e)}),t)return n(a.length+` von `+e.length+` Abgaben vollständig vorhanden.`),{ok:a.length,fehler:o,trocken:!0};if(!a.length)return{ok:0,fehler:e.length};await Xe(r,i,location.href);let{form:s}=await Ft(!1),c=0,l=o;return a.forEach(e=>{let t=s.querySelector(`input[name="`+CSS.escape(e.markfeld)+`"]`),r=t?k(t.value):null;r!==null&&Math.abs(r-e.punkte)<.005?(c++,n(`✓ Abgabe `+e.nr+` — `+O(e.punkte)+` P. eingetragen`)):(l++,n(`✗ Abgabe `+e.nr+` — steht auf `+(r==null?`keinem Wert`:O(r))+` statt `+O(e.punkte)))}),{ok:c,fehler:l}}let Lt=u===`bearbeiten`?[[`horizont`,`1 · Horizont`],[`vorlage`,`2 · Layout-Vorlage`],[`einst`,`⚙`]]:[[`korrektur`,`1 · Bewerten`],[`horizont`,`2 · Horizont`],[`einst`,`⚙`]],K=T(`div`,`mag-panel`);K.innerHTML=`
    <div class="mag-kopf">
      <img class="mag-kopfbild" alt="">
      <div class="mag-titelblock">
        <span class="mag-titel">Freitext Grader <span class="mag-version"></span></span>
        <span class="mag-untertitel"></span>
      </div>
      <button class="mag-ikon" data-tu="zu" title="Schließen">✕</button>
    </div>
    <div class="mag-banner" hidden></div>
    <div class="mag-reiter">

    </div>

    <div class="mag-inhalt" data-panel="horizont">
      <details class="mag-details mag-hilfe mag-wozu" data-rolle="hhilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Hier entsteht der Erwartungshorizont dieser Aufgabe – der Maßstab, nach dem
        die KI später alle Antworten bewertet. Das geschieht einmal je Aufgabe; danach bleibt er in der
        Aufgabe gespeichert, auch beim Export. Schülerinnen und Schüler sehen ihn nicht.</p>
        <p class="mag-hinweis"><strong>1 · Horizont-Prompt kopieren:</strong> Die Erweiterung baut aus
        Aufgabenstellung, Punkten und den Angaben unter „Diese Aufgabe" einen Prompt.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Verweist die
        Aufgabe auf Material, fragt die KI danach. Sie zeigt den Horizont zuerst zum Lesen – prüfen, ggf.
        ändern lassen, dann mit „ok" antworten. Danach gibt sie ihn in einem grauen Kasten aus: diesen
        Kasten hier einfügen.</p>
        <p class="mag-hinweis"><strong>3 · Eintragen:</strong> Der Horizont wird im Feld „Informationen für
        Bewerter/innen" der Aufgabe gespeichert.</p>
        <p class="mag-hinweis">Die Erweiterung hat bewusst keinen eigenen KI-Zugang: Du wählst die KI, und
        die Aufgabe geht nur dorthin, wo du den Prompt einfügst.</p>
      </details>
      <div class="mag-status" data-rolle="hstatus"></div>
      <details class="mag-details" data-rolle="hbisher" hidden>
        <summary>Gespeicherten Horizont ansehen</summary>
        <pre class="mag-hinweis" style="white-space:pre-wrap;max-height:220px;overflow:auto;"></pre>
      </details>
      <div class="mag-modus" data-rolle="hmodus" hidden>
        <div class="mag-rahmen-titel">Diese Aufgabe</div>
        <label>Art der Aufgabe</label>
        <select data-rolle="hmodussel">
          <option value="kurztest">Kurztest – kurze Antworten</option>
          <option value="klausur">Klausur – mehrere Teilaufgaben</option>
        </select>
        <label>Feedbacklänge</label>
        <select data-rolle="hfeedbacksel"></select>
        <div class="mag-zeile3">
          <div><label>Fach</label><input type="text" data-rolle="hfach" placeholder="z. B. Chemie"></div>
          <div><label>Jahrgang</label><select data-rolle="hjahrgang"></select></div>
          <div><label>Niveau</label><select data-rolle="hniveau">
            <option value="G">gymnasial</option><option value="M">mittel</option><option value="E">einfach</option>
          </select></div>
        </div>
        <div class="mag-hinweis" data-rolle="hrahmenhinweis"></div>
        <details class="mag-details mag-mehr">
          <summary>Was bedeuten Art, Feedbacklänge, Fach, Jahrgang und Niveau?</summary>
          <div class="mag-hinweis" data-rolle="hmodushinweis"></div>
          <div class="mag-hinweis" data-rolle="hfeedbackhinweis"></div>
          <p class="mag-hinweis">Alles in diesem Kasten gehört <strong>zur Aufgabe</strong>: Es bestimmt, wie der
          Erwartungshorizont aussieht (z. B. welche Formulierungen für Jahrgang 9 als richtig gelten), und wird
          zusammen mit dem Horizont in der Aufgabe gespeichert – auch in Zufallspools, beim Export und bei
          Kolleginnen und Kollegen.</p>
          <p class="mag-hinweis"><strong>Rechtschreibung, Punkteschritte und Anrede (Du/Sie)</strong> legst du
          erst <strong>beim Bewerten</strong> fest – sie gehören zur Bewertung einer Lerngruppe, nicht zur Aufgabe.</p>
        </details>
      </div>
      <label data-rolle="hschritt1">1 · Prompt zum Erstellen des Erwartungshorizonts kopieren</label>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-primary" data-tu="hprompt">📋 Horizont-Prompt kopieren</button>
      </div>
      <div class="mag-hinweis" data-rolle="hmaterial" hidden></div>
      <label>2 · Antwort der KI einfügen</label>
      <div class="mag-hinweis">Den grauen Kasten am Ende der KI-Antwort hier einfügen – er wird sofort
      geprüft und angezeigt. Gespeichert wird erst in Schritt 3.</div>
      <textarea data-rolle="hjson" rows="5" placeholder="Antwort der KI hier einfügen"></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="hpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-liste" data-rolle="hliste"></div>
      <div class="mag-protokoll" data-rolle="hlog" hidden></div>
      <label data-rolle="hschritt3" hidden>3 · In die Aufgabe eintragen</label>
      <div class="mag-reihe" data-rolle="hknoepfe" hidden></div>
      <details class="mag-details mag-profi">
        <summary>Für Fortgeschrittene</summary>
        <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="hedit">✏️ Horizont-Prompt anpassen</button>
        <p class="mag-hinweis"><strong>Kein Bearbeitungsrecht für die Frage?</strong> Dann den fertigen
        Horizont hier einfügen. Er bleibt in der Erweiterung statt in der Frage.</p>
        <textarea data-rolle="hlokal" rows="4" placeholder="Erwartungshorizont …"></textarea>
        <button class="mag-btn mag-btn-rand" data-tu="hlokalsichern">Hier speichern</button>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="vorlage" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Hier gestaltest du das Aussehen der Aufgabe für die Lernenden – ein Zusatz
        nach Geschmack, für die Bewertung nicht nötig. Teilaufgaben, Anforderungsbereiche und Punkte kommen
        aus dem Erwartungshorizont.</p>
        <p class="mag-hinweis"><strong>Aufgabenstellung:</strong> Der Fragetext kommt in farbige Karten –
        eine je Teilaufgabe, vorn eine Marke (1, 2a, 2b; im Kurztest a, b), hinten die Punkte, links der
        Anforderungsbereich; der Operator wird hervorgehoben. Der Wortlaut bleibt gleich, Material (M1, M2 …)
        bleibt außerhalb der Karten.</p>
        <p class="mag-hinweis"><strong>Antwortvorlage:</strong> Statt eines leeren Eingabefelds gibt es einen
        Antwortkasten je Teilaufgabe mit derselben Marke. So schreiben die Lernenden jede Antwort an die
        richtige Stelle, und die Erweiterung kann sie beim Bewerten sicher zuordnen.</p>
        <p class="mag-hinweis"><strong>Nichts wird automatisch gespeichert.</strong> Gefällt es dir,
        speicherst du mit „Änderungen speichern", sonst „Abbrechen".</p>
      </details>
      <div class="mag-status" data-rolle="vstatus"></div>
      <label>Was möchtest du gestalten?</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAufgabe"> Aufgabenstellung</label>
      <label class="mag-haken"><input type="checkbox" data-opt="layoutAntwort"> Antwortvorlage</label>
      <label>Was soll zu sehen sein?</label>
      <label class="mag-haken"><input type="checkbox" data-opt="afbFarben"> Farben nach Anforderungsbereich (I grün, II orange, III rot)</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlagePunkte"> Punkte je Teilaufgabe</label>
      <label class="mag-haken"><input type="checkbox" data-opt="vorlageAfb"> Anforderungsbereich (z. B. „AFB II")</label>
      <span data-rolle="lpunktezeile" hidden></span><span data-rolle="lpunktehinweis" hidden></span>
      <div data-rolle="lseca" hidden>
        <div class="mag-hinweis" data-rolle="lahinweise"></div>
        <label>Vorschau – so sieht die Aufgabe aus</label>
        <div class="mag-vorschau" data-rolle="lavorschau"></div>
      </div>
      <div data-rolle="lsecv" hidden>
        <div class="mag-hinweis" data-rolle="vformat" hidden></div>
        <label>Vorschau – so sieht das Eingabefeld aus</label>
        <div class="mag-vorschau" data-rolle="vvorschau"></div>
      </div>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="lein">Ins Formular einfügen</button>
      </div>
      <p class="mag-hinweis">Eingefügt wird nur ins Formular. Speichern mit „Änderungen speichern" –
      oder „Abbrechen", wenn es dir nicht gefällt.</p>
    </div>

    <div class="mag-inhalt" data-panel="korrektur" hidden>
      <details class="mag-details mag-hilfe mag-wozu" data-rolle="khilfe">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Hier werden alle Antworten zu dieser Aufgabe mit KI-Hilfe bewertet und danach
        mit Punkten und Rückmeldung in Moodle eingetragen. Maßstab ist der Erwartungshorizont der Aufgabe.</p>
        <p class="mag-hinweis"><strong>1 · Bewertungsprompt kopieren.</strong> Er enthält den Horizont und
        alle Antworten – ohne Namen, nur nummeriert.</p>
        <p class="mag-hinweis"><strong>2 · In die KI einfügen</strong> (z. B. Claude, ChatGPT). Die KI fragt
        zuerst: <em>gemeinsam durchgehen</em> (Arbeit für Arbeit, du kannst jede ändern – empfohlen) oder
        <em>automatisch</em>. Sie beurteilt nur; Punkte rechnet die Erweiterung.</p>
        <p class="mag-hinweis"><strong>3 · Antwort der KI einfügen.</strong> Du siehst jede Bewertung mit
        „bisher → neu".</p>
        <p class="mag-hinweis"><strong>4 · Eintragen.</strong> Gemeinsam besprochene Arbeiten lassen sich
        direkt eintragen. Automatisch bewertete siehst du vorher einmal an – überspringen geht nur mit
        Bestätigung.</p>
      </details>
      <div class="mag-status" data-rolle="kstatus"></div>
      <div class="mag-rahmen">
        <div class="mag-kastenzeile"><span data-rolle="kkurz"></span>
          <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="kaendern">ändern</button></div>
        <div class="mag-hinweis fehler" data-rolle="kwarn" hidden></div>
        <div data-rolle="kfelder" hidden>
        <label>Anrede im Feedback</label>
        <select data-rolle="kanrede">
          <option value="auto">Automatisch nach Jahrgang</option>
          <option value="du">Du</option><option value="sie">Sie</option>
        </select>
        <div class="mag-hinweis" data-rolle="anredehinweis"></div>
        <label data-rolle="krslabel">Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl</label>
        <select data-rolle="krs">
          <option value="0">0 % – kein Abzug</option><option value="5">5 %</option>
          <option value="10">10 %</option><option value="15">15 %</option>
          <option value="20">20 %</option><option value="25">25 %</option><option value="30">30 %</option>
        </select>
        <label>Punkteschritte</label>
        <select data-opt="punkteschritte">
          <option value="0.25">0,25</option><option value="0.5">0,5</option><option value="1">1 – nur ganze Punkte</option>
        </select>
        <div class="mag-rahmen-titel" style="margin-top:8px">Aus dem gespeicherten Horizont dieser Aufgabe</div>
        <div data-rolle="krahmen"></div>
        <button class="mag-btn mag-btn-klein mag-btn-rand" data-tu="zuhorizont">im Reiter Horizont ändern</button>
        <details class="mag-details mag-mehr">
          <summary>Was bedeuten Anrede, Rechtschreibung, Punkteschritte und die Angaben aus dem Horizont?</summary>
          <p class="mag-hinweis"><strong>Anrede:</strong> „Automatisch" schreibt bis Jahrgang 10 „Du hast …",
          ab Jahrgang 11 „Sie haben …".</p>
          <p class="mag-hinweis"><strong>Rechtschreibung:</strong> So viel Prozent der Gesamtpunktzahl kann die
          Sprache höchstens kosten – getrennt für Sekundarstufe I und Oberstufe. Auch bei 0 % gibt es eine
          Rückmeldung zur Sprache.</p>
          <p class="mag-hinweis" data-rolle="rshinweis"></p>
          <p class="mag-hinweis"><strong>Punkteschritte:</strong> Auf diese Schritte wird die Punktzahl je Aufgabe gerundet.</p>
          <p class="mag-hinweis"><strong>Fach, Jahrgang, Niveau, Feedbacklänge:</strong> Der Horizont regelt die
          Bewertung. Ändern heißt: im Reiter Horizont einen neuen Horizont erstellen und eintragen.</p>
        </details>
        </div>
      </div>
      <div data-rolle="kgroessebox" hidden>
        <label>Abgaben je Durchgang</label>
        <select data-rolle="kgroesse"></select>
        <div class="mag-hinweis" data-rolle="kgroessehinweis"></div>
        <details class="mag-details mag-mehr">
          <summary>Was bedeutet „Abgaben je Durchgang“?</summary>
          <p class="mag-hinweis">Eine KI kann pro Antwort nur begrenzt viel Text schreiben. Bei vielen oder
          langen Arbeiten bricht sie sonst mitten im Ergebnis ab oder wird ungenau. Deshalb teilt die
          Erweiterung die Lerngruppe in mehrere Teile – den Vorschlag rechnet sie aus der Textlänge. Geteilt
          wird immer nach Personen, nie nach Aufgaben: Jede Arbeit wird als Ganzes bewertet.</p>
        </details>
      </div>
      <label>1 · Bewertungsprompt mit allen Antworten kopieren</label>
      <div class="mag-reihe" data-rolle="kknoepfe"></div>
      <label>2 · Antwort der KI einfügen</label>
      <div class="mag-hinweis">Den grauen Kasten am Ende der KI-Antwort hier einfügen – nicht den Text davor.</div>
      <div class="mag-hinweis" data-rolle="kteilehinweis" hidden><strong>In mehreren Teilen:</strong> Teil 1
      kopieren → in die KI → Ergebnis hier einfügen. Dann Teil 2 im <em>selben</em> KI-Chat einfügen und sein
      Ergebnis <em>unter</em> das erste in dieses Feld setzen. Die Erweiterung setzt die Teile zusammen und
      meldet, welche Arbeiten noch fehlen.</div>
      <textarea data-rolle="kjson" rows="5" placeholder="Antwort der KI hier einfügen"></textarea>
      <button class="mag-btn mag-btn-primary" data-tu="kpruefen" hidden>🔍 Prüfen</button>
      <div class="mag-hinweis" data-rolle="rsabgleich" hidden></div>
      <div class="mag-liste" data-rolle="kliste"></div>
      <div class="mag-protokoll" data-rolle="klog" hidden></div>
      <div class="mag-reihe" data-rolle="keintragen" hidden>
        <button class="mag-btn mag-btn-ok" data-tu="kschreiben">Alle eintragen</button>
      </div>
      <details class="mag-details mag-profi">
        <summary>Für Fortgeschrittene</summary>
        <div class="mag-reihe">
          <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kedit">✏️ Bewertungsprompt anpassen</button>
          <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="krohdaten">📋 Nur die Antworten kopieren</button>
        </div>
      </details>
    </div>

    <div class="mag-inhalt" data-panel="einst" hidden>
      <details class="mag-details mag-hilfe mag-wozu">
        <summary>So funktioniert's</summary>
        <p class="mag-hinweis">Hier steht nur, was für <strong>alle</strong> Aufgaben gleich ist – es gilt
        überall in der Erweiterung, auf der Bewertungsseite ebenso wie auf der Kurztest-Übersicht. Fach,
        Jahrgang, Art und Feedbacklänge stehen im Reiter „Horizont", Anrede, Rechtschreibung und
        Punkteschritte beim Bewerten.</p>
      </details>
      <div class="mag-status" data-rolle="estatus"></div>
      <label class="mag-haken"><input type="checkbox" data-opt="kiHinweis"> KI-Hinweis unter das Feedback</label>
      <label>Text des KI-Hinweises</label>
      <textarea data-opt="kiHinweisText" rows="3"></textarea>
      <button class="mag-btn mag-btn-rand mag-btn-klein" data-tu="kistandard">Standardtext einsetzen</button>
      <details class="mag-details mag-mehr">
        <summary>Was bedeutet „KI-Hinweis“?</summary>
        <p class="mag-hinweis">Unter jedes eingetragene Feedback setzt die Erweiterung diesen Satz, kursiv
        und klein. Er kommt von der Erweiterung, nicht von der KI. Den Wortlaut kannst du ändern.</p>
      </details>
      <details class="mag-details mag-profi">
        <summary>Für Fortgeschrittene</summary>
        <label class="mag-haken"><input type="checkbox" data-opt="entferneQuellen"> Quellenangaben entfernen</label>
        <details class="mag-details mag-mehr">
          <summary>Was bedeutet „Quellenangaben entfernen“?</summary>
          <p class="mag-hinweis">Manche KI-Chats hängen Quellenmarken wie [1] oder 【4†source】 an. Mit Häkchen
          entfernt die Erweiterung sie aus dem Feedback, bevor es eingetragen wird.</p>
        </details>
        <label class="mag-haken"><input type="checkbox" data-opt="kompaktPrompt"> Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
        <details class="mag-details mag-mehr">
          <summary>Was bedeutet „Kompakter Prompt“?</summary>
          <p class="mag-hinweis">Der Bewertungsprompt verweist für die Bewertungslogik auf die Skills
          „2-didaktik-bewertung" und „3-moodle-erweiterungen", statt sie auszuschreiben – spart mehrere
          Tausend Zeichen. <strong>Nur einschalten, wenn die verwendete KI diese Skills wirklich kennt.</strong></p>
        </details>
      </details>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="esichern">Speichern und zurück</button>
        <button class="mag-btn mag-btn-grau" data-tu="eabbruch">Verwerfen</button>
      </div>
    </div>

    <div class="mag-inhalt" data-panel="prompt" hidden>
      <label data-rolle="ptitel">Prompt bearbeiten</label>
      <textarea data-rolle="ptext" rows="16"></textarea>
      <div class="mag-reihe">
        <button class="mag-btn mag-btn-ok" data-tu="psichern">Speichern</button>
        <button class="mag-btn mag-btn-rand" data-tu="pzurueck">↺ Original</button>
        <button class="mag-btn mag-btn-grau" data-tu="pabbruch">Abbrechen</button>
      </div>
    </div>`,K.querySelector(`.mag-version`).textContent=e;let Rt=K.querySelector(`.mag-reiter`);Lt.forEach((e,t)=>{let n=document.createElement(`button`);n.className=`mag-tab`+(t===0?` aktiv`:``),n.dataset.tab=e[0],n.textContent=e[1],Rt.appendChild(n)});function zt(e,t,n){let r=document.createElement(`button`);return r.className=t,r.dataset.tu=n,r.textContent=e,r}let Bt=K.querySelector(`[data-rolle="hknoepfe"]`);u!==`bearbeiten`&&Bt.appendChild(zt(`Horizont eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));let Vt=T(`button`,`mag-knopf`);Vt.title=`Moodle AI Freitext Grader`;let Ht=document.createElement(`img`);Ht.className=`mag-knopf-bild`,Ht.alt=`Moodle AI Freitext Grader`;try{Ht.src=t.runtime.getURL(`icon/128.png`)}catch{Vt.textContent=`AI`}Ht.src&&Vt.appendChild(Ht);let q=e=>K.querySelector(`[data-rolle="`+e+`"]`),J=null,Y=null,Ut=Lt[0][0],Wt=!1,Gt=!1,Kt=!1;if(typeof IntersectionObserver<`u`){let e=new IntersectionObserver(t=>t.forEach(t=>{t.isIntersecting&&(t.target.dataset.gesehen=`1`,e.unobserve(t.target))}),{threshold:.5}),t=q(`kliste`);t&&new MutationObserver(t=>t.forEach(t=>t.addedNodes.forEach(t=>{t.nodeType===1&&t.classList.contains(`mag-karte`)&&(Kt=!1,e.observe(t))}))).observe(t,{childList:!0})}function qt(){return u===`bearbeiten`&&!new URLSearchParams(location.search).get(`id`)}function Jt(){let e=V();if(e.wer===`coach`)return`kurztest`;if(e.wer===`grader`)return`klausur`;let t=L();return!/(^|\n)\s*(?:[a-h]\)|aufgabe\s*\d|\d+[.)]\s)/i.test(t)&&(R()||0)<=3?`kurztest`:`klausur`}let X=u===`bearbeiten`?Jt():V().wer===`coach`?`kurztest`:`klausur`,Yt={kurztest:[[`Kurz`,`Kurz – 1–2 Sätze`],[`Mittel`,`Mittel – 3–5 Sätze (Standard)`]],klausur:[[`Mittel`,`Mittel – 3–4 Sätze je Teilaufgabe`],[`Ausführlich`,`Ausführlich – ein Absatz je Teilaufgabe (Standard)`],[`Umfangreich`,`Umfangreich – dazu Abschnitt Operatorerfüllung`]]},Xt={kurztest:`Mittel`,klausur:`Ausführlich`},Z=(()=>{let e=S(B()||C.horizontLokal||``);return e&&Yt[X].some(t=>t[0]===e)?e:Xt[X]})();function Zt(){let e=q(`hfeedbacksel`);e&&(e.innerHTML=``,Yt[X].forEach(([t,n])=>{let r=document.createElement(`option`);r.value=t,r.textContent=n,e.appendChild(r)}),Yt[X].some(e=>e[0]===Z)||(Z=Xt[X]),e.value=Z,q(`hfeedbackhinweis`).textContent=X===`kurztest`?`Bei „Kurz" und „Mittel" passt die ganze Klasse meist in einen Durchgang.`:`Feedbacklänge: Längeres Feedback heißt, dass die Klasse in mehr Teilen bewertet wird.`)}let Qt=null;u===`bearbeiten`&&Bt.appendChild(zt(`Horizont eintragen`,`mag-btn mag-btn-ok`,`hschreiben`));function $t(){let e=q(`hmodus`);if(e&&(e.hidden=!1,q(`hmodussel`).value=X,q(`hmodushinweis`).textContent=X===`kurztest`?`Kurztest: kurze Antworten, Horizont mit Kernaussage und „Auch richtig". Bewertet wird auf der Übersicht des Tests, alle Kurztest-Aufgaben zusammen – oder einzeln auf der Bewertungsseite.`:`Klausur: Horizont je Teilaufgabe mit Punkten, Operator und Anforderungsbereich. Bewertet wird auf der Bewertungsseite der Aufgabe; jede Bewertung siehst du vor dem Eintragen einmal an.`,Zt(),gt(),u===`bearbeiten`)){let e=Bt.querySelector(`[data-tu="hschreiben"]`);e&&(e.hidden=!1)}}q(`hfeedbacksel`).addEventListener(`change`,()=>{Z=q(`hfeedbacksel`).value,$()}),q(`hmodussel`).addEventListener(`change`,()=>{X=q(`hmodussel`).value,Z=Xt[X],J=null,Qt=null,q(`hliste`).innerHTML=``,q(`hknoepfe`).hidden=!0,q(`hschritt3`).hidden=!0,Q(`hstatus`,`Modus: `+(X===`kurztest`?`Kurztest`:`Klausur`)+`. Bitte den Prompt jetzt (neu) kopieren.`),$t()});function en(){Oe(),M={fach:(q(`hfach`).value||``).trim(),jahrgang:q(`hjahrgang`).value||``,niveau:q(`hniveau`).value||`G`,ausHorizont:!!Le().jahrgang},C.fach=M.fach,C.jahrgang=M.jahrgang,C.kursniveau=M.niveau,hn(),$()}[`hfach`,`hjahrgang`,`hniveau`].forEach(e=>{let t=q(e);t&&t.addEventListener(e===`hfach`?`input`:`change`,en)});function tn(){u===`bewertung`&&q(`kjson`)&&q(`kjson`).value.trim()&&Y&&Fn()}q(`kanrede`)&&q(`kanrede`).addEventListener(`change`,()=>{C.anredeWahl=q(`kanrede`).value,hn(),$(),tn()}),q(`krs`)&&q(`krs`).addEventListener(`change`,()=>{C[We(N().jahrgang)]=q(`krs`).value,hn(),$(),tn()}),$t();function nn(e){let t=j(String(e||``).replace(/\r/g,``)).trim().split(/\n\s*\n/).filter(e=>e.trim()).map(e=>`<p>`+D(e.trim()).replace(/\n/g,`<br>`)+`</p>`).join(``);return`<p>`+n+`</p>`+te(Z)+t}function rn(e,t){try{Q(t,`Ins Formular eingesetzt: `+Object.keys(e).map(t=>t+` (`+ne(t,e[t])+`)`).join(`, `)+`. Wird mit „Änderungen speichern" zusammen mit der Frage gespeichert.`)}catch(e){Q(t,`Fehler: `+e.message,!0)}}function an(e){if(Wt)return;Wt=!0,Gt=!0,e.hidden=!0;let t=new URLSearchParams(location.search),n=t.get(`id`),r=t.get(`slot`),i=t.get(`qid`),a=K.querySelector(`[data-panel="korrektur"]`);if(!a||!r||!i)return;a.classList.add(`mag-kurztest`);let o=a.querySelector(`.mag-wozu .mag-hinweis`);o&&(o.textContent=`Diese Frage ist ein Kurztest. Hier bewertest du ihre Antworten einzeln: Antworten laden, Prompt kopieren, Ergebnis der KI einfügen, eintragen. Maßstab ist der Erwartungshorizont der Aufgabe (Reiter „Horizont").`);let s=T(`div`,`mag-kurztest-weg`);a.appendChild(s);let c=w(`.que .qtext`),l=c?c.textContent.replace(/\s+/g,` `).trim().slice(0,60):`Diese Aufgabe`;try{Qe({einzel:{slot:r,qid:i,name:l},ziel:s,uebersicht:n?He(n):null})}catch(e){s.textContent=`Der Kurztest-Weg ließ sich hier nicht starten: `+e.message}}function on(){if(u===`bearbeiten`)return location.href;let e=new URLSearchParams(location.search),t=e.get(`qid`),n=e.get(`id`)||e.get(`cmid`);return t?location.origin+`/question/bank/editquestion/question.php?id=`+t+(n?`&cmid=`+n:``):null}function Q(e,t,n){let r=q(e);r&&(r.textContent=t||``,r.className=`mag-status`+(t?n?` fehler`:` ok`:``),t&&sn&&Date.now()-cn<4e3&&!ln(r,sn)&&dn(sn,t,n))}let sn=null,cn=0;function ln(e,t){if(!un(e)||!t.isConnected)return!1;let n=e.getBoundingClientRect(),r=t.getBoundingClientRect();return Math.abs(n.top-r.bottom)<120||Math.abs(r.top-n.bottom)<120}function un(e){if(!e||e.offsetParent===null)return!1;let t=e.closest(`.mag-inhalt`)||K,n=e.getBoundingClientRect(),r=t.getBoundingClientRect();return n.bottom>r.top&&n.top<r.bottom&&n.height>0}function dn(e,t,n){if(!e||!e.isConnected)return;let r=e.closest(`.mag-reihe`)||e,i=r.nextElementSibling;(!i||!i.classList.contains(`mag-quittung`))&&(i=T(`div`,`mag-quittung`),r.insertAdjacentElement(`afterend`,i)),i.textContent=t,i.classList.toggle(`fehler`,!!n),clearTimeout(i._uhr),i._uhr=setTimeout(()=>i.remove(),6e3)}function fn(e,t){e&&e.isConnected&&(e._urText??=e.textContent,e.textContent=t,e.classList.add(`mag-bestaetigt`),clearTimeout(e._uhr),e._uhr=setTimeout(()=>{e.textContent=e._urText,e._urText=null,e.classList.remove(`mag-bestaetigt`)},2500))}function pn(e){let t=q(e);return t.hidden=!1,t.innerHTML=``,e=>{t.appendChild(T(`div`,`mag-logzeile`,e)),t.scrollTop=t.scrollHeight}}function mn(){return new Promise(e=>{if(!(t!==void 0&&t.storage))return e();t.storage.local.get([`magSettings`],t=>{t.magSettings&&(C=Object.assign({},ce,t.magSettings)),e()})})}function hn(){t!==void 0&&t.storage&&t.storage.local.set({magSettings:C})}function gn(){K.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;e.type===`checkbox`?e.checked=!!C[t]:e.value=C[t]==null?``:C[t]}),$()}function _n(){K.querySelectorAll(`[data-opt]`).forEach(e=>{let t=e.dataset.opt;C[t]=e.type===`checkbox`?e.checked:e.value}),String(C.kiHinweisText||``).trim()||(C.kiHinweisText=Pe),C.promptHorizont=null,C.promptKorrektur=null,hn(),$()}function vn(){let e=N();return[e.fach||`⚠ Fach fehlt`,`Jahrgang `+(e.jahrgang||`⚠ fehlt`),`Niveau `+(vt[e.niveau||`G`]||e.niveau),`Feedback `+Fe()].join(` · `)}function yn(){let e=P();return!String(e.fach||``).trim()||!String(e.jahrgang||``).trim()}function bn(){if(u!==`bewertung`||!M)return Z&&u===`bewertung`&&Z!==Fe();let e=N(),t=P();return(t.fach||``)!==(e.fach||``)||String(t.jahrgang||``)!==String(e.jahrgang||``)||(t.niveau||`G`)!==(e.niveau||`G`)||ie()!==Fe()}function xn(){let e=q(`kkurz`);if(!e)return;let t=N(),n=String(C.punkteschritte||`0.5`).replace(`.`,`,`);e.textContent=[ye()===`sie`?`Sie-Anrede`:`Du-Anrede`,`Rechtschreibung bis `+String(ze(t.jahrgang)).replace(`.`,`,`)+` %`,n===`1`?`ganze Punkte`:`Punkte in `+n+`er-Schritten`,[t.fach,t.jahrgang&&`Jg. `+t.jahrgang].filter(Boolean).join(`, `)||`Fach und Jahrgang fehlen`].join(` · `);let r=q(`kwarn`);if(r){let e=q(`krahmen`)&&q(`krahmen`).textContent.split(`  –  `).slice(1).join(` `)||``;r.textContent=e?`⚠ `+e:``,r.hidden=!e}}function Sn(){let e=q(`krahmen`);if(e){let t=N();e.textContent=vn()+(u===`bewertung`&&!t.ausHorizont?`  –  Der Horizont enthält diese Angaben noch nicht; es gelten die zuletzt benutzten Werte. Feste Werte bekommt die Aufgabe mit einem neu eingetragenen Horizont.`:``)+(u===`bewertung`&&!ae()?`  –  Feedbacklänge: Standard.`:``)+(u===`bewertung`&&bn()?`  –  Im Reiter Horizont stehen Änderungen, die noch nicht eingetragen sind. Bewertet wird nach dem gespeicherten Horizont, bis du den neuen einträgst.`:``),e.parentElement.classList.toggle(`unvollstaendig`,yn())}let t=q(`kanrede`);t&&(t.value=C.anredeWahl||`auto`);let n=N().jahrgang,r=q(`krs`);r&&(r.value=ze(n));let i=q(`krslabel`);i&&(i.textContent=`Rechtschreibung: Höchstabzug in % der Gesamtpunktzahl – `+(Te(n)===`sek2`?`Oberstufe (ab Jahrgang 11)`:`Sekundarstufe I (bis Jahrgang 10)`));let a=P(),o=q(`hfach`);o&&document.activeElement!==o&&(o.value=a.fach||``);let s=q(`hjahrgang`);if(s){if(!s.options.length){let e=document.createElement(`option`);e.value=``,e.textContent=`–`,s.appendChild(e);for(let e=5;e<=13;e++){let t=document.createElement(`option`);t.value=String(e),t.textContent=String(e),s.appendChild(t)}}s.value=a.jahrgang||``}let c=q(`hniveau`);c&&(c.value=a.niveau||`G`),xn();let l=q(`hrahmenhinweis`);if(l){let e=yn();l.textContent=e?`⚠ Bitte Fach und Jahrgang angeben – sie gehen in den Prompt und in den Horizont.`:u===`bewertung`?`Der Horizont regelt die Bewertung: Änderungen hier gelten erst, wenn du den neuen Horizont in Schritt 3 einträgst. Bis dahin wird nach dem gespeicherten Horizont bewertet.`:Le().jahrgang?``:`Vorbelegt mit den zuletzt benutzten Werten – bitte prüfen.`,l.classList.toggle(`fehler`,e)}}function $(){Sn();let e=q(`anredehinweis`);e&&(e.textContent=`Im Feedback steht „`+be()+` …"`+((C.anredeWahl||`auto`)===`auto`?` (Jahrgang `+(N().jahrgang||`?`)+`).`:`.`));let t=q(`rshinweis`);t&&(t.textContent=Me(ze(N().jahrgang),`der Gesamtpunktzahl`));let n=q(`vvorschau`),r=ft();n&&Ke(n,r||`<p class="mag-hinweis">Im Horizont sind keine Teilaufgaben erkennbar – daraus entstehen die Kästen.</p>`);let i=q(`vformat`);i&&(i.hidden=dt(),i.textContent=`Hinweis: Das Antwortformat dieser Aufgabe ist nicht „HTML-Editor". Beim Einfügen stellt die Erweiterung es auf „HTML-Editor" um – „Nur Text" kann kein Layout darstellen.`),gt();let a=q(`vhorizont`);a&&Ke(a,X===`kurztest`&&u===`bearbeiten`?Qt?nn(Qt):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`:J?_t(J):`<p class="mag-hinweis">Noch kein Horizont eingelesen.</p>`)}function Cn(e){K.querySelectorAll(`.mag-inhalt`).forEach(t=>{t.hidden=t.dataset.panel!==e}),K.querySelectorAll(`.mag-tab`).forEach(t=>t.classList.toggle(`aktiv`,t.dataset.tab===e));let t=Lt.some(t=>t[0]===e);K.querySelector(`.mag-reiter`).hidden=!t,t&&e!==`einst`&&(Ut=e),e===`vorlage`&&$(),e===`korrektur`&&Nn()}let wn=null;function Tn(e,t,n,r){let i=sn;navigator.clipboard.writeText(e).then(()=>{fn(i,`✓ In die Zwischenablage kopiert`);let a=n+`  (`+e.length.toLocaleString(`de-DE`)+` Zeichen)`;if(Q(t,a),!r||!q(r))return;clearInterval(wn);let o=3;Q(t,a+` — weiter in `+o+` s`),wn=setInterval(()=>{if(o--,o>0)return Q(t,a+` — weiter in `+o+` s`);clearInterval(wn),wn=null,Q(t,a+` — jetzt die Antwort der KI einfügen.`);let e=q(r);e.focus(),e.scrollIntoView({block:`nearest`})},1e3)}).catch(()=>Q(t,`Kopieren fehlgeschlagen — Text bitte von Hand markieren.`,!0))}function En(){let e=q(`hjson`).value.trim();if(!e)return Q(`hstatus`,`Bitte erst die Antwort der KI einfügen.`,!0);if(X===`kurztest`)return Dn(e);try{let t=Nt(e,`aufgaben`).map(e=>({nr:E(e.nr),schlagwort:e.schlagwort||``,afb:e.afb||``,punkte:e.punkte==null?null:k(e.punkte),operator:e.operator||``,horizont:e.horizont||e.text||``})).filter(e=>/^\d{1,2}[a-h]?$/.test(e.nr)).sort((e,t)=>parseInt(e.nr,10)-parseInt(t.nr,10)||e.nr.localeCompare(t.nr));if(!t.length)throw Error(`Keine Aufgaben im JSON.`);let{doppelt:n}=Pt(t,t.map(e=>e.nr));if(n.length)throw Error(`Aufgabe `+n.join(`, `)+` kommt doppelt vor.`);let r=t.reduce((e,t)=>e+(t.punkte||0),0),i=R();J=t;let a=q(`hliste`);a.innerHTML=``,t.forEach(e=>{let t=T(`div`,`mag-karte`);t.appendChild(T(`div`,`mag-kartenkopf`,`Aufgabe `+e.nr+(e.afb?` · AFB `+e.afb:``)+(e.schlagwort?` · `+e.schlagwort:``)+(e.punkte==null?``:`  (`+O(e.punkte)+` P.)`)));let n=T(`textarea`,`mag-kartentext`);n.value=F(e.horizont),n.rows=5,n.addEventListener(`input`,()=>{e.horizont=n.value}),t.appendChild(n),a.appendChild(t)});let o=t.length+` Aufgaben gelesen.`;i&&Math.abs(r-i)>.005&&(o+=`  ⚠ Punktsumme `+O(r)+` weicht von der Fragenpunktzahl `+O(i)+` ab — die Erweiterung rechnet sie beim Bewerten um.`),u===`bearbeiten`&&(o+=`  Dann unten unter Schritt 3 eintragen.`),Q(`hstatus`,o),q(`hknoepfe`).hidden=!1,q(`hschritt3`).hidden=!1,$()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}function Dn(e){try{let t=Nt(e,`horizonte`).find(e=>e&&(e.text||e.horizont));if(!t)throw Error(`Kein Horizont im JSON (erwartet: "horizonte").`);Qt=String(t.text||t.horizont).trim();let n=q(`hliste`);n.innerHTML=``;let r=T(`div`,`mag-karte`);r.appendChild(T(`div`,`mag-kartenkopf`,`Kurztest-Horizont`));let i=T(`textarea`,`mag-kartentext`);i.value=Qt,i.rows=12,i.addEventListener(`input`,()=>{Qt=i.value}),r.appendChild(i),n.appendChild(r),Q(`hstatus`,`Horizont gelesen. Prüfen, bei Bedarf ändern, dann unten unter Schritt 3 eintragen.`),q(`hknoepfe`).hidden=!1,q(`hschritt3`).hidden=!1,$t()}catch(e){Q(`hstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function On(e){if(X===`kurztest`){if(!Qt)return Q(`hstatus`,`Es liegt noch kein geprüfter Horizont vor.`,!0);let t={"graderinfo[text]":nn(Qt)};return qt()?(rn(t,`hstatus`),gt(),setTimeout(ht,50)):(await jn(t,e,pn(`hlog`),`hstatus`),!e&&u===`bearbeiten`&&kn(t),gt(),setTimeout(ht,50))}if(qt()&&J)return rn({"graderinfo[text]":_t(J)},`hstatus`),gt(),setTimeout(ht,50);let t=`hstatus`;if(!J)return Q(t,`Es liegt noch kein geprüfter Horizont vor — bitte erst im Reiter „Horizont" die Antwort der KI einlesen und prüfen.`,!0);if(!on())return Q(t,`Die Adresse der Frage lässt sich hier nicht bestimmen — bitte die Frage zum Bearbeiten öffnen.`,!0);let n=pn(`hlog`),r={"graderinfo[text]":_t(J)};await jn(r,e,n,t),!e&&u===`bearbeiten`&&kn(r),gt(),setTimeout(ht,50)}function kn(e){try{Object.keys(e).forEach(t=>ne(t,e[t]))}catch{}}function An(){try{let e=[],t=``;if(C.layoutAufgabe!==!1){let t=pt();if(t.fehler)return Q(`vstatus`,t.fehler,!0);ne(`questiontext[text]`,t.html),e.push(`Aufgabenstellung`)}if(C.layoutAntwort!==!1){let n=ft();if(!n)return Q(`vstatus`,`Für die Antwortvorlage fehlen die Teilaufgaben aus dem Horizont.`,!0);if(!dt()){let e=w(`[name="responseformat"]`);e.value=`editor`,e.dispatchEvent(new Event(`change`,{bubbles:!0})),t=` Das Antwortformat wurde auf „HTML-Editor" umgestellt – nur so wird das Layout dargestellt.`}ne(`responsetemplate[text]`,n),e.push(`Antwortvorlage`)}if(!e.length)return Q(`vstatus`,`Bitte oben auswählen, was gestaltet werden soll.`,!0);Q(`vstatus`,e.join(` und `)+` ins Formular eingefügt.`+t+` Gefällt es dir, „Änderungen speichern" – sonst „Abbrechen".`),$()}catch(e){Q(`vstatus`,`Fehler: `+e.message,!0)}}async function jn(e,t,n,r){let i=Object.keys(e);try{if(Q(r,t?`Trockenlauf läuft …`:`Wird eingetragen …`),u!==`bearbeiten`){let a=on(),o=[...(await I(a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`));if(!o)throw Error(`Bearbeiten-Formular der Frage nicht erreichbar.`);let s=Ye(o);if(i.forEach(r=>{if(!s.has(r))throw Error(`Feld „`+r+`" nicht im Formular`);n((t?`✓ `:``)+`Feld `+r+` vorhanden`+(F(s.get(r)).length?` (enthält schon Text!)`:``)),t||s.set(r,e[r])}),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);let c=(o.querySelector(`[name="name"]`)||{}).value||``,l=await Ze(await Xe(o,s,a),c,a),u=[...(await I(l||a)).forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`)),d=0;return i.forEach(t=>{let r=u&&u.querySelector(`[name="`+CSS.escape(t)+`"]`),i=!!r&&$e(r.value,e[t]);n((i?`✓ `:`✗ `)+t+(i?` eingetragen`:` NICHT angekommen`)),i||d++}),l||n(`⚠ Neue Fragenversion nicht auffindbar — Gegenprobe unsicher.`),d?Q(r,d+` Feld(er) nicht angekommen — Protokoll lesen.`,!0):(e[`graderinfo[text]`]&&(z=e[`graderinfo[text]`]),Q(r,`Als neue Fassung der Frage gespeichert und gegengeprüft. Moodle zeigt auf dieser Seite weiter den alten Horizont – geschriebene Versuche bleiben in Moodle an der Fassung, mit der sie geschrieben wurden. Die Erweiterung bewertet ab jetzt nach dem neuen Horizont.`))}let a=await et(e,t);if(a.bericht.forEach(e=>n((t?`✓ `:``)+`Feld `+e.feld+` vorhanden`+(e.belegt?` (enthält schon Text!)`:``))),t)return Q(r,`Alles vorhanden. Jetzt eintragen.`);a.warnung&&n(`⚠ `+a.warnung);let o=0;if((a.ergebnis||[]).forEach(e=>{n((e.ok?`✓ `:`✗ `)+e.feld+(e.ok?` eingetragen`:` NICHT angekommen`)),e.ok||o++}),o)return Q(r,o+` Feld(er) nicht angekommen — Protokoll lesen.`,!0);n(`✓ gespeichert und gegengeprüft`),Bn(a.neueUrl),Q(r,a.neueUrl?`Eingetragen und gegengeprüft. Diese Seite zeigt jetzt einen veralteten Stand.`:`Eingetragen und gegengeprüft. Bitte die Frage neu öffnen — Moodle hat beim Speichern eine neue Version angelegt.`,!1)}catch(e){n(`✗ `+e.message),Q(r,`Fehler: `+e.message,!0)}}function Mn(e){let t=e.length?e.reduce((e,t)=>e+ke(t.text),0)/e.length:0,n=Math.max(200,t*6);return Math.max(1,Math.min(30,Math.floor(22e3/n)))}function Nn(){let e=W(),t=q(`kgroesse`);t.options.length||([1,2,3,5,8,10,15,20,30].forEach(e=>t.appendChild(new Option(e+(e===1?` Abgabe`:` Abgaben`),e))),t.value=String(Mn(e)),t.addEventListener(`change`,Nn));let n=e.length?Math.round(e.reduce((e,t)=>e+ke(t.text),0)/e.length):0;q(`kgroessehinweis`).textContent=e.length+` Abgaben, im Schnitt `+n+` Wörter. Vorschlag: `+Mn(e)+` je Durchgang.`;let r=B()||C.horizontLokal,i=parseInt(t.value,10)||5,a=Math.ceil(e.length/i)||1,o=q(`kgroessebox`);o&&(o.hidden=!(Mn(e)<e.length||a>1));let s=q(`kteilehinweis`);s&&(s.hidden=a<=1);let c=q(`kknoepfe`);c.innerHTML=``;for(let t=0;t<a;t++){let n=t*i,o=Math.min(n+i,e.length),s=T(`button`,`mag-btn mag-btn-primary`,a===1?`📋 Bewertungsprompt kopieren`:`📋 Teil `+(t+1)+` kopieren (Arbeit `+(n+1)+`–`+o+`)`);s.addEventListener(`click`,()=>{if(!r)return Q(`kstatus`,`Kein Erwartungshorizont — bitte erst den Reiter „Horizont" verwenden.`,!0);Tn(kt(e.slice(n,o),r,t+1,a),`kstatus`,a===1?`Prompt kopiert.`:`Teil `+(t+1)+` kopiert.`,`kjson`)}),c.appendChild(s)}}let Pn=!1;function Fn(){if(Wt)return;if(Gt)return Q(`kstatus`,`Gesperrt: Antworten zu mehreren Fragen auf dieser Seite. Bitte jede Frage einzeln über die Übersicht öffnen.`,!0);let e=q(`kjson`).value.trim();if(!e)return Q(`kstatus`,`Bitte erst die Antworten der KI einfügen.`,!0);try{let t=W(),n=H(B()||C.horizontLokal),r=Nt(e,`bewertungen`).filter(e=>e&&e.nr!=null),{fehlend:i,doppelt:a}=Pt(r,t.map(e=>e.nr));if(a.length)throw Error(`Abgabe `+a.join(`, `)+` kommt doppelt vor.`);if(i.length&&!Pn){let e=q(`kliste`);e.innerHTML=``,q(`keintragen`).hidden=!0,Y=null;let n=q(`rsabgleich`);n&&(n.hidden=!0);let r=t.length-i.length;Q(`kstatus`,`Teil erkannt: `+r+` von `+t.length+` Abgaben. Nächsten Teil einfach dazu einfügen — geprüft wird, sobald alle da sind. (Es fehlen: `+i.join(`, `)+`)`);let a=T(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`Trotzdem nur diese `+r+` prüfen`);a.addEventListener(`click`,()=>{Pn=!0,Fn()}),e.appendChild(a);return}let o=parseFloat(ze(N().jahrgang))||0,s=parseFloat(C.punkteschritte)||.5,c=q(`kliste`);c.innerHTML=``;let l=q(`rsabgleich`);l&&(l.innerHTML=``,l.hidden=!0),Y=[];let u=0;r.forEach(e=>{let r=t.find(t=>t.nr===Number(e.nr));if(!r)return;let i=G(r,e,n,o,s),a=At(e,i,n);if(Math.abs(i.gesamt-r.ist)<.005&&!r.kommentarfeld){u++;return}Y.push({nr:r.nr,markfeld:r.markfeld,kommentarfeld:r.kommentarfeld,punkte:i.gesamt,feedbackHtml:jt(a),text:a});let l=T(`div`,`mag-karte`);e.besprochen===!0&&(l.dataset.gesehen=`1`,l.dataset.besprochen=`1`),l.appendChild(T(`div`,`mag-kartenkopf`,(e.besprochen===!0?`✓ besprochen · `:``)+`Arbeit `+r.nr+`:  bisher `+O(r.ist)+` → neu `+O(i.gesamt)+` von `+O(i.max)+` P.`+(i.abzug>.004?`   (−`+O(i.abzug)+` P. Sprache)`:``))),l.appendChild(T(`div`,`mag-kartenzeile`,i.teil.map(e=>`A`+e.nr+`: `+e.prozent+`%`).join(`   `)+`   ·   `+i.wortzahl+` Wörter, `+O(i.fehlerDichte)+` Fehler/100`+(i.fehlendeAufgaben.length?`   ·   ⚠ Aufgabe `+i.fehlendeAufgaben.join(`, `)+` von der KI nicht bewertet (0 %)`:``)));let d=T(`textarea`,`mag-kartentext`);d.value=a,d.rows=6;let f=Y[Y.length-1];d.addEventListener(`input`,()=>{f.text=d.value,f.feedbackHtml=jt(d.value)}),l.appendChild(d),c.appendChild(l)});let d=r.filter(e=>e.besprochen===!0).length,f=Y.length+` Arbeiten vorbereitet.`+(d===r.length?` Alle gemeinsam besprochen – du kannst direkt eintragen.`:d?` `+d+` besprochen, `+(r.length-d)+` automatisch bewertet – diese bitte ansehen.`:` Automatisch bewertet – bitte jede Arbeit einmal ansehen.`);u&&(f+=`  `+u+` ohne Änderung übersprungen.`),i.length&&(f+=`  ⚠ Es fehlen die Abgaben `+i.join(`, `)+` — bitte den fehlenden Teil nachreichen.`),Q(`kstatus`,f,i.length>0),q(`keintragen`).hidden=Y.length===0}catch(e){Q(`kstatus`,`Konnte nicht gelesen werden: `+e.message,!0)}}async function In(e){if(!Y||!Y.length)return;let t=pn(`klog`);try{Q(`kstatus`,e?`Trockenlauf läuft …`:`Wird eingetragen …`);let n=await It(Y,e,t);if(e)return Q(`kstatus`,n.fehler?n.fehler+` Abgabe(n) nicht auf der Seite — Protokoll lesen.`:`Alles vorhanden. Jetzt eintragen.`,n.fehler>0);if(t(`— `+n.ok+` eingetragen · `+n.fehler+` fehlgeschlagen —`),n.fehler)Q(`kstatus`,n.fehler+` fehlgeschlagen — Protokoll lesen.`,!0);else{let e=new URLSearchParams(location.search),t=e.get(`id`),r=Ue(await Be(t),e.get(`slot`),e.get(`qid`)),i=null,a=`Fenster schließt`;r&&r.naechste?(i=Ve(t,r.naechste),a=`Weiter zur Klausur-Frage `+(r.index+2)+` von `+r.gesamt):r&&(i=He(t),a=`Alle Klausur-Fragen bewertet — zurück zur Übersicht`);let o=3,s=n.ok+` Bewertungen eingetragen und gegengeprüft.`;Q(`kstatus`,s+` `+a+` in `+o+` s …`);let c=setInterval(()=>{if(o--,o>0)return Q(`kstatus`,s+` `+a+` in `+o+` s …`);clearInterval(c),Rn.zu(),i?location.href=i:location.reload()},1e3)}}catch(e){t(`✗ `+e.message),Q(`kstatus`,`Fehler: `+e.message,!0)}}let Ln=`horizont`,Rn={einst:()=>{gn(),Cn(`einst`)},zueinst:()=>{gn(),Cn(`einst`)},zuhorizont:()=>Cn(`horizont`),zu:()=>{K.classList.remove(`offen`),Vt.classList.remove(`versteckt`)},hprompt:()=>Tn(wt(),`hstatus`,`Prompt kopiert.`,`hjson`),hedit:()=>Vn(`horizont`),hpruefen:En,hschreiben:()=>On(!1),hlokalsichern:()=>{C.horizontLokal=q(`hlokal`).value.trim(),hn(),Q(`hstatus`,C.horizontLokal?`Horizont in der Erweiterung gespeichert (nicht in der Frage).`:`Gespeicherter Horizont gelöscht.`),Nn()},lein:()=>An(),kedit:()=>Vn(`korrektur`),kpruefen:Fn,kschreiben:()=>{let e=ue(`.mag-karte`,q(`kliste`)).filter(e=>e.dataset.gesehen!==`1`).length,t=K.querySelector(`[data-tu="kschreiben"]`);if(e&&!Kt)return Kt=!0,t&&(t.textContent=`⚠ Ja, `+e+` ungeprüft eintragen`),Q(`kstatus`,`⚠ `+e+` automatisch bewertete Arbeit(en) noch nicht angesehen. Bitte durchblättern. Willst du sie ungeprüft eintragen, bestätige das mit dem Knopf unten.`,!0);Kt=!1,t&&(t.textContent=`Alle eintragen`),In(!1)},krohdaten:()=>Tn(JSON.stringify({stand:new Date().toLocaleString(`de-DE`),fach:N().fach,jahrgang:N().jahrgang,gesamtpunkte:R(),aufgabenstellung:L(),horizont:F(B()||C.horizontLokal),abgaben:W().map(e=>{let t=tt(e.rohHtml,e.text);return{nr:e.nr,ist:e.ist,max:e.max,gegliedert:t.gegliedert,aufgaben:t.aufgaben}})},null,2),`kstatus`,`Rohdaten kopiert.`),esichern:()=>{_n(),Q(`estatus`,``),Cn(u===`bearbeiten`?`horizont`:Ut===`einst`?`korrektur`:Ut)},eabbruch:()=>{gn(),Q(`estatus`,``),dn(sn,`Änderungen verworfen – die gespeicherten Einstellungen stehen wieder da.`)},kaendern:()=>{let e=q(`kfelder`);e.hidden=!e.hidden;let t=K.querySelector(`[data-tu="kaendern"]`);t&&(t.textContent=e.hidden?`ändern`:`fertig`)},kistandard:()=>{let e=K.querySelector(`[data-opt="kiHinweisText"]`);e&&(e.value=Pe),dn(sn,`Standardtext eingesetzt. Mit „Speichern und zurück" übernehmen.`)},psichern:()=>{let e=q(`ptext`).value.trim(),t=e===(Ln===`horizont`?xt():Dt()).trim()?null:e;Ln===`horizont`?C.promptHorizont=t:C.promptKorrektur=t,hn(),Cn(Ut)},pzurueck:()=>{q(`ptext`).value=Ln===`horizont`?xt():Dt()},pabbruch:()=>Cn(Ut)},zn=null;function Bn(e){let t=K.querySelector(`.mag-banner`);if(t.hidden=!1,t.className=`mag-banner warnung`,t.innerHTML=``,t.appendChild(T(`div`,null,`Moodle hat beim Speichern eine neue Fassung der Frage angelegt. Dieses Formular zeigt den alten Stand — hier nichts mehr speichern!`)),!e)return;let n=T(`button`,`mag-btn mag-btn-ok`,`Zur neuen Fassung der Frage`),r=T(`button`,`mag-btn mag-btn-klein mag-btn-grau`,`hier bleiben`);n.addEventListener(`click`,()=>{location.href=e}),t.appendChild(n),t.appendChild(r);let i=8,a=T(`div`,`mag-hinweis`,`Wechsel in `+i+` Sekunden …`);t.appendChild(a),r.addEventListener(`click`,()=>{clearInterval(zn),zn=null,a.textContent=`Wechsel angehalten. Diese Seite bitte nicht mehr speichern.`,r.remove()}),zn=setInterval(()=>{if(i--,i<=0){clearInterval(zn),location.href=e;return}a.textContent=`Wechsel in `+i+` Sekunden …`},1e3)}function Vn(e){Ln=e,q(`ptitel`).textContent=e===`horizont`?`Prompt für den Erwartungshorizont`:`Prompt für die Korrektur`;let t=e===`horizont`?C.promptHorizont:C.promptKorrektur;q(`ptext`).value=t&&t.trim()||(e===`horizont`?xt():Dt()),Cn(`prompt`)}K.addEventListener(`click`,e=>{let t=e.target.closest(`button`);t&&!t.classList.contains(`mag-tab`)&&(sn=t,cn=Date.now())},!0),K.addEventListener(`click`,e=>{let t=e.target.closest(`.mag-tab`);if(t)return wn&&=(clearInterval(wn),null),t.dataset.tab===`einst`?Rn.einst():Cn(t.dataset.tab);let n=e.target.closest(`[data-tu]`);n&&Rn[n.dataset.tu]&&(e.preventDefault(),Rn[n.dataset.tu]())}),K.addEventListener(`paste`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;if(t===`hjson`&&setTimeout(En,0),t===`kjson`){let t=e.clipboardData&&e.clipboardData.getData(`text`);if(t){e.preventDefault();let n=e.target,r=n.value.replace(/\s+$/,``);n.value=r?r+`

`+t:t,n.scrollTop=n.scrollHeight}Pn=!1,setTimeout(Fn,0)}});let Hn=null;K.addEventListener(`input`,e=>{let t=e.target&&e.target.dataset&&e.target.dataset.rolle;t!==`hjson`&&t!==`kjson`||e.inputType===`insertFromPaste`||(t===`kjson`&&(Pn=!1),clearTimeout(Hn),Hn=setTimeout(()=>{e.target.value.trim()&&(t===`hjson`?En:Fn)()},800))}),K.addEventListener(`change`,e=>{let t=e.target.closest(`[data-opt]`);t&&[`afbFarben`,`vorlagePunkte`,`vorlageAfb`,`kartePunkte`,`layoutAufgabe`,`layoutAntwort`,`punkteschritte`].includes(t.dataset.opt)&&(C[t.dataset.opt]=t.type===`checkbox`?t.checked:t.value,t.dataset.opt===`vorlagePunkte`&&(C.kartePunkte=t.checked),hn(),$(),t.dataset.opt===`punkteschritte`&&tn())}),Vt.addEventListener(`click`,()=>{K.classList.add(`offen`),Vt.classList.add(`versteckt`)}),mn().then(()=>{try{let e=K.querySelector(`.mag-kopfbild`);e&&(e.src=t.runtime.getURL(`icon/128.png`))}catch{let e=K.querySelector(`.mag-kopfbild`);e&&e.remove()}if(document.body.appendChild(Vt),document.body.appendChild(K),Oe(),u===`bearbeiten`){let e=Le();M={fach:e.fach||C.fach||``,jahrgang:e.jahrgang||C.jahrgang||``,niveau:e.niveau||C.kursniveau||`G`,ausHorizont:!!e.jahrgang}}gn(),q(`hlokal`).value=C.horizontLokal||``;let e=V(),n=K.querySelector(`.mag-banner`),r=u===`bewertung`?new Set(ue(`.que .graderinfo`).map(e=>e.innerText.trim()).filter(Boolean)).size:0;if(Gt=r>1,r>1){n.hidden=!1,n.textContent=`Auf dieser Seite stehen Antworten zu `+r+` verschiedenen Fragen (Zufallsfrage). Bitte über die Übersicht jede Frage einzeln öffnen — sonst würde alles gegen einen einzigen Horizont bewertet.`,q(`kstatus`)&&Q(`kstatus`,`Gesperrt: mehrere Fragen auf einer Seite (siehe oben).`,!0);let e=K.querySelector(`[data-tu="kschreiben"]`);e&&(e.disabled=!0)}else e.wer===`coach`&&u===`bewertung`?an(n):!e.horizont&&u===`bewertung`&&!C.horizontLokal&&(n.hidden=!1,n.textContent=`Diese Frage hat noch keinen Erwartungshorizont. Er lässt sich hier nachtragen.`);let i=K.querySelector(`.mag-untertitel`);i&&(i.textContent=u===`bearbeiten`?`Aufgabe vorbereiten`:`Antworten bewerten`);let a;if(a=u===`bewertung`&&!e.horizont&&!C.horizontLokal||u===`bearbeiten`?`horizont`:`korrektur`,Cn(a),Sn(),u===`bewertung`){let e=W().length;Gt||Q(`kstatus`,e?e+` Arbeiten auf dieser Seite.`:`Keine Arbeiten gefunden.`),mt();let t=r>1?null:_e(w(`.que`)),i=new URLSearchParams(location.search).get(`qid`);if(t&&t.gesamt>t.ist&&i){let r=new URLSearchParams(location.search).get(`id`);ve(i,e=>location.origin+`/question/bank/editquestion/question.php?id=`+e+(r?`&cmid=`+r:``)).then(r=>{if(!r)return;z=r.html;let i=V();X=i.wer===`coach`?`kurztest`:`klausur`;let a=S(z);Z=a&&Yt[X].some(e=>e[0]===a)?a:Xt[X],$t(),$(),i.wer===`coach`&&!Wt&&an(n),Gt||Q(`kstatus`,e+` Arbeiten auf dieser Seite. Maßstab ist der Horizont der neuesten Fragenfassung (v`+t.gesamt+`), nicht der ältere, den Moodle hier anzeigt.`),mt(),(!q(`kknoepfe`)||!K.querySelector(`[data-panel="korrektur"]`).hidden)&&Nn()}).catch(()=>{})}let a=q(`khilfe`);a&&(a.open=!C.khilfeGesehen,a.addEventListener(`toggle`,()=>{!a.open&&!C.khilfeGesehen&&(C.khilfeGesehen=!0,hn())}))}else{mt();let e=St();e.length&&(q(`hmaterial`).hidden=!1,q(`hmaterial`).textContent=`In der Aufgabe stehen `+e.length+` Bild(er)/Datei(en): `+e.join(` · `)+` – bitte zusätzlich in den KI-Chat hochladen.`);let t=q(`hhilfe`);t&&(t.open=!C.hilfeGesehen,t.addEventListener(`toggle`,()=>{!t.open&&!C.hilfeGesehen&&(C.hilfeGesehen=!0,hn())})),K.classList.add(`offen`),Vt.classList.add(`versteckt`)}})}var et=e({matches:[`*://*/*mod/quiz/report.php*`,`*://*/*question/bank/editquestion/question.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){$e(),location.pathname.includes(`/mod/quiz/report.php`)&&Qe()}}),L={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},R=class e extends Event{static EVENT_NAME=z(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function z(e){return`${t?.runtime?.id}:content:${e}`}var B=typeof globalThis.navigation?.addEventListener==`function`;function V(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),B?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new R(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new R(e,t)),t=e)},1e3))}}}var H=class e{static SCRIPT_STARTED_MESSAGE_TYPE=z(`wxt:content-script-started`);id;abortController;locationWatcher=V(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?z(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),L.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},U={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=et;return await e(new H(`content`,t))}catch(e){throw U.error(`The content script "content" crashed on startup!`,e),e}})()})();