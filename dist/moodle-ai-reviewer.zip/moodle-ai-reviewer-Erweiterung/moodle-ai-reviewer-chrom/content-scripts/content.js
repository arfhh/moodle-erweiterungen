(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``,n=new URLSearchParams(location.search);if(n.get(`mode`)!==`grading`)return;let r=n.get(`id`);if(!r||n.get(`includeauto`)!==`1`)return;let i=location.origin+location.pathname,a=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),o=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},s=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),c=e=>Number(e).toFixed(2).replace(`.`,`,`),l=e=>String(Number(e)).replace(`.`,`,`),u=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function d(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let f=e=>new Promise(t=>setTimeout(t,e)),p=e=>((e.id||``).match(/^question-(\d+)-\d+$/)||[])[1]||e.id;async function m(e,t){let n=new Set,r=[],i=0;for(let a=0;a<8;a++){a>0&&await f(500);let o=await d(e),s=0;if(o.querySelectorAll(`div.que`).forEach(e=>{let t=p(e);t&&!n.has(t)&&(n.add(t),r.push(e),s++)}),t!=null&&r.length>=t||(i=s?0:i+1,t==null&&i>=2))break}return r}async function h(e,t){let n=null,r=new URLSearchParams,i=new Set;for(let a=0;a<8;a++){a>0&&await f(500);let o=(await d(e)).querySelector(`form#manualgradingform`);if(!o)throw Error(`Bewertungsformular nicht gefunden`);n=o;let s=de(o);if([...new Set(s.keys())].forEach(e=>{e===`qubaids`?s.get(e).split(`,`).map(e=>e.trim()).filter(Boolean).forEach(e=>i.add(e)):r.has(e)||s.getAll(e).forEach(t=>r.append(e,t))}),t.every(e=>r.has(e)))break}return i.size&&r.set(`qubaids`,[...i].join(`,`)),{form:n,felder:r}}let g=(e,t,n)=>`${i}?id=${r}&mode=grading&slot=${e}&qid=${t}&grade=${n||`autograded`}&includeauto=1&qperpage=100`,_=e=>{let t=String(e||``).match(/sub(\d+)_/);return t?parseInt(t[1],10):1},v=e=>!e.type||e.type===`text`||e.type===`number`;function y(e){let t=``;return e&&e.childNodes.forEach(e=>{e.nodeType===3?t+=e.textContent:e.nodeType===1&&(e.tagName===`INPUT`&&/_answer$/.test(e.name||``)&&v(e)?t+=`[[L`+_(e.name)+`]]`:[`INPUT`,`SELECT`,`TEXTAREA`,`SCRIPT`,`STYLE`].includes(e.tagName)||(e.tagName===`IMG`?t+=`[BILD]`:t+=y(e)))}),t}let b=e=>e.replace(/\s+/g,` `).replace(/^\s*Fragetext\s*/i,``).replace(/Antwort\s+\d+\s+Frage\s+\d+\s*(?=\[\[L)/g,``).trim(),x=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,S={vollstaendig:!1,promptOverride:``,kiHinweisText:x,feedbackSammeln:!0,feedbackSchwelleProzent:50,kompaktPrompt:!1},C={...S};function ee(){return new Promise(e=>{try{t.storage.local.get([`reviewerOptionen`],t=>{C={...S,...t&&t.reviewerOptionen?t.reviewerOptionen:{}},e(C)})}catch{e(C)}})}function w(e){return C={...C,...e},new Promise(e=>{try{t.storage.local.set({reviewerOptionen:C},e)}catch{e()}})}async function T(e){try{let t=await d(`${a}/question/bank/editquestion/question.php?id=${e}&cmid=${r}`);return t.querySelector(`textarea[name="questiontext[text]"]`)?t:null}catch{return null}}let E=e=>{let t=e&&e.querySelector(`textarea[name="questiontext[text]"]`);return t&&(t.value||t.textContent)||null};function D(e){if(!e)return null;if(e.tagName===`SELECT`){let t=e.querySelector(`option[selected]`)||e.selectedOptions&&e.selectedOptions[0]||e.querySelector(`option`);return t?t.value:null}return e.value==null?e.getAttribute(`value`):e.value}let O=e=>{let t=parseFloat(String(D(e)==null?``:D(e)).replace(`,`,`.`));return isNaN(t)?0:t};function k(e,t){let n=[],r=``;for(let i=0;i<e.length;i++){if(e[i]===`\\`){r+=e[i]+(e[i+1]||``),i++;continue}if(e[i]===t){n.push(r),r=``;continue}r+=e[i]}return n.push(r),n}let te=e=>e.replace(/\\([{}~=#\\])/g,`$1`);function A(e){if(!e)return null;let t=new DOMParser().parseFromString(e,`text/html`).body.textContent||``,n=[],r=0,i=-1;for(let e=0;e<t.length;e++){if(t[e]===`\\`){e++;continue}t[e]===`{`?(r===0&&(i=e),r++):t[e]===`}`&&(r--,r===0&&i>=0&&(n.push(t.slice(i+1,e)),i=-1))}return n.length?n.map((e,t)=>{let n=e.match(/^\s*(\d*)\s*:\s*([A-Za-z_]+)\s*:\s*([\s\S]*)$/);if(!n)return{nr:t+1,typ:`?`,richtig:[],varianten:[]};let r=n[2].toUpperCase(),i=k(n[3],`~`).map(e=>{let t=e,n=0,r=t.match(/^%(-?[\d.]+)%/);r?(n=parseFloat(r[1]),t=t.slice(r[0].length)):t.startsWith(`=`)&&(n=100,t=t.slice(1));let i=te(k(t,`#`)[0]||``).trim();return{prozent:n,text:i}}).filter(e=>e.text!==``);return{nr:t+1,typ:r,richtig:i.filter(e=>e.prozent===100).map(e=>e.text),varianten:i}}):null}function ne(e){if(!e)return null;let t=[];return e.querySelectorAll(`[name^="answer["]`).forEach(n=>{let r=(n.getAttribute(`name`).match(/^answer\[(\d+)\]$/)||[])[1];if(r==null)return;let i=String(D(n)||``).trim();i&&i!==`*`&&t.push({prozent:Math.round(O(e.querySelector(`[name="fraction[${r}]"]`))*100),text:i})}),t.length?[{nr:1,typ:O(e.querySelector(`[name="usecase"]`))===1?`SAC`:`SA`,richtig:t.filter(e=>e.prozent===100).map(e=>e.text),varianten:t}]:null}let j=`[MOODLE_AI_REVIEWER_DATEN]`;function M(){return`═══════════════════════════════════════════════════════
MOODLE AI REVIEWER – NACHBEWERTUNG FREI EINGETIPPTER ANTWORTEN
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:

1. „Willkommen beim Moodle AI Reviewer."
2. „Ich sehe die Schülerantworten durch, die Moodle bei den Lückentext- und Kurzantwort-Aufgaben nicht erkannt hat, und schlage dir für jede eine Bewertung vor. Entscheiden tust du."
3. „Der „Moodle AI Reviewer" wurde von A. Spielhoff entwickelt und ist unter der Lizenz CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen, solange du ihn nennst."

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Moodle prüft frei eingetippte Antworten – in Lückentexten genauso wie in
Kurzantwort-Fragen –, indem es den Text mit hinterlegten Antwortvarianten vergleicht.
Was nicht hinterlegt ist, bekommt 0 Punkte – auch wenn es inhaltlich richtig ist. Ein
Tippfehler, eine andere Wortform oder ein Synonym genügen dafür.

Du bekommst unten genau diese Fälle: Antworten, bei denen KEINE hinterlegte Variante
gegriffen hat, obwohl der Schüler etwas geschrieben hat. Zu jeder Frage steht dabei,
welche Antwort eigentlich gesucht war.

═══════════════════════════════════════════════════════
BEVOR DU BEWERTEST – ZWEI PFLICHTSCHRITTE JE ANTWORT
═══════════════════════════════════════════════════════

**1. Lies den Satz um die Lücke.**
Bei jeder Lücke steht unter „kontext" der Satz, in dem sie vorkommt, mit [[L1]], [[L2]]
an der Stelle der Lücke. Ein einzelnes Wort lässt sich oft nicht beurteilen: Derselbe
Begriff kann in der einen Lücke genau richtig und in der anderen völlig falsch sein.
Beispiel: In „Alle Geräte müssen [[L1]] und an ihren Platz [[L2]] werden" passt
„verstaut" zu L2, aber nicht zu L1 – und umgekehrt „gespült" zu L1, aber nicht zu L2.
Prüfe also immer, welche Tätigkeit oder welcher Gegenstand an DIESER Stelle gemeint ist.

Bei Fragen mit „art": „kurzantwort" gibt es keine Lücke im Satz: die ganze Frage ist die
Aufgabe, das Eingabefeld steht darunter. Dort findest du unter „kontext" den kompletten
Fragetext, und es gibt genau eine Lücke mit der Nummer 1. Alles andere – Skala,
Pflichtschritte, Ausgabeformat – gilt unverändert.

**2. Vergleiche mit ALLEN hinterlegten Antworten, nicht nur mit der ersten.**
Unter „loesungen" steht je Lücke die vollständige Liste der Antworten, die als richtig
gelten – oft fünf oder mehr. Kürze diese Liste niemals ab und beurteile niemals gegen
eine verkürzte Fassung. Passt die Schülerantwort zu IRGENDEINER davon, ist sie richtig.

Steht bei einer Lücke zusätzlich „bekannte_varianten", findest du dort bereits erfasste
Falschschreibungen mit dem Prozentwert, den die Lehrkraft ihnen gegeben hat. Das ist
deine wichtigste Orientierung. **Verankere jede Bewertung an einem dieser Einträge**
und nenne ihn in der Begründung. Steht „Glassmüll" auf 75, kann „Glassmülleimer" nicht
plötzlich 25 bekommen; steht „Müll" auf 25, gilt das auch für „Mülleimer". Erfinde die
Skala nicht neu, wenn die Lehrkraft für dieselbe Lücke bereits entschieden hat.

**3. Beurteile das WORT, nicht die Handlung.**
Du prüfst nicht, ob das im Satz Beschriebene fachlich vernünftig ist. Du prüfst nur, ob
das eingetippte Wort zu dem passt, was für DIESE Lücke hinterlegt ist.

Das ist wichtig, weil viele Sätze verneint sind. Beispiel:
„Chemikalienreste werden NICHT in die Vorratsgefäße [[L1]], sondern entsprechend der
Anleitung [[L2]]." Für L1 ist „zurückgegeben" hinterlegt – obwohl der Satz sagt, dass
man das gerade nicht tun soll. Eine Schülerantwort „zurückgebracht" ist hier also
**100 % richtig**, denn sie trifft genau den gesuchten Begriff.

Fällt dir auf, dass die hinterlegte Lösung dem Sinn des Satzes zu widersprechen scheint,
ist fast immer eine Verneinung im Spiel. Halte dich dann an die hinterlegte Liste.

**4. Prüfe ZUERST auf einen reinen Groß-/Kleinschreibfehler.**
Bevor du irgendetwas anderes überlegst: Unterscheidet sich die Antwort von einem
hinterlegten Eintrag ausschließlich in der Groß-/Kleinschreibung? Dann ist sie bei
Lückentyp SAC genau 90 % und bei Lückentyp SA genau 100 %. Diese Prüfung kommt vor
allen Überlegungen zu Synonymen, Tippfehlern und Inhalt.
„Oben" bei hinterlegtem „oben" und Typ SAC ist 90 – nicht 100 und nicht 75.

Diese vier Schritte sind die häufigste Fehlerquelle. Nimm sie ernst.

═══════════════════════════════════════════════════════
BEWERTUNGSSKALA – VERBINDLICH
═══════════════════════════════════════════════════════

Vergib je Lücke genau einen dieser sechs Werte. Keine Zwischenwerte.

100 %  Richtig geschrieben, oder ein echtes gleichwertiges Synonym.
       Beispiele: „Bunsenbrenner" statt „Gasbrenner"; „Stößel" statt „Pistill";
       eine andere gültige Wortform desselben Begriffs.

 90 %  Wort vollständig korrekt, NUR die Groß-/Kleinschreibung stimmt nicht.
       Beispiel: „pistill" statt „Pistill".
       ACHTUNG – diese Stufe gilt AUSSCHLIESSLICH bei Lücken vom Typ SAC
       (unterscheidet Groß-/Kleinschreibung). Bei Lücken vom Typ SA ignoriert
       Moodle die Groß-/Kleinschreibung ohnehin; dort ist so eine Antwort 100 %.
       Der Lückentyp steht unten bei jeder Lücke.
       Vergib 90 % NIEMALS für „inhaltlich fast richtig" – dafür sind 50/25/0 da.

 75 %  Ein einzelner klarer Tippfehler – ein Buchstabe vertauscht, doppelt oder
       fehlend. Das Wort bleibt eindeutig erkennbar.
       Beispiele: „Mistill" statt „Pistill"; „Bechergals" statt „Becherglas".

 50 %  Mehrere Tippfehler oder eine stärkere Verschreibung. Das Wort ist noch mit
       Mühe erkennbar, man muss aber überlegen.
       Beispiele: „Bechaglas" statt „Becherglas"; „Erlemayer" statt „Erlenmeyerkolben".

 25 %  Nur Wortstamm oder Wortanfang erkennbar, starke Verkürzung.
       Beispiele: „Becher" statt „Becherglas"; „Erlen" statt „Erlenmeyerkolben".

  0 %  Falsches Wort oder falscher Gegenstand – auch dann, wenn das Genannte
       fachlich wirklich existiert. Wer statt des Messzylinders „Reagenzglas"
       schreibt, hat das Gerät nicht erkannt: 0 %.
       Ebenso Rateversuche („A", „xyz"), sinnlose Eingaben und Wörter, die
       erkennbar aus dem Aufgabensatz abgeschrieben wurden.
       ABGRENZUNG: Eine Verwechslung innerhalb derselben Gerätefamilie kann höher
       liegen, wenn sie unter „bekannte_varianten" so hinterlegt ist – etwa
       „Kartuschenbrenner" statt „Gasbrenner" mit 50 %. Steht dort ein Wert, gilt
       er; nur wenn nichts hinterlegt ist, entscheidest du nach dieser Skala.

Zur Grenze 50 gegen 25: Frage dich, ob ein Fachkollege beim Lesen sofort weiß, welches
Wort gemeint war (→ 50) oder ob er nur den Anfang wiedererkennt und raten müsste (→ 25).

WICHTIG: Vergib niemals 0,01 %. Das ist kein Bewertungswert, sondern ein technischer
Eintrag im Aufgaben-Quelltext. Deine unterste Stufe ist 0 %.

═══════════════════════════════════════════════════════
DU RECHNEST KEINE PUNKTE AUS
═══════════════════════════════════════════════════════

Wichtig: Gib ausschließlich Prozentwerte an. Die Punkte berechnet die Erweiterung
selbst — sie kennt den bisherigen Punktestand, die Maximalpunktzahl und die Anzahl
der Lücken und rechnet damit zuverlässiger, als du es im Kopf könntest.

Schreibe also nirgends eine Punktzahl hin. Weder in die Tabelle noch ins JSON.

Zum Verständnis, was mit deinem Prozentwert geschieht: Eine manuelle Bewertung gilt
in Moodle immer für die GANZE Frage. Die Erweiterung rechnet
„bisherige Punkte + (Maximalpunkte ÷ Anzahl Lücken) × dein Prozentwert",
sodass bereits erkannte Teilpunkte erhalten bleiben.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Funde aus, **nach Frage gruppiert**. Schreibe je Frage zuerst eine
Kopfzeile mit dem Satz, dann die Tabelle der Antworten dazu:

**1.1.1-Abwaschen-Aufräumen · Lücke 1:** „Alle Geräte müssen [[L1]] werden."
Hinterlegt: gereinigt · gesäubert · gesäubert werden · gewaschen werden · geputzt · weggeräumt

| Nr | Antwort des Schülers | % | Begründung |
|---|---|---|---|
| 1 | müssen gesäubert werden | 100 | entspricht „gesäubert werden" |
| 2 | Verstaut | 100 | entspricht „weggeräumt" |

- In der Kopfzeile stehen der Satz aus „kontext" und die **vollständige** Liste aus
  „loesungen.richtig" – alle Einträge, nicht die ersten zwei.
- Kommen zu einer Frage mehrere Lücken vor, je Lücke eine eigene Kopfzeile mit Tabelle.
- Bei „art": „kurzantwort" lässt du den Zusatz „· Lücke 1" in der Kopfzeile weg – dort
  ist die Frage selbst die Lücke.
- „Begründung": ein knapper Halbsatz, warum dieser Prozentwert – nicht mehr. Gibt es
  zur Lücke „bekannte_varianten", nenne den Eintrag, an dem du dich orientiert hast,
  zum Beispiel: „wie „Glassmüll" (75)".
- Keine Punktespalte. Die Punkte rechnet die Erweiterung.
- **Als „Nr" verwendest du die Zahl, die im Fund unter „nr" steht** – nicht deine
  eigene Zählung. Nur damit lässt sich eine Zeile im Programm wiederfinden.
- Steht bei einem Fund „kein_zugewinn": true, hat der Versuch schon die volle Punktzahl.
  Bewerte ihn trotzdem ganz normal – die Antwort wird für die Pflege der Aufgabe
  gebraucht –, und schreibe „(bereits voll)" in die Begründung.

Halte danach an und gib NICHTS weiter aus. Schreibe:

„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 50, 7 auf 0.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir ein JSON aus, das du in der
Erweiterung unter „2 · Eintragen" einfügst."

Warte auf die Antwort. Bei Änderungswünschen: Werte anpassen, die geänderten Zeilen
noch einmal zeigen und erneut fragen.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON ZUM EINTRAGEN
═══════════════════════════════════════════════════════

Erst nach „ok" gibst du das JSON aus – nichts davor.

\`\`\`json
{
  "bewertungen": [
    { "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "luecken": [ { "nr": 1, "prozent": 75 } ] }
  ]
}
\`\`\`

- **Ein Eintrag je Versuch, nicht je Lücke.** Hat ein Versuch mehrere unerkannte
  Lücken, kommen sie alle in dessen „luecken"-Liste.
- „qubaid" und „slot" übernimmst du unverändert aus den Daten unten. „nr" ist die
  Lückennummer von dort.
- „prozent" ist eine der sechs Stufen: 100, 90, 75, 50, 25 oder 0.
- Versuche, bei denen alle Lücken 0 % bekommen, lässt du weg – da ändert sich nichts.
- Keine Punktzahlen, kein „neu", kein „markfeld". Das ergänzt die Erweiterung.

Schreibe unter das JSON einen Satz: „Kopiere diesen Block in die Erweiterung, Reiter
„2 · Eintragen" — die Prüfung startet beim Einfügen von selbst." 

[FEEDBACK_BLOCK]
═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

Aufbau:
- „fragen"   – je Frage einmal: unter „art" steht „cloze" (Lückentext, eine oder mehrere
               Lücken im Satz) oder „kurzantwort" (eine Frage, ein Eingabefeld, immer
               genau eine Lücke mit der Nummer 1). Dazu der Aufgabentext mit markierten
               Lücken [[L1]], [[L2]], Maximalpunkte, Anzahl Lücken und unter „loesungen"
               je Lücke der Typ (SA / SAC / MC / …) und die als richtig hinterlegten
               Antworten. Ein „*" in einer hinterlegten Antwort ist ein Platzhalter für
               beliebigen Text. Unter „bekannte_varianten" stehen zusätzlich die schon
               erfassten Falschschreibungen dieser Lücke mit dem Prozentwert, den die
               Lehrkraft ihnen früher selbst gegeben hat.
- „funde"    – je Versuch die Lücken, die Moodle nicht erkannt hat, mit „ist" und „max".
               Unter „kontext" steht der Satz, in dem die Lücke vorkommt – bei
               „kurzantwort" der ganze Fragetext.

${j}`}function re(){return`═══════════════════════════════════════════════════════
MOODLE AI REVIEWER – NACHBEWERTUNG (KOMPAKTER PROMPT)
═══════════════════════════════════════════════════════

Falls du Zugriff auf die Skills „3-moodle-auswertung“ und „2-didaktik-bewertung“ von
A. Spielhoff hast: Wende deren komplette Bewertungslogik an — Begrüßung, die zwei
Pflichtschritte vor dem Bewerten (Satz um die Lücke lesen, gegen ALLE hinterlegten
Antworten prüfen und an „bekannte_varianten“ verankern, Verneinungs-Falle beachten,
zuerst auf reinen Groß-/Kleinschreibfehler prüfen), die 6-Stufen-Skala
(100/90/75/50/25/0) und die Regel, nie 0,01 % zu vergeben.

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (Einstellungen dieser
Erweiterung → Häkchen „Kompakter Prompt“ ausschalten) statt zu raten — ohne die
genauen Regeln (besonders die 90-%-Stufe nur bei Lückentyp SAC, und die
Verneinungs-Falle) sind falsche Bewertungen wahrscheinlich.

Kurzreferenz der Skala, nur zur Orientierung, ersetzt die Skill nicht:
100 = korrekt oder echtes Synonym · 90 = nur Groß-/Kleinschreibung falsch UND
Lückentyp SAC (bei SA: 100) · 75 = ein klarer Tippfehler, Wort erkennbar · 50 =
mehrere Tippfehler, mit Mühe erkennbar · 25 = nur Wortanfang/-stamm erkennbar ·
0 = falsches Wort, Rateversuch oder aus dem Aufgabensatz abgeschrieben.
Punkte NICHT selbst ausrechnen, nur Prozentwerte angeben — das rechnet die Erweiterung.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Funde aus, nach Frage gruppiert, je Lücke eine Kopfzeile mit Satz
und vollständiger Lösungsliste, dann eine Tabelle:

| Nr | Antwort des Schülers | % | Begründung |
|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Fund. Keine Punktespalte. Halte danach an und frage:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 50,
7 auf 0. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON ZUM EINTRAGEN
═══════════════════════════════════════════════════════

Erst nach „ok“ ausgeben:

\`\`\`json
{
  "bewertungen": [
    { "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "luecken": [ { "nr": 1, "prozent": 75 } ] }
  ]
}
\`\`\`

Ein Eintrag je Versuch (nicht je Lücke), „qubaid“/„slot“ unverändert übernehmen,
„prozent“ eine der sechs Stufen. Versuche mit 0 % bei allen Lücken weglassen. Keine
Punktzahlen, kein „neu“, kein „markfeld“. Satz danach: „Kopiere diesen Block in die
Erweiterung, Reiter „2 · Eintragen“ — die Prüfung startet beim Einfügen von selbst.“

[FEEDBACK_BLOCK]
═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: „art“ (cloze/kurzantwort), Aufgabentext mit [[L1]],[[L2]],
„loesungen“ je Lücke mit Typ (SA/SAC/…), „richtig“-Liste, ggf. „bekannte_varianten“
mit Prozentwerten. „funde“ – je Versuch die nicht erkannten Lücken mit „kontext“.

${j}`}function N(e,t){let n=(C.promptOverride||``).trim()||(C.kompaktPrompt?re():M());n=n.replace(`[FEEDBACK_BLOCK]`,t?`═══════════════════════════════════════════════════════
SCHRITT 3 – FEEDBACK FÜR SCHWACHE ANTWORTEN
═══════════════════════════════════════════════════════

In den Daten steht zusätzlich ein Abschnitt \`feedback\`: Versuche mit wenigen Punkten
oder leeren Lücken. Schreibe dafür je Versuch einen kurzen Text.

- Nenne das Lösungswort. Das ist ausdrücklich erwünscht.
- Bei Verwechslungsgefahr ein erklärender Satz dazu, sonst nichts weiter.
- Bei mehreren Lücken getrennt: „Lücke 1: … · Lücke 2: …"
- Sprich die Schülerin oder den Schüler direkt an, sachlich und ohne Floskeln.
- WICHTIG – Anführungszeichen im JSON: Willst du im Text ein Wort hervorheben,
  benutze dafür EINFACHE Anführungszeichen ('so') oder schreibe es ohne
  Anführungszeichen. Gerade doppelte Anführungszeichen ("so") NIEMALS in einem
  JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die JSON-Begrenzung
  und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Gib das Feedback im selben Durchgang wie das Punkte-JSON aus:

\`\`\`json
{
  "kommentare": [
    { "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "text": "Gesucht war das Pistill …" }
  ]
}
\`\`\`

Auch hier nur „qubaid" und „slot" – das Kommentarfeld schlägt die Erweiterung selbst nach.
Gib „bewertungen" und „kommentare" zusammen in EINEM JSON-Block aus.

`:``);let r="```json\n"+JSON.stringify(e,null,1)+"\n```";return n.includes(j)?n.replace(j,r):n+`

`+r}function ie(e,t){if(!e)return null;let n=`[[L`+t+`]]`,r=e.indexOf(n);if(r<0)return null;let i=0;for(let t=r;t>0;t--)if(/[.!?:]/.test(e[t-1])){i=t;break}let a=e.length;for(let t=r+n.length;t<e.length;t++)if(/[.!?]/.test(e[t])){a=t+1;break}let o=e.slice(i,a).trim();if(o.length>260){let e=o.indexOf(n),t=Math.max(0,e-120),r=Math.min(o.length,e+n.length+120);o=(t>0?`… `:``)+o.slice(t,r).trim()+(r<o.length?` …`:``)}return o}function ae(e){if(!e)return null;let t=e.replace(/\s*\[\[L\d+\]\]\s*/g,` `).replace(/\s+/g,` `).trim();return t.length>400?t.slice(0,400).trim()+` …`:t}async function oe(){let e=[...(await d(`${i}?id=${r}&mode=grading&includeauto=1`)).querySelectorAll(`table`)].find(e=>[...e.querySelectorAll(`th`)].some(e=>/Fragename/i.test(e.textContent)));if(!e)throw Error(`Keine Fragen-Tabelle gefunden. Bist du auf der Übersicht der Manuellen Bewertung?`);let t=[...e.querySelectorAll(`thead th`)].map(e=>e.textContent.trim()),n=t.findIndex(e=>/Fragename/i.test(e)),a=t.findIndex(e=>/Automatisch/i.test(e)),o=t.findIndex(e=>/Summe|Gesamt|Total/i.test(e));return o<0&&(o=t.length-1),[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.cells],r=null,i=null;for(let t of[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)).filter(Boolean)){let e=new URL(t,location.href);if(e.searchParams.get(`slot`)){r=e.searchParams.get(`slot`),i=e.searchParams.get(`qid`);break}}return{name:n>=0&&t[n]?t[n].textContent.trim():`(ohne Namen)`,slot:r,qid:i,auto:a>=0&&t[a]&&parseInt(t[a].textContent,10)||0,summe:o>=0&&t[o]&&parseInt(t[o].textContent,10)||null}}).filter(e=>e.slot&&e.qid&&e.auto>0)}function se(e,t,n){return t===null||n===null||!e.length?!1:t>n/e.length*e.filter(e=>e.status!==`incorrect`).length+.005}function ce(e,t,n,r,i){let a=[],s=[],c=0,l=null,u=0,d=null,f=null;return e.forEach(e=>{let p=(e.id.match(/question-(\d+)-/)||[])[1]||null,m=[...e.querySelectorAll(`input[name$="_answer"]`)].filter(v),h=m.map(e=>({nr:_(e.name),antwort:e.value,status:[`correct`,`partiallycorrect`,`incorrect`].find(t=>e.classList.contains(t))||`unbekannt`})),g=m.some(e=>/sub\d+_/.test(e.name))?`cloze`:`kurzantwort`,x=e.querySelector(`input[name$="-mark"]`),S=e.querySelector(`input[name$="-maxmark"]`),C=e.querySelector(`textarea[name$="-comment"]`),ee=(e.querySelector(`.info .state`)||{}).textContent||``,w=/manuell/i.test(ee),T=x?o(x.value):null,E=S?o(S.value):null;l===null&&(l=b(y(e.querySelector(`.formulation`))),u=h.length,d=E,f=g);let D=w||se(h,T,E);le(h).length&&D&&!i&&c++;let O=h.filter(e=>e.status===`incorrect`&&e.antwort.trim()!==``);if(O.length&&(!D||i)&&a.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:p,ist:T,max:E,markfeld:x?x.name:null,luecken:O.map(e=>({nr:e.nr,antwort:e.antwort})),...D?{schon_nachbewertet:!0}:{}}),n){let e=h.some(e=>e.antwort.trim()===``),n=E===null?null:E*r/100;h.length&&(T!==null&&n!==null&&T<=n||e)&&s.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:p,ist:T,max:E,kommentarfeld:C?C.name:null,hat_kommentar:!!(C&&C.value.trim()),luecken:h.map(e=>({nr:e.nr,antwort:e.antwort,status:e.status}))})}}),{funde:a,feedback:s,text:l,anzahlLuecken:u,maxPunkte:d,uebersprungen:c,art:f}}let le=e=>e.filter(e=>e.status===`incorrect`&&e.antwort.trim()!==``);async function ue(e,t,n,r,i){let a=await oe(),s=[],c=[],l={},u=[],d=0,f=0,p=async r=>{try{let e=t?r.summe:r.auto,a=await m(g(r.slot,r.qid,t?`all`:`autograded`),e);e!=null&&a.length<e&&u.push(`${r.name}: nur ${a.length} von ${e} Versuchen geladen — bitte noch einmal auslesen`);let o=ce(a,r,t,n,i);f+=o.uebersprungen||0,o.text&&!l[r.name]&&(l[r.name]={qid:r.qid,art:o.art||`cloze`,max:o.maxPunkte,luecken:o.anzahlLuecken,punkt_pro_luecke:o.maxPunkte&&o.anzahlLuecken?Math.round(o.maxPunkte/o.anzahlLuecken*100)/100:null,text:o.text}),s.push(...o.funde),c.push(...o.feedback)}catch(e){u.push(r.name+`: `+e.message)}d++,e(d,a.length,s.length+c.length)},h=[...a];for(;h.length;)await p(h.shift());let _=e=>e.luecken&&e.luecken[0]||{nr:0,antwort:``},v=(e,t)=>{let n=_(e),r=_(t);return e.frage.localeCompare(t.frage)||(n.nr||0)-(r.nr||0)||String(n.antwort||``).localeCompare(String(r.antwort||``))};s.sort(v),c.sort(v);let y=new Set([...s,...c].map(e=>e.frage));Object.keys(l).forEach(e=>{y.has(e)||delete l[e]}),s.forEach((e,t)=>{e.nr=t+1;let n=o(e.ist),r=o(e.max);n!==null&&r!==null&&n>=r&&(e.kein_zugewinn=!0)}),[...s,...c].forEach(e=>{let t=l[e.frage]||{};(e.luecken||[]).forEach(e=>{let n=t.art===`kurzantwort`?ae(t.text):ie(t.text,e.nr);n&&(e.kontext=n)})});let b=Object.keys(l),x=0;e(a.length,a.length,s.length+c.length,`Lösungen werden geladen …`);let S=[...b];return await Promise.all(Array.from({length:4},async()=>{for(;S.length;){let e=S.shift(),t=await T(l[e].qid),n=E(t),i=(n?A(n):null)||ne(t);if(!i){x++;continue}l[e].loesungen=i.map(e=>{let t={nr:e.nr,typ:e.typ,richtig:e.richtig},n={};return(e.varianten||[]).forEach(e=>{e.prozent>=1&&e.prozent<100&&(n[e.text]=e.prozent)}),Object.keys(n).length&&(t.bekannte_varianten=n),t}),r&&n&&A(n)&&(l[e].cloze_quelltext=n)}})),{zeilen:a.length,funde:s,feedback:c,fragen:l,fehler:u,ohneLoesung:x,mitLoesung:b.length-x,uebersprungen:f}}function de(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&e.type!==`file`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&e.type!==`submit`&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function P(e){return!e||!e.slot||!e.qid?null:g(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``)}function fe(e,t){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(C.kiHinweisText||x).trim();e&&(n+=`<p><em><small>`+s(e)+`</small></em></p>`)}return n}let pe=(e,t)=>{let n=e?e.value.replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,r=t.text.replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim().slice(0,20);return!!(n&&r&&n.includes(r))};async function me(e,t,n,r){let i=g(e.slot,e.qid,`all`),{form:a,felder:s}=await h(i,[...e.marks.map(e=>e.markfeld),...e.comments.map(e=>e.kommentarfeld)]),l=[],u=[],p=[],m=[],_=(e,n)=>{r||t(e,n)};e.marks.forEach(e=>{if(!s.has(e.markfeld)){l.push(e),_(`✗ Punktefeld nicht auf der Seite — ${e.frage}: ${e.antwort||``} (${e.markfeld})`,P(e));return}s.set(e.markfeld,c(e.neu)),p.push(e)}),e.comments.forEach(e=>{if(!s.has(e.kommentarfeld)){u.push(e),_(`✗ Kommentarfeld nicht auf der Seite — ${e.frage} (${e.kommentarfeld})`,P(e));return}s.set(e.kommentarfeld,fe(e,n)),m.push(e)});let v=0;if(p.length||m.length){let e=[...a.elements].find(e=>e.type===`submit`&&e.name);e&&s.set(e.name,e.value);let n=new URL(a.getAttribute(`action`)||i,i).href,r=await fetch(n,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!r.ok)throw Error(`HTTP `+r.status+` beim Speichern`);let h=p.slice(),g=m.slice(),y=new Map;for(let e=0;e<8&&(h.length||g.length);e++){e>0&&await f(500);let n=await d(i);h=h.filter(e=>{let r=n.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`);if(!r)return!0;let i=o(r.value);return y.set(e,i),i!==null&&Math.abs(i-e.neu)<.005?(v++,t(`✓ ${e.frage} — ${e.antwort||``} → ${c(e.neu)}`,P(e)),!1):!0}),g=g.filter(e=>{let r=n.querySelector(`textarea[name="${CSS.escape(e.kommentarfeld)}"]`);return!r||!pe(r,e)||(v++,xe(e.kommentarfeld),t(`💬 ${e.frage} — Feedback eingetragen`),!1)})}h.forEach(e=>{l.push(e);let t=y.has(e)?y.get(e):void 0;_(`✗ ${e.frage} — ${e.antwort||``} — steht auf ${t==null?`keinem Wert`:c(t)} statt ${c(e.neu)}`,P(e))}),g.forEach(e=>{u.push(e),_(`✗ ${e.frage} — Feedback nicht angekommen`,P(e))})}return{ok:v,offenMarks:l,offenKomm:u}}function he(e,t){let n=new Map,r=e=>{let t=e.slot+`|`+e.qid;return n.has(t)||n.set(t,{slot:e.slot,qid:e.qid,marks:[],comments:[]}),n.get(t)};return(e||[]).forEach(e=>r(e).marks.push(e)),(t||[]).forEach(e=>r(e).comments.push(e)),[...n.values()]}async function ge(e,t,n,r){let i=he(e,t),a=0,o=0,s=0;for(let e of i){try{let t=[...e.marks.map(e=>e.markfeld),...e.comments.map(e=>e.kommentarfeld)],{felder:r}=await h(g(e.slot,e.qid,`all`),t);e.marks.forEach(e=>{r.has(e.markfeld)?a++:(o++,n(`✗ Punktefeld fehlt — ${e.frage}: ${e.antwort||``}`,P(e)))}),e.comments.forEach(e=>{r.has(e.kommentarfeld)?a++:(o++,n(`✗ Kommentarfeld fehlt — ${e.frage}`,P(e)))})}catch(t){o+=e.marks.length+e.comments.length,n(`✗ Seite ${(e.marks[0]||e.comments[0]||{}).frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,trocken:!0}}async function _e(e,t,n,r,i){let a=e||[],o=t||[],s=0,c=0;for(let e=1;e<=3&&(a.length||o.length);e++){let t=e===3;e>1&&(r(`↻ Runde ${e}/3: ${a.length+o.length} noch nicht bestätigte Einträge erneut …`),await f(1500));let l=he(a,o);e===1&&(c=l.length);let u=[],d=[],p=0;for(let e of l){try{let i=await me(e,r,n,!t);s+=i.ok,u.push(...i.offenMarks),d.push(...i.offenKomm)}catch(n){u.push(...e.marks),d.push(...e.comments),t&&r(`✗ Frage ${(e.marks[0]||e.comments[0]||{}).frage}: ${n.message}`)}p++,i(p,l.length)}a=u,o=d}return{ok:s,fehler:a.length+o.length,gruppen:c}}function ve(){let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:e?e.textContent.trim():``}}let F=u(`button`,`ce-fab`);F.title=`Moodle AI Reviewer`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`AI Reviewer`,e.className=`ce-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),F.textContent=`🔎`}),F.appendChild(e)}catch{F.textContent=`🔎`}F.title=`Moodle AI Reviewer`,document.body.appendChild(F);let I=u(`div`,`ce-panel ce-hidden`);I.innerHTML=`
    <div class="ce-head">
      <div class="ce-titelblock">
        <span class="ce-title">🔎 AI Reviewer <span class="ce-version"></span></span>
        <span class="ce-untertitel">Unerkannte automatische Antworten nachbewerten</span>
      </div>
      <button class="ce-close" title="Schließen">✕</button>
    </div>
    <div class="ce-tabs">
      <button class="ce-tab ce-aktiv" data-tab="ernte">1 · Auslesen</button>
      <button class="ce-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="ce-tab" data-tab="opt">⚙</button>
    </div>

    <div class="ce-body" data-panel="ernte">
      <p class="ce-meta"></p>
      <label class="ce-check"><input type="checkbox" class="ce-fb">
        Auch schwache Antworten fürs Feedback sammeln</label>
      <label class="ce-check"><input type="checkbox" class="ce-bereits">
        Auch schon nachbewertete Versuche noch einmal vorlegen</label>
      <label class="ce-label ce-fbschwelle ce-hidden">Schwelle (% der erreichbaren Punkte)
        <input type="text" class="ce-schwelle" value="50">
      </label>
      <p class="ce-schwelleinfo ce-fbschwelle ce-hidden"></p>
      <button class="ce-go">Test durchsuchen</button>
      <div class="ce-progress ce-hidden"><div class="ce-bar"></div><span class="ce-ptext"></span></div>
      <div class="ce-result ce-hidden">
        <p class="ce-summary"></p>
        <button class="ce-copy">📋 Prompt + Daten kopieren</button>
        <button class="ce-copy2 ce-zweit">📋 nur JSON</button>
        <p class="ce-groesse"></p>
        <div class="ce-list"></div>
      </div>
      <p class="ce-error ce-hidden"></p>
    </div>

    <div class="ce-body ce-hidden" data-panel="eintrag">
      <p class="ce-hinweis">Hier die Punkte-JSON von Claude einfügen. Das Eintragen entspricht
      genau dem, was passiert, wenn du den Wert selbst ins Punktefeld tippst und speicherst.</p>
      <textarea class="ce-json" rows="6" placeholder='{ "punkte": [ … ] }'></textarea>
      <label class="ce-check"><input type="checkbox" class="ce-ki" checked>
        KI-Hinweis ans Feedback anhängen</label>
      <p class="ce-kivorschau"></p>
      <button class="ce-pruef ce-hidden">🔍 Prüfen</button>
      <p class="ce-pinfo ce-hidden"></p>
      <div class="ce-progress2 ce-hidden"><div class="ce-bar2"></div><span class="ce-ptext2"></span></div>
      <p class="ce-abschluss ce-hidden"></p>
      <div class="ce-log ce-hidden"></div>
      <div class="ce-schreibknoepfe ce-hidden">
        <button class="ce-alle">Alle eintragen</button>
      </div>
    </div>

    <div class="ce-body ce-hidden" data-panel="opt">
      <label class="ce-check"><input type="checkbox" class="ce-voll">
        Vollständigen Aufgaben-Quelltext mitgeben</label>
      <p class="ce-hinweis">Normalerweise bekommt die KI je Lücke nur die als richtig
      hinterlegten Antworten – das genügt für die Bewertung. Mit dieser Option geht
      zusätzlich der komplette Quelltext jeder Aufgabe mit, also auch alle bereits
      erfassten Fehlervarianten samt Prozentwerten.
      <strong>Das verbraucht sehr viel mehr KI-Ressourcen</strong> – rund 2.000 Zeichen
      je Aufgabe. Nur einschalten, wenn du die vorhandenen Varianten wirklich brauchst.
      Wirkt nur bei Lückentext-Aufgaben; Kurzantwort-Fragen haben keinen Quelltext.</p>

      <label class="ce-check"><input type="checkbox" class="ce-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <p class="ce-hinweis">Verweist für die Bewertungslogik auf die Skills
      „3-moodle-auswertung“ und „2-didaktik-bewertung“ statt sie komplett auszuschreiben
      – spart pro Aufruf mehrere Tausend Zeichen. <strong>Nur einschalten, wenn du sicher
      bist, dass die verwendete KI diese Skills wirklich kennt</strong> (z. B. dein eigener
      Claude-Cowork-Zugang). Andere Lehrkräfte oder andere KI-Systeme lassen dieses
      Häkchen aus – die bekommen automatisch den vollständigen Prompt.</p>

      <label class="ce-label">Eigener Prompt (leer = Standard)
        <textarea class="ce-prompt" rows="8" placeholder="Leer lassen, um den mitgelieferten Prompt zu verwenden."></textarea>
      </label>
      <p class="ce-hinweis">Der Platzhalter <code>[MOODLE_AI_REVIEWER_DATEN]</code> wird
      durch die Daten aus Moodle ersetzt, <code>[FEEDBACK_BLOCK]</code> durch die
      Feedback-Anweisungen. Fehlen sie, werden die Daten hinten angehängt.</p>
      <label class="ce-label">KI-Hinweis unter dem Feedback
        <textarea class="ce-kitext" rows="3"></textarea>
      </label>
      <p class="ce-hinweis">Dieser Satz wird unter jedes Feedback gesetzt – kursiv und
      klein –, solange in Tab 2 das Häkchen gesetzt ist. Leer lassen setzt beim
      Speichern den Standardsatz wieder ein.</p>

      <button class="ce-optsave">Speichern</button>
      <button class="ce-optvorlage ce-zweit">Standard einfügen</button>
      <button class="ce-optreset ce-zweit">Zurücksetzen</button>
      <p class="ce-optinfo ce-hidden"></p>
    </div>`,document.body.appendChild(I);let L=e=>I.querySelector(e);L(`.ce-version`).textContent=e;let R=ve();L(`.ce-meta`).textContent=[R.kurs,R.test].filter(Boolean).join(` · `)||`Manuelle Bewertung`;function z(){let e=o(L(`.ce-schwelle`).value);return e===null||e<=0?S.feedbackSchwelleProzent:Math.min(100,e)}function B(){let e=L(`.ce-schwelleinfo`);if(!e)return;let t=z();e.textContent=`${l(t)} % — bei einer 2-Punkte-Frage also alles bis ${c(2*t/100)} Punkte, bei einer 1-Punkt-Frage bis ${c(t/100)}. Leere Lücken kommen immer mit, unabhängig von diesem Wert.`}function V(){let e=L(`.ce-fb`).checked;I.querySelectorAll(`.ce-fbschwelle`).forEach(t=>t.classList.toggle(`ce-hidden`,!e)),B()}L(`.ce-fb`).addEventListener(`change`,async()=>{V(),await w({feedbackSammeln:L(`.ce-fb`).checked})}),L(`.ce-schwelle`).addEventListener(`change`,async()=>{B(),await w({feedbackSchwelleProzent:z()})}),L(`.ce-schwelle`).addEventListener(`input`,B),ee().then(()=>{L(`.ce-voll`).checked=!!C.vollstaendig,L(`.ce-kompakt`).checked=!!C.kompaktPrompt,L(`.ce-prompt`).value=C.promptOverride||``,L(`.ce-kitext`).value=C.kiHinweisText||x,L(`.ce-fb`).checked=C.feedbackSammeln!==!1,L(`.ce-schwelle`).value=l(C.feedbackSchwelleProzent??S.feedbackSchwelleProzent),V(),W()});let H=`reviewerErnte_`+r;function U(){try{t.storage.local.set({[H]:K})}catch{}}try{t.storage.local.get([H],e=>{let t=e&&e[H];if(t&&!K){K=t;let e=L(`.ce-meta`);e&&(e.textContent+=` · ${(t.funde||[]).length} Funde aus einem früheren Durchlauf geladen`)}})}catch{}function W(){let e=L(`.ce-kivorschau`);if(!e)return;let t=(C.kiHinweisText||x).trim();if(!L(`.ce-ki`).checked||!t){e.classList.add(`ce-hidden`);return}e.classList.remove(`ce-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}function G(e){let t=L(`.ce-optinfo`);t.textContent=e,t.classList.remove(`ce-hidden`),setTimeout(()=>t.classList.add(`ce-hidden`),3e3)}L(`.ce-optsave`).addEventListener(`click`,async()=>{await w({vollstaendig:L(`.ce-voll`).checked,kompaktPrompt:L(`.ce-kompakt`).checked,promptOverride:L(`.ce-prompt`).value.trim(),kiHinweisText:L(`.ce-kitext`).value.trim()||x}),L(`.ce-kitext`).value=C.kiHinweisText,W(),G(`Gespeichert ✓`)}),L(`.ce-optvorlage`).addEventListener(`click`,()=>{L(`.ce-prompt`).value=M(),G(`Standard eingefügt – zum Übernehmen auf Speichern klicken.`)}),L(`.ce-optreset`).addEventListener(`click`,async()=>{await w({...S}),L(`.ce-voll`).checked=!1,L(`.ce-kompakt`).checked=!1,L(`.ce-prompt`).value=``,L(`.ce-kitext`).value=x,L(`.ce-fb`).checked=S.feedbackSammeln,L(`.ce-schwelle`).value=l(S.feedbackSchwelleProzent),V(),W(),G(`Auf Standard zurückgesetzt.`)}),L(`.ce-ki`).addEventListener(`change`,W),F.addEventListener(`click`,()=>I.classList.toggle(`ce-hidden`)),L(`.ce-close`).addEventListener(`click`,()=>I.classList.add(`ce-hidden`)),I.querySelectorAll(`.ce-tab`).forEach(e=>{e.addEventListener(`click`,t=>{t.isTrusted&&Y!==void 0&&Y&&(clearInterval(Y),Y=null,L(`.ce-copy`).textContent=`📋 Prompt + Daten kopieren`,L(`.ce-copy2`).textContent=`📋 nur JSON`),I.querySelectorAll(`.ce-tab`).forEach(t=>t.classList.toggle(`ce-aktiv`,t===e)),I.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`ce-hidden`,t.dataset.panel!==e.dataset.tab))})});let K=null,q=!1;L(`.ce-go`).addEventListener(`click`,async()=>{let e=L(`.ce-go`);e.disabled=!0,L(`.ce-error`).classList.add(`ce-hidden`),L(`.ce-result`).classList.add(`ce-hidden`),L(`.ce-progress`).classList.remove(`ce-hidden`);try{let e=L(`.ce-fb`).checked,t=z(),n=await ue((e,t,n,r)=>{L(`.ce-bar`).style.width=Math.round(e/t*100)+`%`,L(`.ce-ptext`).textContent=r||`${e} / ${t} Fragen · ${n} Funde`},e,t,C.vollstaendig,L(`.ce-bereits`).checked);K={meta:{test:R.test,kurs:R.kurs,cmid:r,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.zeilen,funde:n.funde.length,loesungen_geladen:n.mitLoesung,loesungen_fehlend:n.ohneLoesung,bereits_nachbewertet_uebersprungen:n.uebersprungen},fragen:n.fragen,funde:n.funde},e&&(K.meta.feedback_schwelle_prozent=t,K.meta.feedback_kandidaten=n.feedback.length,K.feedback=n.feedback),q=e,U(),L(`.ce-summary`).textContent=`${n.funde.length} unerkannte Antworten in ${Object.keys(n.fragen).length} Fragen (von ${n.zeilen} geprüften Fragen)`+(e?` · ${n.feedback.length} Kandidaten fürs Feedback.`:`.`)+(n.uebersprungen?` ${n.uebersprungen} bereits nachbewertete Versuche übersprungen.`:``),n.uebersprungen&&!n.funde.length&&(L(`.ce-summary`).textContent=`Nichts zu tun: alle ${n.uebersprungen} gefundenen Antworten wurden bereits von Hand nachbewertet. Zum erneuten Vorlegen oben das Häkchen setzen.`);let i=N(K,e);L(`.ce-groesse`).textContent=`Prompt: rund ${Math.round(i.length/1e3)}.000 Zeichen`+(C.vollstaendig?` (mit vollständigem Quelltext)`:``)+(n.ohneLoesung?` · Achtung: zu ${n.ohneLoesung} Frage(n) konnten die hinterlegten Antworten nicht geladen werden.`:``),n.ohneLoesung&&n.mitLoesung===0&&(L(`.ce-error`).textContent=`Zu keiner Frage konnten die hinterlegten Antworten geladen werden – vermutlich fehlt das Recht, Fragen zu bearbeiten. Die KI kann dann nicht beurteilen, was gesucht war. Gib in dem Fall die Fragen-XML zusätzlich in den Chat.`,L(`.ce-error`).classList.remove(`ce-hidden`));let a=L(`.ce-list`);a.innerHTML=``;let o=null;n.funde.forEach(e=>{e.frage!==o&&(a.appendChild(u(`div`,`ce-qname`,e.frage)),o=e.frage);let t=u(`a`,`ce-row`);t.href=g(e.slot,e.qid,`all`)+`#question-`+e.qubaid+`-`+e.slot,t.target=`_blank`,t.rel=`noopener`,t.title=`Diesen Versuch in Moodle öffnen`,t.appendChild(u(`span`,`ce-nr`,`#`+e.nr));let n=e.luecken&&e.luecken[0]||{nr:`?`,antwort:``};t.appendChild(u(`span`,`ce-gap`,`L`+n.nr)),t.appendChild(u(`span`,`ce-ans`,n.antwort)),t.appendChild(u(`span`,`ce-pts`,e.kein_zugewinn?`voll`:`${e.ist} / ${e.max}`)),a.appendChild(t)}),n.fehler.length&&(L(`.ce-error`).textContent=`⚠ `+n.fehler.join(` · `),L(`.ce-error`).classList.remove(`ce-hidden`)),L(`.ce-result`).classList.remove(`ce-hidden`)}catch(e){L(`.ce-error`).textContent=`Fehler: `+e.message,L(`.ce-error`).classList.remove(`ce-hidden`)}finally{L(`.ce-progress`).classList.add(`ce-hidden`),e.disabled=!1}});async function J(e){try{await navigator.clipboard.writeText(e)}catch{let t=u(`textarea`,`ce-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}function ye(e){return`Für diese Versuche fehlt noch ein Feedback-Text. Gib mir bitte ein JSON nur mit „kommentare" aus — genau einen Eintrag je Versuch, auch wenn mehrere zur selben Frage gehören:

`+e.map(e=>{let t=(e.luecken||[]).map(e=>`Lücke ${e.nr}: ${String(e.antwort||``).trim()?`„`+e.antwort+`"`:`(leer gelassen)`}`).join(` · `);return`- ${e.frage} · qubaid ${e.qubaid} · slot ${e.slot} · ${t}`}).join(`
`)}let Y=null;function be(e){let t=I.querySelector(`.ce-tab[data-tab="`+e+`"]`);t&&t.click()}function X(e,t){let n=L(e);clearInterval(Y);let r=3;n.textContent=`✓ Kopiert — weiter in ${r} s`,Y=setInterval(()=>{if(r--,r>0){n.textContent=`✓ Kopiert — weiter in ${r} s`;return}clearInterval(Y),Y=null,n.textContent=t,be(`eintrag`),L(`.ce-json`).focus()},1e3)}L(`.ce-copy`).addEventListener(`click`,async()=>{K&&(await J(N(K,q)),X(`.ce-copy`,`📋 Prompt + Daten kopieren`))}),L(`.ce-copy2`).addEventListener(`click`,async()=>{K&&(await J("```json\n"+JSON.stringify(K,null,1)+"\n```"),X(`.ce-copy2`,`📋 nur JSON`))});let Z=null,Q=null;function xe(e){if(!K||!Array.isArray(K.feedback))return;let t=K.feedback.find(t=>t.kommentarfeld===e);t&&!t.hat_kommentar&&(t.hat_kommentar=!0,U())}function $(){if(!K)return null;let e=new Map,t=new Map;return(K.funde||[]).forEach(t=>e.set(t.qubaid+`|`+t.slot,t)),(K.feedback||[]).forEach(e=>t.set(e.qubaid+`|`+e.slot,e)),{funde:e,rueckmeldungen:t,fragen:K.fragen||{}}}let Se=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Tab 1 „Test durchsuchen" laufen lassen — daraus stammen Punktestand, Lückenzahl und Feldnamen.`;function Ce(e){let t=$();if(!t)throw Error(Se);let n=[];return e.forEach((e,r)=>{let i=r+1;if(e.qubaid==null||e.slot==null)throw Error(`Bewertung ${i}: "qubaid" oder "slot" fehlt.`);let a=t.funde.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Bewertung ${i}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keinen ausgelesenen Fund. Stammt das JSON zu diesem Durchlauf?`);let s=(t.fragen[a.frage]||{}).luecken||(a.luecken||[]).length||1,l=o(a.max),u=o(a.ist);if(l===null||u===null)throw Error(`Bewertung ${i}: Punktestand des Versuchs unbekannt.`);let d=l/s,f=0,p=[];(e.luecken||[]).forEach((e,t)=>{let n=Number(e.prozent);if(isNaN(n)||n<0||n>100)throw Error(`Bewertung ${i}, Lücke ${t+1}: Prozentwert „${e.prozent}" ist ungültig.`);p.push(`L${e.nr==null?t+1:e.nr}: ${n} %`),f+=d*n/100});let m=Math.min(l,Math.round((u+f)*100)/100);m<=u||n.push({frage:a.frage,qid:a.qid,slot:String(a.slot),qubaid:String(e.qubaid),markfeld:a.markfeld,neu:m,antwort:(a.luecken||[]).map(e=>e.antwort).join(` / `),prozenttext:p.join(` · `),rechnung:`${c(u)} → ${c(m)} von ${c(l)}`})}),n}function we(e){if(!e.length)return[];let t=$();return e.map((e,n)=>{if(e.kommentarfeld&&e.qid)return e;if(!t)throw Error(Se);if(e.qubaid==null||e.slot==null)throw Error(`Kommentar ${n+1}: "qubaid" oder "slot" fehlt.`);let r=String(e.qubaid)+`|`+String(e.slot),i=t.rueckmeldungen.get(r)||t.funde.get(r);if(!i)throw Error(`Kommentar ${n+1}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesenen Daten.`);if(!i.kommentarfeld)throw Error(`Kommentar ${n+1}: für diesen Versuch wurde kein Kommentarfeld ausgelesen. Beim Auslesen bitte „Auch schwache Antworten fürs Feedback sammeln" ankreuzen.`);return{frage:i.frage,qid:i.qid,slot:String(i.slot),qubaid:String(e.qubaid||i.qubaid||``),kommentarfeld:i.kommentarfeld,text:e.text,leereLuecken:(i.luecken||[]).filter(e=>!String(e.antwort||``).trim()).map(e=>e.nr)}})}L(`.ce-pruef`).addEventListener(`click`,()=>{let e=L(`.ce-pinfo`);e.classList.remove(`ce-hidden`),L(`.ce-schreibknoepfe`).classList.add(`ce-hidden`),L(`.ce-abschluss`).classList.add(`ce-hidden`),L(`.ce-log`).classList.add(`ce-hidden`);let t=I.querySelector(`.ce-fehlend`);t&&t.remove(),Z=null,Q=null;try{let t=L(`.ce-json`).value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen. Ist beim Kopieren versehentlich etwas anderes in der Zwischenablage gelandet?`);let n=JSON.parse(t),r=n.kommentare||[],i,a=!1;Array.isArray(n.bewertungen)?(a=!0,i=Ce(n.bewertungen)):(i=Array.isArray(n)?n:n.punkte||[],i.forEach((e,t)=>{if([`qid`,`slot`,`markfeld`,`neu`].forEach(n=>{if(e[n]===void 0||e[n]===null)throw Error(`Punkte-Eintrag ${t+1}: "${n}" fehlt.`)}),isNaN(Number(e.neu)))throw Error(`Punkte-Eintrag ${t+1}: "neu" ist keine Zahl.`)}));let o=we(r),s=a?(n.bewertungen||[]).length-i.length:0,c=o.filter(e=>{let t=Array.isArray(e.leereLuecken)?e.leereLuecken:[];return t.length>1&&t.some(t=>!RegExp(`Lücke(?:n)?\\s*`+t+`(?!\\d)`,`i`).test(e.text))}).length,l=$(),d=[];if(l&&o.length){let e=new Set(o.map(e=>e.kommentarfeld));l.rueckmeldungen.forEach(t=>{t.kommentarfeld&&!t.hat_kommentar&&!e.has(t.kommentarfeld)&&d.push(t)})}if(!i.length&&!o.length)throw Error(`Weder "bewertungen"/"punkte" noch "kommentare" mit Einträgen gefunden.`);Z=i,Q=o;let f=new Set([...i,...o].map(e=>e.slot+`|`+e.qid)).size,p=[];i.length&&p.push(`${i.length} Bewertungen`),o.length&&p.push(`${o.length} Feedback-Texte`),e.className=`ce-pinfo ce-ok`;let m=[];if(a&&m.push(`Die Punkte wurden aus den Prozentwerten berechnet.`),s>0&&m.push(`${s} Eintrag/Einträge ohne Punktzuwachs (alle Lücken 0 %) wurden weggelassen — sie würden in Moodle nichts ändern.`),d.length&&m.push(`⚠ ${d.length} von ${l?l.rueckmeldungen.size:0} Feedback-Kandidaten haben keinen Text bekommen — Liste unten. Eintragen kannst du trotzdem.`),c>0&&m.push(`⚠ ${c} Feedback-Text nennt nur eine Lücke, obwohl der Versuch mehrere leere Lücken hat — nicht jede leere Lücke wird mit ihrer Nummer genannt. Bitte vor dem Eintragen ansehen.`),e.textContent=`✓ ${p.join(` und `)} auf ${f} Fragenseiten — bereit. `+m.join(` `),a&&i.length){let t=u(`div`,`ce-rechnung`);i.forEach(e=>{let n=u(`a`,`ce-logzeile ce-vorschauzeile`),r=P(e);r&&(n.href=r,n.target=`_blank`,n.rel=`noopener`),n.title=`Diesen Versuch in Moodle öffnen`,n.appendChild(u(`span`,`ce-vfrage`,e.frage)),n.appendChild(u(`span`,`ce-vans`,`„`+(e.antwort||`—`)+`"`)),n.appendChild(u(`span`,`ce-vpkt`,e.rechnung)),n.appendChild(u(`span`,`ce-vproz`,e.prozenttext||``)),t.appendChild(n)});let n=I.querySelector(`.ce-rechnung`);n&&n.remove(),e.after(t)}let h=I.querySelector(`.ce-fehlend`);if(h&&h.remove(),d.length){let t=u(`details`,`ce-fehlend`);t.appendChild(u(`summary`,`ce-fehlendkopf`,`${d.length} Versuch(e) ohne Feedback-Text — anzeigen`)),t.appendChild(u(`div`,`ce-logzeile`,`Für diese Versuche steht im eingefügten JSON kein Feedback. „Nachforderung kopieren" legt eine fertige Bitte an die KI in die Zwischenablage — im KI-Chat einfügen, das neue JSON hier einfügen, eintragen.`)),d.forEach(e=>{let n=u(`a`,`ce-logzeile`),r=P(e);r&&(n.href=r,n.target=`_blank`,n.rel=`noopener`);let i=(e.luecken||[]).map(e=>`L${e.nr}: ${String(e.antwort||``).trim()?`„`+e.antwort+`"`:`(leer)`}`).join(` · `);n.textContent=`${e.frage} — ${i}`,t.appendChild(n)});let n=u(`button`,`ce-nachfordern`,`📋 Nachforderung kopieren`);t.appendChild(n),n.addEventListener(`click`,async()=>{await J(ye(d)),n.textContent=`✓ kopiert — im Chat einfügen`,setTimeout(()=>n.textContent=`📋 Nachforderung kopieren`,3e3)}),e.after(t)}L(`.ce-schreibknoepfe`).classList.remove(`ce-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`ce-pinfo ce-error`,e.textContent=`Fehler: `+t.message}});async function Te(e){if(!Z&&!Q)return;let t=L(`.ce-log`),n=L(`.ce-abschluss`);t.innerHTML=``,t.classList.remove(`ce-hidden`),n.classList.add(`ce-hidden`),L(`.ce-progress2`).classList.remove(`ce-hidden`),L(`.ce-alle`).disabled=!0,L(`.ce-progress2`).scrollIntoView({block:`nearest`});let r=(e,n)=>{let r=u(n?`a`:`div`,`ce-logzeile`,e);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`,r.title=`Diesen Versuch in Moodle öffnen`),(e.startsWith(`✗`)||e.startsWith(`⚠`))&&r.classList.add(`ce-logfehler`),t.appendChild(r),t.scrollTop=t.scrollHeight},i=(e,t)=>{L(`.ce-bar2`).style.width=Math.round(e/t*100)+`%`,L(`.ce-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await ge(Z,Q,r,i):await _e(Z,Q,L(`.ce-ki`).checked,r,i),o=u(`div`,`ce-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`);if(t.prepend(o),!a.ok&&!a.fehler&&r(`Nichts zu tun.`),n.classList.remove(`ce-hidden`),a.fehler>0)n.className=`ce-abschluss ce-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen auf der Bewertungsseite. Trag noch nichts ein — stammt das JSON zu diesem Auslese-Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach und prüfe sie in Moodle, bevor du weitermachst.`;else if(n.className=`ce-abschluss ce-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,!e){let e=3,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),I.classList.add(`ce-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);I.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message),n.classList.remove(`ce-hidden`),n.className=`ce-abschluss ce-abfehler`,n.textContent=`⚠ Abgebrochen: `+e.message}finally{L(`.ce-progress2`).classList.add(`ce-hidden`),L(`.ce-alle`).disabled=!1}}L(`.ce-alle`).addEventListener(`click`,()=>Te(!1)),L(`.ce-json`).addEventListener(`paste`,()=>setTimeout(()=>L(`.ce-pruef`).click(),0));let Ee=null;L(`.ce-json`).addEventListener(`input`,()=>{clearTimeout(Ee),Ee=setTimeout(()=>{L(`.ce-json`).value.trim()&&L(`.ce-pruef`).click()},800)})}var r=e({matches:[`*://*/*mod/quiz/report.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){n()}}),i={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},a=class e extends Event{static EVENT_NAME=o(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function o(e){return`${t?.runtime?.id}:content:${e}`}var s=typeof globalThis.navigation?.addEventListener==`function`;function c(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),s?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new a(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new a(e,t)),t=e)},1e3))}}}var l=class e{static SCRIPT_STARTED_MESSAGE_TYPE=o(`wxt:content-script-started`);id;abortController;locationWatcher=c(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?o(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),i.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=r;return await e(new l(`content`,t))}catch(e){throw u.error(`The content script "content" crashed on startup!`,e),e}})()})();