(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=[100,90,75,50,25,0],r=[`Tippfehler`,`Vertauschung`,`phonetisch`,`Groß-/Kleinschreibung`,`Getrennt-/Zusammenschreibung`,`Auslassung`,`Doppelung`,`Endung`,`Wortstamm`,`Synonym`,`Wortverwechslung`,`Zahlenverwechslung`,`Rateversuch`],i=e=>String(e??``).replace(/\s+/g,` `).trim(),a=e=>i(e).toLowerCase();function o(e,t){if(e=String(e),t=String(t),e===t)return 0;if(!e.length)return t.length;if(!t.length)return e.length;let n=Array.from({length:t.length+1},(e,t)=>t);for(let r=1;r<=e.length;r++){let i=[r];for(let a=1;a<=t.length;a++)i[a]=Math.min(n[a]+1,i[a-1]+1,n[a-1]+(e[r-1]===t[a-1]?0:1));n=i}return n[t.length]}function s(e){let t=Number(e);return isNaN(t)?null:n.reduce((e,n)=>Math.abs(n-t)<Math.abs(e-t)?n:e,0)}var c=e=>String(e||``).toUpperCase()===`SAC`;function l(e,t){let n=i(e);if(!n||!t)return null;let r=c(t.typ),o=t.bekannte_varianten||{};for(let[e,t]of Object.entries(o))if(r?i(e)===n:a(e)===a(n))return{prozent:Number(t),regel:`anker`,anker:e,grund:`schon entschieden: '${e}' (${t})`};for(let e of t.richtig||[])if(!String(e).includes(`*`)&&i(e)!==n&&a(e)===a(n))return{prozent:r?90:100,regel:`grossklein`,kategorie:`Groß-/Kleinschreibung`,grund:r?`nur Groß-/Kleinschreibung (SAC → 90)`:`nur Groß-/Kleinschreibung (SA → 100)`};return null}function u(e,t,n){let r=a(e),i=null;for(let[e,s]of Object.entries(n||{})){if(Number(s)!==Number(t))continue;let n=a(e),c=o(r,n);c<=Math.max(2,Math.floor(.3*Math.max(r.length,n.length)))&&(!i||c<i.d)&&(i={text:e,prozent:Number(s),d:c})}return i}function d(e,t,r,i){let a=i&&i.prozent!=null&&i.prozent!==``?Number(i.prozent):null;if(r)return a!=null&&a!==r.prozent?{unklar:!0,vorschlag:r.prozent,quelle:`Regel`,gruende:[`Regel sagt ${r.prozent}, KI sagt ${a}`]}:{unklar:!1,vorschlag:r.prozent,quelle:`Regel`,gruende:[]};if(a==null||isNaN(a))return{unklar:!0,vorschlag:null,quelle:`KI`,gruende:[`kein KI-Vorschlag`]};let o=[],c=a;n.includes(c)||(o.push(`kein Skalenwert (${a})`),c=s(c));let l=u(e,c,(t||{}).bekannte_varianten);return(c===25||c===50)&&o.push(`Vorschlag ${c}`),l||o.push(c===100?`100 ohne Anker – Synonym?`:`kein passender Anker`),{unklar:o.length>0,vorschlag:c,quelle:`KI`,anker:l,gruende:o}}var f=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r},p=(e,t)=>String(e)+`|`+String(t);function m(e){let t=e&&e.fragen||{},n=new Map;return(e&&e.funde||[]).forEach(e=>{let r=(t[e.frage]||{}).loesungen||[];(e.luecken||[]).forEach(t=>{let i=l(t.antwort,r.find(e=>e.nr===t.nr));i&&n.set(p(e.qubaid,e.slot)+`|`+t.nr,i)})}),n}function h(e){let t=m(e),n=[];(e.funde||[]).forEach(e=>{let r=(e.luecken||[]).filter(n=>!t.has(p(e.qubaid,e.slot)+`|`+n.nr));r.length&&n.push({...e,luecken:r})});let r=new Set([...n,...e.feedback||[]].map(e=>e.frage)),i={};Object.keys(e.fragen||{}).forEach(t=>{r.has(t)&&(i[t]=e.fragen[t])});let a={...e.meta||{},funde:n.length,von_regel_entschieden:t.size};return{daten:{...e,meta:a,fragen:i,funde:n},regelAnzahl:t.size}}function g(e,t){let n=e.fragen||{},r=new Map,i=new Map;(t||[]).forEach(e=>{(e.luecken||[]).forEach(t=>{e.qubaid!=null&&e.slot!=null&&r.set(p(e.qubaid,e.slot)+`|`+t.nr,t),e.nr!=null&&i.set(String(e.nr)+`|`+t.nr,t)})});let a=[];return(e.funde||[]).forEach(e=>{let t=(n[e.frage]||{}).loesungen||[];(e.luecken||[]).forEach(n=>{let o=t.find(e=>e.nr===n.nr)||null,s=l(n.antwort,o),c=r.get(p(e.qubaid,e.slot)+`|`+n.nr)||i.get(String(e.nr)+`|`+n.nr)||null,u=d(n.antwort,o,s,c);a.push({fund:e,frage:e.frage,qid:e.qid,qubaid:String(e.qubaid),slot:String(e.slot),fundNr:e.nr,lueckeNr:n.nr,antwort:n.antwort,kontext:n.kontext||``,typ:o&&o.typ||``,muster:o&&o.richtig||[],bekannt:o&&o.bekannte_varianten||{},ausCloze:!(!s||s.regel!==`anker`||(o&&o.aus_sammlung||[]).includes(s.anker)),regel:s,ki:c,unklar:u.unklar,gruende:u.gruende,anker:u.anker||null,vorschlag:u.vorschlag,entscheidung:u.vorschlag,quelle:u.quelle===`Regel`?`Regel`:`KI`,grund:s&&s.grund||c&&c.grund||``,kategorie:s&&s.kategorie||c&&c.kategorie||``,angesehen:!1})})}),a}function _(e){let t=new Map;return e.forEach(e=>{if(e.entscheidung==null)return;let n=p(e.qubaid,e.slot);t.has(n)||t.set(n,{frage:e.frage,qubaid:e.qubaid,slot:e.slot,luecken:[]}),t.get(n).luecken.push({nr:e.lueckeNr,prozent:e.entscheidung})}),[...t.values()]}function v(e,t){let n=f(`p`,`ce-vkontext`);return String(e||``).split(RegExp(`(\\[\\[L`+t+`\\]\\])`)).forEach(e=>{e===`[[L${t}]]`?n.appendChild(f(`mark`,`ce-vluecke`,`Lücke ${t}`)):n.appendChild(document.createTextNode(e.replace(/\[\[L\d+\]\]/g,`…`)))}),n}function y(e,t){let r=f(`div`,`ce-stufen`),i=n.map(n=>{let i=f(`button`,`ce-stufe`,String(n));return i.type=`button`,n===90&&String(e.typ).toUpperCase()!==`SAC`&&(i.title=`90 % nur bei Lückentyp SAC`),e.vorschlag===n&&i.classList.add(`ce-stufe-vorschlag`),i.addEventListener(`click`,()=>{t(n),a()}),r.appendChild(i),[n,i]});function a(){i.forEach(([t,n])=>n.classList.toggle(`ce-stufe-an`,e.entscheidung===t))}return a(),r}function b(e,t,n){e.innerHTML=``,e.classList.remove(`ce-hidden`);let r=t.filter(e=>e.unklar),a=t.filter(e=>!e.unklar),o=f(`p`,`ce-vkopf`);o.textContent=`${t.length} Fälle${n.titel?` · `+n.titel:``}: ${r.length} unklar, ${a.length} sicher.`+(r.length?` Bitte die unklaren entscheiden – der Vorschlag ist vorausgewählt.`:``),e.appendChild(o);let s=f(`p`,`ce-vzaehler`),c=()=>{let e=r.filter(e=>e.entscheidung==null).length,t=r.filter(e=>e.angesehen).length;s.textContent=e?`⚠ ${e} unklare Fälle haben noch keine Stufe.`:`${t} von ${r.length} unklaren Fällen angeklickt.`,u.disabled=e>0},l=(e,t)=>{let r=f(`div`,`ce-vkarte`+(t?` ce-vkompakt`:``)),a=f(n.link&&n.link(e)?`a`:`div`,`ce-vober`),o=n.link&&n.link(e);o&&(a.href=o,a.target=`_blank`,a.rel=`noopener`,a.title=`Versuch in Moodle öffnen`),a.textContent=`#${e.fundNr} · ${e.frage} · Lücke ${e.lueckeNr}${e.typ?` (`+e.typ+`)`:``}`+(e.fund&&e.fund.kein_zugewinn?` · bereits voll`:``),r.appendChild(a),!t&&e.kontext&&r.appendChild(v(e.kontext,e.lueckeNr)),!t&&e.muster.length&&r.appendChild(f(`p`,`ce-vmuster`,`Muster: `+e.muster.join(` · `)));let s=f(`p`,`ce-vantwort`);s.appendChild(f(`span`,`ce-vlabel`,`Antwort: `)),s.appendChild(f(`strong`,null,i(e.antwort)?`„`+e.antwort+`“`:`(leer)`)),r.appendChild(s);let l=f(`p`,`ce-vki`),u=e.regel?`Regel`:`KI`;if(l.textContent=e.vorschlag==null?`KI: kein Vorschlag`:`${u}: ${e.vorschlag} %${e.grund?` – `+e.grund:``}`+(e.regel&&e.ki&&e.ki.prozent!=null?` · KI: ${e.ki.prozent} %`:``)+(e.anker?` · Anker: '${e.anker.text}' (${e.anker.prozent})`:``),r.appendChild(l),e.gruende.length&&r.appendChild(f(`p`,`ce-vgrund`,`Unklar: `+e.gruende.join(` · `))),!t){let t=Object.entries(e.bekannt);t.length&&r.appendChild(f(`p`,`ce-vbekannt`,`Bekannt: `+t.slice(0,8).map(([e,t])=>`'${e}' ${t}`).join(` · `)+(t.length>8?` …`:``)))}return r.appendChild(y(e,t=>{e.entscheidung=t,e.angesehen=!0,e.quelle=`Lehrkraft`,r.classList.add(`ce-ventschieden`),c()})),r};if(r.length){let t=f(`div`,`ce-vunklar`);r.forEach(e=>t.appendChild(l(e,!1))),e.appendChild(t)}else e.appendChild(f(`p`,`ce-vok`,`✓ Keine unklaren Fälle.`));if(a.length){let t=f(`details`,`ce-vsicher`);t.appendChild(f(`summary`,null,`${a.length} sichere Fälle – anzeigen und ggf. ändern`)),a.forEach(e=>t.appendChild(l(e,!0))),e.appendChild(t)}e.appendChild(s);let u=f(`button`,`ce-vweiter`,`Weiter: Zusammenfassung →`);u.type=`button`,u.addEventListener(`click`,()=>{u.textContent=`… wird berechnet`;try{n.onWeiter(t)}finally{u.textContent=`Weiter: Zusammenfassung →`}}),e.appendChild(u),c()}var x=[`Quelle`,`Stand`,`Kategorie`,`Fragename`,`qid`,`Lücke`,`Lückentyp`,`Musterlösung`,`Schülerantwort`,`Bewertung %`,`Fehlerkategorie`,`Anzahl`,`Status`,`Bemerkung`],S=`reviewerFehlersammlung`,C={Regel:1,KI:1,Lehrkraft:2},w=(e,t,n)=>`${e}|${t}|${i(n).toLowerCase()}`;async function T(){try{let e=await t.storage.local.get([S]);return e&&e[S]||{}}catch{return{}}}async function E(e){try{return await t.storage.local.set({[S]:e}),!0}catch{return!1}}var ee=e=>(String(e).match(/^(\d+\.\d+)/)||[])[1]||``,D=e=>Number(e)===0?`0,01`:String(Number(e)).replace(`.`,`,`),O=e=>{let t=parseFloat(String(e).replace(`,`,`.`));return isNaN(t)?null:t<1?0:t};async function te(e,t){let n=await T(),r=0,a=0,o=[t.test,t.kurs?`(`+t.kurs+`)`:``].filter(Boolean).join(` `);return e.forEach(e=>{if(e.entscheidung==null||!i(e.antwort)||e.regel&&e.regel.regel===`anker`&&e.ausCloze)return;let s=w(e.qid,e.lueckeNr,e.antwort),c=e.qubaid+`|`+e.slot,l=e.quelle||`KI`,u=l===`Lehrkraft`?`Lehrkraft`:`${l}${e.grund?`: `+e.grund:``}`,d=n[s];if(!d){n[s]={Quelle:o,Stand:t.datum,Kategorie:ee(e.frage),Fragename:e.frage,qid:String(e.qid),Lücke:String(e.lueckeNr),Lückentyp:e.typ||``,Musterlösung:(e.muster||[])[0]||``,Schülerantwort:i(e.antwort),"Bewertung %":D(e.entscheidung),Fehlerkategorie:e.kategorie||``,Anzahl:`1`,Status:`offen`,Bemerkung:u,_quelle:l,_versuche:[c]},r++;return}let f=d._versuche||[];f.includes(c)||(f.push(c),d._versuche=f,d.Anzahl=String((parseInt(d.Anzahl,10)||0)+1)),(C[l]||1)>=(C[d._quelle]||1)&&((d[`Bewertung %`]!==D(e.entscheidung)||d._quelle!==l)&&a++,d[`Bewertung %`]=D(e.entscheidung),d._quelle=l,d.Bemerkung=u,d.Stand=t.datum,e.kategorie&&(d.Fehlerkategorie=e.kategorie))}),{ok:await E(n),neu:r,geaendert:a,gesamt:Object.keys(n).length}}function ne(e){let t={};return Object.values(e||{}).forEach(e=>{if(e.Status&&e.Status!==`offen`)return;let n=O(e[`Bewertung %`]);if(n==null)return;let r=e.qid+`|`+e.Lücke;(t[r]=t[r]||{})[e.Schülerantwort]=n}),t}var k=e=>{let t=String(e??``);return/[;"\n\r]/.test(t)?`"`+t.replace(/"/g,`""`)+`"`:t};function re(e){let t=i(e.Schülerantwort),n=i(e.Musterlösung);return e.Fehlerkategorie===`Rateversuch`||/^[%=]/.test(t)||!/[\p{L}\p{N}]/u.test(t)||t.length===1&&/\p{L}/u.test(t)&&n.length>3}function ie(e){let t=Object.values(e||{}),n=t.filter(e=>!re(e)),r=n.sort((e,t)=>String(e.Fragename).localeCompare(String(t.Fragename))||Number(e.Lücke)-Number(t.Lücke)).map(e=>x.map(t=>k(e[t])).join(`;`));return{csv:`﻿`+[x.join(`;`),...r].join(`\r
`)+`\r
`,n:n.length,uebersprungen:t.length-n.length}}async function ae(e){let t=await T(),n=0;return Object.entries(t).forEach(([r,a])=>{let o=e[a.qid+`|`+a.Lücke];if(!o)return;let s=String(a.Lückentyp).toUpperCase()===`SAC`,c=i(a.Schülerantwort);o.some(e=>s?i(e)===c:i(e).toLowerCase()===c.toLowerCase())&&(delete t[r],n++)}),n&&await E(t),n}function A(e){let t=String(e).replace(/^﻿/,``),n=[],r=``,i=[],a=!1;for(let e=0;e<t.length;e++){let o=t[e];a?o===`"`&&t[e+1]===`"`?(r+=`"`,e++):o===`"`?a=!1:r+=o:o===`"`?a=!0:o===`;`?(i.push(r),r=``):o===`
`||o===`\r`?(o===`\r`&&t[e+1]===`
`&&e++,i.push(r),r=``,i.some(e=>e!==``)&&n.push(i),i=[]):r+=o}return i.push(r),i.some(e=>e!==``)&&n.push(i),n}async function oe(e){let t=A(e);if(!t.length)throw Error(`Die Datei ist leer.`);let n=t[0].map(e=>e.trim()),r=[`qid`,`Lücke`,`Schülerantwort`,`Bewertung %`].filter(e=>!n.includes(e));if(r.length)throw Error(`Spalten fehlen: `+r.join(`, `)+` — ist das eine Fehlersammlung.csv?`);let i=await T(),a=0;return t.slice(1).forEach(e=>{let t={};if(n.forEach((n,r)=>{t[n]=(e[r]||``).trim()}),!t.qid||!t.Schülerantwort)return;let r=w(t.qid,t.Lücke,t.Schülerantwort);if(i[r])return;let o=/^(KI|Regel)\b/.test(t.Bemerkung||``)?`KI`:`Lehrkraft`;i[r]={...Object.fromEntries(x.map(e=>[e,t[e]||``])),Anzahl:t.Anzahl||`1`,Status:t.Status||`offen`,_quelle:o,_versuche:[]},a++}),await E(i),{neu:a,gesamt:Object.keys(i).length}}async function se(){return E({})}async function j(e,n){try{return await t.runtime.sendMessage({kanal:`ki-direkt`,typ:e,...n})||{ok:!1,fehler:`intern`,meldung:`keine Antwort vom Hintergrund`}}catch(e){return{ok:!1,fehler:`kontext`,meldung:String(e&&e.message||e)}}}function ce(e,t){let n=t&&t.basis||`die eingestellte Adresse`;switch(e&&e.fehler){case`netz`:return`Keine Verbindung zu ${n}. Läuft der KI-Server (z. B. Bionic, LM Studio, Ollama)?`;case`zeit`:return`Die KI hat nicht rechtzeitig geantwortet. Wartezeit unter „Erweitert" erhöhen oder kleinere Pakete wählen.`;case`berechtigung`:return`Die Erweiterung darf ${n} noch nicht ansprechen. In den KI-Einstellungen „Verbindung testen" klicken und die Berechtigung erlauben.`;case`adresse`:return`Keine Adresse eingestellt.`;case`zusatz`:return`Die Zusatzparameter sind kein gültiges JSON.`;case`kontext`:return`Die Erweiterung wurde neu geladen – bitte diese Seite neu laden.`;case`http`:return e.status===401||e.status===403?`Zugang abgelehnt – API-Schlüssel prüfen.`:e.status===404?`Adresse oder Modell nicht gefunden (404). Endet die Adresse auf /v1?`:e.status===429?`Zu viele Anfragen oder Guthaben aufgebraucht (429).`:`Der Server meldet Fehler ${e.status}: ${e.meldung||``}`;default:return`Unbekannter Fehler: `+(e&&e.meldung||``)}}function le(e){let t=String(e||``).replace(/<think>[\s\S]*?<\/think>/gi,``).trim();t=t.replace(/^```(?:json)?\s*/i,``).replace(/\s*```\s*$/,``).trim();try{return JSON.parse(t)}catch{}let n=t.indexOf(`{`),r=t.lastIndexOf(`}`);if(n>=0&&r>n)return JSON.parse(t.slice(n,r+1));throw Error(`Antwort enthielt kein JSON.`)}var ue=`Du bewertest Schülerantworten in Lücken eines Chemie-Kurztests gegen die hinterlegten richtigen Antworten. Vergib je Lücke genau einen Prozentwert:
100 = richtig oder gleichwertiges Synonym, andere gültige Wortform
90 = NUR Groß-/Kleinschreibung falsch und Typ SAC (bei Typ SA: 100)
75 = ein einzelner klarer Tippfehler, Wort eindeutig erkennbar
50 = mehrere Tippfehler, Wort noch mit Mühe erkennbar
25 = nur Wortstamm/Wortanfang erkennbar
0 = falsches Wort oder anderer Gegenstand (auch wenn fachlich existent), Rateversuch, sinnlos, aus dem Satz abgeschrieben
Regeln: Vergleiche mit ALLEN richtigen Antworten. Beurteile das Wort für DIESE Lücke im Satz, nicht ob der Satz fachlich stimmt (Verneinungen!). Sind bekannte Varianten angegeben, verankere dich daran: eine ähnlich fehlerhafte Antwort bekommt denselben Wert. Nie 0,01.
Antworte NUR mit JSON: {"bewertungen":[{"id":1,"prozent":75,"grund":"höchstens 12 Wörter","kategorie":"Tippfehler"}]} – für jede id genau ein Eintrag. kategorie aus: ${r.join(`, `)}. In Texten keine doppelten Anführungszeichen.`,M=`Du schreibst kurze Rückmeldungen an Schülerinnen und Schüler zu einem Chemie-Kurztest. Je Versuch EIN Text:
- Nenne das gesuchte Lösungswort (ausdrücklich erwünscht), bei mehreren Lücken getrennt: Lücke 1: … · Lücke 2: …
- Jede leere Lücke mit ihrer Nummer nennen.
- Bei Verwechslungsgefahr ein erklärender Satz, sonst nichts weiter. Direkt ansprechen (du), sachlich, ohne Floskeln.
Antworte NUR mit JSON: {"kommentare":[{"id":1,"text":"…"}]} – für jede id genau ein Eintrag. Im Text keine doppelten Anführungszeichen, nimm 'einfache'.`,N=e=>`"`+String(e??``).replace(/"/g,`'`)+`"`;function P(e,t){let n=Math.max(1,Number(t)||20),r=[];for(let t=0;t<e.length;t+=n)r.push(e.slice(t,t+n));return r}async function de(e,t,n,r){let i=[{role:`system`,content:t},{role:`user`,content:n}],a=await j(`anfrage`,{cfg:e,messages:i,maxTokens:r});for(let t=0;t<2;t++){if(a.ok)try{return{ok:!0,json:le(a.text),usage:a.usage}}catch{if(t===1)return{ok:!1,meldung:`Antwort war kein gültiges JSON.`}}else if([`berechtigung`,`adresse`,`zusatz`,`kontext`].includes(a.fehler)||a.status===401||a.status===403)return{ok:!1,meldung:ce(a,e),abbruch:!0};else if(t===1)return{ok:!1,meldung:ce(a,e)};a=await j(`anfrage`,{cfg:e,messages:i,maxTokens:r})}return{ok:!1,meldung:`unbekannt`}}var F=(e,t)=>{t&&(e.ein+=Number(t.prompt_tokens||t.input_tokens||0),e.aus+=Number(t.completion_tokens||t.output_tokens||0))};async function fe(e,t,n){let r=Date.now(),i={ein:0,aus:0},a=[],o=e.fragen||{},s=[];(e.funde||[]).forEach(e=>(e.luecken||[]).forEach(t=>{let n=((o[e.frage]||{}).loesungen||[]).find(e=>e.nr===t.nr)||{};s.push({id:s.length+1,f:e,l:t,loes:n})}));let c=new Map,l=P(s,t.paket);for(let e=0;e<l.length;e++){n(`Bewerte Paket ${e+1} von ${l.length} (${s.length} Lücken) …`,e/(l.length+1));let r=await de(t,ue,l[e].map(e=>{let t=Object.entries(e.loes.bekannte_varianten||{}).slice(0,8).map(([e,t])=>`${N(e)}=${t}`).join(`, `);return`id ${e.id}: Typ ${e.loes.typ||`?`} | Satz: ${N(e.l.kontext||``)} | Lücke ${e.l.nr} | richtig: ${(e.loes.richtig||[]).map(N).join(` / `)||`(unbekannt)`} | Schülerantwort: ${N(e.l.antwort)}`+(t?` | bekannte Varianten: ${t}`:``)}).join(`
`),60*l[e].length+200);if(!r.ok){if(a.push(`Paket ${e+1}: ${r.meldung}`),r.abbruch)break;continue}F(i,r.usage),(r.json.bewertungen||[]).forEach(e=>c.set(Number(e.id),e))}let u=new Map;s.forEach(e=>{let t=c.get(e.id);if(!t)return;let n=e.f.qubaid+`|`+e.f.slot;u.has(n)||u.set(n,{nr:e.f.nr,frage:e.f.frage,qubaid:e.f.qubaid,slot:e.f.slot,luecken:[]}),u.get(n).luecken.push({nr:e.l.nr,prozent:t.prozent,grund:t.grund||``,kategorie:t.kategorie||``})});let d=[],f=e.feedback||[];if(f.length&&!a.some(e=>/Zugang|Berechtigung|neu laden/.test(e))){let e=P(f.map((e,t)=>({id:t+1,f:e})),Math.max(5,Math.round((t.paket||20)/2)));for(let r=0;r<e.length;r++){n(`Schreibe Feedback, Paket ${r+1} von ${e.length} …`,(l.length+r/e.length)/(l.length+1));let s=await de(t,M,e[r].map(({id:e,f:t})=>{let n=(o[t.frage]||{}).loesungen||[];return`id ${e}: ${(t.luecken||[]).map(e=>{let t=(n.find(t=>t.nr===e.nr)||{}).richtig||[];return`Lücke ${e.nr}: Antwort ${String(e.antwort||``).trim()?N(e.antwort):`(leer)`}, gesucht ${t.slice(0,3).map(N).join(` / `)||`?`}, Satz ${N(e.kontext||``)}`}).join(` ; `)}`}).join(`
`),120*e[r].length+200);if(!s.ok){if(a.push(`Feedback-Paket ${r+1}: ${s.meldung}`),s.abbruch)break;continue}F(i,s.usage);let c=new Map((s.json.kommentare||[]).map(e=>[Number(e.id),e.text]));e[r].forEach(({id:e,f:t})=>{let n=c.get(e);n&&d.push({frage:t.frage,qubaid:t.qubaid,slot:t.slot,text:String(n)})})}}return n(`Fertig.`,1),{bewertungen:[...u.values()],kommentare:d,fehler:a,tokens:i,sekunden:Math.round((Date.now()-r)/1e3)}}var pe=`#dc2626`,I=`#eab308`,me=`#16a34a`,he=(e,t,n)=>`#`+[1,3,5].map(r=>Math.round(parseInt(e.substr(r,2),16)*(1-n)+parseInt(t.substr(r,2),16)*n).toString(16).padStart(2,`0`)).join(``),ge=e=>e<35?pe:e<45?he(pe,I,(e-35)/10):e<=55?I:e<65?he(I,me,(e-55)/10):me,_e=(e,t=1)=>Number(e).toFixed(t).replace(`.`,`,`),ve=e=>String(Math.round(e*100)/100).replace(`.`,`,`);function ye(e,t){let n=t=>e.every(e=>Math.abs(e/t-Math.round(e/t))<1e-6);for(let e of[1,.5,.25])if(n(e)&&t/e<=22)return e;for(let e of[.5,1,2,2.5,5,10,20,25,50])if(t/e<=22)return e;return Math.ceil(t/20)}function be(e,t,n={}){let r=e.filter(e=>Number.isFinite(e)),i=r.length;if(!i||!(t>0))return{svg:``,n:0};let a=n.schritt||ye(r,t),o=[];for(let e=0;e<=t+1e-9;e+=a)o.push(Math.round(e*1e3)/1e3);o[o.length-1]<t-1e-9&&o.push(t);let s=o.map(()=>0);r.forEach(e=>{let t=0;o.forEach((n,r)=>{Math.abs(n-e)<Math.abs(o[t]-e)&&(t=r)}),s[t]++});let c=r.reduce((e,t)=>e+t,0)/i,l=Math.sqrt(r.reduce((e,t)=>e+(t-c)**2,0)/i),u=n.breite||400,d=n.hoehe||210,f=(u-30-10)/o.length,p=l>0?i*a/(l*Math.sqrt(2*Math.PI)):0,m=Math.max(2,...s,Math.ceil(p)),h=e=>30+f*(o.length-1-e)+f/2,g=e=>12+(d-12-40)*(1-e/m),_=m<=6?1:m<=12?2:5,v=o.length>12?2:1,y=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${u} ${d}" width="100%" role="img" aria-label="Punkteverteilung" font-family="system-ui, sans-serif" font-size="11">`;for(let e=0;e<=m;e+=_)y+=`<line x1="30" x2="${u-10}" y1="${g(e)}" y2="${g(e)}" stroke="#e2e8f0"/><text x="25" y="${g(e)+4}" text-anchor="end" fill="#64748b">${e}</text>`;if(o.forEach((e,n)=>{let r=Math.min(f*.5,26);s[n]&&(y+=`<rect x="${h(n)-r/2}" y="${g(s[n])}" width="${r}" height="${g(0)-g(s[n])}" rx="2" fill="${ge(e/t*100)}"><title>${ve(e)} P: ${s[n]}</title></rect>`),(n%v===0||n===o.length-1)&&(y+=`<text x="${h(n)}" y="${d-40+14}" text-anchor="middle" fill="#334155">${ve(e)}</text>`)}),l>0){let e=``;for(let n=0;n<=120;n++){let r=-a/2+(t+a)*n/120,s=i*a/(l*Math.sqrt(2*Math.PI))*Math.exp(-((r-c)**2)/(2*l**2)),u=30+f*((o[o.length-1]-r)/a)+f/2;e+=(n?`L`:`M`)+u.toFixed(1)+`,`+g(s).toFixed(1)}y+=`<path d="${e}" fill="none" stroke="#1e293b" stroke-width="1.6"/>`}return y+=`<line x1="30" x2="${u-10}" y1="${g(0)}" y2="${g(0)}" stroke="#94a3b8"/>`,y+=`<text x="${(30+u-10)/2}" y="${d-6}" text-anchor="middle" fill="#64748b">Punkte (max ${ve(t)}) · Ø ${_e(c)} · Streuung ${_e(l)} · ${i} Versuche</text></svg>`,{svg:y,mittel:c,streuung:l,n:i,schritt:a}}var xe=`kiDirekt`,L=`{"reasoning_effort":"none","chat_template_kwargs":{"enable_thinking":false}}`,Se={an:!1,vorlage:`bionic`,basis:{bionic:{name:`Bionic (lokal)`,basis:`http://127.0.0.1:1235/v1`,zusatz:L},lmstudio:{name:`LM Studio (lokal)`,basis:`http://127.0.0.1:1234/v1`,zusatz:L},ollama:{name:`Ollama (lokal)`,basis:`http://127.0.0.1:11434/v1`,zusatz:L},openai:{name:`OpenAI (Cloud, API-Schlüssel)`,basis:`https://api.openai.com/v1`,zusatz:`{}`},anthropic:{name:`Anthropic Claude (Cloud, API-Schlüssel)`,basis:`https://api.anthropic.com/v1`,zusatz:`{}`},eigene:{name:`Eigene Adresse`,basis:``,zusatz:`{}`}}.bionic.basis,modell:``,schluessel:``,wartezeit:120,paket:20,zusatz:L};async function Ce(){try{let e=await t.storage.local.get([xe]);return{...Se,...e&&e.kiDirekt||{}}}catch{return{...Se}}}function we(e){return String(e||``).trim().replace(/\/+$/,``).replace(/\/chat\/completions$/,``)}function Te(e){try{let t=new URL(we(e)).hostname;return t===`localhost`||t===`127.0.0.1`||t===`[::1]`||t.endsWith(`.local`)||/^10\./.test(t)||/^192\.168\./.test(t)||/^172\.(1[6-9]|2\d|3[01])\./.test(t)}catch{return!1}}function Ee(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``,n=new URLSearchParams(location.search);if(n.get(`mode`)!==`grading`)return;let i=n.get(`id`);if(!i||n.get(`includeauto`)!==`1`)return;let a=location.origin+location.pathname,o=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),s=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},c=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),l=e=>Number(e).toFixed(2).replace(`.`,`,`),u=e=>String(Number(e)).replace(`.`,`,`),d=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function f(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let p=e=>new Promise(t=>setTimeout(t,e)),v=e=>((e.id||``).match(/^question-(\d+)-\d+$/)||[])[1]||e.id;async function y(e,t){let n=new Set,r=[],i=0;for(let a=0;a<8;a++){a>0&&await p(500);let o=await f(e),s=0;if(o.querySelectorAll(`div.que`).forEach(e=>{let t=v(e);t&&!n.has(t)&&(n.add(t),r.push(e),s++)}),t!=null&&r.length>=t||(i=s?0:i+1,t==null&&i>=2))break}return r}async function x(e,t){let n=null,r=new URLSearchParams,i=new Set;for(let a=0;a<8;a++){a>0&&await p(500);let o=(await f(e)).querySelector(`form#manualgradingform`);if(!o)throw Error(`Bewertungsformular nicht gefunden`);n=o;let s=Ee(o);if([...new Set(s.keys())].forEach(e=>{e===`qubaids`?s.get(e).split(`,`).map(e=>e.trim()).filter(Boolean).forEach(e=>i.add(e)):r.has(e)||s.getAll(e).forEach(t=>r.append(e,t))}),t.every(e=>r.has(e)))break}return i.size&&r.set(`qubaids`,[...i].join(`,`)),{form:n,felder:r}}let S=(e,t,n)=>`${a}?id=${i}&mode=grading&slot=${e}&qid=${t}&grade=${n||`autograded`}&includeauto=1&qperpage=100`,C=e=>{let t=String(e||``).match(/sub(\d+)_/);return t?parseInt(t[1],10):1},w=e=>!e.type||e.type===`text`||e.type===`number`;function E(e){let t=``;return e&&e.childNodes.forEach(e=>{e.nodeType===3?t+=e.textContent:e.nodeType===1&&(e.tagName===`INPUT`&&/_answer$/.test(e.name||``)&&w(e)?t+=`[[L`+C(e.name)+`]]`:[`INPUT`,`SELECT`,`TEXTAREA`,`SCRIPT`,`STYLE`].includes(e.tagName)||(e.tagName===`IMG`?t+=`[BILD]`:t+=E(e)))}),t}let ee=e=>e.replace(/\s+/g,` `).replace(/^\s*Fragetext\s*/i,``).replace(/Antwort\s+\d+\s+Frage\s+\d+\s*(?=\[\[L)/g,``).trim(),D=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,O={vollstaendig:!1,promptOverride:``,kiHinweisText:D,feedbackSammeln:!0,feedbackSchwelleProzent:50,kompaktPrompt:!1,feedbackVorher:!1},k={...O};function re(){return new Promise(e=>{try{t.storage.local.get([`reviewerOptionen`],t=>{k={...O,...t&&t.reviewerOptionen?t.reviewerOptionen:{}},e(k)})}catch{e(k)}})}function A(e){return k={...k,...e},new Promise(e=>{try{t.storage.local.set({reviewerOptionen:k},e)}catch{e()}})}async function le(e){try{let t=await f(`${o}/question/bank/editquestion/question.php?id=${e}&cmid=${i}`);return t.querySelector(`textarea[name="questiontext[text]"]`)?t:null}catch{return null}}let ue=e=>{let t=e&&e.querySelector(`textarea[name="questiontext[text]"]`);return t&&(t.value||t.textContent)||null};function M(e){if(!e)return null;if(e.tagName===`SELECT`){let t=e.querySelector(`option[selected]`)||e.selectedOptions&&e.selectedOptions[0]||e.querySelector(`option`);return t?t.value:null}return e.value==null?e.getAttribute(`value`):e.value}let N=e=>{let t=parseFloat(String(M(e)==null?``:M(e)).replace(`,`,`.`));return isNaN(t)?0:t};function P(e,t){let n=[],r=``;for(let i=0;i<e.length;i++){if(e[i]===`\\`){r+=e[i]+(e[i+1]||``),i++;continue}if(e[i]===t){n.push(r),r=``;continue}r+=e[i]}return n.push(r),n}let de=e=>e.replace(/\\([{}~=#\\])/g,`$1`);function F(e){if(!e)return null;let t=new DOMParser().parseFromString(e,`text/html`).body.textContent||``,n=[],r=0,i=-1;for(let e=0;e<t.length;e++){if(t[e]===`\\`){e++;continue}t[e]===`{`?(r===0&&(i=e),r++):t[e]===`}`&&(r--,r===0&&i>=0&&(n.push(t.slice(i+1,e)),i=-1))}return n.length?n.map((e,t)=>{let n=e.match(/^\s*(\d*)\s*:\s*([A-Za-z_]+)\s*:\s*([\s\S]*)$/);if(!n)return{nr:t+1,typ:`?`,richtig:[],varianten:[]};let r=n[2].toUpperCase(),i=P(n[3],`~`).map(e=>{let t=e,n=0,r=t.match(/^%(-?[\d.]+)%/);r?(n=parseFloat(r[1]),t=t.slice(r[0].length)):t.startsWith(`=`)&&(n=100,t=t.slice(1));let i=de(P(t,`#`)[0]||``).trim();return{prozent:n,text:i}}).filter(e=>e.text!==``);return{nr:t+1,typ:r,richtig:i.filter(e=>e.prozent===100).map(e=>e.text),varianten:i}}):null}function pe(e){if(!e)return null;let t=[];return e.querySelectorAll(`[name^="answer["]`).forEach(n=>{let r=(n.getAttribute(`name`).match(/^answer\[(\d+)\]$/)||[])[1];if(r==null)return;let i=String(M(n)||``).trim();i&&i!==`*`&&t.push({prozent:Math.round(N(e.querySelector(`[name="fraction[${r}]"]`))*100),text:i})}),t.length?[{nr:1,typ:N(e.querySelector(`[name="usecase"]`))===1?`SAC`:`SA`,richtig:t.filter(e=>e.prozent===100).map(e=>e.text),varianten:t}]:null}let I=`[MOODLE_AI_REVIEWER_DATEN]`;function me(){return`═══════════════════════════════════════════════════════
MOODLE AI REVIEWER – NACHBEWERTUNG FREI EINGETIPPTER ANTWORTEN
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:

1. „Willkommen beim Moodle AI Reviewer."
2. „Ich sehe die Schülerantworten durch, die Moodle bei den Lückentext- und Kurzantwort-Aufgaben nicht erkannt hat, und schlage dir für jede eine Bewertung vor. Entscheiden tust du."
3. „Der „Moodle AI Reviewer" wurde von A. Spielhoff entwickelt und ist unter der Lizenz CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen, solange du ihn nennst."

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Moodle prüft frei eingetippte Antworten – in Lückentexten genauso wie in
Kurzantwort-Fragen –, indem es den Text mit hinterlegten Antwortvarianten vergleicht.
Was nicht hinterlegt ist, bekommt 0 Punkte – auch wenn es inhaltlich richtig ist. Ein
Tippfehler, eine andere Wortform oder ein Synonym genügen dafür.

Du bekommst unten genau diese Fälle: Antworten, bei denen KEINE hinterlegte Variante
gegriffen hat, obwohl der Schüler etwas geschrieben hat. Zu jeder Frage steht dabei,
welche Antwort eigentlich gesucht war.

═══════════════════════════════════════════════════════
BEVOR DU BEWERTEST – ZWEI PFLICHTSCHRITTE JE ANTWORT
═══════════════════════════════════════════════════════

**1. Lies den Satz um die Lücke.**
Bei jeder Lücke steht unter „kontext" der Satz, in dem sie vorkommt, mit [[L1]], [[L2]]
an der Stelle der Lücke. Ein einzelnes Wort lässt sich oft nicht beurteilen: Derselbe
Begriff kann in der einen Lücke genau richtig und in der anderen völlig falsch sein.
Beispiel: In „Alle Geräte müssen [[L1]] und an ihren Platz [[L2]] werden" passt
„verstaut" zu L2, aber nicht zu L1 – und umgekehrt „gespült" zu L1, aber nicht zu L2.
Prüfe also immer, welche Tätigkeit oder welcher Gegenstand an DIESER Stelle gemeint ist.

Bei Fragen mit „art": „kurzantwort" gibt es keine Lücke im Satz: die ganze Frage ist die
Aufgabe, das Eingabefeld steht darunter. Dort findest du unter „kontext" den kompletten
Fragetext, und es gibt genau eine Lücke mit der Nummer 1. Alles andere – Skala,
Pflichtschritte, Ausgabeformat – gilt unverändert.

**2. Vergleiche mit ALLEN hinterlegten Antworten, nicht nur mit der ersten.**
Unter „loesungen" steht je Lücke die vollständige Liste der Antworten, die als richtig
gelten – oft fünf oder mehr. Kürze diese Liste niemals ab und beurteile niemals gegen
eine verkürzte Fassung. Passt die Schülerantwort zu IRGENDEINER davon, ist sie richtig.

Steht bei einer Lücke zusätzlich „bekannte_varianten", findest du dort bereits erfasste
Falschschreibungen mit dem Prozentwert, den die Lehrkraft ihnen gegeben hat. Das ist
deine wichtigste Orientierung. **Verankere jede Bewertung an einem dieser Einträge**
und nenne ihn in der Begründung. Steht „Glassmüll" auf 75, kann „Glassmülleimer" nicht
plötzlich 25 bekommen; steht „Müll" auf 25, gilt das auch für „Mülleimer". Erfinde die
Skala nicht neu, wenn die Lehrkraft für dieselbe Lücke bereits entschieden hat.

**3. Beurteile das WORT, nicht die Handlung.**
Du prüfst nicht, ob das im Satz Beschriebene fachlich vernünftig ist. Du prüfst nur, ob
das eingetippte Wort zu dem passt, was für DIESE Lücke hinterlegt ist.

Das ist wichtig, weil viele Sätze verneint sind. Beispiel:
„Chemikalienreste werden NICHT in die Vorratsgefäße [[L1]], sondern entsprechend der
Anleitung [[L2]]." Für L1 ist „zurückgegeben" hinterlegt – obwohl der Satz sagt, dass
man das gerade nicht tun soll. Eine Schülerantwort „zurückgebracht" ist hier also
**100 % richtig**, denn sie trifft genau den gesuchten Begriff.

Fällt dir auf, dass die hinterlegte Lösung dem Sinn des Satzes zu widersprechen scheint,
ist fast immer eine Verneinung im Spiel. Halte dich dann an die hinterlegte Liste.

**4. Prüfe ZUERST auf einen reinen Groß-/Kleinschreibfehler.**
Bevor du irgendetwas anderes überlegst: Unterscheidet sich die Antwort von einem
hinterlegten Eintrag ausschließlich in der Groß-/Kleinschreibung? Dann ist sie bei
Lückentyp SAC genau 90 % und bei Lückentyp SA genau 100 %. Diese Prüfung kommt vor
allen Überlegungen zu Synonymen, Tippfehlern und Inhalt.
„Oben" bei hinterlegtem „oben" und Typ SAC ist 90 – nicht 100 und nicht 75.

Diese vier Schritte sind die häufigste Fehlerquelle. Nimm sie ernst.

═══════════════════════════════════════════════════════
BEWERTUNGSSKALA – VERBINDLICH
═══════════════════════════════════════════════════════

Vergib je Lücke genau einen dieser sechs Werte. Keine Zwischenwerte.

100 %  Richtig geschrieben, oder ein echtes gleichwertiges Synonym.
       Beispiele: „Bunsenbrenner" statt „Gasbrenner"; „Stößel" statt „Pistill";
       eine andere gültige Wortform desselben Begriffs.

 90 %  Wort vollständig korrekt, NUR die Groß-/Kleinschreibung stimmt nicht.
       Beispiel: „pistill" statt „Pistill".
       ACHTUNG – diese Stufe gilt AUSSCHLIESSLICH bei Lücken vom Typ SAC
       (unterscheidet Groß-/Kleinschreibung). Bei Lücken vom Typ SA ignoriert
       Moodle die Groß-/Kleinschreibung ohnehin; dort ist so eine Antwort 100 %.
       Der Lückentyp steht unten bei jeder Lücke.
       Vergib 90 % NIEMALS für „inhaltlich fast richtig" – dafür sind 50/25/0 da.

 75 %  Ein einzelner klarer Tippfehler – ein Buchstabe vertauscht, doppelt oder
       fehlend. Das Wort bleibt eindeutig erkennbar.
       Beispiele: „Mistill" statt „Pistill"; „Bechergals" statt „Becherglas".

 50 %  Mehrere Tippfehler oder eine stärkere Verschreibung. Das Wort ist noch mit
       Mühe erkennbar, man muss aber überlegen.
       Beispiele: „Bechaglas" statt „Becherglas"; „Erlemayer" statt „Erlenmeyerkolben".

 25 %  Nur Wortstamm oder Wortanfang erkennbar, starke Verkürzung.
       Beispiele: „Becher" statt „Becherglas"; „Erlen" statt „Erlenmeyerkolben".

  0 %  Falsches Wort oder falscher Gegenstand – auch dann, wenn das Genannte
       fachlich wirklich existiert. Wer statt des Messzylinders „Reagenzglas"
       schreibt, hat das Gerät nicht erkannt: 0 %.
       Ebenso Rateversuche („A", „xyz"), sinnlose Eingaben und Wörter, die
       erkennbar aus dem Aufgabensatz abgeschrieben wurden.
       ABGRENZUNG: Eine Verwechslung innerhalb derselben Gerätefamilie kann höher
       liegen, wenn sie unter „bekannte_varianten" so hinterlegt ist – etwa
       „Kartuschenbrenner" statt „Gasbrenner" mit 50 %. Steht dort ein Wert, gilt
       er; nur wenn nichts hinterlegt ist, entscheidest du nach dieser Skala.

Zur Grenze 50 gegen 25: Frage dich, ob ein Fachkollege beim Lesen sofort weiß, welches
Wort gemeint war (→ 50) oder ob er nur den Anfang wiedererkennt und raten müsste (→ 25).

WICHTIG: Vergib niemals 0,01 %. Das ist kein Bewertungswert, sondern ein technischer
Eintrag im Aufgaben-Quelltext. Deine unterste Stufe ist 0 %.

═══════════════════════════════════════════════════════
DU RECHNEST KEINE PUNKTE AUS
═══════════════════════════════════════════════════════

Wichtig: Gib ausschließlich Prozentwerte an. Die Punkte berechnet die Erweiterung
selbst — sie kennt den bisherigen Punktestand, die Maximalpunktzahl und die Anzahl
der Lücken und rechnet damit zuverlässiger, als du es im Kopf könntest.

Schreibe also nirgends eine Punktzahl hin.

Zum Verständnis, was mit deinem Prozentwert geschieht: Eine manuelle Bewertung gilt
in Moodle immer für die GANZE Frage. Die Erweiterung rechnet
„bisherige Punkte + (Maximalpunkte ÷ Anzahl Lücken) × dein Prozentwert",
sodass bereits erkannte Teilpunkte erhalten bleiben.

═══════════════════════════════════════════════════════
AUSGABE – NUR EIN JSON-BLOCK
═══════════════════════════════════════════════════════

Gib nach der Begrüßung direkt EINEN JSON-Block aus – keine Tabelle, keine Rückfrage.
Die Lehrkraft prüft deine Vorschläge in der Erweiterung; welche Fälle unklar sind,
entscheidet die Erweiterung selbst und legt sie ihr dort vor.

\`\`\`json
{
  "bewertungen": [
    { "nr": 1, "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "luecken": [ { "nr": 1, "prozent": 75, "grund": "ein Buchstabe falsch, wie 'Mistill' (75)",
                     "kategorie": "Tippfehler" } ] }
  ]
}
\`\`\`

- **Ein Eintrag je Fund (Versuch), nicht je Lücke.** Alle Lücken des Funds kommen in
  dessen „luecken"-Liste.
- **Jeder Fund bekommt einen Eintrag – auch wenn alle Lücken 0 % bekommen.** Die
  Erweiterung braucht jede Entscheidung.
- „nr" (oben), „qubaid" und „slot" übernimmst du unverändert aus dem Fund. Das „nr" in
  „luecken" ist die Lückennummer von dort.
- „prozent" ist eine der sechs Stufen: 100, 90, 75, 50, 25 oder 0.
- „grund": ein knapper Halbsatz, höchstens 12 Wörter, warum dieser Wert. Gibt es zur
  Lücke „bekannte_varianten", nenne den Eintrag, an dem du dich orientiert hast, mit Wert.
- „kategorie": genau eine aus dieser Liste: ${r.join(`, `)}.
- Steht bei einem Fund „kein_zugewinn": true, bewerte ihn trotzdem ganz normal.
- Keine Punktzahlen, kein „neu", kein „markfeld". Das ergänzt die Erweiterung.
- In Textfeldern NIEMALS gerade doppelte Anführungszeichen – nimm 'einfache'.

Schreibe unter das JSON einen Satz: „Kopiere diesen Block in die Erweiterung, Reiter
„2 · Eintragen" — die Vorschau öffnet sich beim Einfügen von selbst."

[FEEDBACK_BLOCK]
═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

Aufbau:
- „fragen"   – je Frage einmal: unter „art" steht „cloze" (Lückentext, eine oder mehrere
               Lücken im Satz) oder „kurzantwort" (eine Frage, ein Eingabefeld, immer
               genau eine Lücke mit der Nummer 1). Dazu der Aufgabentext mit markierten
               Lücken [[L1]], [[L2]], Maximalpunkte, Anzahl Lücken und unter „loesungen"
               je Lücke der Typ (SA / SAC / MC / …) und die als richtig hinterlegten
               Antworten. Ein „*" in einer hinterlegten Antwort ist ein Platzhalter für
               beliebigen Text. Unter „bekannte_varianten" stehen zusätzlich die schon
               erfassten Falschschreibungen dieser Lücke mit dem Prozentwert, den die
               Lehrkraft ihnen früher selbst gegeben hat.
- „funde"    – je Versuch die Lücken, die Moodle nicht erkannt hat, mit „ist" und „max".
               Unter „kontext" steht der Satz, in dem die Lücke vorkommt – bei
               „kurzantwort" der ganze Fragetext.

${I}`}function he(){return`═══════════════════════════════════════════════════════
MOODLE AI REVIEWER – NACHBEWERTUNG (KOMPAKTER PROMPT)
═══════════════════════════════════════════════════════

Falls du Zugriff auf die Skills „3-moodle-auswertung“ und „2-didaktik-bewertung“ von
A. Spielhoff hast: Wende deren komplette Bewertungslogik an — Begrüßung, die zwei
Pflichtschritte vor dem Bewerten (Satz um die Lücke lesen, gegen ALLE hinterlegten
Antworten prüfen und an „bekannte_varianten“ verankern, Verneinungs-Falle beachten,
zuerst auf reinen Groß-/Kleinschreibfehler prüfen), die 6-Stufen-Skala
(100/90/75/50/25/0) und die Regel, nie 0,01 % zu vergeben.

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (Einstellungen dieser
Erweiterung → Häkchen „Kompakter Prompt“ ausschalten) statt zu raten — ohne die
genauen Regeln (besonders die 90-%-Stufe nur bei Lückentyp SAC, und die
Verneinungs-Falle) sind falsche Bewertungen wahrscheinlich.

Kurzreferenz der Skala, nur zur Orientierung, ersetzt die Skill nicht:
100 = korrekt oder echtes Synonym · 90 = nur Groß-/Kleinschreibung falsch UND
Lückentyp SAC (bei SA: 100) · 75 = ein klarer Tippfehler, Wort erkennbar · 50 =
mehrere Tippfehler, mit Mühe erkennbar · 25 = nur Wortanfang/-stamm erkennbar ·
0 = falsches Wort, Rateversuch oder aus dem Aufgabensatz abgeschrieben.
Punkte NICHT selbst ausrechnen, nur Prozentwerte angeben — das rechnet die Erweiterung.

═══════════════════════════════════════════════════════
AUSGABE – NUR EIN JSON-BLOCK
═══════════════════════════════════════════════════════

Keine Tabelle, keine Rückfrage – direkt ein JSON-Block (die Lehrkraft prüft in der
Erweiterung):

\`\`\`json
{
  "bewertungen": [
    { "nr": 1, "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "luecken": [ { "nr": 1, "prozent": 75, "grund": "ein Buchstabe falsch", "kategorie": "Tippfehler" } ] }
  ]
}
\`\`\`

Ein Eintrag je Fund, auch bei 0 % in allen Lücken. „nr"/„qubaid"/„slot" unverändert
übernehmen, „prozent" eine der sechs Stufen, „grund" höchstens 12 Wörter (Anker nennen),
„kategorie" aus: ${r.join(`, `)}. Keine Punktzahlen. Keine geraden doppelten
Anführungszeichen in Textfeldern. Satz danach: „Kopiere diesen Block in die Erweiterung,
Reiter „2 · Eintragen" — die Vorschau öffnet sich beim Einfügen von selbst."

[FEEDBACK_BLOCK]
═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: „art“ (cloze/kurzantwort), Aufgabentext mit [[L1]],[[L2]],
„loesungen“ je Lücke mit Typ (SA/SAC/…), „richtig“-Liste, ggf. „bekannte_varianten“
mit Prozentwerten. „funde“ – je Versuch die nicht erkannten Lücken mit „kontext“.

${I}`}function ge(e,t){let n=(k.promptOverride||``).trim()||(k.kompaktPrompt?he():me());n=n.replace(`[FEEDBACK_BLOCK]`,t?`═══════════════════════════════════════════════════════
FEEDBACK FÜR SCHWACHE ANTWORTEN
═══════════════════════════════════════════════════════

In den Daten steht zusätzlich ein Abschnitt \`feedback\`: Versuche mit wenigen Punkten
oder leeren Lücken. Schreibe dafür je Versuch einen kurzen Text.

- Nenne das Lösungswort. Das ist ausdrücklich erwünscht.
- Bei Verwechslungsgefahr ein erklärender Satz dazu, sonst nichts weiter.
- Bei mehreren Lücken getrennt: „Lücke 1: … · Lücke 2: …"
- Sprich die Schülerin oder den Schüler direkt an, sachlich und ohne Floskeln.
- WICHTIG – Anführungszeichen im JSON: Willst du im Text ein Wort hervorheben,
  benutze dafür EINFACHE Anführungszeichen ('so') oder schreibe es ohne
  Anführungszeichen. Gerade doppelte Anführungszeichen ("so") NIEMALS in einem
  JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die JSON-Begrenzung
  und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Gib das Feedback im selben JSON-Block wie die Bewertungen aus:

\`\`\`json
{
  "kommentare": [
    { "frage": "1.1.4-Pistill", "qubaid": "2429453", "slot": "5",
      "text": "Gesucht war das Pistill …" }
  ]
}
\`\`\`

Auch hier nur „qubaid" und „slot" – das Kommentarfeld schlägt die Erweiterung selbst nach.
Gib „bewertungen" und „kommentare" zusammen in EINEM JSON-Block aus.

`:``);let r="```json\n"+JSON.stringify(h(e).daten,null,1)+"\n```";return n.includes(I)?n.replace(I,r):n+`

`+r}function _e(e,t){if(!e)return null;let n=`[[L`+t+`]]`,r=e.indexOf(n);if(r<0)return null;let i=0;for(let t=r;t>0;t--)if(/[.!?:]/.test(e[t-1])){i=t;break}let a=e.length;for(let t=r+n.length;t<e.length;t++)if(/[.!?]/.test(e[t])){a=t+1;break}let o=e.slice(i,a).trim();if(o.length>260){let e=o.indexOf(n),t=Math.max(0,e-120),r=Math.min(o.length,e+n.length+120);o=(t>0?`… `:``)+o.slice(t,r).trim()+(r<o.length?` …`:``)}return o}function ve(e){if(!e)return null;let t=e.replace(/\s*\[\[L\d+\]\]\s*/g,` `).replace(/\s+/g,` `).trim();return t.length>400?t.slice(0,400).trim()+` …`:t}async function ye(){let e=[...(await f(`${a}?id=${i}&mode=grading&includeauto=1`)).querySelectorAll(`table`)].find(e=>[...e.querySelectorAll(`th`)].some(e=>/Fragename/i.test(e.textContent)));if(!e)throw Error(`Keine Fragen-Tabelle gefunden. Bist du auf der Übersicht der Manuellen Bewertung?`);let t=[...e.querySelectorAll(`thead th`)].map(e=>e.textContent.trim()),n=t.findIndex(e=>/Fragename/i.test(e)),r=t.findIndex(e=>/Automatisch/i.test(e)),o=t.findIndex(e=>/Summe|Gesamt|Total/i.test(e));return o<0&&(o=t.length-1),[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.cells],i=null,a=null;for(let t of[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)).filter(Boolean)){let e=new URL(t,location.href);if(e.searchParams.get(`slot`)){i=e.searchParams.get(`slot`),a=e.searchParams.get(`qid`);break}}return{name:n>=0&&t[n]?t[n].textContent.trim():`(ohne Namen)`,slot:i,qid:a,auto:r>=0&&t[r]&&parseInt(t[r].textContent,10)||0,summe:o>=0&&t[o]&&parseInt(t[o].textContent,10)||null}}).filter(e=>e.slot&&e.qid&&e.auto>0)}function xe(e,t,n){return t===null||n===null||!e.length?!1:t>n/e.length*e.filter(e=>e.status!==`incorrect`).length+.005}function L(e,t,n,r,i){let a=[],o=[],c=0,l=null,u=0,d=null,f=null;return e.forEach(e=>{let p=(e.id.match(/question-(\d+)-/)||[])[1]||null,m=[...e.querySelectorAll(`input[name$="_answer"]`)].filter(w),h=m.map(e=>({nr:C(e.name),antwort:e.value,status:[`correct`,`partiallycorrect`,`incorrect`].find(t=>e.classList.contains(t))||`unbekannt`})),g=m.some(e=>/sub\d+_/.test(e.name))?`cloze`:`kurzantwort`,_=e.querySelector(`input[name$="-mark"]`),v=e.querySelector(`input[name$="-maxmark"]`),y=e.querySelector(`textarea[name$="-comment"]`),b=(e.querySelector(`.info .state`)||{}).textContent||``,x=/manuell/i.test(b),S=_?s(_.value):null,T=v?s(v.value):null;l===null&&(l=ee(E(e.querySelector(`.formulation`))),u=h.length,d=T,f=g);let D=x||xe(h,S,T);Se(h).length&&D&&!i&&c++;let O=h.filter(e=>e.status===`incorrect`&&e.antwort.trim()!==``);if(O.length&&(!D||i)&&a.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:p,ist:S,max:T,markfeld:_?_.name:null,luecken:O.map(e=>({nr:e.nr,antwort:e.antwort})),...D?{schon_nachbewertet:!0}:{}}),n){let e=h.some(e=>e.antwort.trim()===``),n=T===null?null:T*r/100;h.length&&(S!==null&&n!==null&&S<=n||e)&&o.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:p,ist:S,max:T,kommentarfeld:y?y.name:null,hat_kommentar:!!(y&&y.value.trim()),luecken:h.map(e=>({nr:e.nr,antwort:e.antwort,status:e.status}))})}}),{funde:a,feedback:o,text:l,anzahlLuecken:u,maxPunkte:d,uebersprungen:c,art:f}}let Se=e=>e.filter(e=>e.status===`incorrect`&&e.antwort.trim()!==``);async function we(e,t,n,r,i){let a=await ye(),o=[],c=[],l={},u=[],d=0,f=0,p=async r=>{try{let e=t?r.summe:r.auto,a=await y(S(r.slot,r.qid,t?`all`:`autograded`),e);e!=null&&a.length<e&&u.push(`${r.name}: nur ${a.length} von ${e} Versuchen geladen — bitte noch einmal auslesen`);let s=L(a,r,t,n,i);f+=s.uebersprungen||0,s.text&&!l[r.name]&&(l[r.name]={qid:r.qid,art:s.art||`cloze`,max:s.maxPunkte,luecken:s.anzahlLuecken,punkt_pro_luecke:s.maxPunkte&&s.anzahlLuecken?Math.round(s.maxPunkte/s.anzahlLuecken*100)/100:null,text:s.text}),o.push(...s.funde),c.push(...s.feedback)}catch(e){u.push(r.name+`: `+e.message)}d++,e(d,a.length,o.length+c.length)},m=[...a];for(;m.length;)await p(m.shift());let h=e=>e.luecken&&e.luecken[0]||{nr:0,antwort:``},g=(e,t)=>{let n=h(e),r=h(t);return e.frage.localeCompare(t.frage)||(n.nr||0)-(r.nr||0)||String(n.antwort||``).localeCompare(String(r.antwort||``))};o.sort(g),c.sort(g);let _=new Set([...o,...c].map(e=>e.frage));Object.keys(l).forEach(e=>{_.has(e)||delete l[e]}),o.forEach((e,t)=>{e.nr=t+1;let n=s(e.ist),r=s(e.max);n!==null&&r!==null&&n>=r&&(e.kein_zugewinn=!0)}),[...o,...c].forEach(e=>{let t=l[e.frage]||{};(e.luecken||[]).forEach(e=>{let n=t.art===`kurzantwort`?ve(t.text):_e(t.text,e.nr);n&&(e.kontext=n)})});let v=Object.keys(l),b=0;e(a.length,a.length,o.length+c.length,`Lösungen werden geladen …`);let x=[...v],C={};return await Promise.all(Array.from({length:4},async()=>{for(;x.length;){let e=x.shift(),t=await le(l[e].qid),n=ue(t),i=(n?F(n):null)||pe(t);if(!i){b++;continue}i.forEach(t=>{C[l[e].qid+`|`+t.nr]=(t.varianten||[]).map(e=>e.text)}),l[e].loesungen=i.map(e=>{let t={nr:e.nr,typ:e.typ,richtig:e.richtig},n={};return(e.varianten||[]).forEach(e=>{e.prozent>=1&&e.prozent<100&&(n[e.text]=e.prozent)}),Object.keys(n).length&&(t.bekannte_varianten=n),t}),r&&n&&F(n)&&(l[e].cloze_quelltext=n)}})),{zeilen:a.length,funde:o,feedback:c,fragen:l,fehler:u,clozeTexte:C,ohneLoesung:b,mitLoesung:v.length-b,uebersprungen:f}}function Ee(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&e.type!==`file`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&e.type!==`submit`&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function R(e){return!e||!e.slot||!e.qid?null:S(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``)}function De(e,t){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(k.kiHinweisText||D).trim();e&&(n+=`<p><em><small>`+c(e)+`</small></em></p>`)}return n}let Oe=(e,t)=>{let n=e?e.value.replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,r=t.text.replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim().slice(0,20);return!!(n&&r&&n.includes(r))};async function z(e,t,n,r){let i=S(e.slot,e.qid,`all`),{form:a,felder:o}=await x(i,[...e.marks.map(e=>e.markfeld),...e.comments.map(e=>e.kommentarfeld)]),c=[],u=[],d=[],m=[],h=(e,n)=>{r||t(e,n)};e.marks.forEach(e=>{if(!o.has(e.markfeld)){c.push(e),h(`✗ Punktefeld nicht auf der Seite — ${e.frage}: ${e.antwort||``} (${e.markfeld})`,R(e));return}o.set(e.markfeld,l(e.neu)),d.push(e)}),e.comments.forEach(e=>{if(!o.has(e.kommentarfeld)){u.push(e),h(`✗ Kommentarfeld nicht auf der Seite — ${e.frage} (${e.kommentarfeld})`,R(e));return}o.set(e.kommentarfeld,De(e,n)),m.push(e)});let g=0;if(d.length||m.length){let e=[...a.elements].find(e=>e.type===`submit`&&e.name);e&&o.set(e.name,e.value);let n=new URL(a.getAttribute(`action`)||i,i).href,r=await fetch(n,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:o.toString()});if(!r.ok)throw Error(`HTTP `+r.status+` beim Speichern`);let _=d.slice(),v=m.slice(),y=new Map;for(let e=0;e<8&&(_.length||v.length);e++){e>0&&await p(500);let n=await f(i);_=_.filter(e=>{let r=n.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`);if(!r)return!0;let i=s(r.value);return y.set(e,i),i!==null&&Math.abs(i-e.neu)<.005?(g++,t(`✓ ${e.frage} — ${e.antwort||``} → ${l(e.neu)}`,R(e)),!1):!0}),v=v.filter(e=>{let r=n.querySelector(`textarea[name="${CSS.escape(e.kommentarfeld)}"]`);return!r||!Oe(r,e)||(g++,Je(e.kommentarfeld),t(`💬 ${e.frage} — Feedback eingetragen`),!1)})}_.forEach(e=>{c.push(e);let t=y.has(e)?y.get(e):void 0;h(`✗ ${e.frage} — ${e.antwort||``} — steht auf ${t==null?`keinem Wert`:l(t)} statt ${l(e.neu)}`,R(e))}),v.forEach(e=>{u.push(e),h(`✗ ${e.frage} — Feedback nicht angekommen`,R(e))})}return{ok:g,offenMarks:c,offenKomm:u}}function ke(e,t){let n=new Map,r=e=>{let t=e.slot+`|`+e.qid;return n.has(t)||n.set(t,{slot:e.slot,qid:e.qid,marks:[],comments:[]}),n.get(t)};return(e||[]).forEach(e=>r(e).marks.push(e)),(t||[]).forEach(e=>r(e).comments.push(e)),[...n.values()]}async function Ae(e,t,n,r){let i=ke(e,t),a=0,o=0,s=0;for(let e of i){try{let t=[...e.marks.map(e=>e.markfeld),...e.comments.map(e=>e.kommentarfeld)],{felder:r}=await x(S(e.slot,e.qid,`all`),t);e.marks.forEach(e=>{r.has(e.markfeld)?a++:(o++,n(`✗ Punktefeld fehlt — ${e.frage}: ${e.antwort||``}`,R(e)))}),e.comments.forEach(e=>{r.has(e.kommentarfeld)?a++:(o++,n(`✗ Kommentarfeld fehlt — ${e.frage}`,R(e)))})}catch(t){o+=e.marks.length+e.comments.length,n(`✗ Seite ${(e.marks[0]||e.comments[0]||{}).frage}: ${t.message}`)}s++,r(s,i.length)}return{ok:a,fehler:o,gruppen:i.length,trocken:!0}}async function je(e,t,n,r,i){let a=e||[],o=t||[],s=0,c=0;for(let e=1;e<=3&&(a.length||o.length);e++){let t=e===3;e>1&&(r(`↻ Runde ${e}/3: ${a.length+o.length} noch nicht bestätigte Einträge erneut …`),await p(1500));let l=ke(a,o);e===1&&(c=l.length);let u=[],d=[],f=0;for(let e of l){try{let i=await z(e,r,n,!t);s+=i.ok,u.push(...i.offenMarks),d.push(...i.offenKomm)}catch(n){u.push(...e.marks),d.push(...e.comments),t&&r(`✗ Frage ${(e.marks[0]||e.comments[0]||{}).frage}: ${n.message}`)}f++,i(f,l.length)}a=u,o=d}return{ok:s,fehler:a.length+o.length,gruppen:c}}function Me(){let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:e?e.textContent.trim():``}}let B=d(`button`,`ce-fab`);B.title=`Moodle AI Reviewer`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`AI Reviewer`,e.className=`ce-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),B.textContent=`🔎`}),B.appendChild(e)}catch{B.textContent=`🔎`}B.title=`Moodle AI Reviewer`,document.body.appendChild(B);let V=d(`div`,`ce-panel ce-hidden`);V.innerHTML=`
    <div class="ce-head">
      <div class="ce-titelblock">
        <span class="ce-title">🔎 AI Reviewer <span class="ce-version"></span></span>
        <span class="ce-untertitel">Unerkannte automatische Antworten nachbewerten</span>
      </div>
      <button class="ce-close" title="Schließen">✕</button>
    </div>
    <div class="ce-tabs">
      <button class="ce-tab ce-aktiv" data-tab="ernte">1 · Auslesen</button>
      <button class="ce-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="ce-tab" data-tab="opt">⚙</button>
    </div>

    <div class="ce-body" data-panel="ernte">
      <p class="ce-meta"></p>
      <label class="ce-check"><input type="checkbox" class="ce-fb">
        Auch schwache Antworten fürs Feedback sammeln</label>
      <label class="ce-check"><input type="checkbox" class="ce-bereits">
        Auch schon nachbewertete Versuche noch einmal vorlegen</label>
      <label class="ce-label ce-fbschwelle ce-hidden">Schwelle (% der erreichbaren Punkte)
        <input type="text" class="ce-schwelle" value="50">
      </label>
      <p class="ce-schwelleinfo ce-fbschwelle ce-hidden"></p>
      <button class="ce-go">Test durchsuchen</button>
      <details class="ce-verteilung">
        <summary>📊 Punkteverteilung des Tests</summary>
        <div class="ce-vtinhalt"></div>
        <button class="ce-vtneu ce-zweit">↻ Neu laden</button>
      </details>
      <div class="ce-progress ce-hidden"><div class="ce-bar"></div><span class="ce-ptext"></span></div>
      <div class="ce-result ce-hidden">
        <p class="ce-summary"></p>
        <button class="ce-direkt ce-hidden">⚡ Direkt bewerten</button>
        <p class="ce-direktinfo ce-hidden"></p>
        <button class="ce-copy">📋 Prompt + Daten kopieren</button>
        <button class="ce-copy2 ce-zweit">📋 nur JSON</button>
        <button class="ce-ohneki ce-zweit">✋ Ohne KI selbst entscheiden</button>
        <p class="ce-groesse"></p>
        <div class="ce-list"></div>
      </div>
      <p class="ce-error ce-hidden"></p>
    </div>

    <div class="ce-body ce-hidden" data-panel="eintrag">
      <p class="ce-hinweis">Hier die Antwort der KI einfügen. Danach öffnet sich die Vorschau:
      unklare Fälle entscheidest du, eingetragen wird erst nach deinem Klick – genau so, als
      tipptest du den Wert selbst ins Punktefeld und speichertest.</p>
      <textarea class="ce-json" rows="6" placeholder='{ "punkte": [ … ] }'></textarea>
      <label class="ce-check"><input type="checkbox" class="ce-ki" checked>
        KI-Hinweis ans Feedback anhängen</label>
      <p class="ce-kivorschau"></p>
      <button class="ce-pruef ce-hidden">🔍 Prüfen</button>
      <div class="ce-vorschau ce-hidden"></div>
      <p class="ce-pinfo ce-hidden"></p>
      <button class="ce-zurueck ce-zweit ce-hidden">← Vorschau ändern</button>
      <div class="ce-progress2 ce-hidden"><div class="ce-bar2"></div><span class="ce-ptext2"></span></div>
      <p class="ce-abschluss ce-hidden"></p>
      <div class="ce-log ce-hidden"></div>
      <div class="ce-schreibknoepfe ce-hidden">
        <button class="ce-alle">In Moodle eintragen</button>
      </div>
    </div>

    <div class="ce-body ce-hidden" data-panel="opt">
      <label class="ce-check"><input type="checkbox" class="ce-voll">
        Vollständigen Aufgaben-Quelltext mitgeben</label>
      <p class="ce-hinweis">Normalerweise bekommt die KI je Lücke nur die als richtig
      hinterlegten Antworten – das genügt für die Bewertung. Mit dieser Option geht
      zusätzlich der komplette Quelltext jeder Aufgabe mit, also auch alle bereits
      erfassten Fehlervarianten samt Prozentwerten.
      <strong>Das verbraucht sehr viel mehr KI-Ressourcen</strong> – rund 2.000 Zeichen
      je Aufgabe. Nur einschalten, wenn du die vorhandenen Varianten wirklich brauchst.
      Wirkt nur bei Lückentext-Aufgaben; Kurzantwort-Fragen haben keinen Quelltext.</p>

      <label class="ce-check"><input type="checkbox" class="ce-fbvorher">
        Feedback vor dem Eintragen anzeigen</label>
      <p class="ce-hinweis">Aus (Standard): Die Feedback-Texte der KI gehen mit dem
      KI-Hinweis direkt mit. An: Du siehst jeden Text in der Zusammenfassung und kannst
      ihn vor dem Eintragen ändern.</p>

      <label class="ce-check"><input type="checkbox" class="ce-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <p class="ce-hinweis">Verweist für die Bewertungslogik auf die Skills
      „3-moodle-auswertung“ und „2-didaktik-bewertung“ statt sie komplett auszuschreiben
      – spart pro Aufruf mehrere Tausend Zeichen. <strong>Nur einschalten, wenn du sicher
      bist, dass die verwendete KI diese Skills wirklich kennt</strong> (z. B. dein eigener
      Claude-Cowork-Zugang). Andere Lehrkräfte oder andere KI-Systeme lassen dieses
      Häkchen aus – die bekommen automatisch den vollständigen Prompt.</p>

      <label class="ce-label">Eigener Prompt (leer = Standard)
        <textarea class="ce-prompt" rows="8" placeholder="Leer lassen, um den mitgelieferten Prompt zu verwenden."></textarea>
      </label>
      <p class="ce-hinweis">Der Platzhalter <code>[MOODLE_AI_REVIEWER_DATEN]</code> wird
      durch die Daten aus Moodle ersetzt, <code>[FEEDBACK_BLOCK]</code> durch die
      Feedback-Anweisungen. Fehlen sie, werden die Daten hinten angehängt.</p>
      <label class="ce-label">KI-Hinweis unter dem Feedback
        <textarea class="ce-kitext" rows="3"></textarea>
      </label>
      <p class="ce-hinweis">Dieser Satz wird unter jedes Feedback gesetzt – kursiv und
      klein –, solange in Tab 2 das Häkchen gesetzt ist. Leer lassen setzt beim
      Speichern den Standardsatz wieder ein.</p>

      <div class="ce-abschnitt">
        <p class="ce-abschnittkopf">KI direkt (optional)</p>
        <p class="ce-hinweis ce-kistand">…</p>
        <p class="ce-hinweis">Statt Prompt kopieren und Antwort einfügen kann die Erweiterung eine
        KI selbst fragen: eine <strong>lokale</strong> auf deinem Rechner (z. B. LM Studio, Ollama,
        Bionic – die Daten verlassen den Rechner nicht) oder mit eigenem API-Schlüssel einen
        <strong>Cloud-Dienst</strong>. Standard: aus. Ohne diese Einstellung funktioniert alles wie
        gewohnt über das Kopieren.</p>
        <button class="ce-kiopt ce-zweit">KI-Einstellungen öffnen</button>
        <p class="ce-kioptinfo ce-sinfo ce-hidden"></p>
      </div>

      <div class="ce-abschnitt">
        <p class="ce-abschnittkopf">Fehlersammlung</p>
        <p class="ce-hinweis ce-sammelstand">…</p>
        <p class="ce-hinweis">Jeder Fall, den du über die Vorschau einträgst, wird hier gesammelt
        (nur in diesem Browser). Noch nicht in die Frage eingepflegte Varianten helfen beim nächsten
        Test als Vergleich; deine eigenen Entscheidungen gehen dabei vor denen der KI. Der Export
        hat denselben Aufbau wie Fehlersammlung.csv.</p>
        <button class="ce-sexport ce-zweit">⬇ Als CSV exportieren</button>
        <button class="ce-simport ce-zweit">⬆ CSV importieren</button>
        <input type="file" class="ce-sdatei ce-hidden" accept=".csv,text/csv">
        <button class="ce-sleeren ce-zweit">Sammlung leeren</button>
        <p class="ce-sinfo ce-hidden"></p>
      </div>

      <button class="ce-optsave">Speichern</button>
      <button class="ce-optvorlage ce-zweit">Standard einfügen</button>
      <button class="ce-optreset ce-zweit">Zurücksetzen</button>
      <p class="ce-optinfo ce-hidden"></p>
    </div>`,document.body.appendChild(V);let H=e=>V.querySelector(e);H(`.ce-version`).textContent=e;let U=Me();H(`.ce-meta`).textContent=[U.kurs,U.test].filter(Boolean).join(` · `)||`Manuelle Bewertung`;function Ne(){let e=s(H(`.ce-schwelle`).value);return e===null||e<=0?O.feedbackSchwelleProzent:Math.min(100,e)}function Pe(){let e=H(`.ce-schwelleinfo`);if(!e)return;let t=Ne();e.textContent=`${u(t)} % — bei einer 2-Punkte-Frage also alles bis ${l(2*t/100)} Punkte, bei einer 1-Punkt-Frage bis ${l(t/100)}. Leere Lücken kommen immer mit, unabhängig von diesem Wert.`}function Fe(){let e=H(`.ce-fb`).checked;V.querySelectorAll(`.ce-fbschwelle`).forEach(t=>t.classList.toggle(`ce-hidden`,!e)),Pe()}H(`.ce-fb`).addEventListener(`change`,async()=>{Fe(),await A({feedbackSammeln:H(`.ce-fb`).checked})}),H(`.ce-schwelle`).addEventListener(`change`,async()=>{Pe(),await A({feedbackSchwelleProzent:Ne()})}),H(`.ce-schwelle`).addEventListener(`input`,Pe),re().then(()=>{H(`.ce-voll`).checked=!!k.vollstaendig,H(`.ce-kompakt`).checked=!!k.kompaktPrompt,H(`.ce-fbvorher`).checked=!!k.feedbackVorher,H(`.ce-prompt`).value=k.promptOverride||``,H(`.ce-kitext`).value=k.kiHinweisText||D,H(`.ce-fb`).checked=k.feedbackSammeln!==!1,H(`.ce-schwelle`).value=u(k.feedbackSchwelleProzent??O.feedbackSchwelleProzent),Fe(),W()});let Ie=`reviewerErnte_`+i;function Le(){try{t.storage.local.set({[Ie]:J})}catch{}}try{t.storage.local.get([Ie],e=>{let t=e&&e[Ie];if(t&&!J){J=t;let e=H(`.ce-meta`);e&&(e.textContent+=` · ${(t.funde||[]).length} Funde aus einem früheren Durchlauf geladen`)}})}catch{}function W(){let e=H(`.ce-kivorschau`);if(!e)return;let t=(k.kiHinweisText||D).trim();if(!H(`.ce-ki`).checked||!t){e.classList.add(`ce-hidden`);return}e.classList.remove(`ce-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}function Re(e){let t=H(`.ce-optinfo`);t.textContent=e,t.classList.remove(`ce-hidden`),setTimeout(()=>t.classList.add(`ce-hidden`),3e3)}H(`.ce-optsave`).addEventListener(`click`,async()=>{await A({vollstaendig:H(`.ce-voll`).checked,kompaktPrompt:H(`.ce-kompakt`).checked,feedbackVorher:H(`.ce-fbvorher`).checked,promptOverride:H(`.ce-prompt`).value.trim(),kiHinweisText:H(`.ce-kitext`).value.trim()||D}),H(`.ce-kitext`).value=k.kiHinweisText,W(),Re(`Gespeichert ✓`)}),H(`.ce-optvorlage`).addEventListener(`click`,()=>{H(`.ce-prompt`).value=me(),Re(`Standard eingefügt – zum Übernehmen auf Speichern klicken.`)}),H(`.ce-optreset`).addEventListener(`click`,async()=>{await A({...O}),H(`.ce-voll`).checked=!1,H(`.ce-kompakt`).checked=!1,H(`.ce-fbvorher`).checked=!1,H(`.ce-prompt`).value=``,H(`.ce-kitext`).value=D,H(`.ce-fb`).checked=O.feedbackSammeln,H(`.ce-schwelle`).value=u(O.feedbackSchwelleProzent),Fe(),W(),Re(`Auf Standard zurückgesetzt.`)}),H(`.ce-ki`).addEventListener(`change`,W);async function ze(){let e=await Ce();H(`.ce-kistand`).textContent=e.an?`An: ${e.modell||`(kein Modell gewählt)`} · ${Te(e.basis)?`lokal`:`Cloud`} · ${e.basis}`:`Aus.`}ze(),H(`.ce-kiopt`).addEventListener(`click`,async()=>{let e=await j(`optionen`,{}),t=H(`.ce-kioptinfo`);t.textContent=e.ok?`✓ Einstellungen in einem neuen Tab geöffnet. Danach diese Seite neu laden.`:ce(e),t.classList.remove(`ce-hidden`),setTimeout(()=>t.classList.add(`ce-hidden`),6e3)});async function Be(){let e=H(`.ce-direkt`),t=H(`.ce-direktinfo`);e.classList.add(`ce-hidden`),t.classList.add(`ce-hidden`);let n=await Ce();if(!n.an)return;let r=e=>{t.textContent=e,t.classList.remove(`ce-hidden`)};if(!n.modell){r(`KI direkt ist eingeschaltet, aber kein Modell gewählt (⚙ → KI-Einstellungen).`);return}r(`Prüfe Verbindung zur KI …`);let i=await j(`modelle`,{cfg:n});if(!i.ok){r(`KI direkt nicht verfügbar: `+ce(i,n)+` Der Weg über „Prompt kopieren" funktioniert weiter.`);return}t.classList.add(`ce-hidden`),e.textContent=`⚡ Direkt bewerten – ${n.modell} (${Te(n.basis)?`lokal`:`Cloud`})`,e.classList.remove(`ce-hidden`)}async function Ve(){let e=await f(`${a}?id=${i}&mode=overview&pagesize=5000`),t=e.querySelector(`table#attempts`)||e.querySelector(`table.generaltable`);if(!t)throw Error(`Ergebnisübersicht nicht gefunden.`);let n=[...t.querySelectorAll(`thead th`)],r=n.findIndex(e=>e.classList.contains(`sumgrades`));if(r<0&&(r=n.findIndex(e=>/\/\s*[\d.,]+\s*$/.test(e.textContent.trim()))),r<0)throw Error(`Spalte mit den Gesamtpunkten nicht gefunden.`);let o=s((n[r].textContent.match(/\/\s*([\d.,]+)\s*$/)||[])[1]),c=[],l=0;return t.querySelectorAll(`tbody tr`).forEach(e=>{if(!e.querySelector(`a[href*="review.php"]`))return;let t=e.querySelector(`td.sumgrades`)||e.children[r],n=t?s(t.textContent.replace(/[^\d.,-]/g,``)):null;n===null?l++:c.push(n)}),{werte:c,max:o,ohne:l}}async function He(){let e=H(`.ce-vtinhalt`);e.textContent=`Lade Ergebnisübersicht …`;try{let t=await Ve();if(!t.max)throw Error(`Höchstpunktzahl nicht erkannt.`);let n=be(t.werte,t.max);if(!n.n){e.textContent=`Noch keine bewerteten Versuche.`;return}e.innerHTML=n.svg,t.ohne&&e.appendChild(d(`p`,`ce-hinweis`,`${t.ohne} Versuch(e) noch ohne Gesamtbewertung.`))}catch(t){e.textContent=`Konnte die Verteilung nicht laden: `+t.message}}H(`.ce-verteilung`).addEventListener(`toggle`,()=>{H(`.ce-verteilung`).open&&He()}),H(`.ce-vtneu`).addEventListener(`click`,He);async function G(){let e=await T(),t=Object.values(e),n=t.filter(e=>!e.Status||e.Status===`offen`).length,r=t.filter(e=>e._quelle===`Lehrkraft`).length;H(`.ce-sammelstand`).textContent=t.length?`${t.length} Fälle gesammelt · ${n} offen · ${r} von dir entschieden.`:`Noch keine Fälle gesammelt.`}function K(e){let t=H(`.ce-sinfo`);t.textContent=e,t.classList.remove(`ce-hidden`),clearTimeout(K.uhr),K.uhr=setTimeout(()=>t.classList.add(`ce-hidden`),5e3)}G(),H(`.ce-sexport`).addEventListener(`click`,async()=>{let e=await T();if(!Object.keys(e).length){K(`Nichts zu exportieren – die Sammlung ist leer.`);return}let t=ie(e),n=URL.createObjectURL(new Blob([t.csv],{type:`text/csv;charset=utf-8`})),r=document.createElement(`a`);r.href=n,r.download=`Fehlersammlung-${new Date().toISOString().slice(0,10)}.csv`,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(n),5e3),K(`✓ ${t.n} Fälle als CSV heruntergeladen`+(t.uebersprungen?`, ${t.uebersprungen} als Rateversuch übersprungen.`:`.`))}),H(`.ce-simport`).addEventListener(`click`,()=>H(`.ce-sdatei`).click()),H(`.ce-sdatei`).addEventListener(`change`,async()=>{let e=H(`.ce-sdatei`).files[0];if(e){try{let t=await oe(await e.text());K(`✓ ${t.neu} Fälle übernommen, ${t.gesamt} insgesamt. Vorhandene blieben unverändert.`),G()}catch(e){K(`Fehler: `+e.message)}H(`.ce-sdatei`).value=``}});let q=null;H(`.ce-sleeren`).addEventListener(`click`,async()=>{let e=H(`.ce-sleeren`);if(!q){e.textContent=`Wirklich leeren? Noch einmal klicken`,q=setTimeout(()=>{q=null,e.textContent=`Sammlung leeren`},4e3);return}clearTimeout(q),q=null,e.textContent=`Sammlung leeren`,await se(),G(),K(`Sammlung geleert.`)}),B.addEventListener(`click`,()=>V.classList.toggle(`ce-hidden`)),H(`.ce-close`).addEventListener(`click`,()=>V.classList.add(`ce-hidden`)),V.querySelectorAll(`.ce-tab`).forEach(e=>{e.addEventListener(`click`,t=>{t.isTrusted&&Y!==void 0&&Y&&(clearInterval(Y),Y=null,H(`.ce-copy`).textContent=`📋 Prompt + Daten kopieren`,H(`.ce-copy2`).textContent=`📋 nur JSON`),V.querySelectorAll(`.ce-tab`).forEach(t=>t.classList.toggle(`ce-aktiv`,t===e)),V.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`ce-hidden`,t.dataset.panel!==e.dataset.tab))})});let J=null,Ue=!1;H(`.ce-go`).addEventListener(`click`,async()=>{let e=H(`.ce-go`);e.disabled=!0,H(`.ce-error`).classList.add(`ce-hidden`),H(`.ce-result`).classList.add(`ce-hidden`),H(`.ce-progress`).classList.remove(`ce-hidden`);try{let e=H(`.ce-fb`).checked,t=Ne(),n=await we((e,t,n,r)=>{H(`.ce-bar`).style.width=Math.round(e/t*100)+`%`,H(`.ce-ptext`).textContent=r||`${e} / ${t} Fragen · ${n} Funde`},e,t,k.vollstaendig,H(`.ce-bereits`).checked),r=await ae(n.clozeTexte||{});r&&G();let a=ne(await T()),o=0;Object.values(n.fragen).forEach(e=>(e.loesungen||[]).forEach(t=>{let n=a[e.qid+`|`+t.nr];if(!n)return;let r=t.bekannte_varianten||{},i=[];Object.entries(n).forEach(([e,t])=>{e in r||(r[e]=t,i.push(e))}),i.length&&(t.bekannte_varianten=r,t.aus_sammlung=i,o+=i.length)})),J={meta:{test:U.test,kurs:U.kurs,cmid:i,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.zeilen,funde:n.funde.length,loesungen_geladen:n.mitLoesung,loesungen_fehlend:n.ohneLoesung,bereits_nachbewertet_uebersprungen:n.uebersprungen},fragen:n.fragen,funde:n.funde},e&&(J.meta.feedback_schwelle_prozent=t,J.meta.feedback_kandidaten=n.feedback.length,J.feedback=n.feedback),Ue=e,Le(),H(`.ce-summary`).textContent=`${n.funde.length} unerkannte Antworten in ${Object.keys(n.fragen).length} Fragen (von ${n.zeilen} geprüften Fragen)`+(e?` · ${n.feedback.length} Kandidaten fürs Feedback.`:`.`)+(n.uebersprungen?` ${n.uebersprungen} bereits nachbewertete Versuche übersprungen.`:``),n.uebersprungen&&!n.funde.length&&(H(`.ce-summary`).textContent=`Nichts zu tun: alle ${n.uebersprungen} gefundenen Antworten wurden bereits von Hand nachbewertet. Zum erneuten Vorlegen oben das Häkchen setzen.`);let s=ge(J,e),c=m(J).size;o&&(H(`.ce-summary`).textContent+=` ${o} Variante(n) aus deiner Fehlersammlung dienen als Anker.`),r&&(H(`.ce-summary`).textContent+=` ${r} Fall/Fälle aus der Fehlersammlung stehen inzwischen in den Fragen und wurden dort gelöscht.`),c&&(H(`.ce-summary`).textContent+=` ${c} Lücke(n) entscheidet die Erweiterung selbst (nur Groß-/Kleinschreibung oder schon bekannte Variante) – sie gehen nicht an die KI.`),H(`.ce-groesse`).textContent=`Prompt: rund ${Math.round(s.length/1e3)}.000 Zeichen`+(k.vollstaendig?` (mit vollständigem Quelltext)`:``)+(n.ohneLoesung?` · Achtung: zu ${n.ohneLoesung} Frage(n) konnten die hinterlegten Antworten nicht geladen werden.`:``),n.ohneLoesung&&n.mitLoesung===0&&(H(`.ce-error`).textContent=`Zu keiner Frage konnten die hinterlegten Antworten geladen werden – vermutlich fehlt das Recht, Fragen zu bearbeiten. Die KI kann dann nicht beurteilen, was gesucht war. Gib in dem Fall die Fragen-XML zusätzlich in den Chat.`,H(`.ce-error`).classList.remove(`ce-hidden`));let l=H(`.ce-list`);l.innerHTML=``;let u=null;n.funde.forEach(e=>{e.frage!==u&&(l.appendChild(d(`div`,`ce-qname`,e.frage)),u=e.frage);let t=d(`a`,`ce-row`);t.href=S(e.slot,e.qid,`all`)+`#question-`+e.qubaid+`-`+e.slot,t.target=`_blank`,t.rel=`noopener`,t.title=`Diesen Versuch in Moodle öffnen`,t.appendChild(d(`span`,`ce-nr`,`#`+e.nr));let n=e.luecken&&e.luecken[0]||{nr:`?`,antwort:``};t.appendChild(d(`span`,`ce-gap`,`L`+n.nr)),t.appendChild(d(`span`,`ce-ans`,n.antwort)),t.appendChild(d(`span`,`ce-pts`,e.kein_zugewinn?`voll`:`${e.ist} / ${e.max}`)),l.appendChild(t)}),n.fehler.length&&(H(`.ce-error`).textContent=`⚠ `+n.fehler.join(` · `),H(`.ce-error`).classList.remove(`ce-hidden`)),H(`.ce-result`).classList.remove(`ce-hidden`),Be()}catch(e){H(`.ce-error`).textContent=`Fehler: `+e.message,H(`.ce-error`).classList.remove(`ce-hidden`)}finally{H(`.ce-progress`).classList.add(`ce-hidden`),e.disabled=!1}});async function We(e){try{await navigator.clipboard.writeText(e)}catch{let t=d(`textarea`,`ce-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}function Ge(e){return`Für diese Versuche fehlt noch ein Feedback-Text. Gib mir bitte ein JSON nur mit „kommentare" aus — genau einen Eintrag je Versuch, auch wenn mehrere zur selben Frage gehören:

`+e.map(e=>{let t=(e.luecken||[]).map(e=>`Lücke ${e.nr}: ${String(e.antwort||``).trim()?`„`+e.antwort+`"`:`(leer gelassen)`}`).join(` · `);return`- ${e.frage} · qubaid ${e.qubaid} · slot ${e.slot} · ${t}`}).join(`
`)}let Y=null;function Ke(e){let t=V.querySelector(`.ce-tab[data-tab="`+e+`"]`);t&&t.click()}function qe(e,t){let n=H(e);clearInterval(Y);let r=3;n.textContent=`✓ Kopiert — weiter in ${r} s`,Y=setInterval(()=>{if(r--,r>0){n.textContent=`✓ Kopiert — weiter in ${r} s`;return}clearInterval(Y),Y=null,n.textContent=t,Ke(`eintrag`),H(`.ce-json`).focus()},1e3)}H(`.ce-copy`).addEventListener(`click`,async()=>{J&&(await We(ge(J,Ue)),qe(`.ce-copy`,`📋 Prompt + Daten kopieren`))}),H(`.ce-copy2`).addEventListener(`click`,async()=>{J&&(await We("```json\n"+JSON.stringify(h(J).daten,null,1)+"\n```"),qe(`.ce-copy2`,`📋 nur JSON`))});let X=null,Z=null;function Je(e){if(!J||!Array.isArray(J.feedback))return;let t=J.feedback.find(t=>t.kommentarfeld===e);t&&!t.hat_kommentar&&(t.hat_kommentar=!0,Le())}function Q(){if(!J)return null;let e=new Map,t=new Map;return(J.funde||[]).forEach(t=>e.set(t.qubaid+`|`+t.slot,t)),(J.feedback||[]).forEach(e=>t.set(e.qubaid+`|`+e.slot,e)),{funde:e,rueckmeldungen:t,fragen:J.fragen||{}}}let Ye=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Tab 1 „Test durchsuchen" laufen lassen — daraus stammen Punktestand, Lückenzahl und Feldnamen.`;function Xe(e){let t=Q();if(!t)throw Error(Ye);let n=[];return e.forEach((e,r)=>{let i=r+1;if(e.qubaid==null||e.slot==null)throw Error(`Bewertung ${i}: "qubaid" oder "slot" fehlt.`);let a=t.funde.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Bewertung ${i}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keinen ausgelesenen Fund. Stammt das JSON zu diesem Durchlauf?`);let o=(t.fragen[a.frage]||{}).luecken||(a.luecken||[]).length||1,c=s(a.max),u=s(a.ist);if(c===null||u===null)throw Error(`Bewertung ${i}: Punktestand des Versuchs unbekannt.`);let d=c/o,f=0,p=[];(e.luecken||[]).forEach((e,t)=>{let n=Number(e.prozent);if(isNaN(n)||n<0||n>100)throw Error(`Bewertung ${i}, Lücke ${t+1}: Prozentwert „${e.prozent}" ist ungültig.`);p.push(`L${e.nr==null?t+1:e.nr}: ${n} %`),f+=d*n/100});let m=Math.min(c,Math.round((u+f)*100)/100);m<=u||n.push({frage:a.frage,qid:a.qid,slot:String(a.slot),qubaid:String(e.qubaid),markfeld:a.markfeld,neu:m,antwort:(a.luecken||[]).map(e=>e.antwort).join(` / `),prozenttext:p.join(` · `),rechnung:`${l(u)} → ${l(m)} von ${l(c)}`})}),n}function Ze(e){if(!e.length)return[];let t=Q();return e.map((e,n)=>{if(e.kommentarfeld&&e.qid)return e;if(!t)throw Error(Ye);if(e.qubaid==null||e.slot==null)throw Error(`Kommentar ${n+1}: "qubaid" oder "slot" fehlt.`);let r=String(e.qubaid)+`|`+String(e.slot),i=t.rueckmeldungen.get(r)||t.funde.get(r);if(!i)throw Error(`Kommentar ${n+1}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesenen Daten.`);if(!i.kommentarfeld)throw Error(`Kommentar ${n+1}: für diesen Versuch wurde kein Kommentarfeld ausgelesen. Beim Auslesen bitte „Auch schwache Antworten fürs Feedback sammeln" ankreuzen.`);return{frage:i.frage,qid:i.qid,slot:String(i.slot),qubaid:String(e.qubaid||i.qubaid||``),kommentarfeld:i.kommentarfeld,text:e.text,leereLuecken:(i.luecken||[]).filter(e=>!String(e.antwort||``).trim()).map(e=>e.nr)}})}H(`.ce-pruef`).addEventListener(`click`,()=>Qe(null));function Qe(e){let t=H(`.ce-pinfo`);H(`.ce-vorschau`).classList.add(`ce-hidden`),t.classList.remove(`ce-hidden`),H(`.ce-schreibknoepfe`).classList.add(`ce-hidden`),H(`.ce-abschluss`).classList.add(`ce-hidden`),H(`.ce-log`).classList.add(`ce-hidden`);let n=V.querySelector(`.ce-fehlend`);n&&n.remove(),X=null,Z=null;try{let n=e;if(!n&&(n=$e(H(`.ce-json`).value),$=null,Array.isArray(n.bewertungen)&&Q())){nt(n,`Vorschläge aus dem KI-Chat`);return}let r=V.querySelector(`.ce-fbliste`);r&&r.remove();let i=n.kommentare||[],a,o=!1;Array.isArray(n.bewertungen)?(o=!0,a=Xe(n.bewertungen)):(a=Array.isArray(n)?n:n.punkte||[],a.forEach((e,t)=>{if([`qid`,`slot`,`markfeld`,`neu`].forEach(n=>{if(e[n]===void 0||e[n]===null)throw Error(`Punkte-Eintrag ${t+1}: "${n}" fehlt.`)}),isNaN(Number(e.neu)))throw Error(`Punkte-Eintrag ${t+1}: "neu" ist keine Zahl.`)}));let s=Ze(i),c=o?(n.bewertungen||[]).length-a.length:0,l=s.filter(e=>{let t=Array.isArray(e.leereLuecken)?e.leereLuecken:[];return t.length>1&&t.some(t=>!RegExp(`Lücke(?:n)?\\s*`+t+`(?!\\d)`,`i`).test(e.text))}).length,u=Q(),f=[];if(u&&s.length){let e=new Set(s.map(e=>e.kommentarfeld));u.rueckmeldungen.forEach(t=>{t.kommentarfeld&&!t.hat_kommentar&&!e.has(t.kommentarfeld)&&f.push(t)})}if(!a.length&&!s.length&&e)throw Error(`Nichts einzutragen: keiner der entschiedenen Fälle bringt einen Punktzuwachs, und es gibt keine Feedback-Texte. „← Vorschau ändern" führt zurück.`);if(!a.length&&!s.length)throw Error(`Weder "bewertungen"/"punkte" noch "kommentare" mit Einträgen gefunden.`);X=a,Z=s;let p=new Set([...a,...s].map(e=>e.slot+`|`+e.qid)).size,m=[];a.length&&m.push(`${a.length} Bewertungen`),s.length&&m.push(`${s.length} Feedback-Texte`),t.className=`ce-pinfo ce-ok`;let h=[];if(o&&h.push(`Die Punkte wurden aus den Prozentwerten berechnet.`),c>0&&h.push(`${c} Eintrag/Einträge ohne Punktzuwachs (alle Lücken 0 %) wurden weggelassen — sie würden in Moodle nichts ändern.`),f.length&&h.push(`⚠ ${f.length} von ${u?u.rueckmeldungen.size:0} Feedback-Kandidaten haben keinen Text bekommen — Liste unten. Eintragen kannst du trotzdem.`),l>0&&h.push(`⚠ ${l} Feedback-Text nennt nur eine Lücke, obwohl der Versuch mehrere leere Lücken hat — nicht jede leere Lücke wird mit ihrer Nummer genannt. Bitte vor dem Eintragen ansehen.`),t.textContent=`✓ ${m.join(` und `)} auf ${p} Fragenseiten — bereit. `+h.join(` `),o&&a.length){let e=d(`div`,`ce-rechnung`);a.forEach(t=>{let n=d(`a`,`ce-logzeile ce-vorschauzeile`),r=R(t);r&&(n.href=r,n.target=`_blank`,n.rel=`noopener`),n.title=`Diesen Versuch in Moodle öffnen`,n.appendChild(d(`span`,`ce-vfrage`,t.frage)),n.appendChild(d(`span`,`ce-vans`,`„`+(t.antwort||`—`)+`"`)),n.appendChild(d(`span`,`ce-vpkt`,t.rechnung)),n.appendChild(d(`span`,`ce-vproz`,t.prozenttext||``)),e.appendChild(n)});let n=V.querySelector(`.ce-rechnung`);n&&n.remove(),t.after(e)}let g=V.querySelector(`.ce-fehlend`);if(g&&g.remove(),f.length){let e=d(`details`,`ce-fehlend`);e.appendChild(d(`summary`,`ce-fehlendkopf`,`${f.length} Versuch(e) ohne Feedback-Text — anzeigen`)),e.appendChild(d(`div`,`ce-logzeile`,`Für diese Versuche steht im eingefügten JSON kein Feedback. „Nachforderung kopieren" legt eine fertige Bitte an die KI in die Zwischenablage — im KI-Chat einfügen, das neue JSON hier einfügen, eintragen.`)),f.forEach(t=>{let n=d(`a`,`ce-logzeile`),r=R(t);r&&(n.href=r,n.target=`_blank`,n.rel=`noopener`);let i=(t.luecken||[]).map(e=>`L${e.nr}: ${String(e.antwort||``).trim()?`„`+e.antwort+`"`:`(leer)`}`).join(` · `);n.textContent=`${t.frage} — ${i}`,e.appendChild(n)});let n=d(`button`,`ce-nachfordern`,`📋 Nachforderung kopieren`);e.appendChild(n),n.addEventListener(`click`,async()=>{await We(Ge(f)),n.textContent=`✓ kopiert — im Chat einfügen`,setTimeout(()=>n.textContent=`📋 Nachforderung kopieren`,3e3)}),t.after(e)}if(k.feedbackVorher&&s.length){let e=d(`details`,`ce-fbliste`);e.open=!0,e.appendChild(d(`summary`,null,`${s.length} Feedback-Texte – vor dem Eintragen ansehen/ändern`)),s.forEach(t=>{e.appendChild(d(`div`,`ce-fbkopf`,t.frage));let n=d(`textarea`,`ce-fbtext`);n.rows=3,n.value=t.text||``,n.addEventListener(`input`,()=>{t.text=n.value}),e.appendChild(n)}),H(`.ce-schreibknoepfe`).before(e)}H(`.ce-zurueck`).classList.toggle(`ce-hidden`,!$),H(`.ce-schreibknoepfe`).classList.remove(`ce-hidden`),t.scrollIntoView({block:`nearest`})}catch(n){t.className=`ce-pinfo ce-error`,t.textContent=`Fehler: `+n.message,H(`.ce-zurueck`).classList.toggle(`ce-hidden`,!(e&&$))}}function $e(e){let t=String(e||``).replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen. Ist beim Kopieren versehentlich etwas anderes in der Zwischenablage gelandet?`);return JSON.parse(t)}let $=null,et=null;function tt(){[`.ce-pinfo`,`.ce-schreibknoepfe`,`.ce-abschluss`,`.ce-log`,`.ce-zurueck`].forEach(e=>H(e).classList.add(`ce-hidden`)),[`.ce-rechnung`,`.ce-fehlend`,`.ce-fbliste`].forEach(e=>{let t=V.querySelector(e);t&&t.remove()})}function nt(e,t,n){tt(),X=null,Z=null,et=e,$=n||g(J,e.bewertungen||[]);let r=H(`.ce-vorschau`);b(r,$,{titel:t,link:e=>R(e),onWeiter:e=>{r.classList.add(`ce-hidden`),Qe({...et,bewertungen:_(e)})}}),r.scrollIntoView({block:`nearest`})}H(`.ce-zurueck`).addEventListener(`click`,()=>{$&&nt(et,`erneut geöffnet`,$)}),H(`.ce-direkt`).addEventListener(`click`,async()=>{if(!J)return;let e=H(`.ce-direkt`),t=H(`.ce-direktinfo`),n=await Ce();e.disabled=!0,t.classList.remove(`ce-hidden`),t.textContent=`Starte …`;try{let e=await fe(h(J).daten,n,e=>{t.textContent=e}),r=[`${e.sekunden} s`];(e.tokens.ein||e.tokens.aus)&&r.push(`${e.tokens.ein+e.tokens.aus} Tokens`),t.textContent=`✓ KI fertig (${r.join(` · `)}).`+(e.fehler.length?` ⚠ `+e.fehler.join(` · `)+` – betroffene Fälle erscheinen als unklar.`:``),Ke(`eintrag`),H(`.ce-json`).value=``,nt({bewertungen:e.bewertungen,kommentare:e.kommentare},`KI direkt: ${n.modell}, ${r.join(` · `)}`+(e.fehler.length?` · ⚠ ${e.fehler.length} Paket(e) fehlgeschlagen`:``))}catch(e){t.textContent=`Fehler: `+e.message}finally{e.disabled=!1}}),H(`.ce-ohneki`).addEventListener(`click`,()=>{J&&(Ke(`eintrag`),nt({bewertungen:[]},`ohne KI`))});async function rt(e){if(!X&&!Z)return;let t=``;if(!e&&$){let e=await te($,{test:U.test,kurs:U.kurs,datum:new Date().toISOString().slice(0,10)});t=e.ok?`Fehlersammlung: ${e.neu} neu, ${e.geaendert} geändert, ${e.gesamt} insgesamt (Export unter ⚙).`:`⚠ Fehlersammlung konnte nicht gespeichert werden.`,G()}let n=H(`.ce-log`),r=H(`.ce-abschluss`);n.innerHTML=``,n.classList.remove(`ce-hidden`),r.classList.add(`ce-hidden`),H(`.ce-progress2`).classList.remove(`ce-hidden`),H(`.ce-alle`).disabled=!0,H(`.ce-progress2`).scrollIntoView({block:`nearest`});let i=(e,t)=>{let r=d(t?`a`:`div`,`ce-logzeile`,e);t&&(r.href=t,r.target=`_blank`,r.rel=`noopener`,r.title=`Diesen Versuch in Moodle öffnen`),(e.startsWith(`✗`)||e.startsWith(`⚠`))&&r.classList.add(`ce-logfehler`),n.appendChild(r),n.scrollTop=n.scrollHeight},a=(e,t)=>{H(`.ce-bar2`).style.width=Math.round(e/t*100)+`%`,H(`.ce-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let o=e?await Ae(X,Z,i,a):await je(X,Z,H(`.ce-ki`).checked,i,a),s=d(`div`,`ce-logkopf`,e?`${o.ok} Felder gefunden · ${o.fehler} fehlen · ${o.gruppen} Seiten geprüft`:`${o.ok} eingetragen und geprüft · ${o.fehler} fehlgeschlagen · ${o.gruppen} Seiten`);if(n.prepend(s),t&&s.after(d(`div`,`ce-logzeile`,t)),!o.ok&&!o.fehler&&i(`Nichts zu tun.`),r.classList.remove(`ce-hidden`),o.fehler>0)r.className=`ce-abschluss ce-abfehler`,r.textContent=e?`⚠ ${o.fehler} Feld/Felder fehlen auf der Bewertungsseite. Trag noch nichts ein — stammt das JSON zu diesem Auslese-Durchlauf?`:`⚠ ${o.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach und prüfe sie in Moodle, bevor du weitermachst.`;else if(r.className=`ce-abschluss ce-abok`,r.textContent=e?`✓ Alles vorhanden — ${o.ok} Felder auf ${o.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${o.ok} Einträge auf ${o.gruppen} Seiten, keine Fehler.`,!e){let e=3,t=setInterval(()=>{e--,r.textContent=`✓ Fertig — ${o.ok} Einträge auf ${o.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),V.classList.add(`ce-hidden`),r.textContent=`✓ Fertig — ${o.ok} Einträge auf ${o.gruppen} Seiten, keine Fehler.`)},1e3);V.addEventListener(`click`,()=>clearInterval(t),{once:!0})}r.scrollIntoView({block:`nearest`})}catch(e){i(`✗ Abbruch: `+e.message),r.classList.remove(`ce-hidden`),r.className=`ce-abschluss ce-abfehler`,r.textContent=`⚠ Abgebrochen: `+e.message}finally{H(`.ce-progress2`).classList.add(`ce-hidden`),H(`.ce-alle`).disabled=!1}}H(`.ce-alle`).addEventListener(`click`,()=>rt(!1)),H(`.ce-json`).addEventListener(`paste`,()=>setTimeout(()=>H(`.ce-pruef`).click(),0));let it=null;H(`.ce-json`).addEventListener(`input`,()=>{clearTimeout(it),it=setTimeout(()=>{H(`.ce-json`).value.trim()&&H(`.ce-pruef`).click()},800)})}var R=e({matches:[`*://*/*mod/quiz/report.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){Ee()}}),De={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},Oe=class e extends Event{static EVENT_NAME=z(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function z(e){return`${t?.runtime?.id}:content:${e}`}var ke=typeof globalThis.navigation?.addEventListener==`function`;function Ae(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),ke?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new Oe(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new Oe(e,t)),t=e)},1e3))}}}var je=class e{static SCRIPT_STARTED_MESSAGE_TYPE=z(`wxt:content-script-started`);id;abortController;locationWatcher=Ae(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?z(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),De.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Me={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=R;return await e(new je(`content`,t))}catch(e){throw Me.error(`The content script "content" crashed on startup!`,e),e}})()})();